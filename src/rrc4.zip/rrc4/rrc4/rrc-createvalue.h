/*****************************************************************************/
/* THIS SAMPLE PROGRAM IS PROVIDED AS IS. THE SAMPLE PROGRAM AND ANY RESULTS */
/* OBTAINED FROM IT ARE PROVIDED WITHOUT ANY WARRANTIES OR REPRESENTATIONS,  */
/* EXPRESS, IMPLIED OR STATUTORY.                                            */
/*****************************************************************************/

#include "rrc.h"

BCCH_BCH_Message *create_samplevalue_BCCH_BCH_Message();
BCCH_BCH_Message_MBMS *create_samplevalue_BCCH_BCH_Message_MBMS();
BCCH_DL_SCH_Message *create_samplevalue_BCCH_DL_SCH_Message();
BCCH_DL_SCH_Message_BR *create_samplevalue_BCCH_DL_SCH_Message_BR();
BCCH_DL_SCH_Message_MBMS *create_samplevalue_BCCH_DL_SCH_Message_MBMS();
MCCH_Message *create_samplevalue_MCCH_Message();
PCCH_Message *create_samplevalue_PCCH_Message();
DL_CCCH_Message *create_samplevalue_DL_CCCH_Message();
UL_CCCH_Message *create_samplevalue_UL_CCCH_Message();
UL_DCCH_Message *create_samplevalue_UL_DCCH_Message();
SC_MCCH_Message_r13 *create_samplevalue_SC_MCCH_Message_r13();
SPS_ConfigDL_STTI_r15 *create_samplevalue_SPS_ConfigDL_STTI_r15();
UE_EUTRA_Capability *create_samplevalue_UE_EUTRA_Capability();
SBCCH_SL_BCH_Message *create_samplevalue_SBCCH_SL_BCH_Message();
SBCCH_SL_BCH_Message_V2X_r14 *create_samplevalue_SBCCH_SL_BCH_Message_V2X_r14();
BCCH_BCH_Message_NB *create_samplevalue_BCCH_BCH_Message_NB();
BCCH_BCH_Message_TDD_NB *create_samplevalue_BCCH_BCH_Message_TDD_NB();
BCCH_DL_SCH_Message_NB *create_samplevalue_BCCH_DL_SCH_Message_NB();
PCCH_Message_NB *create_samplevalue_PCCH_Message_NB();
DL_CCCH_Message_NB *create_samplevalue_DL_CCCH_Message_NB();
DL_DCCH_Message_NB *create_samplevalue_DL_DCCH_Message_NB();
UL_CCCH_Message_NB *create_samplevalue_UL_CCCH_Message_NB();
SC_MCCH_Message_NB *create_samplevalue_SC_MCCH_Message_NB();
UL_DCCH_Message_NB *create_samplevalue_UL_DCCH_Message_NB();
VarConnEstFailReport_r11 *create_samplevalue_VarConnEstFailReport_r11();
VarLogMeasConfig_r10 *create_samplevalue_VarLogMeasConfig_r10();
VarLogMeasConfig_r11 *create_samplevalue_VarLogMeasConfig_r11();
VarLogMeasConfig_r12 *create_samplevalue_VarLogMeasConfig_r12();
VarLogMeasConfig_r15 *create_samplevalue_VarLogMeasConfig_r15();
VarLogMeasReport_r10 *create_samplevalue_VarLogMeasReport_r10();
VarLogMeasReport_r11 *create_samplevalue_VarLogMeasReport_r11();
VarMeasConfig *create_samplevalue_VarMeasConfig();
VarMeasIdleConfig_r15 *create_samplevalue_VarMeasIdleConfig_r15();
VarMeasIdleReport_r15 *create_samplevalue_VarMeasIdleReport_r15();
VarMeasReportList *create_samplevalue_VarMeasReportList();
VarMeasReportList_r12 *create_samplevalue_VarMeasReportList_r12();
VarMobilityHistoryReport_r12 *create_samplevalue_VarMobilityHistoryReport_r12();
VarPendingRnaProcedure_r15 *create_samplevalue_VarPendingRnaProcedure_r15();
VarRLF_Report_r10 *create_samplevalue_VarRLF_Report_r10();
VarRLF_Report_r11 *create_samplevalue_VarRLF_Report_r11();
VarShortINACTIVE_MAC_Input_r15 *create_samplevalue_VarShortINACTIVE_MAC_Input_r15();
VarWLAN_MobilityConfig *create_samplevalue_VarWLAN_MobilityConfig();
VarWLAN_Status_r13 *create_samplevalue_VarWLAN_Status_r13();
VarShortMAC_Input_NB_r13 *create_samplevalue_VarShortMAC_Input_NB_r13();
VarShortResumeMAC_Input_NB_r13 *create_samplevalue_VarShortResumeMAC_Input_NB_r13();
SL_Preconfiguration_r12 *create_samplevalue_SL_Preconfiguration_r12();
SL_V2X_Preconfiguration_r14 *create_samplevalue_SL_V2X_Preconfiguration_r14();
HandoverCommand *create_samplevalue_HandoverCommand();
HandoverPreparationInformation *create_samplevalue_HandoverPreparationInformation();
HandoverPreparationInformation_v1530_IEs *create_samplevalue_HandoverPreparationInformation_v1530_IEs();
SCG_ConfigInfo_r12 *create_samplevalue_SCG_ConfigInfo_r12();
UEPagingCoverageInformation *create_samplevalue_UEPagingCoverageInformation();
UERadioAccessCapabilityInformation *create_samplevalue_UERadioAccessCapabilityInformation();
UERadioPagingInformation *create_samplevalue_UERadioPagingInformation();
HandoverPreparationInformation_NB *create_samplevalue_HandoverPreparationInformation_NB();
UEPagingCoverageInformation_NB *create_samplevalue_UEPagingCoverageInformation_NB();
UERadioAccessCapabilityInformation_NB *create_samplevalue_UERadioAccessCapabilityInformation_NB();
UERadioPagingInformation_NB *create_samplevalue_UERadioPagingInformation_NB();
