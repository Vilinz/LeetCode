/*****************************************************************************/
/* THIS SAMPLE PROGRAM IS PROVIDED AS IS. THE SAMPLE PROGRAM AND ANY RESULTS */
/* OBTAINED FROM IT ARE PROVIDED WITHOUT ANY WARRANTIES OR REPRESENTATIONS,  */
/* EXPRESS, IMPLIED OR STATUTORY.                                            */
/*****************************************************************************/


//cppsoedmd.lib;cppsoedmt.lib;cpptoedmd.lib;osscppmd.lib;
#include "rrc-createvalue.h"
#include "rrc-printvalue.h"

/* Sample exception class to report ASN.1/C++ errors */
class ASN1Exception {
private:
    int code;
public:
    ASN1Exception(int asn1_code);
    ASN1Exception(const ASN1Exception & that);
    int get_code() const;
};

ASN1Exception::ASN1Exception(int asn1_code)
{
    code = asn1_code;
}

ASN1Exception::ASN1Exception(const ASN1Exception & that)
{
    code = that.code;
}

int ASN1Exception::get_code() const
{
    return code;
}

/*
 * The ASN.1/C++ error reporting function.
 */

void throw_error(int code)
{
    throw ASN1Exception(code);
}

int main(void)
{
    int retcode=0;
    const char *errmsg;

    /* Handle ASN.1/C++ runtime errors with C++ exceptions */
    asn1_set_error_handling(throw_error, TRUE);

    try {
	rrc_Control ctl;
	/* Set flags */
	ctl.setEncodingFlags(ctl.getEncodingFlags() | AUTOMATIC_ENCDEC | OSS_TRAPPING);

	ctl.setDecodingFlags(ctl.getDecodingFlags() | AUTOMATIC_ENCDEC | OSS_TRAPPING);

	/* Enable skipping fields that are equal to their default values. */
	ctl.setEncodingFlags(ctl.getEncodingFlags() | STRICT_PER_ENCODING_OF_DEFAULT_VALUES);

	/* Set the encoding rules */
	ctl.setEncodingRules(OSS_PER_UNALIGNED);

	/* To avoid printing the resulted encoded value, comment out the following line. */
	ctl.setDebugFlags(ctl.getDebugFlags() | PRINT_ENCODER_OUTPUT);

	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_BCCH_BCH_Message'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_BCCH_BCH_Message' value */
	    BCCH_BCH_Message *value = create_samplevalue_BCCH_BCH_Message();
	    BCCH_BCH_Message_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_BCCH_BCH_Message(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_BCCH_BCH_Message(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_BCCH_BCH_Message_MBMS'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_BCCH_BCH_Message_MBMS' value */
	    BCCH_BCH_Message_MBMS *value = create_samplevalue_BCCH_BCH_Message_MBMS();
	    BCCH_BCH_Message_MBMS_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_BCCH_BCH_Message_MBMS(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_BCCH_BCH_Message_MBMS(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_BCCH_DL_SCH_Message'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_BCCH_DL_SCH_Message' value */
	    BCCH_DL_SCH_Message *value = create_samplevalue_BCCH_DL_SCH_Message();
	    BCCH_DL_SCH_Message_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_BCCH_DL_SCH_Message(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_BCCH_DL_SCH_Message(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_BCCH_DL_SCH_Message_BR'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_BCCH_DL_SCH_Message_BR' value */
	    BCCH_DL_SCH_Message_BR *value = create_samplevalue_BCCH_DL_SCH_Message_BR();
	    BCCH_DL_SCH_Message_BR_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_BCCH_DL_SCH_Message_BR(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_BCCH_DL_SCH_Message_BR(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_BCCH_DL_SCH_Message_MBMS'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_BCCH_DL_SCH_Message_MBMS' value */
	    BCCH_DL_SCH_Message_MBMS *value = create_samplevalue_BCCH_DL_SCH_Message_MBMS();
	    BCCH_DL_SCH_Message_MBMS_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_BCCH_DL_SCH_Message_MBMS(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_BCCH_DL_SCH_Message_MBMS(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_MCCH_Message'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_MCCH_Message' value */
	    MCCH_Message *value = create_samplevalue_MCCH_Message();
	    MCCH_Message_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_MCCH_Message(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_MCCH_Message(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_PCCH_Message'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_PCCH_Message' value */
	    PCCH_Message *value = create_samplevalue_PCCH_Message();
	    PCCH_Message_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_PCCH_Message(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_PCCH_Message(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_DL_CCCH_Message'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_DL_CCCH_Message' value */
	    DL_CCCH_Message *value = create_samplevalue_DL_CCCH_Message();
	    DL_CCCH_Message_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_DL_CCCH_Message(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_DL_CCCH_Message(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UL_CCCH_Message'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UL_CCCH_Message' value */
	    UL_CCCH_Message *value = create_samplevalue_UL_CCCH_Message();
	    UL_CCCH_Message_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UL_CCCH_Message(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UL_CCCH_Message(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UL_DCCH_Message'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UL_DCCH_Message' value */
	    UL_DCCH_Message *value = create_samplevalue_UL_DCCH_Message();
	    UL_DCCH_Message_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UL_DCCH_Message(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UL_DCCH_Message(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_SC_MCCH_Message_r13'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_SC_MCCH_Message_r13' value */
	    SC_MCCH_Message_r13 *value = create_samplevalue_SC_MCCH_Message_r13();
	    SC_MCCH_Message_r13_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_SC_MCCH_Message_r13(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_SC_MCCH_Message_r13(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_SPS_ConfigDL_STTI_r15'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_SPS_ConfigDL_STTI_r15' value */
	    SPS_ConfigDL_STTI_r15 *value = create_samplevalue_SPS_ConfigDL_STTI_r15();
	    SPS_ConfigDL_STTI_r15_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_SPS_ConfigDL_STTI_r15(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_SPS_ConfigDL_STTI_r15(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UE_EUTRA_Capability'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UE_EUTRA_Capability' value */
	    UE_EUTRA_Capability *value = create_samplevalue_UE_EUTRA_Capability();
	    UE_EUTRA_Capability_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UE_EUTRA_Capability(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UE_EUTRA_Capability(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_SBCCH_SL_BCH_Message'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_SBCCH_SL_BCH_Message' value */
	    SBCCH_SL_BCH_Message *value = create_samplevalue_SBCCH_SL_BCH_Message();
	    SBCCH_SL_BCH_Message_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_SBCCH_SL_BCH_Message(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_SBCCH_SL_BCH_Message(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_SBCCH_SL_BCH_Message_V2X_r14'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_SBCCH_SL_BCH_Message_V2X_r14' value */
	    SBCCH_SL_BCH_Message_V2X_r14 *value = create_samplevalue_SBCCH_SL_BCH_Message_V2X_r14();
	    SBCCH_SL_BCH_Message_V2X_r14_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_SBCCH_SL_BCH_Message_V2X_r14(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_SBCCH_SL_BCH_Message_V2X_r14(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_BCCH_BCH_Message_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_BCCH_BCH_Message_NB' value */
	    BCCH_BCH_Message_NB *value = create_samplevalue_BCCH_BCH_Message_NB();
	    BCCH_BCH_Message_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_BCCH_BCH_Message_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_BCCH_BCH_Message_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_BCCH_BCH_Message_TDD_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_BCCH_BCH_Message_TDD_NB' value */
	    BCCH_BCH_Message_TDD_NB *value = create_samplevalue_BCCH_BCH_Message_TDD_NB();
	    BCCH_BCH_Message_TDD_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_BCCH_BCH_Message_TDD_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_BCCH_BCH_Message_TDD_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_BCCH_DL_SCH_Message_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_BCCH_DL_SCH_Message_NB' value */
	    BCCH_DL_SCH_Message_NB *value = create_samplevalue_BCCH_DL_SCH_Message_NB();
	    BCCH_DL_SCH_Message_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_BCCH_DL_SCH_Message_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_BCCH_DL_SCH_Message_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_PCCH_Message_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_PCCH_Message_NB' value */
	    PCCH_Message_NB *value = create_samplevalue_PCCH_Message_NB();
	    PCCH_Message_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_PCCH_Message_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_PCCH_Message_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_DL_CCCH_Message_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_DL_CCCH_Message_NB' value */
	    DL_CCCH_Message_NB *value = create_samplevalue_DL_CCCH_Message_NB();
	    DL_CCCH_Message_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_DL_CCCH_Message_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_DL_CCCH_Message_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_DL_DCCH_Message_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_DL_DCCH_Message_NB' value */
	    DL_DCCH_Message_NB *value = create_samplevalue_DL_DCCH_Message_NB();
	    DL_DCCH_Message_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_DL_DCCH_Message_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_DL_DCCH_Message_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UL_CCCH_Message_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UL_CCCH_Message_NB' value */
	    UL_CCCH_Message_NB *value = create_samplevalue_UL_CCCH_Message_NB();
	    UL_CCCH_Message_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UL_CCCH_Message_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UL_CCCH_Message_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_SC_MCCH_Message_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_SC_MCCH_Message_NB' value */
	    SC_MCCH_Message_NB *value = create_samplevalue_SC_MCCH_Message_NB();
	    SC_MCCH_Message_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_SC_MCCH_Message_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_SC_MCCH_Message_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UL_DCCH_Message_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UL_DCCH_Message_NB' value */
	    UL_DCCH_Message_NB *value = create_samplevalue_UL_DCCH_Message_NB();
	    UL_DCCH_Message_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UL_DCCH_Message_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UL_DCCH_Message_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarConnEstFailReport_r11'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarConnEstFailReport_r11' value */
	    VarConnEstFailReport_r11 *value = create_samplevalue_VarConnEstFailReport_r11();
	    VarConnEstFailReport_r11_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarConnEstFailReport_r11(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarConnEstFailReport_r11(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarLogMeasConfig_r10'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarLogMeasConfig_r10' value */
	    VarLogMeasConfig_r10 *value = create_samplevalue_VarLogMeasConfig_r10();
	    VarLogMeasConfig_r10_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarLogMeasConfig_r10(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarLogMeasConfig_r10(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarLogMeasConfig_r11'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarLogMeasConfig_r11' value */
	    VarLogMeasConfig_r11 *value = create_samplevalue_VarLogMeasConfig_r11();
	    VarLogMeasConfig_r11_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarLogMeasConfig_r11(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarLogMeasConfig_r11(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarLogMeasConfig_r12'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarLogMeasConfig_r12' value */
	    VarLogMeasConfig_r12 *value = create_samplevalue_VarLogMeasConfig_r12();
	    VarLogMeasConfig_r12_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarLogMeasConfig_r12(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarLogMeasConfig_r12(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarLogMeasConfig_r15'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarLogMeasConfig_r15' value */
	    VarLogMeasConfig_r15 *value = create_samplevalue_VarLogMeasConfig_r15();
	    VarLogMeasConfig_r15_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarLogMeasConfig_r15(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarLogMeasConfig_r15(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarLogMeasReport_r10'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarLogMeasReport_r10' value */
	    VarLogMeasReport_r10 *value = create_samplevalue_VarLogMeasReport_r10();
	    VarLogMeasReport_r10_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarLogMeasReport_r10(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarLogMeasReport_r10(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarLogMeasReport_r11'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarLogMeasReport_r11' value */
	    VarLogMeasReport_r11 *value = create_samplevalue_VarLogMeasReport_r11();
	    VarLogMeasReport_r11_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarLogMeasReport_r11(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarLogMeasReport_r11(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarMeasConfig'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarMeasConfig' value */
	    VarMeasConfig *value = create_samplevalue_VarMeasConfig();
	    VarMeasConfig_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarMeasConfig(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarMeasConfig(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarMeasIdleConfig_r15'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarMeasIdleConfig_r15' value */
	    VarMeasIdleConfig_r15 *value = create_samplevalue_VarMeasIdleConfig_r15();
	    VarMeasIdleConfig_r15_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarMeasIdleConfig_r15(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarMeasIdleConfig_r15(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarMeasIdleReport_r15'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarMeasIdleReport_r15' value */
	    VarMeasIdleReport_r15 *value = create_samplevalue_VarMeasIdleReport_r15();
	    VarMeasIdleReport_r15_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarMeasIdleReport_r15(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarMeasIdleReport_r15(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarMeasReportList'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarMeasReportList' value */
	    VarMeasReportList *value = create_samplevalue_VarMeasReportList();
	    VarMeasReportList_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarMeasReportList(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarMeasReportList(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarMeasReportList_r12'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarMeasReportList_r12' value */
	    VarMeasReportList_r12 *value = create_samplevalue_VarMeasReportList_r12();
	    VarMeasReportList_r12_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarMeasReportList_r12(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarMeasReportList_r12(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarMobilityHistoryReport_r12'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarMobilityHistoryReport_r12' value */
	    VarMobilityHistoryReport_r12 *value = create_samplevalue_VarMobilityHistoryReport_r12();
	    VarMobilityHistoryReport_r12_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarMobilityHistoryReport_r12(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarMobilityHistoryReport_r12(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarPendingRnaProcedure_r15'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarPendingRnaProcedure_r15' value */
	    VarPendingRnaProcedure_r15 *value = create_samplevalue_VarPendingRnaProcedure_r15();
	    VarPendingRnaProcedure_r15_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarPendingRnaProcedure_r15(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarPendingRnaProcedure_r15(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarRLF_Report_r10'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarRLF_Report_r10' value */
	    VarRLF_Report_r10 *value = create_samplevalue_VarRLF_Report_r10();
	    VarRLF_Report_r10_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarRLF_Report_r10(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarRLF_Report_r10(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarRLF_Report_r11'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarRLF_Report_r11' value */
	    VarRLF_Report_r11 *value = create_samplevalue_VarRLF_Report_r11();
	    VarRLF_Report_r11_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarRLF_Report_r11(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarRLF_Report_r11(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarShortINACTIVE_MAC_Input_r15'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarShortINACTIVE_MAC_Input_r15' value */
	    VarShortINACTIVE_MAC_Input_r15 *value = create_samplevalue_VarShortINACTIVE_MAC_Input_r15();
	    VarShortINACTIVE_MAC_Input_r15_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarShortINACTIVE_MAC_Input_r15(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarShortINACTIVE_MAC_Input_r15(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarWLAN_MobilityConfig'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarWLAN_MobilityConfig' value */
	    VarWLAN_MobilityConfig *value = create_samplevalue_VarWLAN_MobilityConfig();
	    VarWLAN_MobilityConfig_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarWLAN_MobilityConfig(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarWLAN_MobilityConfig(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarWLAN_Status_r13'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarWLAN_Status_r13' value */
	    VarWLAN_Status_r13 *value = create_samplevalue_VarWLAN_Status_r13();
	    VarWLAN_Status_r13_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarWLAN_Status_r13(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarWLAN_Status_r13(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarShortMAC_Input_NB_r13'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarShortMAC_Input_NB_r13' value */
	    VarShortMAC_Input_NB_r13 *value = create_samplevalue_VarShortMAC_Input_NB_r13();
	    VarShortMAC_Input_NB_r13_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarShortMAC_Input_NB_r13(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarShortMAC_Input_NB_r13(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_VarShortResumeMAC_Input_NB_r13'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_VarShortResumeMAC_Input_NB_r13' value */
	    VarShortResumeMAC_Input_NB_r13 *value = create_samplevalue_VarShortResumeMAC_Input_NB_r13();
	    VarShortResumeMAC_Input_NB_r13_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_VarShortResumeMAC_Input_NB_r13(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_VarShortResumeMAC_Input_NB_r13(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_SL_Preconfiguration_r12'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_SL_Preconfiguration_r12' value */
	    SL_Preconfiguration_r12 *value = create_samplevalue_SL_Preconfiguration_r12();
	    SL_Preconfiguration_r12_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_SL_Preconfiguration_r12(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_SL_Preconfiguration_r12(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_SL_V2X_Preconfiguration_r14'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_SL_V2X_Preconfiguration_r14' value */
	    SL_V2X_Preconfiguration_r14 *value = create_samplevalue_SL_V2X_Preconfiguration_r14();
	    SL_V2X_Preconfiguration_r14_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_SL_V2X_Preconfiguration_r14(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_SL_V2X_Preconfiguration_r14(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_HandoverCommand'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_HandoverCommand' value */
	    HandoverCommand *value = create_samplevalue_HandoverCommand();
	    HandoverCommand_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_HandoverCommand(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_HandoverCommand(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_HandoverPreparationInformation'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_HandoverPreparationInformation' value */
	    HandoverPreparationInformation *value = create_samplevalue_HandoverPreparationInformation();
	    HandoverPreparationInformation_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_HandoverPreparationInformation(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_HandoverPreparationInformation(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_HandoverPreparationInformation_v1530_IEs'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_HandoverPreparationInformation_v1530_IEs' value */
	    HandoverPreparationInformation_v1530_IEs *value = create_samplevalue_HandoverPreparationInformation_v1530_IEs();
	    HandoverPreparationInformation_v1530_IEs_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_HandoverPreparationInformation_v1530_IEs(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_HandoverPreparationInformation_v1530_IEs(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_SCG_ConfigInfo_r12'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_SCG_ConfigInfo_r12' value */
	    SCG_ConfigInfo_r12 *value = create_samplevalue_SCG_ConfigInfo_r12();
	    SCG_ConfigInfo_r12_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_SCG_ConfigInfo_r12(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_SCG_ConfigInfo_r12(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UEPagingCoverageInformation'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UEPagingCoverageInformation' value */
	    UEPagingCoverageInformation *value = create_samplevalue_UEPagingCoverageInformation();
	    UEPagingCoverageInformation_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UEPagingCoverageInformation(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UEPagingCoverageInformation(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UERadioAccessCapabilityInformation'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UERadioAccessCapabilityInformation' value */
	    UERadioAccessCapabilityInformation *value = create_samplevalue_UERadioAccessCapabilityInformation();
	    UERadioAccessCapabilityInformation_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UERadioAccessCapabilityInformation(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UERadioAccessCapabilityInformation(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UERadioPagingInformation'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UERadioPagingInformation' value */
	    UERadioPagingInformation *value = create_samplevalue_UERadioPagingInformation();
	    UERadioPagingInformation_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UERadioPagingInformation(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UERadioPagingInformation(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_HandoverPreparationInformation_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_HandoverPreparationInformation_NB' value */
	    HandoverPreparationInformation_NB *value = create_samplevalue_HandoverPreparationInformation_NB();
	    HandoverPreparationInformation_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_HandoverPreparationInformation_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_HandoverPreparationInformation_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UEPagingCoverageInformation_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UEPagingCoverageInformation_NB' value */
	    UEPagingCoverageInformation_NB *value = create_samplevalue_UEPagingCoverageInformation_NB();
	    UEPagingCoverageInformation_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UEPagingCoverageInformation_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UEPagingCoverageInformation_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UERadioAccessCapabilityInformation_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UERadioAccessCapabilityInformation_NB' value */
	    UERadioAccessCapabilityInformation_NB *value = create_samplevalue_UERadioAccessCapabilityInformation_NB();
	    UERadioAccessCapabilityInformation_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UERadioAccessCapabilityInformation_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UERadioAccessCapabilityInformation_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
	printf("=====================================================================\n");
	printf("Demonstration of procedures with the value 'samplevalue_UERadioPagingInformation_NB'\n");
	printf("=====================================================================\n");

	try {
	    /* Create the 'samplevalue_UERadioPagingInformation_NB' value */
	    UERadioPagingInformation_NB *value = create_samplevalue_UERadioPagingInformation_NB();
	    UERadioPagingInformation_NB_PDU pdu;

	    /* Print the value */
	    printf("\nThe encoder input value:\n\n");
	    print_UERadioPagingInformation_NB(*value);
	    printf("\n");

	    /* Encode the value */
	    EncodedBuffer encodedData;
	    pdu.set_data(*value);
	    pdu.encode(ctl, encodedData);

	    /* Free memory had been allocated for the value */
	    delete value;

	    /* Decode the PDU */
	    pdu.decode(ctl, encodedData);

	    /* Traverse the decoded value and print its contents */
	    printf("\nThe decoder output:\n\n");
	    value = pdu.get_data();
	    print_UERadioPagingInformation_NB(*value);

	    /* Free memory allocated for the decoded value */
	    delete value;

	} catch (ASN1Exception &exc) {
	    retcode = exc.get_code();
	    printf("An error occurred: code = %d.\n", retcode);
	    errmsg = ctl.getErrorMsg();
	    if (errmsg)
		printf("%s", errmsg);
	}

	printf("\n");
    } catch (ASN1Exception &exc) {
	retcode = exc.get_code();
	printf("An initialization error occurred: code = %d.\n", retcode);
    }

    printf("Sample application finished.\n");
    return retcode;
}
