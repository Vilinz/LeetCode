/*****************************************************************************/
/* Copyright (C) 2019 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.,                   */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/* File: @(#)cppopt.h	17.1  13/12/19                                       */
/*                                                                           */

#ifndef __CPPOPT_H
#define __CPPOPT_H

#ifndef EXCEPTIONS_SUPPORTED
#define EXCEPTIONS_SUPPORTED 1
#endif

/* Features supported by the current version */
#define OSS_PREALLOCATED_BUFFER_DECODE_SUPPORTED

#endif /* __CPPOPT_H */
