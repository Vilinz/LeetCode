/*****************************************************************************/
/* Copyright (C) 2019 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.,                   */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/* File: @(#)asn1.h	17.16 18/10/04                                       */
/*                                                                           */
/** @file
 *  @brief  Declarations of ASN.1/C++ Runtime classes.
 */

#ifndef __ASN1_H
#define __ASN1_H

#ifdef USE_MD_LIB
#define ONE_DLL
#endif

#if defined(CPP_TOED_SOURCECODE_SHIPPING)
#if !defined(CPP_TOED_SOURCECODE_SHIPPING)
#include "environ.h"
/*
 * OSS_SOED_* defines below are needed only for application building with
 * development headers, tools building and application building with shipment
 * headers do not need them
 */

#define OSS_SOED_BER
#define OSS_SOED_PER
#define OSS_SOED_XER
#define OSS_SOED_EXER
#else
#ifdef OSS_BUILD
#include "config.h"
#endif
#endif
#define OSS_TOED_EXER
#define OSS_TOED_OER
#endif
#include "osstype.h"
#include "asn1mem.h"

#define OSS_USE_SOED_AND_LED

#if !defined(_WIN32)
    typedef int SOCKET;
#else
#include <winsock.h>
#endif

/* forward definitions */
class OSS_DECLSPEC OssControl;
class OSS_DECLSPEC EncodedData;
class OSS_DECLSPEC EncodedBuffer;
#ifndef CPP_TOED_SOURCECODE_SHIPPING
class OSS_DECLSPEC OssCompressor;
#endif
/* an internal index type - each generated ASN.1 type has its own type index */
typedef unsigned short OssTypeIndex;

/* ASN.1/C++ coding classes */

/* a coding class without encoding/decoding capablities */
class OSS_DECLSPEC ASN1Handle
{
friend class OssOpen;
friend class UniversalPDU;
protected:
    void *data;
    int constant;
    ASN1Handle();
    void do_set_data(void *d);
public:
    int print(OssControl &ctl) const;
    char *toString(OssControl &ctl, char *buffer = NULL,
	    unsigned long length = 0) const;
    unsigned long toStringLength(OssControl &ctl) const;
    int check_constraints(OssControl &ctl) const;
    int setFromValueNotation(OssControl &ctl, const char *valnot);
    char *asValueNotation(OssControl &ctl) const;
    void release_data();
    virtual int copy(OssControl &, const ASN1Handle &);
    int equals(OssControl &, const ASN1Handle &) const;
    int free_data(OssControl &);
    virtual ~ASN1Handle();
    void *get_raw_data();
    int is_constant() const;
    virtual OssTypeIndex get_index() const = 0;
};

/* a enumeration that lists all supported encoding rules */
typedef ossEncodingRules OssEncodingRules;

/* a coding class with full encoding/decoding capabilities */
class OSS_DECLSPEC PDU: public ASN1Handle
{
friend class OssOpen;
friend class OssConstrainedOpenType;
protected:
    virtual int is_universal() const = 0;
    virtual int do_set_data(void *, OssTypeIndex, int c) = 0;    
public:
    int encode(OssControl &ctl, EncodedData &buf) const;
    virtual int decode(OssControl &ctl, EncodedData &buf) = 0;
    virtual int decode(OssControl &ctl, EncodedData &input,
	    EncodedBuffer &output);
    long determineEncodingLength(OssControl &ctl) const;
    int binary2XML(OssControl &ctl, OssEncodingRules rule, EncodedData &from, EncodedData &to);
    int XML2Binary(OssControl &ctl, OssEncodingRules rule, EncodedData &from, EncodedData &to);
    int binary2JSON(OssControl &ctl, OssEncodingRules rule, EncodedData &from, EncodedData &to);
    int JSON2Binary(OssControl &ctl, OssEncodingRules rule, EncodedData &from, EncodedData &to);
    int convertData(OssControl &ctl, EncodedBuffer &fromData, unsigned int fromFormat,
		    EncodedBuffer &toData, unsigned int toFormat);
};

/* a class used as an interface by ConcretePDU::partialDecode */
class OSS_DECLSPEC OssCallback
{
public:
    void * userVar;
};

/* a coding class representing a given PDU type */
class OSS_DECLSPEC ConcretePDU: public PDU
{
protected:
    int is_universal() const;
    int do_set_data(void *, OssTypeIndex, int);
public:
    int decode(OssControl &ctl, EncodedData &buf);
    int decode(OssControl &ctl, EncodedData &input, EncodedBuffer &output);
    int partialDecode(OssControl &ctl, EncodedData &buf, OssCallback &callback);
    int partialDecode(OssControl &ctl, EncodedData &buf, OssCallback &callback,  EncodedBuffer &dst);
};

/* a coding class that can hold any PDU type from the given specification */
class OSS_DECLSPEC UniversalPDU: public PDU
{
protected:
    int index;
    UniversalPDU();
    int is_universal() const;
    int do_set_data(void *, OssTypeIndex, int);
public:
    int decode(OssControl &ctl, EncodedData &buf);
    int decode(OssControl &ctl, EncodedData &input, EncodedBuffer &output);
    int copy(OssControl &, const ASN1Handle &);
    OssTypeIndex get_index() const;
};

/* ASN.1/C++ representation classes */

/* ASN.1 NULL type */
typedef char Nulltype;

/* ASN.1 BOOLEAN type */
typedef char ossBoolean;

/* ASN.1 restricted character set string types using single-byte characters */
/* this class is also used for ASN.1 OCTET STRING type */
class OSS_DECLSPEC OssString
{
private:
    OSS_UINT32 size;
    char *value;
public:
    OssString();
    OssString(const OssString &);
    OssString & operator = (const OssString &);
    ~OssString();
    int operator == (const OssString &) const;
    int operator != (const OssString &) const;
    void *operator new(size_t);
    void operator delete(void *);
    OssString(const char *);
    OssString(OSS_UINT32 length, const char *);
    OSS_UINT32 length() const;
    char *get_buffer();
    const char *get_buffer() const;
    void resize(OSS_UINT32);
    void set(const char *);
    void set(OSS_UINT32 length, const char *);
    /* ownership-transferring functions */
    char *release_buffer(OSS_UINT32 & length);
    void grab(OSS_UINT32 length, char *);
    /* higher level functions */
    char & operator [] (OSS_UINT32 pos);
    const char & operator [] (OSS_UINT32 pos) const;
    char elem(OSS_UINT32 pos);
    OssString & operator += (const OssString &);
    OssString & operator += (const char *);
};

/* an auxiliary type for ASN.1 BIT STRING type that provides access to an */
/* individual bit in the BIT STRING */
class OSS_DECLSPEC OssBit
{
friend class OssBitString;
private:
    unsigned char *byte;
    char bitpos;
    OssBit(unsigned char *, char);
public:
    OssBit(const OssBit &);
    ~OssBit();
    operator int() const;
    OssBit & operator = (int);
};

/* ASN.1 BIT STRING type */
class OSS_DECLSPEC OssBitString
{
private:
    OSS_UINT32 size;
    unsigned char *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssBitString();
    OssBitString(const OssBitString &);
    OssBitString & operator = (const OssBitString &);
    ~OssBitString();
    int operator == (const OssBitString &) const;
    int operator != (const OssBitString &) const;
    OssBitString(OSS_UINT32 length, const unsigned char *);
    OSS_UINT32 length() const;
    unsigned char *get_buffer();
    const unsigned char *get_buffer() const;
    void resize(OSS_UINT32);
    void set(OSS_UINT32 length, const unsigned char *);
    /* ownership-transferring functions */
    unsigned char *release_buffer(OSS_UINT32 & length);
    void grab(OSS_UINT32 length, unsigned char *);
    /* higher level functions */
    void set(OSS_UINT32 pos);
    void clear(OSS_UINT32 pos);
    void invert(OSS_UINT32 pos);
    void set(OSS_UINT32 pos, OSS_UINT32 length);
    void clear(OSS_UINT32 pos, OSS_UINT32 length);
    void invert(OSS_UINT32 pos, OSS_UINT32 length);
    void assign(OSS_UINT32 pos, int bit);
    int test(OSS_UINT32 pos) const;
    OssBit operator [] (OSS_UINT32 pos);
    const OssBit operator [] (OSS_UINT32 pos) const;
};

/* a 16-bit character type for BMPString representation */
typedef unsigned short OSS_CHAR16;

/* a 32-bit character type for UniversalString representation */
typedef OSS_UINT32 OSS_CHAR32;

/* ASN.1 BMPString type */
class OSS_DECLSPEC OssBMPString
{
private:
    OSS_UINT32 size;
    OSS_CHAR16 *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssBMPString();
    OssBMPString(const OssBMPString &);
    OssBMPString & operator = (const OssBMPString &);
    ~OssBMPString();
    int operator == (const OssBMPString &) const;
    int operator != (const OssBMPString &) const;
    OssBMPString(OSS_UINT32 length, const OSS_CHAR16 *);
    OSS_UINT32 length() const;
    OSS_CHAR16 *get_buffer();
    const OSS_CHAR16 *get_buffer() const;
    void resize(OSS_UINT32);
    void set(OSS_UINT32 length, const OSS_CHAR16 *);
    /* ownership-transferring functions */
    OSS_CHAR16 *release_buffer(OSS_UINT32 & length);
    void grab(OSS_UINT32 length, OSS_CHAR16 *);
    /* higher level functions */
    OSS_CHAR16 & operator [] (OSS_UINT32 pos);
    const OSS_CHAR16 & operator [] (OSS_UINT32 pos) const;
    OSS_CHAR16 elem(OSS_UINT32 pos);
    OssBMPString & operator += (const OssBMPString &);
};

/* ASN.1 UniversalString type */
class OSS_DECLSPEC OssUniversalString
{
private:
    OSS_UINT32 size;
    OSS_CHAR32 *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssUniversalString();
    OssUniversalString(const OssUniversalString &);
    OssUniversalString & operator = (const OssUniversalString &);
    ~OssUniversalString();
    int operator == (const OssUniversalString &) const;
    int operator != (const OssUniversalString &) const;
    OssUniversalString(OSS_UINT32 length, const OSS_CHAR32 *);
    OSS_UINT32 length() const;
    OSS_CHAR32 *get_buffer();
    const OSS_CHAR32 *get_buffer() const;
    void resize(OSS_UINT32);
    void set(OSS_UINT32 length, const OSS_CHAR32 *);
    /* ownership-transferring functions */
    OSS_CHAR32 *release_buffer(OSS_UINT32 & length);
    void grab(OSS_UINT32 length, OSS_CHAR32 *);
    /* higher level functions */
    OSS_CHAR32 & operator [] (OSS_UINT32 pos);
    const OSS_CHAR32 & operator [] (OSS_UINT32 pos) const;
    OSS_CHAR32 elem(OSS_UINT32 pos);
    OssUniversalString & operator += (const OssUniversalString &);
};

/* ASN.1 OBJECT IDENTIFIER type */
class OSS_DECLSPEC OssEncOID
{
private:
    OSS_UINT32 size;
    unsigned char *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssEncOID();
    OssEncOID(const OssEncOID &);
    OssEncOID & operator = (const OssEncOID &);
    ~OssEncOID();
    int operator == (const OssEncOID &) const;
    int operator != (const OssEncOID &) const;
    OssEncOID(const char *);
    OssEncOID & operator = (const char *);
    void replace(OssEncOID &);
    char *get_value() const;
    char *getDotValNotation() const;
    int setDotValNotation(const char *);
};

/* ASN.1 RELATIVE-OID type */
class OSS_DECLSPEC OssRelOID
{
private:
    OSS_UINT32 size;
    unsigned char *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssRelOID();
    OssRelOID(const OssRelOID &);
    OssRelOID & operator = (const OssRelOID &);
    ~OssRelOID();
    int operator == (const OssRelOID &) const;
    int operator != (const OssRelOID &) const;
    OssRelOID(const char *);
    OssRelOID & operator = (const char *);
    void replace(OssRelOID &);
    char *get_value() const;
    char *getDotValNotation() const;
    int setDotValNotation(const char *);
};

/* ASN.1 REAL type with the --<DECIMAL>-- directive applied */
class OSS_DECLSPEC OssDecimal
{
private:
    char *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    static const OssDecimal & PlusInfinity;
    static const OssDecimal & MinusInfinity;
    OssDecimal();
    OssDecimal(const OssDecimal &);
    OssDecimal & operator = (const OssDecimal &);
    ~OssDecimal();
    int operator == (const OssDecimal &) const;
    int operator != (const OssDecimal &) const;
    OssDecimal(const char *);
    void set(const char *);
    void grab(char *);
    char *get_value();
    const char *get_value() const;
    char *release_value();
    int isPlusInfinity() const;
    int isMinusInfinity() const;
};

/* ASN.1 GeneralizedTime type */
class OSS_DECLSPEC OssGeneralizedTime
{
private:
    char *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssGeneralizedTime();
    OssGeneralizedTime(const OssGeneralizedTime &);
    OssGeneralizedTime & operator = (const OssGeneralizedTime &);
    ~OssGeneralizedTime();
    int operator == (const OssGeneralizedTime &) const;
    int operator != (const OssGeneralizedTime &) const;
    OssGeneralizedTime(unsigned short year, unsigned short month, unsigned short day, 
	unsigned short hour = 0, unsigned short minute = 0,
	unsigned short second = 0, unsigned short millisec = 0,
	short mindiff = 0, int utc = 0); 
    OssGeneralizedTime(const char *);
    int set_components(unsigned year, unsigned month, unsigned day, 
        unsigned hour = 0, unsigned minute = 0,
        unsigned second = 0, unsigned fraction = 0, unsigned short precision = 3,
        int mindiff = 0, int utc = 0); 
    int get_components(unsigned &year, unsigned &month, unsigned &day, 
        unsigned &hour, unsigned &minute,
        unsigned &second, unsigned &fraction, unsigned short &precision,
        int &mindiff, int &utc); 
    void set_value(const char *);
    const char *get_value() const;
    int set_year(unsigned short year); 
    unsigned short get_year() const; 
    int set_month(unsigned short month); 
    unsigned short get_month() const; 
    int set_day(unsigned short day); 
    unsigned short get_day() const; 
    int set_hour(unsigned short hour); 
    unsigned short get_hour() const; 
    int set_minute(unsigned short minute); 
    unsigned short get_minute() const; 
    int set_second(unsigned short second); 
    unsigned short get_second() const; 
    int set_millisec(unsigned short millisec); 
    unsigned short get_millisec() const; 
    int set_mindiff(short mindiff); 
    short get_mindiff() const; 
    int set_utc(int utc); 
    int get_utc() const; 
};

/* ASN.1 UTCTime type */
class OSS_DECLSPEC OssUTCTime
{
private:
    char *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssUTCTime();
    OssUTCTime(const OssUTCTime &);
    OssUTCTime & operator = (const OssUTCTime &);
    ~OssUTCTime();
    int operator == (const OssUTCTime &) const;
    int operator != (const OssUTCTime &) const;
    OssUTCTime(unsigned short year, unsigned short month, unsigned short day, 
	unsigned short hour = 0, unsigned short minute = 0,
	unsigned short second = 0, short mindiff = 0, int utc = 0);
    OssUTCTime(const OssControl* ctl, unsigned short year, unsigned short month, unsigned short day, 
	unsigned short hour = 0, unsigned short minute = 0,
	unsigned short second = 0, short mindiff = 0, int utc = 0);
    OssUTCTime(const char *);
    int set_components(unsigned year, unsigned month, unsigned day, 
                       unsigned hour = 0, unsigned minute = 0,
                       unsigned second = 0, int mindiff = 0, int utc = 0); 
    int set_components(const OssControl* ctl, unsigned year, unsigned month, unsigned day, 
                       unsigned hour = 0, unsigned minute = 0,
                       unsigned second = 0, int mindiff = 0, int utc = 0); 
    int get_components(unsigned &year, unsigned &month, unsigned &day, 
                       unsigned &hour, unsigned &minute,
                       unsigned &second, int &mindiff, int &utc); 
    int get_components(const OssControl* ctl, unsigned &year, unsigned &month, unsigned &day, 
                       unsigned &hour, unsigned &minute,
                       unsigned &second, int &mindiff, int &utc); 
    void set_value(const char *);
    const char *get_value() const;
    int set_year(unsigned short year); 
    int set_year(const OssControl* ctl, unsigned short year); 
    unsigned short get_year() const; 
    unsigned short get_year(const OssControl* ctl) const; 
    int set_month(unsigned short month); 
    int set_month(const OssControl* ctl, unsigned short month); 
    unsigned short get_month() const; 
    unsigned short get_month(const OssControl* ctl) const; 
    int set_day(unsigned short day); 
    int set_day(const OssControl* ctl, unsigned short day); 
    unsigned short get_day() const; 
    unsigned short get_day(const OssControl* ctl) const; 
    int set_hour(unsigned short hour); 
    int set_hour(const OssControl* ctl, unsigned short hour); 
    unsigned short get_hour() const; 
    unsigned short get_hour(const OssControl* ctl) const; 
    int set_minute(unsigned short minute); 
    int set_minute(const OssControl* ctl, unsigned short minute); 
    unsigned short get_minute() const; 
    unsigned short get_minute(const OssControl* ctl) const; 
    int set_second(unsigned short second); 
    int set_second(const OssControl* ctl, unsigned short second); 
    unsigned short get_second() const; 
    unsigned short get_second(const OssControl* ctl) const; 
    int set_mindiff(short mindiff); 
    int set_mindiff(const OssControl* ctl, short mindiff); 
    short get_mindiff() const; 
    short get_mindiff(const OssControl* ctl) const; 
    int set_utc(int utc); 
    int set_utc(const OssControl* ctl, int utc); 
    int get_utc() const; 
    int get_utc(const OssControl* ctl) const; 
    void strip_zero_sec();
};

/* auxiliary time conversion classes */
class OssTimePoint;
class OssDuration;
class OssTimeInterval;

/* ASN.1 TIME type */
class OSS_DECLSPEC OssTime
{
private:
    char *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssTime();
    OssTime(const OssTime &);
    OssTime & operator = (const OssTime &);
    ~OssTime();
    int operator == (const OssTime &) const;
    int operator != (const OssTime &) const;
    OssTime(const OssTimePoint &);
    OssTime(const OssDuration &);
    OssTime(const OssTimeInterval &);
    OssTime(const char *);
    void set_value(const char *);
    const char *get_value() const;
    int is_time_point() const;
    int is_duration() const;
    int is_interval() const;
    int get_time_point(OssTimePoint &) const;
    int get_duration(OssDuration &) const;
    int get_interval(OssTimeInterval &) const;
    int set_time_point(const OssTimePoint &);
    int set_duration(const OssDuration &);
    int set_interval(const OssTimeInterval &);
};

/* a forward declaration */
class OSS_DECLSPEC EncodedBuffer;

/* ASN.1 open type (can hold any PDU either in encoded or in decoded form */
class OSS_DECLSPEC OssOpen
{
private:
    OSS_INT32 pdunum;
    long size;
    void *encoded;
    void *decoded;
    void *ctl;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssOpen();
    OssOpen(const OssOpen &);
    OssOpen & operator = (const OssOpen &);
    ~OssOpen();
    int operator == (const OssOpen &) const;
    int operator != (const OssOpen &) const;
    int get_decoded(PDU &) const;
    int get_decoded_data(PDU &);
    int get_decoded_data(PDU &) const;
    int release_decoded(PDU &);
    int set_decoded(PDU &, OssControl &);
    int grab_decoded(PDU &, OssControl &);
    EncodedBuffer *get_encoded() const;
    EncodedBuffer *release_encoded();
    int set_encoded(const EncodedBuffer &);
    int grab_encoded(EncodedBuffer &);
    int encode(OssControl &);
    int decode(OssControl &);
    int has_decoded() const;
    int has_encoded() const;
    int has_type_info() const;
private:
    int cleanup_encoded();
    int cleanup_decoded();
    int copy_encoded(const char *, unsigned long);
    int copy_decoded(const void *, int);
};

/* ASN.1 INTEGER type with the --<HUGE>-- directivbe applied */
class OSS_DECLSPEC OssHugeInt
{
private:
    OSS_UINT32 size;
    unsigned char *value;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssHugeInt();
    OssHugeInt(const OssHugeInt &);
    OssHugeInt & operator = (const OssHugeInt &);
    ~OssHugeInt();
    int operator == (const OssHugeInt &) const;
    int operator != (const OssHugeInt &) const;
    OssHugeInt(OSS_UINT32 length, const unsigned char *);
    OSS_UINT32 length() const;
    unsigned char *get_buffer();
    const unsigned char *get_buffer() const;
    void set(OSS_UINT32 length, const unsigned char *);
    /* ownership-transferring functions */
    unsigned char *release_buffer(OSS_UINT32 & length);
    void grab(OSS_UINT32 length, unsigned char *);
    /* higher level functions */
    unsigned char & operator [] (OSS_UINT32 pos);
    const unsigned char & operator [] (OSS_UINT32 pos) const;
    unsigned char elem(OSS_UINT32 pos);
};

/* a non-user-instantiable class that is used as a superclass for all ASN.1 */
/* CHOICE types */ 
class OSS_DECLSPEC OssChoice
{
protected:
    OSS_UINT32 _choice;
    OssChoice();
public:
    void *operator new(size_t);
    void operator delete(void *);
    OSS_UINT32 get_selection() const;
};

/* an iterator type for SEQUENCE OF/SET OF types */
typedef void * OssIndex;

/* an OssIndex value that acts as a null iterator */
#define OSS_NOINDEX ((OssIndex)0)

/* a non-user-instantiable class that is used as a superclass for all ASN.1 */
/* SEQUENCE OF and SET OF types */
class OSS_DECLSPEC OssList
{
protected:
    void *head;
    OssList();
    ~OssList();
    OssIndex do_prepend(OssIndex);
    OssIndex do_prepend(OssList *);
    OssIndex do_insert_after(OssIndex, OssIndex);
    OssIndex do_insert_after(OssIndex, OssList *);
    OssList *do_extract_after(OssIndex, OssIndex);
    OssIndex do_extract_front();
    OssIndex do_extract_after(OssIndex);
    void do_copy(const OssList &, void * (*func)(void *));
    void do_destroy(void (*func)(void *));
    int do_compare(const OssList &, int (*func)(void *, void *)) const;
public:
    void *operator new(size_t);
    void operator delete(void *);
    int empty() const;
    OssIndex first() const;
    OssIndex next(OssIndex index) const;
};

/* a non-user-instantiable class that is used as a superclass for all */
/* table-constrained open types */
class OSS_DECLSPEC OssConstrainedOpenType
{
protected:
    OSS_UINT32 pdunum;
    struct {
	long size;
	unsigned char *buffer;
    } encoded;
    void *decoded;
    OssConstrainedOpenType();
    ~OssConstrainedOpenType();
    void cleanup_encoded();
    int copy_encoded(const unsigned char *buf, long length, unsigned char **dst);
    int equal_helper(const OssConstrainedOpenType & that) const;
    int encode_helper(OssControl & control);
public:
    void *operator new(size_t);
    void operator delete(void *);
    int get_decoded(PDU &);
    int get_decoded(PDU &) const;
    int release_decoded(PDU &);
    EncodedBuffer *get_encoded() const;
    EncodedBuffer *release_encoded();
    int has_decoded() const;
    int has_encoded() const;
};

/* auxiliary classes for -relaySafe implementation */

/* an auxiliary class for OssExtensions implementation */
class OSS_DECLSPEC OssExtensionList 
{
friend class OssExtensions;
public:
    void *operator new(size_t);
    void operator delete(void *);
    OssExtensionList();
    OssExtensionList(const OssExtensionList &);
    OssExtensionList & operator = (const OssExtensionList &);
    ~OssExtensionList();
    int operator == (const OssExtensionList &) const;
    int operator != (const OssExtensionList &) const;
private:
     OSS_UINT32 count;
     OssString *value;	
};

/* the -relaySafe field for SEQUENCE/SET types */
class OSS_DECLSPEC OssExtensions {
public:
    /* the copy constructor is automatically generated by the C++ compiler */
    void *operator new(size_t);
    void operator delete(void *);
    int operator == (const OssExtensions &) const;
    int operator != (const OssExtensions &) const;
    OSS_UINT32 size() const;
    OssString * get_ext(OSS_UINT32 num);
    const OssString * get_ext(OSS_UINT32 num) const;
private:
    OssBitString extMask;
    OssExtensionList extList;
};

/* the -relaySafe field for CHOICE types */
class OSS_DECLSPEC OssAlternative {
public:
    /* the copy constructor is automatically generated by the C++ compiler */
    void *operator new(size_t);
    void operator delete(void *);
    int operator == (const OssAlternative &) const;
    int operator != (const OssAlternative &) const;
    ~OssAlternative();
    OSS_UINT32 index() const;
    OssString & value();
    const OssString & value() const;
private:
    OSS_UINT32 idx;
    OssString data;
};

/* ASN.1/C++ control table class (for internal use) */
class OSS_DECLSPEC OssControlTable
{
friend class OssControl;
protected:
    void *ctl;
    OssControlTable(void *);
    virtual ~OssControlTable();
public:
    virtual int destroy(void *data, OssTypeIndex typeindex) = 0; 
    virtual int copy(void *src, void **dst, OssTypeIndex typeindex) = 0;
    virtual int equal(void *data1, void *data2, OssTypeIndex typeindex) = 0;
};


/* the non-user-instantiable ancestor for ASN.1/C++ control classes */
class OSS_DECLSPEC OssControl
{
friend class ASN1Handle;
friend class PDU;
friend class ConcretePDU;
friend class UniversalPDU;
friend class EncodedBuffer;
friend class PEREncodedBuffer;
friend class EncodedFile;
friend class EncodedSocket;
friend class OssOpen;
friend class OssUTCTime;
#ifndef CPP_TOED_SOURCECODE_SHIPPING
friend class OssCompressor;
#endif
friend class OssConstrainedOpenType;
private:
    unsigned char status;
    void init(const OssControl & that);
protected:
#ifndef CPP_TOED_SOURCECODE_SHIPPING
    OssCompressor *oss_comprsr;
#endif
    ossGlobal world;
    int (DLL_ENTRY_FPTR *savedprint)(ossGlobal *, const char *, va_list);
    OssControl(OssControlTable *table, void *cptr);
    OssControl(const OssControl &that);
    virtual ~OssControl();
    int setErrorMsg(int code);
    void *unmark(void *);
public:
    OssControl & operator = (const OssControl & that);
    int setEncodingRules(OssEncodingRules rules);
    OssEncodingRules getEncodingRules() const;
    int setEncodingFlags(unsigned long flags);
    unsigned long getEncodingFlags() const;
    int setDecodingFlags(unsigned long flags);
    unsigned long getDecodingFlags() const;
    int setInternalFlags(unsigned long flags);
    unsigned long getInternalFlags() const;
    const char *getErrorMsg() const;
    int printHex(const char *buffer, unsigned long length);
#ifndef FILESYSTEM_NOT_SUPPORTED
    int setOutputFile(const char *filename);
    int resetOutputFile();
    virtual int userPrint(FILE *stream, const char *fmt, va_list ap);
#else
    virtual int userPrint(void *stream, const char *fmt, va_list ap);
#endif /* FILESYSTEM_NOT_SUPPORTED */
#ifndef NO_XML
    int setXmlStylesheet(const char *name);
    int setXmlDTD(const char *name, const char *ExternalID, short dtd_kind);
    void printXML(const char *buffer, unsigned long length, int pretty_print);
    int getNamespacePrefix(const char *ns, const char **prefix);
    int setNamespacePrefix(const char *ns, const char *prefix);
    int setXMLEncodingRules(OssEncodingRules rules);
    OssEncodingRules getXMLEncodingRules() const;
#endif /* NO_XML */
    void print(const char *text);
    int setDebugFlags(unsigned long flags);
    unsigned long getDebugFlags() const;
    unsigned long getCompatibilityFlags();
    int setCompatibilityFlags(unsigned long flag);
    void setTimeout(long timeout);
    void setDebugStringTruncate(size_t length);
    size_t getDebugStringTruncate() const;
    int valid();
    void printJSON(const char *buffer, unsigned long length, int pretty_print);
    int setJsonFlags(unsigned long flags);
    unsigned long getJsonFlags() const;
    int setJsonIndentSize(int indent_size);
    int getJsonIndentSize() const;

#ifndef CPP_TOED_SOURCECODE_SHIPPING
    /* these methods are to support compression */
    void setCompressor(OssCompressor *comp);
    OssCompressor* getCompressor();
#endif
};

/* ASN.1/C++ encoded data classes */

/* the abstract ancestor */
class OSS_DECLSPEC EncodedData
{
friend class PDU;
friend class ConcretePDU;
friend class UniversalPDU;
protected:
    unsigned int skipFlag;
    unsigned int skipValue; 
    EncodedData();
    virtual ~EncodedData();
    virtual int pre_encode(OssBuf &, OssControl &, int) = 0;
    virtual int pre_decode(OssBuf &, OssControl &) = 0;
    virtual void post_encode(OssBuf &, OssControl &, int) = 0;
    virtual void post_decode(OssBuf &, OssControl &, int) = 0;
private:
    EncodedData(const EncodedData &);
    EncodedData & operator = (const EncodedData &);
public:
    void enableSkipPadBytes(unsigned char pad_byte);
    void disableSkipPadBytes();    
};

/* a memory buffer */
class OSS_DECLSPEC EncodedBuffer: public EncodedData
{
friend class ASN1Handle;
friend class ConcretePDU;
friend class UniversalPDU;
friend class OssOpen;
friend class PDU;
protected:
    char *buffer;
    unsigned long position;
    unsigned long length;
    unsigned long datalength;
    unsigned long dataoffset;
    unsigned char status;
    virtual int pre_encode(OssBuf &, OssControl &, int);
    virtual int pre_decode(OssBuf &, OssControl &);
    virtual void post_encode(OssBuf &, OssControl &, int);
    virtual void post_decode(OssBuf &, OssControl &, int);
public:
    EncodedBuffer();
    EncodedBuffer(unsigned long length, char *value);
    EncodedBuffer(OssString & any);
    ~EncodedBuffer();
    void set_buffer(unsigned long length, char *value);
    void grab_buffer(unsigned long length, char *value);
    void clone(EncodedBuffer & orig);
    char *get_data() const;
    char *release_data();
    unsigned long get_length() const;
    unsigned long get_data_size() const;
    unsigned long get_data_offset() const;
    unsigned long get_position() const;
    int set_position(unsigned long pos);
    int is_preallocated() const;
    int print_hex(OssControl & ctl) const;
    void reset();
#ifndef NO_XML
    void print_xml(OssControl & ctl, int pretty_print) const;
#endif /* !NO_XML */
    void print_json(OssControl & ctl, int pretty_print) const;
};

/* a memory buffer that can hold non-integral number of bytes
  (to be used with PER) */
class OSS_DECLSPEC PEREncodedBuffer: public EncodedBuffer
{
protected:
    int padBits;
    virtual int pre_decode(OssBuf &, OssControl &);
    virtual void post_encode(OssBuf &, OssControl &, int);
public:
    PEREncodedBuffer();
    PEREncodedBuffer(unsigned long length, char *value);
    PEREncodedBuffer(OssString & any);
    void set_buffer(unsigned long length, char *value);
    void grab_buffer(unsigned long length, char *value);
    void clone(EncodedBuffer & orig);
    int set_position(unsigned long pos);
    int get_pad_bits() const;
    void reset();
};

#ifndef FILESYSTEM_NOT_SUPPORTED

/* a file as an encoded data source */
class OSS_DECLSPEC EncodedFile : public EncodedData
{
protected:
    unsigned char *oss;
    unsigned int position;
    char status;
    virtual int pre_encode(OssBuf &, OssControl &, int);
    virtual int pre_decode(OssBuf &, OssControl &);
    virtual void post_encode(OssBuf &, OssControl &, int);
    virtual void post_decode(OssBuf &, OssControl &, int);
public:
    EncodedFile(const char *name, int append = 0);
    ~EncodedFile();
    void reset();
};

/* a socket as an encoded data source */
class OSS_DECLSPEC EncodedSocket : public EncodedData
{
protected:
    OssBuf oss;
    virtual int pre_encode(OssBuf &, OssControl &, int);
    virtual int pre_decode(OssBuf &, OssControl &);
    virtual void post_encode(OssBuf &, OssControl &, int);
    virtual void post_decode(OssBuf &, OssControl &, int);
public:
    EncodedSocket(SOCKET socket);
    ~EncodedSocket();
};

#endif /* FILESYSTEM_NOT_SUPPORTED */


#ifndef CPP_TOED_SOURCECODE_SHIPPING
/* compression support using OssCompressor */

class OSS_DECLSPEC OssCompressor {
public:
    virtual ~OssCompressor();
    virtual int compress(void *inbuf, size_t inlen, 
		void *outbuf, size_t *outlen) = 0;
    virtual int decompress(void *inbuf, size_t inlen, 
		void *outbuf, size_t *outlen) = 0;
    virtual size_t compress_estimate(void *inbuf, size_t inlen) = 0;
};

/* compressor to support ZLIB */
class OSS_DECLSPEC OssZlibCompressor : public OssCompressor {
public:
    OssZlibCompressor();
    OssZlibCompressor(int lvl);
    int compress(void *inbuf, size_t inlen, void *outbuf, size_t *outlen);
    int decompress(void *inbuf, size_t inlen, void *outbuf, size_t *outlen);
    size_t compress_estimate(void *inbuf, size_t inlen);
    int get_compressionLevel();
    void set_compressionLevel(int level);
private:
    int comp_level;
};
#endif

/* utility XML time/date classes */
class OSS_DECLSPEC OssXMLDate {
private:
    char *string;
    int year;
    unsigned month;
    unsigned day;
    int local_utc_mindiff;
    int valid;
    void copy(const OssXMLDate &);
    int convert_to_ints();
public:
    OssXMLDate();
    OssXMLDate(const OssXMLDate &);
    OssXMLDate & operator = (const OssXMLDate &);
    ~OssXMLDate();
    OssXMLDate(const char *xmlString);
    OssXMLDate(int yearval, unsigned int monthval, unsigned int dayval,
	    int local_utc_mindiffval = 0);
    operator const char *();
    OssXMLDate & operator = (const char *xmlString);
    int get_year();
    unsigned get_month();
    unsigned get_day();
    int get_local_utc_mindiff();
    int get_components(int &yearval, unsigned int &monthval, unsigned int &dayval,
	    int &local_utc_mindiffval);
    int set_year(int yearval);
    int set_month(unsigned int monthval);
    int set_day(unsigned int dayval);
    int set_local_utc_mindiff(int local_utc_mindiffval);
    int set_components(int yearval, unsigned int monthval, unsigned int dayval,
	    int local_utc_mindiffval = 0);
};

class OSS_DECLSPEC OssXMLDateTime {
private:
    char *string;
    int year;
    unsigned month;
    unsigned day;
    unsigned hours;
    unsigned minutes;
    unsigned seconds;
    unsigned precision;
    char *fraction;
    int local_utc_mindiff;
    int valid;
    void copy(const OssXMLDateTime &);
    int convert_to_ints();
public:
    OssXMLDateTime();
    OssXMLDateTime(const OssXMLDateTime &);
    OssXMLDateTime & operator = (const OssXMLDateTime &);
    ~OssXMLDateTime();
    OssXMLDateTime(const char *xmlString);
    OssXMLDateTime(int yearval, unsigned monthval, unsigned dayval,
	    unsigned hoursval = 0, unsigned minutesval = 0,
	    unsigned secondsval = 0,
	    const char *fractionval = NULL, unsigned precisionval = 0,
	    int local_utc_mindiffval = 0);
    operator const char *();
    OssXMLDateTime & operator = (const char *xmlString);
    int get_year();
    unsigned get_month();
    unsigned get_day();
    unsigned get_hours();
    unsigned get_minutes();
    unsigned get_seconds();
    const char *get_fraction(unsigned &precisionval);
    int get_local_utc_mindiff();
    int get_components(int &yearval, unsigned &monthval, unsigned &dayval,
	    unsigned &hoursval, unsigned &minutesval, unsigned &secondsval,
	    const char *&fractionval, unsigned &precisionval,
	    int &local_utc_mindiffval);
    int set_year(int yearval);
    int set_month(unsigned int monthval);
    int set_day(unsigned int dayval);
    int set_hours(unsigned int hoursval);
    int set_minutes(unsigned int minutesval);
    int set_seconds(unsigned int secondsval);
    int set_fraction(const char *fractionval, unsigned precisionval = 0);
    int set_local_utc_mindiff(int local_utc_mindiffval);
    int set_components(int yearval, unsigned int monthval, unsigned int dayval,
	    unsigned hoursval = 0, unsigned minutesval = 0,
	    unsigned secondsval = 0,
	    const char *fractionval = NULL, unsigned precisionval = 0,
	    int local_utc_mindiffval = 0);
};

class OSS_DECLSPEC OssXMLDuration {
private:
    char *string;
    unsigned years;
    unsigned months;
    unsigned days;
    unsigned hours;
    unsigned minutes;
    unsigned seconds;
    unsigned precision;
    char *fraction;
    int flags;
    void copy(const OssXMLDuration &);
    int convert_to_ints();
public:
    OssXMLDuration();
    OssXMLDuration(const OssXMLDuration &);
    OssXMLDuration & operator = (const OssXMLDuration &);
    ~OssXMLDuration();
    OssXMLDuration(const char *xmlString);
    OssXMLDuration(int negative, unsigned yearsval, unsigned monthsval = 0,
	    unsigned daysval = 0, unsigned hoursval = 0,
	    unsigned minutesval = 0, unsigned secondsval = 0,
	    const char *fractionval = NULL, unsigned precisionval = 0);
    operator const char *();
    OssXMLDuration & operator = (const char *xmlString);
    int get_negative();
    unsigned get_years();
    unsigned get_months();
    unsigned get_days();
    unsigned get_hours();
    unsigned get_minutes();
    unsigned get_seconds();
    const char *get_fraction(unsigned &precisionval);
    int get_components(int &negative, unsigned &yearsval, unsigned &monthsval,
	    unsigned &daysval, unsigned &hoursval, unsigned &minutesval,
	    unsigned &secondsval,
	    const char *&fractionval, unsigned &precisionval);
    int set_negative(int negative);
    int set_years(unsigned yearsval);
    int set_months(unsigned int monthsval);
    int set_days(unsigned int daysval);
    int set_hours(unsigned int hoursval);
    int set_minutes(unsigned int minutesval);
    int set_seconds(unsigned int secondsval);
    int set_fraction(const char *fractionval, unsigned precisionval = 0);
    int set_components(int negative, unsigned yearsval, unsigned monthsval = 0,
	    unsigned daysval = 0, unsigned hoursval = 0,
	    unsigned minutesval = 0, unsigned secondsval = 0,
	    const char *fractionval = NULL, unsigned precisionval = 0);
};

class OSS_DECLSPEC OssXMLGDay {
private:
    char *string;
    unsigned day;
    int local_utc_mindiff;
    int valid;
    void copy(const OssXMLGDay &);
    int convert_to_ints();
public:
    OssXMLGDay();
    OssXMLGDay(const OssXMLGDay &);
    OssXMLGDay & operator = (const OssXMLGDay &);
    ~OssXMLGDay();
    OssXMLGDay(const char *xmlString);
    OssXMLGDay(unsigned int dayval, int local_utc_mindiffval = 0);
    operator const char *();
    OssXMLGDay & operator = (const char *xmlString);
    unsigned int get_day();
    int get_local_utc_mindiff();
    int get_components(unsigned int &dayval, int &local_utc_mindiffval);
    int set_day(unsigned int dayval);
    int set_local_utc_mindiff(int local_utc_mindiffval);
    int set_components(unsigned dayval, int local_utc_mindiffval = 0);
};

class OSS_DECLSPEC OssXMLGMonthDay {
private:
    char *string;
    unsigned month;
    unsigned day;
    int local_utc_mindiff;
    int valid;
    void copy(const OssXMLGMonthDay &);
    int convert_to_ints();
public:
    OssXMLGMonthDay();
    OssXMLGMonthDay(const OssXMLGMonthDay &);
    OssXMLGMonthDay & operator = (const OssXMLGMonthDay &);
    ~OssXMLGMonthDay();
    OssXMLGMonthDay(const char *xmlString);
    OssXMLGMonthDay(unsigned int monthval, unsigned int dayval,
	    int local_utc_mindiffval = 0);
    operator const char *();
    OssXMLGMonthDay & operator = (const char *xmlString);
    unsigned get_month();
    unsigned get_day();
    int get_local_utc_mindiff();
    int get_components(unsigned int &monthval, unsigned int &dayval,
	    int &local_utc_mindiffval);
    int set_month(unsigned int monthval);
    int set_day(unsigned int dayval);
    int set_local_utc_mindiff(int local_utc_mindiffval);
    int set_components(unsigned int monthval, unsigned int dayval,
	    int local_utc_mindiffval = 0);
};

class OSS_DECLSPEC OssXMLGMonth {
private:
    char *string;
    unsigned month;
    int local_utc_mindiff;
    int valid;
    void copy(const OssXMLGMonth &);
    int convert_to_ints();
public:
    OssXMLGMonth();
    OssXMLGMonth(const OssXMLGMonth &);
    OssXMLGMonth & operator = (const OssXMLGMonth &);
    ~OssXMLGMonth();
    OssXMLGMonth(const char *xmlString);
    OssXMLGMonth(unsigned int monthval, int local_utc_mindiffval = 0);
    operator const char *();
    OssXMLGMonth & operator = (const char *xmlString);
    unsigned get_month();
    int get_local_utc_mindiff();
    int get_components(unsigned int &monthval, int &local_utc_mindiffval);
    int set_month(unsigned int monthval);
    int set_local_utc_mindiff(int local_utc_mindiffval);
    int set_components(unsigned int monthval, int local_utc_mindiffval = 0);
};

class OSS_DECLSPEC OssXMLGYear {
private:
    char *string;
    int year;
    int local_utc_mindiff;
    int valid;
    void copy(const OssXMLGYear &);
    int convert_to_ints();
public:
    OssXMLGYear();
    OssXMLGYear(const OssXMLGYear &);
    OssXMLGYear & operator = (const OssXMLGYear &);
    ~OssXMLGYear();
    OssXMLGYear(const char *xmlString);
    OssXMLGYear(int yearval, int local_utc_mindiffval = 0);
    operator const char *();
    OssXMLGYear & operator = (const char *xmlString);
    int get_year();
    int get_local_utc_mindiff();
    int get_components(int &yearval, int &local_utc_mindiffval);
    int set_year(int yearval);
    int set_local_utc_mindiff(int local_utc_mindiffval);
    int set_components(int yearval, int local_utc_mindiffval = 0);
};

class OSS_DECLSPEC OssXMLGYearMonth {
private:
    char *string;
    int year;
    unsigned month;
    int local_utc_mindiff;
    int valid;
    void copy(const OssXMLGYearMonth &);
    int convert_to_ints();
public:
    OssXMLGYearMonth();
    OssXMLGYearMonth(const OssXMLGYearMonth &);
    OssXMLGYearMonth & operator = (const OssXMLGYearMonth &);
    ~OssXMLGYearMonth();
    OssXMLGYearMonth(const char *xmlString);
    OssXMLGYearMonth(int yearval, unsigned monthval,
	    int local_utc_mindiffval = 0);
    operator const char *();
    OssXMLGYearMonth & operator = (const char *xmlString);
    int get_year();
    unsigned get_month();
    int get_local_utc_mindiff();
    int get_components(int &yearval, unsigned &monthval,
	    int &local_utc_mindiffval);
    int set_year(int yearval);
    int set_month(unsigned int monthval);
    int set_local_utc_mindiff(int local_utc_mindiffval);
    int set_components(int yearval, unsigned monthval,
	    int local_utc_mindiffval = 0);
};

class OSS_DECLSPEC OssXMLTime {
private:
    char *string;
    unsigned hours;
    unsigned minutes;
    unsigned seconds;
    unsigned precision;
    char *fraction;
    int local_utc_mindiff;
    int valid;
    void copy(const OssXMLTime &);
    int convert_to_ints();
public:
    OssXMLTime();
    OssXMLTime(const OssXMLTime &);
    OssXMLTime & operator = (const OssXMLTime &);
    ~OssXMLTime();
    OssXMLTime(const char *xmlString);
    OssXMLTime(unsigned hoursval, unsigned minutesval = 0,
	    unsigned secondsval = 0,
	    const char *fractionval = NULL, unsigned precisionval = 0,
	    int local_utc_mindiffval = 0);
    operator const char *();
    OssXMLTime & operator = (const char *xmlString);
    unsigned get_hours();
    unsigned get_minutes();
    unsigned get_seconds();
    const char *get_fraction(unsigned &precisionval);
    int get_local_utc_mindiff();
    int get_components(unsigned &hoursval, unsigned &minutesval,
	    unsigned &secondsval,
	    const char *&fractionval, unsigned &precisionval,
	    int &local_utc_mindiffval);
    int set_hours(unsigned int hoursval);
    int set_minutes(unsigned int minutesval);
    int set_seconds(unsigned int secondsval);
    int set_fraction(const char *fractionval, unsigned precisionval = 0);
    int set_local_utc_mindiff(int local_utc_mindiffval);
    int set_components(unsigned hoursval, unsigned minutesval = 0,
	    unsigned secondsval = 0,
	    const char *fractionval = NULL, unsigned precisionval = 0,
	    int local_utc_mindiffval = 0);
};

/* auxiliary ISO 8601 time conversion types */

class OSS_DECLSPEC OssTimePoint {
friend class OssTimeInterval;
friend class OssTime;
private:
    struct ossTimePoint data;
public:
    OssTimePoint();
    OssTimePoint(const OssTimePoint &);
    OssTimePoint & operator = (const OssTimePoint &);
    void clear();
    int has_century() const;
    int get_century() const;
    int set_century(int centval);
    int omit_century();
    int has_year() const;
    int get_year() const;
    int set_year(int yearval);
    int omit_year();
    int has_week() const;
    unsigned short get_week() const;
    int set_week(unsigned short weekval);
    int omit_week();
    int has_month() const;
    unsigned short get_month() const;
    int set_month(unsigned short monthval);
    int omit_month();
    int has_day() const;
    unsigned short get_day() const;
    int set_day(unsigned short dayval);
    int omit_day();
    int has_hours() const;
    unsigned short get_hours() const;
    int set_hours(unsigned short hoursval);
    int omit_hours();
    int has_minutes() const;
    unsigned short get_minutes() const;
    int set_minutes(unsigned short minutesval);
    int omit_minutes();
    int has_seconds() const;
    unsigned short get_seconds() const;
    int set_seconds(unsigned short secondsval);
    int omit_seconds();
    int has_fraction() const;
    ULONG_LONG get_fraction(unsigned & precision) const;
    int set_fraction(ULONG_LONG fractionval, unsigned precisionval);
    int omit_fraction();
    int is_utc() const;
    int set_utc(int utcval);
    int has_difference() const;
    int has_difference_minutes() const;
    unsigned short get_difference_hours() const;
    unsigned short get_difference_minutes() const;
    int is_difference_negative() const;
    int set_difference_hours(unsigned short hoursval, int negative);
    int set_difference(unsigned short hoursval, unsigned short minutesval,
	    int negative);
    int omit_difference();
    int omit_difference_minutes();
};

class OSS_DECLSPEC OssDuration {
friend class OssTimeInterval;
friend class OssTime;
private:
    struct ossDuration data;
public:
    OssDuration();
    OssDuration(const OssDuration &);
    OssDuration & operator = (const OssDuration &);
    void clear();
    int has_years() const;
    unsigned int get_years() const;
    int set_years(unsigned yearsval);
    int omit_years();
    int has_months() const;
    unsigned get_months() const;
    int set_months(unsigned monthsval);
    int omit_months();
    int has_weeks() const;
    unsigned get_weeks() const;
    int set_weeks(unsigned weeksval);
    int omit_weeks();
    int has_days() const;
    unsigned get_days() const;
    int set_days(unsigned dayval);
    int omit_days();
    int has_hours() const;
    unsigned get_hours() const;
    int set_hours(unsigned hoursval);
    int omit_hours();
    int has_minutes() const;
    unsigned get_minutes() const;
    int set_minutes(unsigned minutesval);
    int omit_minutes();
    int has_seconds() const;
    unsigned get_seconds() const;
    int set_seconds(unsigned secondsval);
    int omit_seconds();
    int has_fraction() const;
    ULONG_LONG get_fraction(unsigned & precision) const;
    int set_fraction(ULONG_LONG fractionval, unsigned precisionval);
    int omit_fraction();
};

class OSS_DECLSPEC OssTimeInterval {
friend class OssTime;
private:
    OSS_UINT32 flags;
    OssTimePoint start;
    OssTimePoint end;
    OssDuration duration;
    int recurrence;
public:
    OssTimeInterval();
    OssTimeInterval(const OssTimeInterval &);
    OssTimeInterval & operator = (const OssTimeInterval &);
    void clear();
    int has_start_point() const;
    OssTimePoint *get_start_point();
    const OssTimePoint *get_start_point() const;
    int set_start_point(const OssTimePoint & sp);
    int omit_start_point();
    int has_end_point() const;
    OssTimePoint *get_end_point();
    const OssTimePoint *get_end_point() const;
    int set_end_point(const OssTimePoint & ep);
    int omit_end_point();
    int has_duration() const;
    OssDuration *get_duration();
    const OssDuration *get_duration() const;
    int set_duration(const OssDuration & dur);
    int omit_duration();
    int has_recurrence() const;
    int is_unbounded() const;
    unsigned get_recurrence() const;
    int set_recurrence(unsigned recval); 
    int set_unbounded();
    int omit_recurrence();
};

class OSS_DECLSPEC ASN1RuntimeException {
private:
    int code;
public:
    ASN1RuntimeException(int asn1_code);
    ASN1RuntimeException(const ASN1RuntimeException & that);
    int get_code() const;
    char* describe_error() const;
};

/* virtual test procedure */
int OSS_DECLSPEC ossTestCPP(OssControl &ctl, PDU &pdu, PDU &tmp, PDU &tmp2, long run);

/* virtual test procedure for partial decoding*/
int OSS_DECLSPEC ossTestCPPPD(OssControl &ctl, PDU &pdu, ConcretePDU &tmp, long run, OssCallback &callback);

/* set the error handling procedure */
void OSS_DECLSPEC asn1_set_error_handling(void (*func)(int), int complete = FALSE);

/* legacy error handler, does not throw any exceptions */ 
void OSS_DECLSPEC asn1_legacy_error_handler(int code);

/* default error handler, throws ASN1RuntimeException */ 
void OSS_DECLSPEC asn1_default_error_handler(int code);

void OSS_DECLSPEC _oss_compat_error_mode();

/* clean the last saved error code when the default error handling is */
/* in effect */
void OSS_DECLSPEC asn1_clean_error();

/* get the last saved error code when the default error handling is */
/* in effect */
int OSS_DECLSPEC asn1_get_last_error();

/* provide textual description of numeric return code obtained from */
/* any OSS ASN.1/C++ API function */
char OSS_DECLSPEC * asn1_describe_error_code(int);

/* ASN.1/C++ specific error codes */
#define OSS_CPP_CODES_START		200

	/* the requested component is missing */
#define OSS_COMPONENT_MISSING		200
	/* an invalid interval in the SEQUENCE OF/SET OF is specified */
#define OSS_INVALID_INTERVAL		201
	/* the position outside the buffer bounds is specified */
#define OSS_INVALID_POSITION		202
	/* the invalid encoding alignment is used */
#define OSS_INVALID_ALIGNMENT		203
	/* the requested data is missing */
#define OSS_DATA_MISSING		204
	/* an object of an unsuitable type is specified */
#define OSS_TYPE_MISMATCH		205
	/* cannot figure the type of the object */
#define OSS_UNKNOWN_TYPE		206
	/* the value of the specified object is unsuitable for the operation */
#define OSS_INVALID_VALUE		207
	/* insufficient memory for the operation */
#define OSS_NO_MEMORY			208
	/* an invalid ASN.1 value notation is specified */
#define OSS_INVALID_NOTATION		209
	/* an operation is currently not supported */
#define OSS_UNSUPPORTED_OPERATION	210
	/* memory pool system is not initialized */
#define OSS_MEMPOOLS_NOT_INITIALIZED	211
	/* memory pool belong to another thread */
#define OSS_MEMPOOL_BUSY		212
	/* attempt to set up an invalid time interval */
#define OSS_TIME_INTERVAL_ERROR		213
	/* uninitialized OssControl */
#define OSS_CONTROL_NOT_INITIALIZED	214

#define OSS_CPP_CODES_END		214

/* internally used functions */

void OSS_DECLSPEC *ossNewFunc(size_t);
char OSS_DECLSPEC *oss_string_copy(const char *);
int OSS_DECLSPEC init_dummy_world(ossGlobal *);
int OSS_DECLSPEC oss_call_error(int);
int OSS_DECLSPEC oss_call_error_cond(int);

#include "oss.h"

#ifndef OSS_PUBLIC
#define OSS_PUBLIC
#endif

#endif /* __ASN1_H */

