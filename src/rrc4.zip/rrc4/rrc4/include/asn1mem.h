/*****************************************************************************/
/* Copyright (C) 2019 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.,                   */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/* File: @(#)asn1mem.h	17.2 18/09/17                                        */
/*                                                                           */

#ifndef __ASN1MEM_H
#define __ASN1MEM_H

#include "osstype.h"

#if defined(__BORLANDC__)
#include <winbase.h>
#endif /* __BORLANDC__ */

#ifndef _WIN32
#define USE_PTHREADS
#include <pthread.h>
#endif

#if defined(_WIN32)
#define THREADID DWORD
#elif defined(USE_PTHREADS)
#define THREADID pthread_t
#else
#define THREADID int
#endif

/* Middle-level ASN.1 memory allocation functions */
extern "C" {
    void OSS_DECLSPEC * DLL_ENTRY asn1Malloc(size_t size);
    void OSS_DECLSPEC DLL_ENTRY asn1Free(void *ptr);
    void OSS_DECLSPEC * DLL_ENTRY asn1Realloc(void *ptr, size_t oldsize, size_t size);
}

/* Abstract memory system class */
class OSS_DECLSPEC OssMemorySystem {
friend void OSS_DECLSPEC * DLL_ENTRY asn1Malloc(size_t size);
friend void OSS_DECLSPEC DLL_ENTRY asn1Free(void *ptr);
friend void OSS_DECLSPEC * DLL_ENTRY asn1Realloc(void *ptr, size_t oldsize, size_t size);
private:
    static OssMemorySystem *current;
protected:
    OssMemorySystem *previous;
    OssMemorySystem();
    OssMemorySystem(int dummy);		/* for internal use */
public:
    virtual ~OssMemorySystem();
    static OssMemorySystem *get_current();
    virtual void *base_malloc(size_t size);
    virtual void base_free(void *ptr);
    virtual void *base_realloc(void *ptr, size_t oldsize, size_t size);
    virtual void *asn1_malloc(size_t size);
    virtual void asn1_free(void *ptr);
    virtual void *asn1_realloc(void *ptr, size_t oldsize, size_t size);
};

/* Default memory system class */
class OSS_DECLSPEC OssDefaultMemorySystem : public OssMemorySystem {
public:
    OssDefaultMemorySystem();
    OssDefaultMemorySystem(int dummy);	/* for internal use */
};

/* abstract memory pool class */
class OSS_DECLSPEC OssMemoryPool
{
protected:
    THREADID thread;
    THREADID active;
    OssMemoryPool();
    virtual int detach() = 0;
public:
    THREADID get_thread();
    int activate();
    int deactivate();
    virtual void *alloc(size_t size) = 0;
    virtual void clean() = 0;
    virtual void dealloc(void *ptr) = 0;
    virtual ~OssMemoryPool();
};

/* memory system class with memory pools support */
class OSS_DECLSPEC OssPoolMemorySystem : public OssMemorySystem {
private:
    int initflag;
public:
    OssPoolMemorySystem();
    virtual ~OssPoolMemorySystem();
    virtual void *asn1_malloc(size_t size);
    virtual void asn1_free(void *ptr);
    virtual void *asn1_realloc(void *ptr, size_t oldsize, size_t size);
};

/* "ordinary" unsynchronized memory Pool */
class OSS_DECLSPEC OssSimpleMemoryPool : public OssMemoryPool {
private:
    size_t 	chunkLength;	 /* provided by user in 'create' */
    size_t	system_allocated;/* total length of all allocated blocks */
    unsigned int nodes;		 /* total number of allocated blocks */
    void	*head;		 /* first block of memory */
    char	*xlast;		 /* optimization data */
    int 	getBlock(size_t size);
    int		detach();
public:
    OssSimpleMemoryPool(size_t chunk);
    void *alloc(size_t size);
    void dealloc(void *ptr);
    void clean();
    ~OssSimpleMemoryPool();
};

/* These function is for internal use */
extern "C" {
    void OSS_DECLSPEC * DLL_ENTRY osscppMalloc(size_t size);
    void OSS_DECLSPEC * DLL_ENTRY osscppRealloc(void *ptr, size_t oldsize, size_t size);
}

#endif /* __ASN1MEM_H */

