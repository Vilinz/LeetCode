/*****************************************************************************/
/* Copyright (C) 2019 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC. AND                */
/* MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.                 */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/*****************************************************************************/
/* FILE: @(#)ossltype.h	17.6  18/09/17                                      */
/*****************************************************************************/
/** @file
 *  @brief  Declarations and prototypes of LEAN encoder/decoder functions.
 *
 */

#ifndef OSSLTYPE_H
#define OSSLTYPE_H
#include "ossasn1.h"

/* BER decoder function references */
#define LEAN_TYPE_NOT_SUPPORTED_BER_DEC         ossBerDecTypeNotSupported
#define LEAN_INTEGER_BER_DEC                    ossBerDecIntegerEnumerated
#define LEAN_NULL_BER_DEC                       ossBerDecNull
#define LEAN_ENUMERATED_BER_DEC                 ossBerDecIntegerEnumerated
#define LEAN_REAL_BER_DEC                       ossBerDecReal
#define LEAN_BOOLEAN_BER_DEC                    ossBerDecBoolean
#define LEAN_SEQUENCE_BER_DEC                   ossBerDecSequence
#define LEAN_CHOICE_BER_DEC                     ossBerDecChoice
#define LEAN_LINKED_SEQUENCE_OF_BER_DEC         ossBerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_BER_DEC      ossBerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_BER_DEC ossBerDecUnboundedOctetString
#define LEAN_UNSIGNED_INTEGER_BER_DEC           ossBerDecUIntegerEnumerated
#define LEAN_UNSIGNED_ENUMERATED_BER_DEC        ossBerDecUIntegerEnumerated
#define LEAN_DECIMAL_REAL_BER_DEC               ossBerDecDecimalReal
#define LEAN_DEFERRED_TYPE_BER_DEC              ossBerDecDeferredType
#define LEAN_DEFERRED_OBJECT_BER_DEC            ossBerDecDeferredType
#define LEAN_LONGLONG_INTEGER_BER_DEC           ossBerDecLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_BER_DEC  ossBerDecULLInteger
#define LEAN_ANY_INTEGER_BER_DEC                ossBerDecAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_BER_DEC       ossBerDecUAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_BER_DEC	ossBerDecDlinkedPlusSetSequenceOf


extern void CDECL_ENTRY ossBerDecTypeNotSupported(void);
extern void CDECL_ENTRY ossBerDecNull(void);
extern void CDECL_ENTRY ossBerDecUnboundedBitString(void);
extern void CDECL_ENTRY ossBerDecBMPUniversalString(void);
extern void CDECL_ENTRY ossBerDecNullTermTime(void);
extern void CDECL_ENTRY ossBerDecUnboundedAny(void);
extern void CDECL_ENTRY ossBerDecSet(void);
extern void CDECL_ENTRY ossBerDecContentConstraint(void);
extern void CDECL_ENTRY ossBerDecDeferredType(void);
extern void CDECL_ENTRY ossBerDecDlinkedPlusSetSequenceOf(void);
extern void CDECL_ENTRY ossBerDecIntegerEnumerated(void);
extern void CDECL_ENTRY ossBerDecUIntegerEnumerated(void);
extern void CDECL_ENTRY ossBerDecBoolean(void);
extern void CDECL_ENTRY ossBerDecUnboundedOctetString(void);
extern void CDECL_ENTRY ossBerDecSequence(void);
extern void CDECL_ENTRY ossBerDecChoice(void);
extern void CDECL_ENTRY ossBerDecLinkedUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossBerDecReal(void);
extern void CDECL_ENTRY ossBerDecDecimalReal(void);
extern void CDECL_ENTRY ossBerDecLLInteger(void);
extern void CDECL_ENTRY ossBerDecULLInteger(void);
extern void CDECL_ENTRY ossBerDecAnyInteger(void);
extern void CDECL_ENTRY ossBerDecUAnyInteger(void);
extern void CDECL_ENTRY ossBerDecNulltermISO8601Time(void);

/* BER encoder function references */
#define LEAN_TYPE_NOT_SUPPORTED_BER_ENC         ossBerEncTypeNotSupported
#define LEAN_INTEGER_BER_ENC                    ossBerEncIntegerEnumerated
#define LEAN_NULL_BER_ENC                       ossBerEncNull
#define LEAN_ENUMERATED_BER_ENC                 ossBerEncIntegerEnumerated
#define LEAN_REAL_BER_ENC                       ossBerEncReal
#define LEAN_BOOLEAN_BER_ENC                    ossBerEncBoolean
#define LEAN_SEQUENCE_BER_ENC                   ossBerEncSetSequence
#define LEAN_CHOICE_BER_ENC                     ossBerEncChoice
#define LEAN_LINKED_SEQUENCE_OF_BER_ENC         ossBerEncLinkedSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_BER_ENC      ossBerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_BER_ENC ossBerEncUnboundedOctetString
#define LEAN_UNSIGNED_INTEGER_BER_ENC           ossBerEncUIntegerEnumerated
#define LEAN_UNSIGNED_ENUMERATED_BER_ENC        ossBerEncUIntegerEnumerated
#define LEAN_DECIMAL_REAL_BER_ENC               ossBerEncDecimalReal
#define LEAN_DEFERRED_TYPE_BER_ENC              ossBerEncDeferredType
#define LEAN_DEFERRED_OBJECT_BER_ENC            ossBerEncDeferredType
#define LEAN_LONGLONG_INTEGER_BER_ENC           ossBerEncLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_BER_ENC  ossBerEncULLInteger
#define LEAN_ANY_INTEGER_BER_ENC                ossBerEncAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_BER_ENC       ossBerEncUAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_BER_ENC	ossBerEncLinkedSetSequenceOf

extern void CDECL_ENTRY ossBerEncTypeNotSupported(void);
extern void CDECL_ENTRY ossBerEncIntegerEnumerated(void);
extern void CDECL_ENTRY ossBerEncNull(void);
extern void CDECL_ENTRY ossBerEncUnboundedBitString(void);
extern void CDECL_ENTRY ossBerEncUnboundedAny(void);
extern void CDECL_ENTRY ossBerEncUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossBerEncNullTermTime(void);
extern void CDECL_ENTRY ossBerEncOpenType(void);
extern void CDECL_ENTRY ossBerEncBMPUniversalString(void);
extern void CDECL_ENTRY ossBerEncDeferredType(void);
extern void CDECL_ENTRY ossBerEncContentConstraint(void);
extern void CDECL_ENTRY ossBerEncObjectIdentifier(void);
extern void CDECL_ENTRY ossBerEncReal(void);
extern void CDECL_ENTRY ossBerEncBoolean(void);
extern void CDECL_ENTRY ossBerEncSetSequence(void);
extern void CDECL_ENTRY ossBerEncChoice(void);
extern void CDECL_ENTRY ossBerEncLinkedSetSequenceOf(void);
extern void CDECL_ENTRY ossBerEncUnboundedOctetString(void);
extern void CDECL_ENTRY ossBerEncUIntegerEnumerated(void);
extern void CDECL_ENTRY ossBerEncDecimalReal(void);
extern void CDECL_ENTRY ossBerEncHugeInteger(void);
extern void CDECL_ENTRY ossBerEncLLInteger(void);
extern void CDECL_ENTRY ossBerEncULLInteger(void);
extern void CDECL_ENTRY ossBerEncAnyInteger(void);
extern void CDECL_ENTRY ossBerEncUAnyInteger(void);
extern void CDECL_ENTRY ossBerEncNulltermISO8601Time(void);

/* PER decoder function references */
#define LEAN_TYPE_NOT_SUPPORTED_PER_DEC         ossPerDecTypeNotSupported
#define LEAN_INTEGER_PER_DEC                    ossPerDecInteger
#define LEAN_NULL_PER_DEC                       ossPerDecNull
#define LEAN_ENUMERATED_PER_DEC                 ossPerDecEnumerated
#define LEAN_REAL_PER_DEC                       ossPerDecReal
#define LEAN_BOOLEAN_PER_DEC                    ossPerDecBoolean
#define LEAN_SEQUENCE_PER_DEC                   ossPerDecSetSequence
#define LEAN_CHOICE_PER_DEC                     ossPerDecChoice
#define LEAN_LINKED_SEQUENCE_OF_PER_DEC         ossPerDecSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_PER_DEC      ossPerDecUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_PER_DEC ossPerDecPrintableString
#define LEAN_UNSIGNED_INTEGER_PER_DEC           ossPerDecInteger
#define LEAN_UNSIGNED_ENUMERATED_PER_DEC        ossPerDecEnumerated
#define LEAN_DECIMAL_REAL_PER_DEC               ossPerDecCharReal
#define LEAN_DEFERRED_TYPE_PER_DEC              ossPerDecTypeNotSupported
#define LEAN_DEFERRED_OBJECT_PER_DEC            ossPerDecTypeNotSupported
#define LEAN_LONGLONG_INTEGER_PER_DEC           ossPerDecLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_PER_DEC  ossPerDecLLInteger
#define LEAN_ANY_INTEGER_PER_DEC                ossPerDecAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_PER_DEC       ossPerDecAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_PER_DEC	ossPerDecDlinkedPlusSetSequenceOf

extern void CDECL_ENTRY ossPerDecTypeNotSupported(void);
extern void CDECL_ENTRY ossPerDecInteger(void);
extern void CDECL_ENTRY ossPerDecBitString(void);
extern void CDECL_ENTRY ossPerDecAny(void);
extern void CDECL_ENTRY ossPerDecUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossPerDecNull(void);
extern void CDECL_ENTRY ossPerDecOpenType(void);
extern void CDECL_ENTRY ossPerDecWideCharacterString(void);
extern void CDECL_ENTRY ossPerDecNulltermTime(void);
extern void CDECL_ENTRY ossPerDecContentConstraint(void);
extern void CDECL_ENTRY ossPerDecDlinkedPlusSetSequenceOf(void);
extern void CDECL_ENTRY ossPerDecObjectIdentifier(void);
extern void CDECL_ENTRY ossPerDecEnumerated(void);
extern void CDECL_ENTRY ossPerDecBoolean(void);
extern void CDECL_ENTRY ossPerDecSetSequence(void);
extern void CDECL_ENTRY ossPerDecChoice(void);
extern void CDECL_ENTRY ossPerDecSetSequenceOf(void);
extern void CDECL_ENTRY ossPerDecOctetString(void);
extern void CDECL_ENTRY ossPerDecPrintableString(void);
extern void CDECL_ENTRY ossPerDecHugeInteger(void);
extern void CDECL_ENTRY ossPerDecCharReal(void);
extern void CDECL_ENTRY ossPerDecReal(void);
extern void CDECL_ENTRY ossPerDecLLInteger(void);
extern void CDECL_ENTRY ossPerDecAnyInteger(void);
extern void CDECL_ENTRY ossPerDecNulltermISO8601Time(void);

/* PER encoder function references */
#define LEAN_TYPE_NOT_SUPPORTED_PER_ENC         ossPerEncTypeNotSupported
#define LEAN_INTEGER_PER_ENC                    ossPerEncInteger
#define LEAN_NULL_PER_ENC                       ossPerEncNull
#define LEAN_ENUMERATED_PER_ENC                 ossPerEncEnumerated
#define LEAN_REAL_PER_ENC                       ossPerEncReal
#define LEAN_BOOLEAN_PER_ENC                    ossPerEncBoolean
#define LEAN_SEQUENCE_PER_ENC                   ossPerEncSetSequence
#define LEAN_CHOICE_PER_ENC                     ossPerEncChoice
#define LEAN_LINKED_SEQUENCE_OF_PER_ENC         ossPerEncSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_PER_ENC      ossPerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_PER_ENC ossPerEncPrintableString
#define LEAN_UNSIGNED_INTEGER_PER_ENC           ossPerEncInteger
#define LEAN_UNSIGNED_ENUMERATED_PER_ENC        ossPerEncEnumerated
#define LEAN_DECIMAL_REAL_PER_ENC               ossPerEncCharReal
#define LEAN_DEFERRED_TYPE_PER_ENC              ossPerEncTypeNotSupported
#define LEAN_DEFERRED_OBJECT_PER_ENC            ossPerEncTypeNotSupported
#define LEAN_LONGLONG_INTEGER_PER_ENC           ossPerEncLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_PER_ENC  ossPerEncLLInteger
#define LEAN_ANY_INTEGER_PER_ENC                ossPerEncAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_PER_ENC       ossPerEncAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_PER_ENC	ossPerEncSetSequenceOf

extern void CDECL_ENTRY ossPerEncInteger(void);
extern void CDECL_ENTRY ossPerEncBitString(void);
extern void CDECL_ENTRY ossPerEncAny(void);
extern void CDECL_ENTRY ossPerEncUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossPerEncNull(void);
extern void CDECL_ENTRY ossPerEncOpenType(void);
extern void CDECL_ENTRY ossPerEncWideCharacterString(void);
extern void CDECL_ENTRY ossPerEncNulltermTime(void);
extern void CDECL_ENTRY ossPerEncContentConstraint(void);
extern void CDECL_ENTRY ossPerEncObjectIdentifier(void);
extern void CDECL_ENTRY ossPerEncEnumerated(void);
extern void CDECL_ENTRY ossPerEncBoolean(void);
extern void CDECL_ENTRY ossPerEncSetSequence(void);
extern void CDECL_ENTRY ossPerEncChoice(void);
extern void CDECL_ENTRY ossPerEncSetSequenceOf(void);
extern void CDECL_ENTRY ossPerEncOctetString(void);
extern void CDECL_ENTRY ossPerEncPrintableString(void);
extern void CDECL_ENTRY ossPerEncHugeInteger(void);
extern void CDECL_ENTRY ossPerEncReal(void);
extern void CDECL_ENTRY ossPerEncCharReal(void);
extern void CDECL_ENTRY ossPerEncTypeNotSupported(void);
extern void CDECL_ENTRY ossPerEncLLInteger(void);
extern void CDECL_ENTRY ossPerEncAnyInteger(void);
extern void CDECL_ENTRY ossPerEncNulltermISO8601Time(void);

/* XER decoder function references */
#define LEAN_TYPE_NOT_SUPPORTED_XER_DEC         ossXerDecTypeNotSupported
#define LEAN_INTEGER_XER_DEC                    ossXerDecInteger
#define LEAN_NULL_XER_DEC                       ossXerDecNull
#define LEAN_ENUMERATED_XER_DEC                 ossXerDecEnumerated
#define LEAN_REAL_XER_DEC                       ossXerDecReal
#define LEAN_BOOLEAN_XER_DEC                    ossXerDecBoolean
#define LEAN_SEQUENCE_XER_DEC                   ossXerDecSeqSet
#define LEAN_CHOICE_XER_DEC                     ossXerDecChoice
#define LEAN_LINKED_SEQUENCE_OF_XER_DEC         ossXerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_XER_DEC      ossXerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_XER_DEC ossXerDecUnboundedCharString
#define LEAN_UNSIGNED_INTEGER_XER_DEC           ossXerDecInteger
#define LEAN_UNSIGNED_ENUMERATED_XER_DEC        ossXerDecEnumerated
#define LEAN_DECIMAL_REAL_XER_DEC               ossXerDecReal
#define LEAN_DEFERRED_TYPE_XER_DEC              ossXerDecDeferredType
#define LEAN_DEFERRED_OBJECT_XER_DEC            ossXerDecDeferredType
#define LEAN_LONGLONG_INTEGER_XER_DEC           ossXerDecLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_XER_DEC  ossXerDecLLInteger
#define LEAN_ANY_INTEGER_XER_DEC                ossXerDecAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_XER_DEC       ossXerDecAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_XER_DEC	ossXerDecDlinkedPlusSetSequenceOf

extern void CDECL_ENTRY ossXerDecTypeNotSupported(void);
extern void CDECL_ENTRY ossXerDecNull(void);
extern void CDECL_ENTRY ossXerDecInteger(void);
extern void CDECL_ENTRY ossXerDecEnumerated(void);
extern void CDECL_ENTRY ossXerDecBoolean(void);
extern void CDECL_ENTRY ossXerDecUnboundedOctetString(void);
extern void CDECL_ENTRY ossXerDecHugeInteger(void);
extern void CDECL_ENTRY ossXerDecUnboundedBitString(void);
extern void CDECL_ENTRY ossXerDecUnboundedCharString(void);
extern void CDECL_ENTRY ossXerDecUnboundedXCharString(void);
extern void CDECL_ENTRY ossXerDecNullTermTime(void);
extern void CDECL_ENTRY ossXerDecUnboundedAny(void);
extern void CDECL_ENTRY ossXerDecSeqSet(void);
extern void CDECL_ENTRY ossXerDecChoice(void);
extern void CDECL_ENTRY ossXerDecLinkedUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossXerDecDeferredType(void);
extern void CDECL_ENTRY ossXerDecReal(void);
extern void CDECL_ENTRY ossXerDecContentConstraint(void);
extern void CDECL_ENTRY ossXerDecLLInteger(void);
extern void CDECL_ENTRY ossXerDecAnyInteger(void);
extern void CDECL_ENTRY ossXerDecEncodedObjid(void);
extern void CDECL_ENTRY ossXerDecDlinkedPlusSetSequenceOf(void);
extern void CDECL_ENTRY ossXerDecNulltermISO8601Time(void);

/* XER encoder function references */
#define LEAN_TYPE_NOT_SUPPORTED_XER_ENC         ossXerEncTypeNotSupported
#define LEAN_INTEGER_XER_ENC                    ossXerEncInteger
#define LEAN_NULL_XER_ENC                       ossXerEncTypeNotSupported
#define LEAN_ENUMERATED_XER_ENC                 ossXerEncEnumerated
#define LEAN_REAL_XER_ENC                       ossXerEncReal
#define LEAN_BOOLEAN_XER_ENC                    ossXerEncBoolean
#define LEAN_SEQUENCE_XER_ENC                   ossXerEncSetSequence
#define LEAN_CHOICE_XER_ENC                     ossXerEncChoice
#define LEAN_LINKED_SEQUENCE_OF_XER_ENC         ossXerEncLinkedSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_XER_ENC      ossXerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_XER_ENC ossXerEncUnboundedCharString
#define LEAN_UNSIGNED_INTEGER_XER_ENC           ossXerEncInteger
#define LEAN_UNSIGNED_ENUMERATED_XER_ENC        ossXerEncEnumerated
#define LEAN_DECIMAL_REAL_XER_ENC               ossXerEncDecimalReal
#define LEAN_DEFERRED_TYPE_XER_ENC              ossXerEncDeferredType
#define LEAN_DEFERRED_OBJECT_XER_ENC            ossXerEncDeferredType
#define LEAN_LONGLONG_INTEGER_XER_ENC           ossXerEncLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_XER_ENC  ossXerEncLLInteger
#define LEAN_ANY_INTEGER_XER_ENC                ossXerEncAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_XER_ENC       ossXerEncAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_XER_ENC	ossXerEncLinkedSetSequenceOf

extern void CDECL_ENTRY ossXerEncTypeNotSupported(void);
extern void CDECL_ENTRY ossXerEncInteger(void);
extern void CDECL_ENTRY ossXerEncEnumerated(void);
extern void CDECL_ENTRY ossXerEncUnboundedBitString(void);
extern void CDECL_ENTRY ossXerEncReal(void);
extern void CDECL_ENTRY ossXerEncBoolean(void);
extern void CDECL_ENTRY ossXerEncUnboundedAny(void);
extern void CDECL_ENTRY ossXerEncSetSequence(void);
extern void CDECL_ENTRY ossXerEncChoice(void);
extern void CDECL_ENTRY ossXerEncLinkedSetSequenceOf(void);
extern void CDECL_ENTRY ossXerEncUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossXerEncUnboundedOctetString(void);
extern void CDECL_ENTRY ossXerEncNullTermTime(void);
extern void CDECL_ENTRY ossXerEncUnboundedCharString(void);
extern void CDECL_ENTRY ossXerEncOpenType(void);
extern void CDECL_ENTRY ossXerEncUTF8String(void);
extern void CDECL_ENTRY ossXerEncDecimalReal(void);
extern void CDECL_ENTRY ossXerEncHugeInteger(void);
extern void CDECL_ENTRY ossXerEncObjectIdentifier(void);
extern void CDECL_ENTRY ossXerEncDeferredType(void);
extern void CDECL_ENTRY ossXerEncContentConstraint(void);
extern void CDECL_ENTRY ossXerEncLLInteger(void);
extern void CDECL_ENTRY ossXerEncAnyInteger(void);
extern void CDECL_ENTRY ossXerEncNulltermISO8601Time(void);

/* EXER decoder function references */
#define LEAN_TYPE_NOT_SUPPORTED_EXER_DEC         ossEXerDecTypeNotSupported
#define LEAN_INTEGER_EXER_DEC                    ossEXerDecInteger
#define LEAN_NULL_EXER_DEC                       ossEXerDecNull
#define LEAN_ENUMERATED_EXER_DEC                 ossEXerDecInteger
#define LEAN_REAL_EXER_DEC                       ossEXerDecReal
#define LEAN_BOOLEAN_EXER_DEC                    ossEXerDecBoolean
#define LEAN_SEQUENCE_EXER_DEC                   ossEXerDecSequence
#define LEAN_CHOICE_EXER_DEC                     ossEXerDecChoice
#define LEAN_LINKED_SEQUENCE_OF_EXER_DEC         ossEXerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_EXER_DEC      ossEXerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_EXER_DEC ossEXerDecUnboundedCharString
#define LEAN_UNSIGNED_INTEGER_EXER_DEC           ossEXerDecInteger
#define LEAN_UNSIGNED_ENUMERATED_EXER_DEC        ossEXerDecInteger
#define LEAN_DECIMAL_REAL_EXER_DEC               ossEXerDecCharReal
#define LEAN_DEFERRED_TYPE_EXER_DEC              ossEXerDecTypeNotSupported
#define LEAN_DEFERRED_OBJECT_EXER_DEC            ossEXerDecTypeNotSupported
#define LEAN_LONGLONG_INTEGER_EXER_DEC           ossEXerDecLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_EXER_DEC  ossEXerDecLLInteger
#define LEAN_ANY_INTEGER_EXER_DEC                ossEXerDecAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_EXER_DEC       ossEXerDecAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_EXER_DEC	 ossEXerDecDlinkedPlusSetSequenceOf

extern void CDECL_ENTRY ossEXerDecTypeNotSupported(void);
extern void CDECL_ENTRY ossEXerDecNull(void);
extern void CDECL_ENTRY ossEXerDecNullTermTime(void);
extern void CDECL_ENTRY ossEXerDecUnboundedBitString(void);
extern void CDECL_ENTRY ossEXerDecUnboundedXCharString(void);
extern void CDECL_ENTRY ossEXerDecUnboundedAny(void);
extern void CDECL_ENTRY ossEXerDecContentConstraint(void);
extern void CDECL_ENTRY ossEXerDecDlinkedPlusSetSequenceOf(void);
extern void CDECL_ENTRY ossEXerDecEncodedObjid(void);
extern void CDECL_ENTRY ossEXerDecSet(void);
extern void CDECL_ENTRY ossEXerDecInteger(void);
extern void CDECL_ENTRY ossEXerDecBoolean(void);
extern void CDECL_ENTRY ossEXerDecUnboundedOctetString(void);
extern void CDECL_ENTRY ossEXerDecHugeInteger(void);
extern void CDECL_ENTRY ossEXerDecUnboundedCharString(void);
extern void CDECL_ENTRY ossEXerDecSequence(void);
extern void CDECL_ENTRY ossEXerDecChoice(void);
extern void CDECL_ENTRY ossEXerDecLinkedUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossEXerDecReal(void);
extern void CDECL_ENTRY ossEXerDecCharReal(void);
extern void CDECL_ENTRY ossEXerDecLLInteger(void);
extern void CDECL_ENTRY ossEXerDecAnyInteger(void);

/* EXER encoder function references */
#define LEAN_TYPE_NOT_SUPPORTED_EXER_ENC         ossEXerEncTypeNotSupported
#define LEAN_INTEGER_EXER_ENC                    ossEXerEncInteger
#define LEAN_NULL_EXER_ENC                       ossEXerEncNull
#define LEAN_ENUMERATED_EXER_ENC                 ossEXerEncEnumerated
#define LEAN_REAL_EXER_ENC                       ossEXerEncReal
#define LEAN_BOOLEAN_EXER_ENC                    ossEXerEncNormalEnum
#define LEAN_SEQUENCE_EXER_ENC                   ossEXerEncSetSequence
#define LEAN_CHOICE_EXER_ENC                     ossEXerEncChoice
#define LEAN_LINKED_SEQUENCE_OF_EXER_ENC         ossEXerEncLinkedSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_EXER_ENC      ossEXerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_EXER_ENC ossEXerEncUnboundedCharString
#define LEAN_UNSIGNED_INTEGER_EXER_ENC           ossEXerEncInteger
#define LEAN_UNSIGNED_ENUMERATED_EXER_ENC        ossEXerEncEnumerated
#define LEAN_DECIMAL_REAL_EXER_ENC               ossEXerEncDecimalReal
#define LEAN_DEFERRED_TYPE_EXER_ENC              ossEXerEncTypeNotSupported
#define LEAN_DEFERRED_OBJECT_EXER_ENC            ossEXerEncTypeNotSupported
#define LEAN_LONGLONG_INTEGER_EXER_ENC           ossEXerEncInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_EXER_ENC  ossEXerEncInteger
#define LEAN_ANY_INTEGER_EXER_ENC                ossEXerEncInteger
#define LEAN_UNSIGNED_ANY_INTEGER_EXER_ENC       ossEXerEncInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_EXER_ENC	 ossEXerEncLinkedSetSequenceOf

extern void CDECL_ENTRY ossEXerEncTypeNotSupported(void);
extern void CDECL_ENTRY ossEXerEncInteger(void);
extern void CDECL_ENTRY ossEXerEncEnumerated(void);
extern void CDECL_ENTRY ossEXerEncNull(void);
extern void CDECL_ENTRY ossEXerEncUnboundedBitString(void);
extern void CDECL_ENTRY ossEXerEncUnboundedAny(void);
extern void CDECL_ENTRY ossEXerEncUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossEXerEncNullTermTime(void);
extern void CDECL_ENTRY ossEXerEncOpenType(void);
extern void CDECL_ENTRY ossEXerEncUnboundedWCharString(void);
extern void CDECL_ENTRY ossEXerEncContentConstraint(void);
extern void CDECL_ENTRY ossEXerEncObjectIdentifier(void);
extern void CDECL_ENTRY ossEXerEncReal(void);
extern void CDECL_ENTRY ossEXerEncSetSequence(void);
extern void CDECL_ENTRY ossEXerEncChoice(void);
extern void CDECL_ENTRY ossEXerEncLinkedSetSequenceOf(void);
extern void CDECL_ENTRY ossEXerEncUnboundedOctetString(void);
extern void CDECL_ENTRY ossEXerEncUnboundedCharString(void);
extern void CDECL_ENTRY ossEXerEncDecimalReal(void);
extern void CDECL_ENTRY ossEXerEncHugeInteger(void);
extern void CDECL_ENTRY ossEXerEncAnyInteger(void);
extern void CDECL_ENTRY ossEXerEncNulltermISO8601Time(void);

/* EXER decoder i-kind function references */
#define LEAN_NORMAL_INT_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_NORMAL_ENUM_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_BASE64_UNBND_CHAR_EXER_DEC		ossEXerDecBase64UnbndChar
#define LEAN_NORMAL_UNBND_CHAR_EXER_DEC		ossEXerDecNormalUnbndChar
#define LEAN_BASE64_UNBND_OCTET_EXER_DEC	ossEXerDecBase64UnbndOctetString
#define LEAN_NORMAL_UNBND_OCTET_EXER_DEC	ossEXerDecNormalUnbndOctetString
#define LEAN_BASE64_PAD_CHAR_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_NORMAL_PAD_CHAR_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_BASE64_NLLTRM_CHAR_EXER_DEC	ossEXerDecTypeNotSupported
#define LEAN_NORMAL_NLLTRM_CHAR_EXER_DEC	ossEXerDecTypeNotSupported
#define LEAN_ANYEL_NLLTRM_CHAR_EXER_DEC		ossEXerDecAnyElementCharString
#define LEAN_BASE64_4BYTE_CHAR_EXER_DEC		ossEXerDecBase64UnbdXCharString
#define LEAN_NORMAL_4BYTE_CHAR_EXER_DEC		ossEXerDecNormalUnbdXCharString
#define LEAN_USEORDER_SEQ_EXER_DEC		ossEXerDecSet
#define LEAN_QNAME_SEQ_EXER_DEC			ossEXerDecQnameSequence
#define LEAN_NORMAL_SEQ_EXER_DEC		ossEXerDecNormalSequence
#define LEAN_ANYATTR_LINK_SOF_EXER_DEC		ossEXerDecAnyAttrUnbndCharString
#define LEAN_NORMAL_LINK_SOF_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_BASE64_OPENTYPE_EXER_DEC		ossEXerDecBase64UnbndOctetString
#define LEAN_NORMAL_OPENTYPE_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_NORMAL_REAL_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_MODIFIED_REAL_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_NORMAL_CHAR_REAL_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_MODIFIED_CHAR_REAL_EXER_DEC	ossEXerDecTypeNotSupported
#define LEAN_DECIMAL_CHAR_REAL_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_NORMAL_LONGLONG_INT_EXER_DEC	ossEXerDecTypeNotSupported
#define LEAN_NORMAL_LONGLONG_ENUM_EXER_DEC	ossEXerDecTypeNotSupported
#define LEAN_NORMAL_ANY_INT_EXER_DEC		ossEXerDecTypeNotSupported
#define LEAN_NORMAL_ANY_ENUM_EXER_DEC		ossEXerDecTypeNotSupported

/* ossLeanCopyValue - is used for USE-UNION & DEFAULT-FOR-EMPTY *
 * generate instead of LEAN_NORMAL_PAD_CHAR_EXER_DEC            */
#define LEAN_CPY_VAL_EXER_DEC			ossLeanCopyValue


extern void CDECL_ENTRY ossEXerDecNormalUnbndChar(void);
extern void CDECL_ENTRY ossEXerDecBase64UnbndChar(void);
extern void CDECL_ENTRY ossEXerDecNormalUnbdXCharString(void);
extern void CDECL_ENTRY ossEXerDecBase64UnbdXCharString(void);
extern void CDECL_ENTRY ossEXerDecAnyElementCharString(void);
extern void CDECL_ENTRY ossEXerDecNormalSequence(void);
extern void CDECL_ENTRY ossEXerDecQnameSequence(void);
extern void CDECL_ENTRY ossEXerDecAnyAttrUnbndCharString(void);
extern void CDECL_ENTRY ossEXerDecNormalUnbndOctetString(void);
extern void CDECL_ENTRY ossEXerDecBase64UnbndOctetString(void);
extern void CDECL_ENTRY ossLeanCopyValue(void);

/* EXER encoder i-kind function references */
#define LEAN_NORMAL_INT_EXER_ENC		ossEXerEncNormalInteger
#define LEAN_NORMAL_ENUM_EXER_ENC		ossEXerEncNormalEnum
#define LEAN_BASE64_UNBND_CHAR_EXER_ENC		ossEXerEncBase64UnbndChar
#define LEAN_NORMAL_UNBND_CHAR_EXER_ENC		ossEXerEncNormalUnbndChar
#define LEAN_BASE64_UNBND_OCTET_EXER_ENC	ossEXerEncBase64UnbndOctet
#define LEAN_NORMAL_UNBND_OCTET_EXER_ENC	ossEXerEncNormalUnbndOctet
#define LEAN_BASE64_PAD_CHAR_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_NORMAL_PAD_CHAR_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_BASE64_NLLTRM_CHAR_EXER_ENC	ossEXerEncTypeNotSupported
#define LEAN_NORMAL_NLLTRM_CHAR_EXER_ENC	ossEXerEncNormalUnbndChar
#define LEAN_ANYEL_NLLTRM_CHAR_EXER_ENC		ossEXerEncAnyelUnbndChar
#define LEAN_BASE64_4BYTE_CHAR_EXER_ENC		ossEXerEncBase64UnbndXCharString
#define LEAN_NORMAL_4BYTE_CHAR_EXER_ENC		ossEXerEncNormalUnbndXCharString
#define LEAN_USEORDER_SEQ_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_QNAME_SEQ_EXER_ENC			ossEXerEncQNnameSeq
#define LEAN_NORMAL_SEQ_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_ANYATTR_LINK_SOF_EXER_ENC		ossEXerEncAnyattrUnbndChar
#define LEAN_NORMAL_LINK_SOF_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_BASE64_OPENTYPE_EXER_ENC		ossEXerEncBase64UnbndOctet
#define LEAN_NORMAL_OPENTYPE_EXER_ENC		ossEXerEncNormalUnbndOctet
#define LEAN_NORMAL_REAL_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_MODIFIED_REAL_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_NORMAL_CHAR_REAL_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_MODIFIED_CHAR_REAL_EXER_ENC	ossEXerEncTypeNotSupported
#define LEAN_DECIMAL_CHAR_REAL_EXER_ENC		ossEXerEncTypeNotSupported
#define LEAN_NORMAL_LONGLONG_INT_EXER_ENC	ossEXerEncAnyInteger
#define LEAN_NORMAL_LONGLONG_ENUM_EXER_ENC	ossEXerEncAnyEnum
#define LEAN_NORMAL_ANY_INT_EXER_ENC		ossEXerEncAnyInteger
#define LEAN_NORMAL_ANY_ENUM_EXER_ENC		ossEXerEncAnyEnum

extern void CDECL_ENTRY ossEXerEncNormalInteger(void);
extern void CDECL_ENTRY ossEXerEncNormalEnum(void);
extern void CDECL_ENTRY ossEXerEncAnyEnum(void);
extern void CDECL_ENTRY ossEXerEncNormalUnbndChar(void);
extern void CDECL_ENTRY ossEXerEncNormalUnbndOctet(void);
extern void CDECL_ENTRY ossEXerEncBase64UnbndOctet(void);
extern void CDECL_ENTRY ossEXerEncAnyelUnbndChar(void);
extern void CDECL_ENTRY ossEXerEncQNnameSeq(void);
extern void CDECL_ENTRY ossEXerEncAnyattrUnbndChar(void);

extern void CDECL_ENTRY ossEXerEncBase64UnbndChar(void);
extern void CDECL_ENTRY ossEXerEncNormalUnbndXCharString(void);
extern void CDECL_ENTRY ossEXerEncBase64UnbndXCharString(void);

/* PER time decoder function references */
#define LEAN_MIXED_PER_DEC                                    ossPerDecMixed
#define LEAN_CENTURY_PER_DEC                                  ossPerDecCentury
#define LEAN_ANY_CENTURY_PER_DEC                              ossPerDecAnyCentury
#define LEAN_YEAR_PER_DEC                                     ossPerDecYear
#define LEAN_ANY_YEAR_PER_DEC                                 ossPerDecAnyYear
#define LEAN_YEAR_MONTH_PER_DEC                               ossPerDecYearMonth
#define LEAN_ANY_YEAR_MONTH_PER_DEC                           ossPerDecAnyYearMonth
#define LEAN_DATE_PER_DEC                                     ossPerDecDate
#define LEAN_ANY_DATE_PER_DEC                                 ossPerDecAnyDate
#define LEAN_YEAR_DAY_PER_DEC                                 ossPerDecYearDay
#define LEAN_ANY_YEAR_DAY_PER_DEC                             ossPerDecAnyYearDay
#define LEAN_YEAR_WEEK_PER_DEC                                ossPerDecYearWeek
#define LEAN_ANY_YEAR_WEEK_PER_DEC                            ossPerDecAnyYearWeek
#define LEAN_YEAR_WEEK_DAY_PER_DEC                            ossPerDecYearWeekDay
#define LEAN_ANY_YEAR_WEEK_DAY_PER_DEC                        ossPerDecAnyYearWeekDay
#define LEAN_HOURS_PER_DEC                                    ossPerDecHours
#define LEAN_HOURS_UTC_PER_DEC                                ossPerDecHoursUtc
#define LEAN_HOURS_AND_DIFF_PER_DEC                           ossPerDecHoursAndDiff
#define LEAN_MINUTES_PER_DEC                                  ossPerDecMinutes
#define LEAN_MINUTES_UTC_PER_DEC                              ossPerDecMinutesUtc
#define LEAN_MINUTES_AND_DIFF_PER_DEC                         ossPerDecMinutesAndDiff
#define LEAN_TIME_OF_DAY_PER_DEC                              ossPerDecTimeOfDay
#define LEAN_TIME_OF_DAY_UTC_PER_DEC                          ossPerDecTimeOfDayUtc
#define LEAN_TIME_OF_DAY_AND_DIFF_PER_DEC                     ossPerDecTimeOfDayAndDiff
#define LEAN_HOURS_AND_FRACTION_PER_DEC                       ossPerDecHoursAndFraction
#define LEAN_HOURS_UTC_AND_FRACTION_PER_DEC                   ossPerDecHoursUtcAndFraction
#define LEAN_HOURS_AND_DIFF_AND_FRACTION_PER_DEC              ossPerDecHoursAndDiffAndFraction
#define LEAN_MINUTES_AND_FRACTION_PER_DEC                     ossPerDecMinutesAndFraction
#define LEAN_MINUTES_UTC_AND_FRACTION_PER_DEC                 ossPerDecMinutesUtcAndFraction
#define LEAN_MINUTES_AND_DIFF_AND_FRACTION_PER_DEC            ossPerDecMinutesAndDiffAndFraction
#define LEAN_TIME_OF_DAY_AND_FRACTION_PER_DEC                 ossPerDecTimeOfDayAndFraction
#define LEAN_TIME_OF_DAY_UTC_AND_FRACTION_PER_DEC             ossPerDecTimeOfDayUtcAndFraction
#define LEAN_TIME_OF_DAY_AND_DIFF_AND_FRACTION_PER_DEC        ossPerDecTimeOfDayAndDiffAndFraction
#define LEAN_DATE_TIME_PER_DEC                                ossPerDecDateTime
#define LEAN_START_END_DATE_INTERVAL_PER_DEC                  ossPerDecStartEndDateInterval
#define LEAN_START_END_TIME_INTERVAL_PER_DEC                  ossPerDecStartEndTimeInterval
#define LEAN_START_END_DATE_TIME_INTERVAL_PER_DEC             ossPerDecStartEndDateTimeInterval
#define LEAN_DURATION_INTERVAL_PER_DEC                        ossPerDecDurationInterval
#define LEAN_START_DATE_DURATION_INTERVAL_PER_DEC             ossPerDecStartDateDurationInterval
#define LEAN_START_TIME_DURATION_INTERVAL_PER_DEC             ossPerDecStartTimeDurationInterval
#define LEAN_START_DATE_TIME_DURATION_INTERVAL_PER_DEC        ossPerDecStartDateTimeDurationInterval
#define LEAN_DURATION_END_DATE_INTERVAL_PER_DEC               ossPerDecDurationEndDateInterval
#define LEAN_DURATION_END_TIME_INTERVAL_PER_DEC               ossPerDecDurationEndTimeInterval
#define LEAN_DURATION_END_DATE_TIME_INTERVAL_PER_DEC          ossPerDecDurationEndDateTimeInterval
#define LEAN_REC_START_END_DATE_INTERVAL_PER_DEC              ossPerDecRecStartEndDateInterval
#define LEAN_REC_START_END_TIME_INTERVAL_PER_DEC              ossPerDecRecStartEndTimeInterval
#define LEAN_REC_START_END_DATE_TIME_INTERVAL_PER_DEC         ossPerDecRecStartEndDateTimeInterval
#define LEAN_REC_DURATION_INTERVAL_PER_DEC                    ossPerDecRecDurationInterval
#define LEAN_REC_START_DATE_DURATION_INTERVAL_PER_DEC         ossPerDecRecStartDateDurationInterval
#define LEAN_REC_START_TIME_DURATION_INTERVAL_PER_DEC         ossPerDecRecStartTimeDurationInterval
#define LEAN_REC_START_DATE_TIME_DURATION_INTERVAL_PER_DEC    ossPerDecRecStartDateTimeDurationInterval
#define LEAN_REC_DURATION_END_DATE_INTERVAL_PER_DEC           ossPerDecRecDurationEndDateInterval
#define LEAN_REC_DURATION_END_TIME_INTERVAL_PER_DEC           ossPerDecRecDurationEndTimeInterval
#define LEAN_REC_DURATION_END_DATE_TIME_INTERVAL_PER_DEC      ossPerDecRecDurationEndDateTimeInterval

extern void CDECL_ENTRY ossPerDecMixed(void);
extern void CDECL_ENTRY ossPerDecCentury(void);
extern void CDECL_ENTRY ossPerDecAnyCentury(void);
extern void CDECL_ENTRY ossPerDecYear(void);
extern void CDECL_ENTRY ossPerDecAnyYear(void);
extern void CDECL_ENTRY ossPerDecYearMonth(void);
extern void CDECL_ENTRY ossPerDecAnyYearMonth(void);
extern void CDECL_ENTRY ossPerDecDate(void);
extern void CDECL_ENTRY ossPerDecAnyDate(void);
extern void CDECL_ENTRY ossPerDecYearDay(void);
extern void CDECL_ENTRY ossPerDecAnyYearDay(void);
extern void CDECL_ENTRY ossPerDecYearWeek(void);
extern void CDECL_ENTRY ossPerDecAnyYearWeek(void);
extern void CDECL_ENTRY ossPerDecYearWeekDay(void);
extern void CDECL_ENTRY ossPerDecAnyYearWeekDay(void);
extern void CDECL_ENTRY ossPerDecHours(void);
extern void CDECL_ENTRY ossPerDecHoursUtc(void);
extern void CDECL_ENTRY ossPerDecHoursAndDiff(void);
extern void CDECL_ENTRY ossPerDecMinutes(void);
extern void CDECL_ENTRY ossPerDecMinutesUtc(void);
extern void CDECL_ENTRY ossPerDecMinutesAndDiff(void);
extern void CDECL_ENTRY ossPerDecTimeOfDay(void);
extern void CDECL_ENTRY ossPerDecTimeOfDayUtc(void);
extern void CDECL_ENTRY ossPerDecTimeOfDayAndDiff(void);
extern void CDECL_ENTRY ossPerDecHoursAndFraction(void);
extern void CDECL_ENTRY ossPerDecHoursUtcAndFraction(void);
extern void CDECL_ENTRY ossPerDecHoursAndDiffAndFraction(void);
extern void CDECL_ENTRY ossPerDecMinutesAndFraction(void);
extern void CDECL_ENTRY ossPerDecMinutesUtcAndFraction(void);
extern void CDECL_ENTRY ossPerDecMinutesAndDiffAndFraction(void);
extern void CDECL_ENTRY ossPerDecTimeOfDayAndFraction(void);
extern void CDECL_ENTRY ossPerDecTimeOfDayUtcAndFraction(void);
extern void CDECL_ENTRY ossPerDecTimeOfDayAndDiffAndFraction(void);
extern void CDECL_ENTRY ossPerDecDateTime(void);
extern void CDECL_ENTRY ossPerDecStartEndDateInterval(void);
extern void CDECL_ENTRY ossPerDecStartEndTimeInterval(void);
extern void CDECL_ENTRY ossPerDecStartEndDateTimeInterval(void);
extern void CDECL_ENTRY ossPerDecDurationInterval(void);
extern void CDECL_ENTRY ossPerDecStartDateDurationInterval(void);
extern void CDECL_ENTRY ossPerDecStartTimeDurationInterval(void);
extern void CDECL_ENTRY ossPerDecStartDateTimeDurationInterval(void);
extern void CDECL_ENTRY ossPerDecDurationEndDateInterval(void);
extern void CDECL_ENTRY ossPerDecDurationEndTimeInterval(void);
extern void CDECL_ENTRY ossPerDecDurationEndDateTimeInterval(void);
extern void CDECL_ENTRY ossPerDecRecStartEndDateInterval(void);
extern void CDECL_ENTRY ossPerDecRecStartEndTimeInterval(void);
extern void CDECL_ENTRY ossPerDecRecStartEndDateTimeInterval(void);
extern void CDECL_ENTRY ossPerDecRecDurationInterval(void);
extern void CDECL_ENTRY ossPerDecRecStartDateDurationInterval(void);
extern void CDECL_ENTRY ossPerDecRecStartTimeDurationInterval(void);
extern void CDECL_ENTRY ossPerDecRecStartDateTimeDurationInterval(void);
extern void CDECL_ENTRY ossPerDecRecDurationEndDateInterval(void);
extern void CDECL_ENTRY ossPerDecRecDurationEndTimeInterval(void);
extern void CDECL_ENTRY ossPerDecRecDurationEndDateTimeInterval(void);

/* PER time encoder function references */
#define LEAN_MIXED_PER_ENC                                    ossPerEncMixed
#define LEAN_CENTURY_PER_ENC                                  ossPerEncCentury
#define LEAN_ANY_CENTURY_PER_ENC                              ossPerEncAnyCentury
#define LEAN_YEAR_PER_ENC                                     ossPerEncYear
#define LEAN_ANY_YEAR_PER_ENC                                 ossPerEncAnyYear
#define LEAN_YEAR_MONTH_PER_ENC                               ossPerEncYearMonth
#define LEAN_ANY_YEAR_MONTH_PER_ENC                           ossPerEncAnyYearMonth
#define LEAN_DATE_PER_ENC                                     ossPerEncDate
#define LEAN_ANY_DATE_PER_ENC                                 ossPerEncAnyDate
#define LEAN_YEAR_DAY_PER_ENC                                 ossPerEncYearDay
#define LEAN_ANY_YEAR_DAY_PER_ENC                             ossPerEncAnyYearDay
#define LEAN_YEAR_WEEK_PER_ENC                                ossPerEncYearWeek
#define LEAN_ANY_YEAR_WEEK_PER_ENC                            ossPerEncAnyYearWeek
#define LEAN_YEAR_WEEK_DAY_PER_ENC                            ossPerEncYearWeekDay
#define LEAN_ANY_YEAR_WEEK_DAY_PER_ENC                        ossPerEncAnyYearWeekDay
#define LEAN_HOURS_PER_ENC                                    ossPerEncHours
#define LEAN_HOURS_UTC_PER_ENC                                ossPerEncHoursUtc
#define LEAN_HOURS_AND_DIFF_PER_ENC                           ossPerEncHoursAndDiff
#define LEAN_MINUTES_PER_ENC                                  ossPerEncMinutes
#define LEAN_MINUTES_UTC_PER_ENC                              ossPerEncMinutesUtc
#define LEAN_MINUTES_AND_DIFF_PER_ENC                         ossPerEncMinutesAndDiff
#define LEAN_TIME_OF_DAY_PER_ENC                              ossPerEncTimeOfDay
#define LEAN_TIME_OF_DAY_UTC_PER_ENC                          ossPerEncTimeOfDayUtc
#define LEAN_TIME_OF_DAY_AND_DIFF_PER_ENC                     ossPerEncTimeOfDayAndDiff
#define LEAN_HOURS_AND_FRACTION_PER_ENC                       ossPerEncHoursAndFraction
#define LEAN_HOURS_UTC_AND_FRACTION_PER_ENC                   ossPerEncHoursUtcAndFraction
#define LEAN_HOURS_AND_DIFF_AND_FRACTION_PER_ENC              ossPerEncHoursAndDiffAndFraction
#define LEAN_MINUTES_AND_FRACTION_PER_ENC                     ossPerEncMinutesAndFraction
#define LEAN_MINUTES_UTC_AND_FRACTION_PER_ENC                 ossPerEncMinutesUtcAndFraction
#define LEAN_MINUTES_AND_DIFF_AND_FRACTION_PER_ENC            ossPerEncMinutesAndDiffAndFraction
#define LEAN_TIME_OF_DAY_AND_FRACTION_PER_ENC                 ossPerEncTimeOfDayAndFraction
#define LEAN_TIME_OF_DAY_UTC_AND_FRACTION_PER_ENC             ossPerEncTimeOfDayUtcAndFraction
#define LEAN_TIME_OF_DAY_AND_DIFF_AND_FRACTION_PER_ENC        ossPerEncTimeOfDayAndDiffAndFraction
#define LEAN_DATE_TIME_PER_ENC                                ossPerEncDateTime
#define LEAN_START_END_DATE_INTERVAL_PER_ENC                  ossPerEncStartEndDateInterval
#define LEAN_START_END_TIME_INTERVAL_PER_ENC                  ossPerEncStartEndTimeInterval
#define LEAN_START_END_DATE_TIME_INTERVAL_PER_ENC             ossPerEncStartEndDateTimeInterval
#define LEAN_DURATION_INTERVAL_PER_ENC                        ossPerEncDurationInterval
#define LEAN_START_DATE_DURATION_INTERVAL_PER_ENC             ossPerEncStartDateDurationInterval
#define LEAN_START_TIME_DURATION_INTERVAL_PER_ENC             ossPerEncStartTimeDurationInterval
#define LEAN_START_DATE_TIME_DURATION_INTERVAL_PER_ENC        ossPerEncStartDateTimeDurationInterval
#define LEAN_DURATION_END_DATE_INTERVAL_PER_ENC               ossPerEncDurationEndDateInterval
#define LEAN_DURATION_END_TIME_INTERVAL_PER_ENC               ossPerEncDurationEndTimeInterval
#define LEAN_DURATION_END_DATE_TIME_INTERVAL_PER_ENC          ossPerEncDurationEndDateTimeInterval
#define LEAN_REC_START_END_DATE_INTERVAL_PER_ENC              ossPerEncRecStartEndDateInterval
#define LEAN_REC_START_END_TIME_INTERVAL_PER_ENC              ossPerEncRecStartEndTimeInterval
#define LEAN_REC_START_END_DATE_TIME_INTERVAL_PER_ENC         ossPerEncRecStartEndDateTimeInterval
#define LEAN_REC_DURATION_INTERVAL_PER_ENC                    ossPerEncRecDurationInterval
#define LEAN_REC_START_DATE_DURATION_INTERVAL_PER_ENC         ossPerEncRecStartDateDurationInterval
#define LEAN_REC_START_TIME_DURATION_INTERVAL_PER_ENC         ossPerEncRecStartTimeDurationInterval
#define LEAN_REC_START_DATE_TIME_DURATION_INTERVAL_PER_ENC    ossPerEncRecStartDateTimeDurationInterval
#define LEAN_REC_DURATION_END_DATE_INTERVAL_PER_ENC           ossPerEncRecDurationEndDateInterval
#define LEAN_REC_DURATION_END_TIME_INTERVAL_PER_ENC           ossPerEncRecDurationEndTimeInterval
#define LEAN_REC_DURATION_END_DATE_TIME_INTERVAL_PER_ENC      ossPerEncRecDurationEndDateTimeInterval

extern void CDECL_ENTRY ossPerEncMixed(void);
extern void CDECL_ENTRY ossPerEncCentury(void);
extern void CDECL_ENTRY ossPerEncAnyCentury(void);
extern void CDECL_ENTRY ossPerEncYear(void);
extern void CDECL_ENTRY ossPerEncAnyYear(void);
extern void CDECL_ENTRY ossPerEncYearMonth(void);
extern void CDECL_ENTRY ossPerEncAnyYearMonth(void);
extern void CDECL_ENTRY ossPerEncDate(void);
extern void CDECL_ENTRY ossPerEncAnyDate(void);
extern void CDECL_ENTRY ossPerEncYearDay(void);
extern void CDECL_ENTRY ossPerEncAnyYearDay(void);
extern void CDECL_ENTRY ossPerEncYearWeek(void);
extern void CDECL_ENTRY ossPerEncAnyYearWeek(void);
extern void CDECL_ENTRY ossPerEncYearWeekDay(void);
extern void CDECL_ENTRY ossPerEncAnyYearWeekDay(void);
extern void CDECL_ENTRY ossPerEncHours(void);
extern void CDECL_ENTRY ossPerEncHoursUtc(void);
extern void CDECL_ENTRY ossPerEncHoursAndDiff(void);
extern void CDECL_ENTRY ossPerEncMinutes(void);
extern void CDECL_ENTRY ossPerEncMinutesUtc(void);
extern void CDECL_ENTRY ossPerEncMinutesAndDiff(void);
extern void CDECL_ENTRY ossPerEncTimeOfDay(void);
extern void CDECL_ENTRY ossPerEncTimeOfDayUtc(void);
extern void CDECL_ENTRY ossPerEncTimeOfDayAndDiff(void);
extern void CDECL_ENTRY ossPerEncHoursAndFraction(void);
extern void CDECL_ENTRY ossPerEncHoursUtcAndFraction(void);
extern void CDECL_ENTRY ossPerEncHoursAndDiffAndFraction(void);
extern void CDECL_ENTRY ossPerEncMinutesAndFraction(void);
extern void CDECL_ENTRY ossPerEncMinutesUtcAndFraction(void);
extern void CDECL_ENTRY ossPerEncMinutesAndDiffAndFraction(void);
extern void CDECL_ENTRY ossPerEncTimeOfDayAndFraction(void);
extern void CDECL_ENTRY ossPerEncTimeOfDayUtcAndFraction(void);
extern void CDECL_ENTRY ossPerEncTimeOfDayAndDiffAndFraction(void);
extern void CDECL_ENTRY ossPerEncDateTime(void);
extern void CDECL_ENTRY ossPerEncStartEndDateInterval(void);
extern void CDECL_ENTRY ossPerEncStartEndTimeInterval(void);
extern void CDECL_ENTRY ossPerEncStartEndDateTimeInterval(void);
extern void CDECL_ENTRY ossPerEncDurationInterval(void);
extern void CDECL_ENTRY ossPerEncStartDateDurationInterval(void);
extern void CDECL_ENTRY ossPerEncStartTimeDurationInterval(void);
extern void CDECL_ENTRY ossPerEncStartDateTimeDurationInterval(void);
extern void CDECL_ENTRY ossPerEncDurationEndDateInterval(void);
extern void CDECL_ENTRY ossPerEncDurationEndTimeInterval(void);
extern void CDECL_ENTRY ossPerEncDurationEndDateTimeInterval(void);
extern void CDECL_ENTRY ossPerEncRecStartEndDateInterval(void);
extern void CDECL_ENTRY ossPerEncRecStartEndTimeInterval(void);
extern void CDECL_ENTRY ossPerEncRecStartEndDateTimeInterval(void);
extern void CDECL_ENTRY ossPerEncRecDurationInterval(void);
extern void CDECL_ENTRY ossPerEncRecStartDateDurationInterval(void);
extern void CDECL_ENTRY ossPerEncRecStartTimeDurationInterval(void);
extern void CDECL_ENTRY ossPerEncRecStartDateTimeDurationInterval(void);
extern void CDECL_ENTRY ossPerEncRecDurationEndDateInterval(void);
extern void CDECL_ENTRY ossPerEncRecDurationEndTimeInterval(void);
extern void CDECL_ENTRY ossPerEncRecDurationEndDateTimeInterval(void);

/* *******************************************************************/
/* Customization of encoding/decoding functions depending on defines */
/* *******************************************************************/
#ifndef OSS_OCTET_STRING_NOT_SUPPORTED
#define LEAN_UNBOUNDED_OCTET_STRING_BER_DEC     ossBerDecUnboundedOctetString
#define LEAN_UNBOUNDED_OCTET_STRING_PER_DEC     ossPerDecOctetString
#define LEAN_UNBOUNDED_OCTET_STRING_EXER_DEC    ossEXerDecUnboundedOctetString
#define LEAN_UNBOUNDED_OCTET_STRING_BER_ENC     ossBerEncUnboundedOctetString
#define LEAN_UNBOUNDED_OCTET_STRING_PER_ENC     ossPerEncOctetString
#define LEAN_UNBOUNDED_OCTET_STRING_EXER_ENC    ossEXerEncUnboundedOctetString
#ifndef OSSXSD
#define LEAN_UNBOUNDED_OCTET_STRING_XER_DEC     ossXerDecUnboundedOctetString
#define LEAN_UNBOUNDED_OCTET_STRING_XER_ENC     ossXerEncUnboundedOctetString
#endif
#endif
#ifndef OSS_HUGE_INTEGER_NOT_SUPPORTED
#define LEAN_HUGE_INTEGER_BER_DEC               ossBerDecUnboundedOctetString
#define LEAN_HUGE_INTEGER_PER_DEC               ossPerDecHugeInteger
#define LEAN_HUGE_INTEGER_EXER_DEC              ossEXerDecHugeInteger
#define LEAN_HUGE_INTEGER_BER_ENC               ossBerEncHugeInteger
#define LEAN_HUGE_INTEGER_PER_ENC               ossPerEncHugeInteger
#define LEAN_HUGE_INTEGER_EXER_ENC              ossEXerEncHugeInteger
#define LEAN_HUGE_INTEGER_XER_DEC               ossXerDecHugeInteger
#define LEAN_HUGE_INTEGER_XER_ENC               ossXerEncHugeInteger
#define LEAN_HUGE_INTEGER_OER_DEC               ossOerDecHugeInteger
#define LEAN_HUGE_INTEGER_OER_ENC               ossOerEncHugeInteger
#define LEAN_HUGE_INTEGER_JSON_DEC              ossJsonDecHugeInteger
#define LEAN_HUGE_INTEGER_JSON_ENC              ossJsonEncHugeInteger
#endif
#ifndef OSS_OBJECT_IDENTIFIER_NOT_SUPPORTED
#define LEAN_ENCODED_OBJECT_IDENTIFIER_BER_DEC  ossBerDecUnboundedOctetString
#define LEAN_ENCODED_OBJECT_IDENTIFIER_PER_DEC  ossPerDecObjectIdentifier
#define LEAN_ENCODED_OBJECT_IDENTIFIER_EXER_DEC ossEXerDecEncodedObjid
#define LEAN_ENCODED_RELATIVE_OID_BER_DEC       ossBerDecUnboundedOctetString
#define LEAN_ENCODED_RELATIVE_OID_PER_DEC       ossPerDecObjectIdentifier
#define LEAN_ENCODED_RELATIVE_OID_EXER_DEC      ossEXerDecEncodedObjid
#define LEAN_ENCODED_RELATIVE_OID_OER_DEC       ossOerDecObjectIdentifier
#define LEAN_ENCODED_RELATIVE_OID_JSON_DEC      ossJsonDecObjectIdentifier
#define LEAN_ENCODED_OBJECT_IDENTIFIER_BER_ENC  ossBerEncObjectIdentifier
#define LEAN_ENCODED_OBJECT_IDENTIFIER_PER_ENC  ossPerEncObjectIdentifier
#define LEAN_ENCODED_OBJECT_IDENTIFIER_EXER_ENC ossEXerEncObjectIdentifier
#define LEAN_ENCODED_RELATIVE_OID_BER_ENC       ossBerEncObjectIdentifier
#define LEAN_ENCODED_RELATIVE_OID_PER_ENC       ossPerEncObjectIdentifier
#define LEAN_ENCODED_RELATIVE_OID_EXER_ENC      ossEXerEncObjectIdentifier
#define LEAN_ENCODED_RELATIVE_OID_OER_ENC       ossOerEncObjectIdentifier
#define LEAN_ENCODED_RELATIVE_OID_JSON_ENC      ossJsonEncObjectIdentifier
#define LEAN_ENCODED_OBJECT_IDENTIFIER_XER_DEC  ossXerDecEncodedObjid
#define LEAN_ENCODED_RELATIVE_OID_XER_DEC       ossXerDecEncodedObjid
#define LEAN_ENCODED_OBJECT_IDENTIFIER_XER_ENC  ossXerEncObjectIdentifier
#define LEAN_ENCODED_RELATIVE_OID_XER_ENC       ossXerEncObjectIdentifier
#endif
#ifndef OSS_TIME_NOT_SUPPORTED
#define LEAN_NULLTERM_ISO8601_TIME_BER_DEC      ossBerDecNulltermISO8601Time
#define LEAN_NULLTERM_ISO8601_TIME_PER_DEC      ossPerDecNulltermISO8601Time
#define LEAN_NULLTERM_ISO8601_TIME_EXER_DEC     ossEXerDecNullTermTime
#define LEAN_NULLTERM_ISO8601_TIME_BER_ENC      ossBerEncNulltermISO8601Time
#define LEAN_NULLTERM_ISO8601_TIME_PER_ENC      ossPerEncNulltermISO8601Time
#define LEAN_NULLTERM_ISO8601_TIME_EXER_ENC     ossEXerEncNulltermISO8601Time
#define LEAN_NULLTERM_ISO8601_TIME_XER_DEC      ossXerDecNullTermTime
#define LEAN_NULLTERM_ISO8601_TIME_OER_DEC      ossOerDecNulltermISO8601Time
#define LEAN_NULLTERM_ISO8601_TIME_JSON_DEC     ossJsonDecNullTermTime
#define LEAN_NULLTERM_ISO8601_TIME_XER_ENC      ossXerEncNulltermISO8601Time
#define LEAN_NULLTERM_ISO8601_TIME_OER_ENC      ossOerEncNulltermISO8601Time
#define LEAN_NULLTERM_ISO8601_TIME_JSON_ENC     ossJsonEncNullTermTime
#endif

#ifndef OSS_CONTENT_CONSTRAINT_NOT_SUPPORTED
#define LEAN_CONTAINING_CONSTRAINT_BER_DEC	ossBerDecContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_PER_DEC	ossPerDecContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_XER_DEC	ossXerDecContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_EXER_DEC	ossEXerDecContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_OER_DEC      ossOerDecContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_JSON_DEC     ossJsonDecContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_BER_ENC	ossBerEncContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_PER_ENC	ossPerEncContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_XER_ENC	ossXerEncContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_EXER_ENC	ossEXerEncContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_OER_ENC      ossOerEncContentConstraint
#define LEAN_CONTAINING_CONSTRAINT_JSON_ENC     ossJsonEncContentConstraint
#endif
#ifndef OSS_BIT_STRING_NOT_SUPPORTED
#define LEAN_UNBOUNDED_BIT_STRING_BER_DEC       ossBerDecUnboundedBitString
#define LEAN_UNBOUNDED_BIT_STRING_PER_DEC       ossPerDecBitString
#define LEAN_UNBOUNDED_BIT_STRING_XER_DEC       ossXerDecUnboundedBitString
#define LEAN_UNBOUNDED_BIT_STRING_EXER_DEC      ossEXerDecUnboundedBitString
#define LEAN_UNBOUNDED_BIT_STRING_OER_DEC       ossOerDecBitString
#define LEAN_UNBOUNDED_BIT_STRING_JSON_DEC      ossJsonDecBitString
#define LEAN_UNBOUNDED_BIT_STRING_BER_ENC       ossBerEncUnboundedBitString
#define LEAN_UNBOUNDED_BIT_STRING_PER_ENC       ossPerEncBitString
#define LEAN_UNBOUNDED_BIT_STRING_XER_ENC       ossXerEncUnboundedBitString
#define LEAN_UNBOUNDED_BIT_STRING_EXER_ENC      ossEXerEncUnboundedBitString
#define LEAN_UNBOUNDED_BIT_STRING_OER_ENC       ossOerEncBitString
#define LEAN_UNBOUNDED_BIT_STRING_JSON_ENC      ossJsonEncBitString
#endif
#ifndef OSS_ANY_NOT_SUPPORTED
#define LEAN_UNBOUNDED_ANY_BER_DEC              ossBerDecUnboundedAny
#define LEAN_UNBOUNDED_ANY_PER_DEC              ossPerDecAny
#define LEAN_UNBOUNDED_ANY_XER_DEC              ossXerDecUnboundedAny
#define LEAN_UNBOUNDED_ANY_EXER_DEC             ossEXerDecUnboundedAny
#define LEAN_UNBOUNDED_ANY_OER_DEC              ossOerDecAny
#define LEAN_UNBOUNDED_ANY_JSON_DEC             ossJsonDecOpenType
#define LEAN_UNBOUNDED_ANY_BER_ENC              ossBerEncUnboundedAny
#define LEAN_UNBOUNDED_ANY_PER_ENC              ossPerEncAny
#define LEAN_UNBOUNDED_ANY_XER_ENC              ossXerEncUnboundedAny
#define LEAN_UNBOUNDED_ANY_EXER_ENC             ossEXerEncUnboundedAny
#define LEAN_UNBOUNDED_ANY_OER_ENC              ossOerEncAny
#define LEAN_UNBOUNDED_ANY_JSON_ENC             ossJsonEncAny
#endif
#ifndef OSS_SET_NOT_SUPPORTED
#define LEAN_SET_BER_DEC                        ossBerDecSet
#define LEAN_SET_PER_DEC                        ossPerDecSetSequence
#define LEAN_SET_XER_DEC                        ossXerDecSeqSet
#define LEAN_SET_EXER_DEC                       ossEXerDecSet
#define LEAN_SET_OER_DEC                        ossOerDecSeqSet
#define LEAN_SET_JSON_DEC                       ossJsonDecSeqSet
#define LEAN_SET_BER_ENC                        ossBerEncSetSequence
#define LEAN_SET_PER_ENC                        ossPerEncSetSequence
#define LEAN_SET_XER_ENC                        ossXerEncSetSequence
#define LEAN_SET_EXER_ENC                       ossEXerEncSetSequence
#define LEAN_SET_OER_ENC                        ossOerEncSetSeq
#define LEAN_SET_JSON_ENC                       ossJsonEncSetSeq
#endif
#ifndef OSS_SET_OF_NOT_SUPPORTED
#define LEAN_LINKED_SET_OF_BER_DEC              ossBerDecLinkedUnboundedSetSequenceOf
#define LEAN_LINKED_SET_OF_PER_DEC              ossPerDecSetSequenceOf
#define LEAN_LINKED_SET_OF_XER_DEC              ossXerDecLinkedUnboundedSetSequenceOf
#define LEAN_LINKED_SET_OF_EXER_DEC             ossEXerDecLinkedUnboundedSetSequenceOf
#define LEAN_LINKED_SET_OF_OER_DEC              ossOerDecSetSequenceOf
#define LEAN_LINKED_SET_OF_JSON_DEC             ossJsonDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_BER_DEC           ossBerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_PER_DEC           ossPerDecUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_XER_DEC           ossXerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_EXER_DEC          ossEXerDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_OER_DEC           ossOerDecUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_JSON_DEC          ossJsonDecLinkedUnboundedSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_PER_DEC	ossPerDecDlinkedPlusSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_BER_DEC	ossBerDecDlinkedPlusSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_XER_DEC	ossXerDecDlinkedPlusSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_EXER_DEC	ossEXerDecDlinkedPlusSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_OER_DEC	ossOerDecDlinkedPlusSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_JSON_DEC	ossJsonDecDlinkedPlusSetSequenceOf
#define LEAN_LINKED_SET_OF_BER_ENC              ossBerEncLinkedSetSequenceOf
#define LEAN_LINKED_SET_OF_PER_ENC              ossPerEncSetSequenceOf
#define LEAN_LINKED_SET_OF_XER_ENC              ossXerEncLinkedSetSequenceOf
#define LEAN_LINKED_SET_OF_EXER_ENC             ossEXerEncLinkedSetSequenceOf
#define LEAN_LINKED_SET_OF_OER_ENC              ossOerEncSetSequenceOf
#define LEAN_LINKED_SET_OF_JSON_ENC             ossJsonEncSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_BER_ENC           ossBerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_PER_ENC           ossPerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_XER_ENC           ossXerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_EXER_ENC          ossEXerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_OER_ENC           ossOerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SET_OF_JSON_ENC          ossJsonEncUnboundedSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_BER_ENC	ossBerEncLinkedSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_PER_ENC	ossPerEncSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_XER_ENC	ossXerEncLinkedSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_EXER_ENC	ossEXerEncLinkedSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_OER_ENC	ossOerEncSetSequenceOf
#define LEAN_DLINKED_PLUS_SET_OF_JSON_ENC	ossJsonEncSetSequenceOf
#endif
#ifndef OSS_UTC_GENERALIZED_TIME_NOT_SUPPORTED
#define LEAN_NULLTERM_TIME_BER_DEC              ossBerDecNullTermTime
#define LEAN_NULLTERM_TIME_PER_DEC              ossPerDecNulltermTime
#define LEAN_NULLTERM_TIME_XER_DEC              ossXerDecNullTermTime
#define LEAN_NULLTERM_TIME_EXER_DEC             ossEXerDecNullTermTime
#define LEAN_NULLTERM_TIME_OER_DEC              ossOerDecNullTermTime
#define LEAN_NULLTERM_TIME_JSON_DEC             ossJsonDecNullTermTime
#define LEAN_NULLTERM_TIME_BER_ENC              ossBerEncNullTermTime
#define LEAN_NULLTERM_TIME_PER_ENC              ossPerEncNulltermTime
#define LEAN_NULLTERM_TIME_XER_ENC              ossXerEncNullTermTime
#define LEAN_NULLTERM_TIME_EXER_ENC             ossEXerEncNullTermTime
#define LEAN_NULLTERM_TIME_OER_ENC              ossOerEncNullTermTime
#define LEAN_NULLTERM_TIME_JSON_ENC             ossJsonEncNullTermTime
#endif
#ifndef OSS_OPEN_TYPE_NOT_SUPPORTED
#define LEAN_OPENTYPE_BER_DEC                   ossBerDecUnboundedAny
#define LEAN_OPENTYPE_PER_DEC                   ossPerDecOpenType
#define LEAN_OPENTYPE_XER_DEC                   ossXerDecUnboundedAny
#define LEAN_OPENTYPE_EXER_DEC                  ossEXerDecUnboundedAny
#define LEAN_OPENTYPE_OER_DEC                   ossOerDecOpenType
#define LEAN_OPENTYPE_JSON_DEC                  ossJsonDecOpenType
#define LEAN_OPENTYPE_BER_ENC                   ossBerEncOpenType
#define LEAN_OPENTYPE_PER_ENC                   ossPerEncOpenType
#define LEAN_OPENTYPE_XER_ENC                   ossXerEncOpenType
#define LEAN_OPENTYPE_EXER_ENC                  ossEXerEncOpenType
#define LEAN_OPENTYPE_OER_ENC                   ossOerEncOpenType
#define LEAN_OPENTYPE_JSON_ENC                  ossJsonEncOpenType
#endif
#ifndef OSS_WIDE_CHAR_NOT_SUPPORTED
#define LEAN_BMPSTRING_BER_DEC                  ossBerDecBMPUniversalString
#define LEAN_BMPSTRING_PER_DEC                  ossPerDecWideCharacterString
#define LEAN_BMPSTRING_XER_DEC                  ossXerDecUnboundedXCharString
#define LEAN_BMPSTRING_EXER_DEC                 ossEXerDecUnboundedXCharString
#define LEAN_BMPSTRING_OER_DEC                  ossOerDecWideCharacterString
#define LEAN_BMPSTRING_JSON_DEC                 ossJsonDecWideCharacterString
#define LEAN_UNIVERSAL_STRING_BER_DEC           ossBerDecBMPUniversalString
#define LEAN_UNIVERSAL_STRING_PER_DEC           ossPerDecWideCharacterString
#define LEAN_UNIVERSAL_STRING_XER_DEC           ossXerDecUnboundedXCharString
#define LEAN_UNIVERSAL_STRING_EXER_DEC          ossEXerDecUnboundedXCharString
#define LEAN_UNIVERSAL_STRING_OER_DEC           ossOerDecWideCharacterString
#define LEAN_UNIVERSAL_STRING_JSON_DEC          ossJsonDecWideCharacterString
#define LEAN_BMPSTRING_BER_ENC                  ossBerEncBMPUniversalString
#define LEAN_BMPSTRING_PER_ENC                  ossPerEncWideCharacterString
#define LEAN_BMPSTRING_XER_ENC                  ossXerEncUTF8String
#define LEAN_BMPSTRING_EXER_ENC                 ossEXerEncUnboundedWCharString
#define LEAN_BMPSTRING_OER_ENC                  ossOerEncWideCharacterString
#define LEAN_BMPSTRING_JSON_ENC                 ossJsonEncWideCharacterString
#define LEAN_UNIVERSAL_STRING_BER_ENC           ossBerEncBMPUniversalString
#define LEAN_UNIVERSAL_STRING_PER_ENC           ossPerEncWideCharacterString
#define LEAN_UNIVERSAL_STRING_XER_ENC           ossXerEncUTF8String
#define LEAN_UNIVERSAL_STRING_EXER_ENC          ossEXerEncUnboundedWCharString
#define LEAN_UNIVERSAL_STRING_OER_ENC           ossOerEncWideCharacterString
#define LEAN_UNIVERSAL_STRING_JSON_ENC          ossJsonEncWideCharacterString
#endif

/*******************************************************
 * Declarations of link routines that are needed       *
 * to link the given encoding rules or rules specified *
 * on the compiler command line. Function calls        *
 * are generated by the compiler to _ossinit_...()     *
 * in the control table.  These functions are not      *
 * meant to be referenced in user code.                *
 *******************************************************/
#ifndef OSS_BER_NOT_SUPPORTED
#if defined(OSS_COMPILER_API_LEVEL) || defined(OSS_BUILD)
OSS_DECLSPEC void DLL_ENTRY ossLinkBerDec(OssGlobal *, int, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkBerEnc(OssGlobal *, int, const OssStubFuncp *);
#else
OSS_DECLSPEC void DLL_ENTRY ossLinkBerDec(OssGlobal *, int, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkBerEnc(OssGlobal *, int, const void **);
#endif
#else
#define ossLinkBerDec(a, b, c)	OSS_BER_DECODER_NOT_SUPPORTED
#define ossLinkBerEnc(a, b, c)	OSS_BER_ENCODER_NOT_SUPPORTED
#endif
#ifndef OSS_PER_NOT_SUPPORTED
#if defined(OSS_COMPILER_API_LEVEL) || defined(OSS_BUILD)
OSS_DECLSPEC void DLL_ENTRY ossLinkPerDec(OssGlobal *, int, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkPerEnc(OssGlobal *, int, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkPerTimeEnc(OssGlobal *, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkPerTimeDec(OssGlobal *, const OssStubFuncp *);
#else
OSS_DECLSPEC void DLL_ENTRY ossLinkPerDec(OssGlobal *, int, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkPerEnc(OssGlobal *, int, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkPerTimeEnc(OssGlobal *, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkPerTimeDec(OssGlobal *, const void **);
#endif
#else
#define ossLinkPerDec(a, b, c) OSS_PER_DECODER_NOT_SUPPORTED
#define ossLinkPerEnc(a, b, c) OSS_PER_ENCODER_NOT_SUPPORTED
#endif
#ifndef OSS_XER_NOT_SUPPORTED
#if defined(OSS_COMPILER_API_LEVEL) || defined(OSS_BUILD)
OSS_DECLSPEC void DLL_ENTRY ossLinkXerDec(OssGlobal *, int, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkXerEnc(OssGlobal *, int, const OssStubFuncp *);
#else
OSS_DECLSPEC void DLL_ENTRY ossLinkXerDec(OssGlobal *, int, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkXerEnc(OssGlobal *, int, const void **);
#endif
#else
#define ossLinkXerDec(a, b, c) OSS_XER_DECODER_NOT_SUPPORTED
#define ossLinkXerEnc(a, b, c) OSS_XER_ENCODER_NOT_SUPPORTED
#endif
#ifndef OSS_EXER_NOT_SUPPORTED
#if defined(OSS_COMPILER_API_LEVEL) || defined(OSS_BUILD)
OSS_DECLSPEC void DLL_ENTRY ossLinkExerDec(OssGlobal *, void *, int,
							const OssStubFuncp *,
							const OssStubFuncp *);

OSS_DECLSPEC void DLL_ENTRY ossLinkExerEnc(OssGlobal *, void *, int,
							const OssStubFuncp *,
							const OssStubFuncp *);
#else
OSS_DECLSPEC void DLL_ENTRY ossLinkExerDec(OssGlobal *, void *, int,
							const void **,
							const void **);

OSS_DECLSPEC void DLL_ENTRY ossLinkExerEnc(OssGlobal *, void *, int,
							const void **,
							const void **);
#endif
#else
#define ossLinkExerDec(a, b, c, d, e)	OSS_EXER_DECODER_NOT_SUPPORTED
#define ossLinkExerEnc(a, b, c, d, e)	OSS_EXER_ENCODER_NOT_SUPPORTED
#endif
#ifndef OSS_OER_NOT_SUPPORTED
#if defined(OSS_COMPILER_API_LEVEL) || defined(OSS_BUILD)
OSS_DECLSPEC void DLL_ENTRY ossLinkOerDec(OssGlobal *, int, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkOerEnc(OssGlobal *, int, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkOerTimeEnc(OssGlobal *, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkOerTimeDec(OssGlobal *, const OssStubFuncp *);
#else
OSS_DECLSPEC void DLL_ENTRY ossLinkOerDec(OssGlobal *, int, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkOerEnc(OssGlobal *, int, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkOerTimeEnc(OssGlobal *, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkOerTimeDec(OssGlobal *, const void **);
#endif
#else
#define ossLinkOerDec(a, b, c) OSS_OER_DECODER_NOT_SUPPORTED
#define ossLinkOerEnc(a, b, c) OSS_OER_ENCODER_NOT_SUPPORTED
#endif

#ifndef OSS_JSON_NOT_SUPPORTED
#if defined(OSS_COMPILER_API_LEVEL) || defined(OSS_BUILD)
OSS_DECLSPEC void DLL_ENTRY ossLinkJsonDec(OssGlobal *, int, const OssStubFuncp *);
OSS_DECLSPEC void DLL_ENTRY ossLinkJsonEnc(OssGlobal *, int, const OssStubFuncp *);
#else
OSS_DECLSPEC void DLL_ENTRY ossLinkJsonDec(OssGlobal *, int, const void **);
OSS_DECLSPEC void DLL_ENTRY ossLinkJsonEnc(OssGlobal *, int, const void **);
#endif
#else
#define ossLinkJsonDec(a, b, c) OSS_JSON_DECODER_NOT_SUPPORTED
#define ossLinkJsonEnc(a, b, c) OSS_JSON_ENCODER_NOT_SUPPORTED
#endif
OSS_DECLSPEC void DLL_ENTRY ossLinkLeanMemoryManager(OssGlobal *);
OSS_DECLSPEC void DLL_ENTRY ossCheckFeaturesUsed(OssGlobal *, int,
							const unsigned char *);
#define ossLinkLeanMemoryManager() ossLinkLeanMemoryManager(world)

#define LEAN_TYPE_NOT_SUPPORTED_OER_DEC         ossOerDecTypeNotSupported
#define LEAN_INTEGER_OER_DEC                    ossOerDecInteger
#define LEAN_NULL_OER_DEC                       ossOerDecNull
#define LEAN_ENUMERATED_OER_DEC                 ossOerDecEnumerated
#define LEAN_REAL_OER_DEC                       ossOerDecReal
#define LEAN_BOOLEAN_OER_DEC                    ossOerDecBoolean
#define LEAN_SEQUENCE_OER_DEC                   ossOerDecSeqSet
#define LEAN_CHOICE_OER_DEC                     ossOerDecChoice
#define LEAN_LINKED_SEQUENCE_OF_OER_DEC         ossOerDecSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_OER_DEC      ossOerDecUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_OER_DEC ossOerDecPrintableString
#define LEAN_UNSIGNED_INTEGER_OER_DEC           ossOerDecInteger
#define LEAN_UNSIGNED_ENUMERATED_OER_DEC        ossOerDecEnumerated
#define LEAN_DECIMAL_REAL_OER_DEC               ossOerDecCharReal
#define LEAN_DEFERRED_TYPE_OER_DEC              ossOerDecTypeNotSupported
#define LEAN_DEFERRED_OBJECT_OER_DEC            ossOerDecTypeNotSupported
#define LEAN_LONGLONG_INTEGER_OER_DEC           ossOerDecLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_OER_DEC  ossOerDecLLInteger
#define LEAN_ANY_INTEGER_OER_DEC                ossOerDecAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_OER_DEC       ossOerDecAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_OER_DEC	ossOerDecDlinkedPlusSetSequenceOf
#define LEAN_UNBOUNDED_OCTET_STRING_OER_DEC     ossOerDecOctetString
#define LEAN_ENCODED_OBJECT_IDENTIFIER_OER_DEC  ossOerDecObjectIdentifier

extern void CDECL_ENTRY ossOerDecTypeNotSupported(void);
extern void CDECL_ENTRY ossOerDecNull(void);
extern void CDECL_ENTRY ossOerDecAny(void);
extern void CDECL_ENTRY ossOerDecInteger(void);
extern void CDECL_ENTRY ossOerDecEnumerated(void);
extern void CDECL_ENTRY ossOerDecBoolean(void);
extern void CDECL_ENTRY ossOerDecUnboundedOctetString(void);
extern void CDECL_ENTRY ossOerDecHugeInteger(void);
extern void CDECL_ENTRY ossOerDecBitString(void);
extern void CDECL_ENTRY ossOerDecUnboundedCharString(void);
extern void CDECL_ENTRY ossOerDecPrintableString(void);
extern void CDECL_ENTRY ossOerDecNullTermTime(void);
extern void CDECL_ENTRY ossOerDecUnboundedAny(void);
extern void CDECL_ENTRY ossOerDecSeqSet(void);
extern void CDECL_ENTRY ossOerDecChoice(void);
extern void CDECL_ENTRY ossOerDecSetSequenceOf(void);
extern void CDECL_ENTRY ossOerDecReal(void);
extern void CDECL_ENTRY ossOerDecCharReal(void);
extern void CDECL_ENTRY ossOerDecContentConstraint(void);
extern void CDECL_ENTRY ossOerDecLLInteger(void);
extern void CDECL_ENTRY ossOerDecAnyInteger(void);
extern void CDECL_ENTRY ossOerDecObjectIdentifier(void);
extern void CDECL_ENTRY ossOerDecDlinkedPlusSetSequenceOf(void);
extern void CDECL_ENTRY ossOerDecUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossOerDecNulltermISO8601Time(void);
extern void CDECL_ENTRY ossOerDecOctetString(void);
extern void CDECL_ENTRY ossOerDecOpenType(void);
extern void CDECL_ENTRY ossOerDecWideCharacterString(void);
extern void CDECL_ENTRY ossOerDecNullTermTime(void);
extern void CDECL_ENTRY ossOerDecNulltermISO8601Time(void);

#define LEAN_TYPE_NOT_SUPPORTED_OER_ENC         ossOerEncTypeNotSupported
#define LEAN_INTEGER_OER_ENC                    ossOerEncInteger
#define LEAN_NULL_OER_ENC                       ossOerEncNull
#define LEAN_ENUMERATED_OER_ENC                 ossOerEncEnumerated
#define LEAN_REAL_OER_ENC                       ossOerEncReal
#define LEAN_BOOLEAN_OER_ENC                    ossOerEncBoolean
#define LEAN_SEQUENCE_OER_ENC                   ossOerEncSetSeq
#define LEAN_CHOICE_OER_ENC                     ossOerEncChoice
#define LEAN_LINKED_SEQUENCE_OF_OER_ENC         ossOerEncSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_OER_ENC      ossOerEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_OER_ENC ossOerEncPrintableString
#define LEAN_UNSIGNED_INTEGER_OER_ENC           ossOerEncInteger
#define LEAN_UNSIGNED_ENUMERATED_OER_ENC        ossOerEncEnumerated
#define LEAN_DECIMAL_REAL_OER_ENC               ossOerEncCharReal
#define LEAN_DEFERRED_TYPE_OER_ENC              ossOerEncTypeNotSupported
#define LEAN_DEFERRED_OBJECT_OER_ENC            ossOerEncTypeNotSupported
#define LEAN_LONGLONG_INTEGER_OER_ENC           ossOerEncLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_OER_ENC  ossOerEncLLInteger
#define LEAN_ANY_INTEGER_OER_ENC                ossOerEncAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_OER_ENC       ossOerEncAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_OER_ENC	ossOerEncSetSequenceOf
#define LEAN_UNBOUNDED_OCTET_STRING_OER_ENC     ossOerEncOctetString
#define LEAN_ENCODED_OBJECT_IDENTIFIER_OER_ENC  ossOerEncObjectIdentifier

extern void CDECL_ENTRY ossOerEncTypeNotSupported(void);
extern void CDECL_ENTRY ossOerEncInteger(void);
extern void CDECL_ENTRY ossOerEncNull(void);
extern void CDECL_ENTRY ossOerEncEnumerated(void);
extern void CDECL_ENTRY ossOerEncBitString(void);
extern void CDECL_ENTRY ossOerEncReal(void);
extern void CDECL_ENTRY ossOerEncAny(void);
extern void CDECL_ENTRY ossOerEncBoolean(void);
extern void CDECL_ENTRY ossOerEncUnboundedAny(void);
extern void CDECL_ENTRY ossOerEncSetSeq(void);
extern void CDECL_ENTRY ossOerEncChoice(void);
extern void CDECL_ENTRY ossOerEncSetSequenceOf(void);
extern void CDECL_ENTRY ossOerEncUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossOerEncUnboundedOctetString(void);
extern void CDECL_ENTRY ossOerEncNullTermTime(void);
extern void CDECL_ENTRY ossOerEncUnboundedCharString(void);
extern void CDECL_ENTRY ossOerEncPrintableString(void);
extern void CDECL_ENTRY ossOerEncOpenType(void);
extern void CDECL_ENTRY ossOerEncUTF8String(void);
extern void CDECL_ENTRY ossOerEncCharReal(void);
extern void CDECL_ENTRY ossOerEncHugeInteger(void);
extern void CDECL_ENTRY ossOerEncObjectIdentifier(void);
extern void CDECL_ENTRY ossOerEncContentConstraint(void);
extern void CDECL_ENTRY ossOerEncLLInteger(void);
extern void CDECL_ENTRY ossOerEncAnyInteger(void);
extern void CDECL_ENTRY ossOerEncNulltermISO8601Time(void);
extern void CDECL_ENTRY ossOerEncOctetString(void);
extern void CDECL_ENTRY ossOerEncOpenType(void);
extern void CDECL_ENTRY ossOerEncWideCharacterString(void);
extern void CDECL_ENTRY ossOerEncNullTermTime(void);
extern void CDECL_ENTRY ossOerEncNulltermISO8601Time(void);

#define LEAN_MIXED_OER_ENC    		ossOerEncNonOptimizedISO8601Time
#define LEAN_CENTURY_OER_ENC    	ossOerEncNonOptimizedISO8601Time
#define LEAN_ANY_CENTURY_OER_ENC    	ossOerEncNonOptimizedISO8601Time
#define LEAN_YEAR_OER_ENC    		ossOerEncYear
#define LEAN_ANY_YEAR_OER_ENC    	ossOerEncAnyYear
#define LEAN_YEAR_MONTH_OER_ENC    	ossOerEncYearMonth
#define LEAN_ANY_YEAR_MONTH_OER_ENC    	ossOerEncAnyYearMonth
#define LEAN_DATE_OER_ENC    		ossOerEncDate
#define LEAN_ANY_DATE_OER_ENC    	ossOerEncAnyDate
#define LEAN_YEAR_DAY_OER_ENC    	ossOerEncNonOptimizedISO8601Time
#define LEAN_ANY_YEAR_DAY_OER_ENC    	ossOerEncNonOptimizedISO8601Time
#define LEAN_YEAR_WEEK_OER_ENC   	ossOerEncNonOptimizedISO8601Time
#define LEAN_ANY_YEAR_WEEK_OER_ENC    	ossOerEncNonOptimizedISO8601Time
#define LEAN_YEAR_WEEK_DAY_OER_ENC    	ossOerEncNonOptimizedISO8601Time
#define LEAN_ANY_YEAR_WEEK_DAY_OER_ENC  ossOerEncNonOptimizedISO8601Time
#define LEAN_HOURS_OER_ENC    		ossOerEncHours
#define LEAN_HOURS_UTC_OER_ENC    	ossOerEncHoursUtc
#define LEAN_HOURS_AND_DIFF_OER_ENC    	ossOerEncHoursAndDiff
#define LEAN_MINUTES_OER_ENC    	ossOerEncMinutes
#define LEAN_MINUTES_UTC_OER_ENC    	ossOerEncMinutesUtc
#define LEAN_MINUTES_AND_DIFF_OER_ENC  	ossOerEncMinutesAndDiff
#define LEAN_TIME_OF_DAY_OER_ENC    	ossOerEncTimeOfDay
#define LEAN_TIME_OF_DAY_UTC_OER_ENC    ossOerEncTimeOfDayUtc
#define LEAN_TIME_OF_DAY_AND_DIFF_OER_ENC ossOerEncTimeOfDayAndDiff
#define LEAN_HOURS_AND_FRACTION_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_HOURS_UTC_AND_FRACTION_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_HOURS_AND_DIFF_AND_FRACTION_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_MINUTES_AND_FRACTION_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_MINUTES_UTC_AND_FRACTION_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_MINUTES_AND_DIFF_AND_FRACTION_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_TIME_OF_DAY_AND_FRACTION_OER_ENC ossOerEncTimeOfDayAndFraction
#define LEAN_TIME_OF_DAY_UTC_AND_FRACTION_OER_ENC ossOerEncTimeOfDayUtcAndFraction
#define LEAN_TIME_OF_DAY_AND_DIFF_AND_FRACTION_OER_ENC ossOerEncTimeOfDayAndDiffAndFraction
#define LEAN_DATE_TIME_OER_ENC    	ossOerEncDateTime
#define LEAN_START_END_DATE_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_START_END_TIME_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_START_END_DATE_TIME_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_DURATION_INTERVAL_OER_ENC	ossOerEncDurationInterval
#define LEAN_START_DATE_DURATION_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_START_TIME_DURATION_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_START_DATE_TIME_DURATION_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_DURATION_END_DATE_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_DURATION_END_TIME_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_DURATION_END_DATE_TIME_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_START_END_DATE_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_START_END_TIME_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_START_END_DATE_TIME_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_DURATION_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_START_DATE_DURATION_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_START_TIME_DURATION_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_START_DATE_TIME_DURATION_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_DURATION_END_DATE_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_DURATION_END_TIME_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time
#define LEAN_REC_DURATION_END_DATE_TIME_INTERVAL_OER_ENC ossOerEncNonOptimizedISO8601Time

extern void CDECL_ENTRY ossOerEncNonOptimizedISO8601Time(void);
extern void CDECL_ENTRY ossOerEncYear(void);
extern void CDECL_ENTRY ossOerEncAnyYear(void);
extern void CDECL_ENTRY ossOerEncYearMonth(void);
extern void CDECL_ENTRY ossOerEncAnyYearMonth(void);
extern void CDECL_ENTRY ossOerEncDate(void);
extern void CDECL_ENTRY ossOerEncAnyDate(void);
extern void CDECL_ENTRY ossOerEncHours(void);
extern void CDECL_ENTRY ossOerEncHoursUtc(void);
extern void CDECL_ENTRY ossOerEncMinutes(void);
extern void CDECL_ENTRY ossOerEncMinutesUtc(void);
extern void CDECL_ENTRY ossOerEncHoursAndDiff(void);
extern void CDECL_ENTRY ossOerEncMinutesAndDiff(void);
extern void CDECL_ENTRY ossOerEncTimeOfDay(void);
extern void CDECL_ENTRY ossOerEncTimeOfDayUtc(void);
extern void CDECL_ENTRY ossOerEncTimeOfDayAndDiff(void);
extern void CDECL_ENTRY ossOerEncTimeOfDayAndFraction(void);
extern void CDECL_ENTRY ossOerEncTimeOfDayUtcAndFraction(void);
extern void CDECL_ENTRY ossOerEncTimeOfDayAndDiffAndFraction(void);
extern void CDECL_ENTRY ossOerEncDateTime(void);
extern void CDECL_ENTRY ossOerEncDurationInterval(void);

#define LEAN_MIXED_OER_DEC    		ossOerDecNonOptimizedISO8601Time
#define LEAN_CENTURY_OER_DEC    	ossOerDecNonOptimizedISO8601Time
#define LEAN_ANY_CENTURY_OER_DEC    	ossOerDecNonOptimizedISO8601Time
#define LEAN_YEAR_OER_DEC    		ossOerDecYear
#define LEAN_ANY_YEAR_OER_DEC    	ossOerDecAnyYear
#define LEAN_YEAR_MONTH_OER_DEC    	ossOerDecYearMonth
#define LEAN_ANY_YEAR_MONTH_OER_DEC    	ossOerDecAnyYearMonth
#define LEAN_DATE_OER_DEC    		ossOerDecDate
#define LEAN_ANY_DATE_OER_DEC    	ossOerDecAnyDate
#define LEAN_YEAR_DAY_OER_DEC    	ossOerDecNonOptimizedISO8601Time
#define LEAN_ANY_YEAR_DAY_OER_DEC    	ossOerDecNonOptimizedISO8601Time
#define LEAN_YEAR_WEEK_OER_DEC    	ossOerDecNonOptimizedISO8601Time
#define LEAN_ANY_YEAR_WEEK_OER_DEC    	ossOerDecNonOptimizedISO8601Time
#define LEAN_YEAR_WEEK_DAY_OER_DEC    	ossOerDecNonOptimizedISO8601Time
#define LEAN_ANY_YEAR_WEEK_DAY_OER_DEC	ossOerDecNonOptimizedISO8601Time
#define LEAN_HOURS_OER_DEC   		ossOerDecHours
#define LEAN_HOURS_UTC_OER_DEC    	ossOerDecHoursUtc
#define LEAN_HOURS_AND_DIFF_OER_DEC    	ossOerDecHoursAndDiff
#define LEAN_MINUTES_OER_DEC    	ossOerDecMinutes
#define LEAN_MINUTES_UTC_OER_DEC    	ossOerDecMinutesUtc
#define LEAN_MINUTES_AND_DIFF_OER_DEC   ossOerDecMinutesAndDiff
#define LEAN_TIME_OF_DAY_OER_DEC    	ossOerDecTimeOfDay
#define LEAN_TIME_OF_DAY_UTC_OER_DEC    ossOerDecTimeOfDayUtc
#define LEAN_TIME_OF_DAY_AND_DIFF_OER_DEC ossOerDecTimeOfDayAndDiff
#define LEAN_HOURS_AND_FRACTION_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_HOURS_UTC_AND_FRACTION_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_HOURS_AND_DIFF_AND_FRACTION_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_MINUTES_AND_FRACTION_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_MINUTES_UTC_AND_FRACTION_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_MINUTES_AND_DIFF_AND_FRACTION_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_TIME_OF_DAY_AND_FRACTION_OER_DEC ossOerDecTimeOfDayAndFraction
#define LEAN_TIME_OF_DAY_UTC_AND_FRACTION_OER_DEC ossOerDecTimeOfDayUtcAndFraction
#define LEAN_TIME_OF_DAY_AND_DIFF_AND_FRACTION_OER_DEC ossOerDecTimeOfDayAndDiffAndFraction
#define LEAN_DATE_TIME_OER_DEC    	ossOerDecDateTime
#define LEAN_START_END_DATE_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_START_END_TIME_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_START_END_DATE_TIME_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_DURATION_INTERVAL_OER_DEC	ossOerDecDurationInterval
#define LEAN_START_DATE_DURATION_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_START_TIME_DURATION_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_START_DATE_TIME_DURATION_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_DURATION_END_DATE_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_DURATION_END_TIME_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_DURATION_END_DATE_TIME_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_START_END_DATE_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_START_END_TIME_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_START_END_DATE_TIME_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_DURATION_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_START_DATE_DURATION_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_START_TIME_DURATION_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_START_DATE_TIME_DURATION_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_DURATION_END_DATE_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_DURATION_END_TIME_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time
#define LEAN_REC_DURATION_END_DATE_TIME_INTERVAL_OER_DEC ossOerDecNonOptimizedISO8601Time

extern void CDECL_ENTRY ossOerDecNonOptimizedISO8601Time(void);
extern void CDECL_ENTRY ossOerDecYear(void);
extern void CDECL_ENTRY ossOerDecAnyYear(void);
extern void CDECL_ENTRY ossOerDecYearMonth(void);
extern void CDECL_ENTRY ossOerDecAnyYearMonth(void);
extern void CDECL_ENTRY ossOerDecDate(void);
extern void CDECL_ENTRY ossOerDecAnyDate(void);
extern void CDECL_ENTRY ossOerDecHours(void);
extern void CDECL_ENTRY ossOerDecHoursUtc(void);
extern void CDECL_ENTRY ossOerDecMinutes(void);
extern void CDECL_ENTRY ossOerDecMinutesUtc(void);
extern void CDECL_ENTRY ossOerDecHoursAndDiff(void);
extern void CDECL_ENTRY ossOerDecMinutesAndDiff(void);
extern void CDECL_ENTRY ossOerDecTimeOfDay(void);
extern void CDECL_ENTRY ossOerDecTimeOfDayUtc(void);
extern void CDECL_ENTRY ossOerDecTimeOfDayAndDiff(void);
extern void CDECL_ENTRY ossOerDecTimeOfDayAndFraction(void);
extern void CDECL_ENTRY ossOerDecTimeOfDayUtcAndFraction(void);
extern void CDECL_ENTRY ossOerDecTimeOfDayAndDiffAndFraction(void);
extern void CDECL_ENTRY ossOerDecDateTime(void);
extern void CDECL_ENTRY ossOerDecDurationInterval(void);

#define LEAN_TYPE_NOT_SUPPORTED_JSON_DEC         ossJsonDecTypeNotSupported
#define LEAN_INTEGER_JSON_DEC                    ossJsonDecInteger
#define LEAN_NULL_JSON_DEC                       ossJsonDecNull
#define LEAN_ENUMERATED_JSON_DEC                 ossJsonDecEnumerated
#define LEAN_REAL_JSON_DEC                       ossJsonDecReal
#define LEAN_BOOLEAN_JSON_DEC                    ossJsonDecBoolean
#define LEAN_SEQUENCE_JSON_DEC                   ossJsonDecSeqSet
#define LEAN_CHOICE_JSON_DEC                     ossJsonDecChoice
#define LEAN_LINKED_SEQUENCE_OF_JSON_DEC         ossJsonDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_JSON_DEC      ossJsonDecLinkedUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_JSON_DEC ossJsonDecPrintableString
#define LEAN_UNSIGNED_INTEGER_JSON_DEC           ossJsonDecInteger
#define LEAN_UNSIGNED_ENUMERATED_JSON_DEC        ossJsonDecEnumerated
#define LEAN_DECIMAL_REAL_JSON_DEC               ossJsonDecCharReal
#define LEAN_DEFERRED_TYPE_JSON_DEC              ossJsonDecTypeNotSupported
#define LEAN_DEFERRED_OBJECT_JSON_DEC            ossJsonDecTypeNotSupported
#define LEAN_LONGLONG_INTEGER_JSON_DEC           ossJsonDecLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_JSON_DEC  ossJsonDecLLInteger
#define LEAN_ANY_INTEGER_JSON_DEC                ossJsonDecAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_JSON_DEC       ossJsonDecAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_JSON_DEC	 ossJsonDecDlinkedPlusSetSequenceOf
#define LEAN_UNBOUNDED_OCTET_STRING_JSON_DEC     ossJsonDecOctetString
#define LEAN_ENCODED_OBJECT_IDENTIFIER_JSON_DEC  ossJsonDecObjectIdentifier

extern void CDECL_ENTRY ossJsonDecTypeNotSupported(void);
extern void CDECL_ENTRY ossJsonDecNull(void);
extern void CDECL_ENTRY ossJsonDecInteger(void);
extern void CDECL_ENTRY ossJsonDecEnumerated(void);
extern void CDECL_ENTRY ossJsonDecBoolean(void);
extern void CDECL_ENTRY ossJsonDecHugeInteger(void);
extern void CDECL_ENTRY ossJsonDecBitString(void);
extern void CDECL_ENTRY ossJsonDecPrintableString(void);
extern void CDECL_ENTRY ossJsonDecNullTermTime(void);
extern void CDECL_ENTRY ossJsonDecSeqSet(void);
extern void CDECL_ENTRY ossJsonDecChoice(void);
extern void CDECL_ENTRY ossJsonDecReal(void);
extern void CDECL_ENTRY ossJsonDecCharReal(void);
extern void CDECL_ENTRY ossJsonDecContentConstraint(void);
extern void CDECL_ENTRY ossJsonDecLLInteger(void);
extern void CDECL_ENTRY ossJsonDecAnyInteger(void);
extern void CDECL_ENTRY ossJsonDecObjectIdentifier(void);
extern void CDECL_ENTRY ossJsonDecDlinkedPlusSetSequenceOf(void);
extern void CDECL_ENTRY ossJsonDecLinkedUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossJsonDecOctetString(void);
extern void CDECL_ENTRY ossJsonDecOpenType(void);
extern void CDECL_ENTRY ossJsonDecWideCharacterString(void);
extern void CDECL_ENTRY ossJsonDecNulltermISO8601Time(void);

#define LEAN_TYPE_NOT_SUPPORTED_JSON_ENC         ossJsonEncTypeNotSupported
#define LEAN_INTEGER_JSON_ENC                    ossJsonEncInteger
#define LEAN_NULL_JSON_ENC                       ossJsonEncNull
#define LEAN_ENUMERATED_JSON_ENC                 ossJsonEncEnumerated
#define LEAN_REAL_JSON_ENC                       ossJsonEncReal
#define LEAN_BOOLEAN_JSON_ENC                    ossJsonEncBoolean
#define LEAN_SEQUENCE_JSON_ENC                   ossJsonEncSetSeq
#define LEAN_CHOICE_JSON_ENC                     ossJsonEncChoice
#define LEAN_LINKED_SEQUENCE_OF_JSON_ENC         ossJsonEncSetSequenceOf
#define LEAN_UNBOUNDED_SEQUENCE_OF_JSON_ENC      ossJsonEncUnboundedSetSequenceOf
#define LEAN_UNBOUNDED_CHARACTER_STRING_JSON_ENC ossJsonEncPrintableString
#define LEAN_UNSIGNED_INTEGER_JSON_ENC           ossJsonEncInteger
#define LEAN_UNSIGNED_ENUMERATED_JSON_ENC        ossJsonEncEnumerated
#define LEAN_DECIMAL_REAL_JSON_ENC               ossJsonEncCharReal
#define LEAN_DEFERRED_TYPE_JSON_ENC              ossJsonEncTypeNotSupported
#define LEAN_DEFERRED_OBJECT_JSON_ENC            ossJsonEncTypeNotSupported
#define LEAN_LONGLONG_INTEGER_JSON_ENC           ossJsonEncLLInteger
#define LEAN_UNSIGNED_LONGLONG_INTEGER_JSON_ENC  ossJsonEncLLInteger
#define LEAN_ANY_INTEGER_JSON_ENC                ossJsonEncAnyInteger
#define LEAN_UNSIGNED_ANY_INTEGER_JSON_ENC       ossJsonEncAnyInteger
#define LEAN_DLINKED_PLUS_SEQUENCE_OF_JSON_ENC	 ossJsonEncSetSequenceOf
#define LEAN_UNBOUNDED_OCTET_STRING_JSON_ENC     ossJsonEncOctetString
#define LEAN_ENCODED_OBJECT_IDENTIFIER_JSON_ENC  ossJsonEncObjectIdentifier

extern void CDECL_ENTRY ossJsonEncTypeNotSupported(void);
extern void CDECL_ENTRY ossJsonEncInteger(void);
extern void CDECL_ENTRY ossJsonEncNull(void);
extern void CDECL_ENTRY ossJsonEncEnumerated(void);
extern void CDECL_ENTRY ossJsonEncBitString(void);
extern void CDECL_ENTRY ossJsonEncReal(void);
extern void CDECL_ENTRY ossJsonEncAny(void);
extern void CDECL_ENTRY ossJsonEncBoolean(void);
extern void CDECL_ENTRY ossJsonEncAny(void);
extern void CDECL_ENTRY ossJsonEncSetSeq(void);
extern void CDECL_ENTRY ossJsonEncChoice(void);
extern void CDECL_ENTRY ossJsonEncSetSequenceOf(void);
extern void CDECL_ENTRY ossJsonEncUnboundedSetSequenceOf(void);
extern void CDECL_ENTRY ossJsonEncPrintableString(void);
extern void CDECL_ENTRY ossJsonEncOpenType(void);
extern void CDECL_ENTRY ossJsonEncCharReal(void);
extern void CDECL_ENTRY ossJsonEncHugeInteger(void);
extern void CDECL_ENTRY ossJsonEncObjectIdentifier(void);
extern void CDECL_ENTRY ossJsonEncContentConstraint(void);
extern void CDECL_ENTRY ossJsonEncLLInteger(void);
extern void CDECL_ENTRY ossJsonEncAnyInteger(void);
extern void CDECL_ENTRY ossJsonEncOctetString(void);
extern void CDECL_ENTRY ossJsonEncWideCharacterString(void);
extern void CDECL_ENTRY ossJsonEncNullTermTime(void);


#endif /* OSSLTYPE_H */
