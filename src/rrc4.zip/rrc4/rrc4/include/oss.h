/*****************************************************************************/
/* Copyright (C) 2019 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.
 * AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.
 * THIS FILE MAY NOT BE DISTRIBUTED.
 * THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.
 */
/*****************************************************************************/
/* File: @(#)oss.h	17.4  15/08/23	*/
/*							 		     */
#ifndef OSSC_H
#define OSSC_H

#include "asn1.h"
#include "cppopt.h"

#if EXCEPTIONS_SUPPORTED
#define OSSTRY try
#define OSSCLEAN(type) catch (...) { this->~type(); throw; }
#define OSSCLEANUP(stmt) catch (...) { stmt throw; }
#else
#define OSSTRY
#define OSSCLEAN(type)
#define OSSCLEANUP
#endif

class OSSC {
public:

/** Internal representation of REAL with DECIMAL directive and time types */
struct CNullString {
    char *value;
};
typedef char *COssDecimal;
typedef char *COssGeneralizedTime;
typedef char *COssUTCTime;


/** Internal representation of byte-character strings */
struct COssString { 
    OSS_UINT32 length;
    char *value;
};

/** Internal representation of OCTET STRING and ANY */
struct COssOctet {
    OSS_UINT32 length;
    unsigned char *value;
};

/** Internal representation of BIT STRING */
struct COssBitString {
    OSS_UINT32 length;
    unsigned char *value;
};

/** Internal representation of BMPString */
struct COssBMPString {
    OSS_UINT32 length;
    OSS_CHAR16 *value;
};

/** Internal representation of UniversalString */
struct COssUniversalString {
    OSS_UINT32 length;
    OSS_CHAR32 *value;
};

/** Internal representation of OBJECT IDENTIFIER */
struct COssEncOID {
    OSS_UINT32 length;
    unsigned char *value;
};

/** Internal representation of RELATIVE-OID */
struct COssRelOID {
    OSS_UINT32 length;
    unsigned char *value;
};

/** Internal representation of open types */
struct COssOpen {
    OSS_INT32 pduNum;
    long length;
    void *encoded;
    void *decoded;
    void *ctl;
};

/** Internal representation of INTEGER with HUGE directive */
struct COssHugeInt {
    OSS_UINT32 length;
    unsigned char *value;
};

/** Internal representation of BIT STRING with content constraints */
struct COssBitContaining {
    COssBitString encoded;
    void *decoded;
};

/** Internal representation of OCTET STRING with content constraints */
struct COssOctetContaining {
    COssString encoded;
    void *decoded;
};

/** Internal representation of the -relaySafe field for SEQUENCE/SET types */
struct COssExtensions {
   COssBitString extMask;
   struct COssExtensionList {
	OSS_UINT32 count;
   	COssString *value;
   }; 
};

/** Internal representation of the -relaySafe field for CHOICE types */
struct COssAlternative {
    OSS_UINT32 idx;
    COssOctet data;
};

/** Internal representation of new (CHOICE-like) open types */
struct COssConstrainedOpenType {
    OSS_UINT32 pduNum;
    OssBuf encoded;
    void *decoded;
};


}; // end of OSSC class

#endif /* OSSC_H */

