/*****************************************************************************/
/* Copyright (C) 2019 OSS Nokalva, Inc.  All rights reserved.                */
/*****************************************************************************/
/* THIS FILE IS PROPRIETARY MATERIAL OF OSS NOKALVA, INC.,                   */
/* AND MAY BE USED ONLY BY DIRECT LICENSEES OF OSS NOKALVA, INC.             */
/* THIS FILE MAY NOT BE DISTRIBUTED.                                         */
/* THIS COPYRIGHT STATEMENT MAY NOT BE REMOVED.                              */
/*****************************************************************************/
/* FILE: @(#)osscpp.h	17.1 13/12/19                                        */
/*****************************************************************************/
/* This header file is preserved for backward compatibility and should not   */
/* be used by new applications. It is recommended that you should include    */
/* ASN.1 compiler generated header file(s) instead.                          */
/*****************************************************************************/

#include "osstype.h"
