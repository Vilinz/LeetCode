/*****************************************************************************/
/* THIS SAMPLE PROGRAM IS PROVIDED AS IS. THE SAMPLE PROGRAM AND ANY RESULTS */
/* OBTAINED FROM IT ARE PROVIDED WITHOUT ANY WARRANTIES OR REPRESENTATIONS,  */
/* EXPRESS, IMPLIED OR STATUTORY.                                            */
/*****************************************************************************/

#include "rrc.h"

void print_BCCH_BCH_Message(const BCCH_BCH_Message & value);
void print_BCCH_BCH_Message_MBMS(const BCCH_BCH_Message_MBMS & value);
void print_BCCH_DL_SCH_Message(const BCCH_DL_SCH_Message & value);
void print_BCCH_DL_SCH_Message_BR(const BCCH_DL_SCH_Message_BR & value);
void print_BCCH_DL_SCH_Message_MBMS(const BCCH_DL_SCH_Message_MBMS & value);
void print_MCCH_Message(const MCCH_Message & value);
void print_PCCH_Message(const PCCH_Message & value);
void print_DL_CCCH_Message(const DL_CCCH_Message & value);
void print_UL_CCCH_Message(const UL_CCCH_Message & value);
void print_UL_DCCH_Message(const UL_DCCH_Message & value);
void print_SC_MCCH_Message_r13(const SC_MCCH_Message_r13 & value);
void print_SPS_ConfigDL_STTI_r15(const SPS_ConfigDL_STTI_r15 & value);
void print_UE_EUTRA_Capability(const UE_EUTRA_Capability & value);
void print_SBCCH_SL_BCH_Message(const SBCCH_SL_BCH_Message & value);
void print_SBCCH_SL_BCH_Message_V2X_r14(const SBCCH_SL_BCH_Message_V2X_r14 & value);
void print_BCCH_BCH_Message_NB(const BCCH_BCH_Message_NB & value);
void print_BCCH_BCH_Message_TDD_NB(const BCCH_BCH_Message_TDD_NB & value);
void print_BCCH_DL_SCH_Message_NB(const BCCH_DL_SCH_Message_NB & value);
void print_PCCH_Message_NB(const PCCH_Message_NB & value);
void print_DL_CCCH_Message_NB(const DL_CCCH_Message_NB & value);
void print_DL_DCCH_Message_NB(const DL_DCCH_Message_NB & value);
void print_UL_CCCH_Message_NB(const UL_CCCH_Message_NB & value);
void print_SC_MCCH_Message_NB(const SC_MCCH_Message_NB & value);
void print_UL_DCCH_Message_NB(const UL_DCCH_Message_NB & value);
void print_VarConnEstFailReport_r11(const VarConnEstFailReport_r11 & value);
void print_VarLogMeasConfig_r10(const VarLogMeasConfig_r10 & value);
void print_VarLogMeasConfig_r11(const VarLogMeasConfig_r11 & value);
void print_VarLogMeasConfig_r12(const VarLogMeasConfig_r12 & value);
void print_VarLogMeasConfig_r15(const VarLogMeasConfig_r15 & value);
void print_VarLogMeasReport_r10(const VarLogMeasReport_r10 & value);
void print_VarLogMeasReport_r11(const VarLogMeasReport_r11 & value);
void print_VarMeasConfig(const VarMeasConfig & value);
void print_VarMeasIdleConfig_r15(const VarMeasIdleConfig_r15 & value);
void print_VarMeasIdleReport_r15(const VarMeasIdleReport_r15 & value);
void print_VarMeasReportList(const VarMeasReportList & value);
void print_VarMeasReportList_r12(const VarMeasReportList_r12 & value);
void print_VarMobilityHistoryReport_r12(const VarMobilityHistoryReport_r12 & value);
void print_VarPendingRnaProcedure_r15(const VarPendingRnaProcedure_r15 & value);
void print_VarRLF_Report_r10(const VarRLF_Report_r10 & value);
void print_VarRLF_Report_r11(const VarRLF_Report_r11 & value);
void print_VarShortINACTIVE_MAC_Input_r15(const VarShortINACTIVE_MAC_Input_r15 & value);
void print_VarWLAN_MobilityConfig(const VarWLAN_MobilityConfig & value);
void print_VarWLAN_Status_r13(const VarWLAN_Status_r13 & value);
void print_VarShortMAC_Input_NB_r13(const VarShortMAC_Input_NB_r13 & value);
void print_VarShortResumeMAC_Input_NB_r13(const VarShortResumeMAC_Input_NB_r13 & value);
void print_SL_Preconfiguration_r12(const SL_Preconfiguration_r12 & value);
void print_SL_V2X_Preconfiguration_r14(const SL_V2X_Preconfiguration_r14 & value);
void print_HandoverCommand(const HandoverCommand & value);
void print_HandoverPreparationInformation(const HandoverPreparationInformation & value);
void print_HandoverPreparationInformation_v1530_IEs(const HandoverPreparationInformation_v1530_IEs & value);
void print_SCG_ConfigInfo_r12(const SCG_ConfigInfo_r12 & value);
void print_UEPagingCoverageInformation(const UEPagingCoverageInformation & value);
void print_UERadioAccessCapabilityInformation(const UERadioAccessCapabilityInformation & value);
void print_UERadioPagingInformation(const UERadioPagingInformation & value);
void print_HandoverPreparationInformation_NB(const HandoverPreparationInformation_NB & value);
void print_UEPagingCoverageInformation_NB(const UEPagingCoverageInformation_NB & value);
void print_UERadioAccessCapabilityInformation_NB(const UERadioAccessCapabilityInformation_NB & value);
void print_UERadioPagingInformation_NB(const UERadioPagingInformation_NB & value);
