/*****************************************************************************/
/* THIS SAMPLE PROGRAM IS PROVIDED AS IS. THE SAMPLE PROGRAM AND ANY RESULTS */
/* OBTAINED FROM IT ARE PROVIDED WITHOUT ANY WARRANTIES OR REPRESENTATIONS,  */
/* EXPRESS, IMPLIED OR STATUTORY.                                            */
/*****************************************************************************/

#include "rrc-createvalue.h"

static void fill_PHICH_Config(PHICH_Config & value)
{
    value.set_phich_Duration(phich_Duration_normal);
    value.set_phich_Resource(phich_Resource_oneSixth);
}

static void fill_MasterInformationBlock(BCCH_BCH_MessageType & value)
{
    value.set_dl_Bandwidth(MasterInformationBlock_dl_Bandwidth_n6);
    /* Setting 'phich_Config' field */
    PHICH_Config phich_Config;
    fill_PHICH_Config(phich_Config);
    value.set_phich_Config(phich_Config);

    /* Setting 'systemFrameNumber' field */
    static unsigned char systemFrameNumber_value[] = {
	0x00
    };
    OssBitString systemFrameNumber(8, systemFrameNumber_value);
    value.set_systemFrameNumber(systemFrameNumber);

    value.set_schedulingInfoSIB1_BR_r13(0);
    value.set_systemInfoUnchanged_BR_r15(TRUE);
    /* Setting 'spare' field */
    static unsigned char spare_value[] = {
	0x00
    };
    OssBitString spare(4, spare_value);
    value.set_spare(spare);
}

BCCH_BCH_Message *create_samplevalue_BCCH_BCH_Message()
{
    /* Creating 'message' field */
    BCCH_BCH_MessageType message;
    fill_MasterInformationBlock(message);

    /* Calling a fully-initializing constructor */
    return new BCCH_BCH_Message(message);
}

BCCH_BCH_Message_MBMS *create_samplevalue_BCCH_BCH_Message_MBMS()
{
    /* Creating 'message' field */
    /* Creating 'systemFrameNumber_r14' field of 'message' field */
    static unsigned char systemFrameNumber_r14_value[] = {
	0x00
    };
    OssBitString systemFrameNumber_r14(6, systemFrameNumber_r14_value);

    /* Creating 'spare' field of 'message' field */
    static unsigned char spare_value[] = {
	0x00, 0x00
    };
    OssBitString spare(13, spare_value);

    /* Calling a fully-initializing constructor */
    BCCH_BCH_MessageType_MBMS_r14 message(dl_Bandwidth_MBMS_r14_n6, systemFrameNumber_r14, 0, spare);

    /* Calling a fully-initializing constructor */
    return new BCCH_BCH_Message_MBMS(message);
}

static void fill_AC_BarringConfig(AC_BarringConfig & value)
{
    value.set_ac_BarringFactor(ac_BarringFactor_p00);
    value.set_ac_BarringTime(ac_BarringTime_s4);
    /* Setting 'ac_BarringForSpecialAC' field */
    static unsigned char ac_BarringForSpecialAC_value[] = {
	0x00
    };
    OssBitString ac_BarringForSpecialAC(5, ac_BarringForSpecialAC_value);
    value.set_ac_BarringForSpecialAC(ac_BarringForSpecialAC);
}

static void fill_data_23(SystemInformationBlockType2::ac_BarringInfo & value)
{
    value.set_ac_BarringForEmergency(TRUE);
    /* Setting 'ac_BarringForMO_Signalling' field */
    AC_BarringConfig ac_BarringForMO_Signalling;
    fill_AC_BarringConfig(ac_BarringForMO_Signalling);
    value.set_ac_BarringForMO_Signalling(ac_BarringForMO_Signalling);

    /* Setting 'ac_BarringForMO_Data' field */
    AC_BarringConfig ac_BarringForMO_Data;
    fill_AC_BarringConfig(ac_BarringForMO_Data);
    value.set_ac_BarringForMO_Data(ac_BarringForMO_Data);
}

static void fill_PowerRampingParameters(PowerRampingParameters & value)
{
    value.set_powerRampingStep(powerRampingStep_dB0);
    value.set_preambleInitialReceivedTargetPower(preambleInitialReceivedTargetPower_dBm_120);
}

static void fill_RACH_CE_LevelInfo_r13(RACH_CE_LevelInfo_r13 & value)
{
    /* Setting 'preambleMappingInfo_r13' field */

    /* Calling a fully-initializing constructor */
    RACH_CE_LevelInfo_r13::preambleMappingInfo_r13 preambleMappingInfo_r13(0, 0);

    value.set_preambleMappingInfo_r13(preambleMappingInfo_r13);

    value.set_ra_ResponseWindowSize_r13(ra_ResponseWindowSize_r13_sf20);
    value.set_mac_ContentionResolutionTimer_r13(mac_ContentionResolutionTimer_r13_sf80);
    value.set_rar_HoppingConfig_r13(rar_HoppingConfig_r13_on);
    /* Setting 'edt_Parameters_r15' field */

    /* Calling a fully-initializing constructor */
    RACH_CE_LevelInfo_r13::edt_Parameters_r15 edt_Parameters_r15(0, TRUE, edt_Parameters_r15_edt_TBS_r15_b328, mac_ContentionResolutionTimer_r15_sf240);

    value.set_edt_Parameters_r15(edt_Parameters_r15);
}

static void fill_RACH_ConfigCommon(RACH_ConfigCommon & value)
{
    /* Setting 'preambleInfo' field */
    /* Creating 'preamblesGroupAConfig' field of 'preambleInfo' field */

    /* Calling a fully-initializing constructor */
    RACH_ConfigCommon::preambleInfo::preamblesGroupAConfig preamblesGroupAConfig(sizeOfRA_PreamblesGroupA_n4, messageSizeGroupA_b56, minusinfinity);

    /* Calling a fully-initializing constructor */
    RACH_ConfigCommon::preambleInfo preambleInfo(numberOfRA_Preambles_n4, preamblesGroupAConfig);

    value.set_preambleInfo(preambleInfo);

    /* Setting 'powerRampingParameters' field */
    PowerRampingParameters powerRampingParameters;
    fill_PowerRampingParameters(powerRampingParameters);
    value.set_powerRampingParameters(powerRampingParameters);

    /* Setting 'ra_SupervisionInfo' field */

    /* Calling a fully-initializing constructor */
    RACH_ConfigCommon::ra_SupervisionInfo ra_SupervisionInfo(PreambleTransMax_n3, ra_ResponseWindowSize_sf2, mac_ContentionResolutionTimer_sf8);

    value.set_ra_SupervisionInfo(ra_SupervisionInfo);

    value.set_maxHARQ_Msg3Tx(1);
    value.set_preambleTransMax_CE_r13(PreambleTransMax_n3);
    /* Setting 'rach_CE_LevelInfoList_r13' field */
    RACH_CE_LevelInfoList_r13 rach_CE_LevelInfoList_r13;
    {
	/* Adding component #2 */
	RACH_CE_LevelInfo_r13 comp2;
	fill_RACH_CE_LevelInfo_r13(comp2);
	rach_CE_LevelInfoList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	RACH_CE_LevelInfo_r13 comp1;
	fill_RACH_CE_LevelInfo_r13(comp1);
	rach_CE_LevelInfoList_r13.prepend(comp1);
    }
    value.set_rach_CE_LevelInfoList_r13(rach_CE_LevelInfoList_r13);

    value.set_edt_SmallTBS_Subset_r15(RACH_ConfigCommon_edt_SmallTBS_Subset_r15_true);
}

static void fill_PRACH_ConfigInfo(PRACH_ConfigInfo & value)
{
    value.set_prach_ConfigIndex(0);
    value.set_highSpeedFlag(TRUE);
    value.set_zeroCorrelationZoneConfig(0);
    value.set_prach_FreqOffset(0);
}

static void fill_PDSCH_ConfigCommon(PDSCH_ConfigCommon & value)
{
    value.set_referenceSignalPower(50);
    value.set_p_b(0);
}

static void fill_PUSCH_ConfigCommon(PUSCH_ConfigCommon & value)
{
    /* Setting 'pusch_ConfigBasic' field of 'prach_ConfigInfo' field of 'pusch_ConfigCommon' field */

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigCommon::pusch_ConfigBasic pusch_ConfigBasic(1, interSubFrame, 0, TRUE);

    value.set_pusch_ConfigBasic(pusch_ConfigBasic);

    /* Setting 'ul_ReferenceSignalsPUSCH' field of 'prach_ConfigInfo' field of 'pusch_ConfigCommon' field */

    /* Calling a fully-initializing constructor */
    UL_ReferenceSignalsPUSCH ul_ReferenceSignalsPUSCH(TRUE, 0, TRUE, 0);

    value.set_ul_ReferenceSignalsPUSCH(ul_ReferenceSignalsPUSCH);
}

static void fill_PUCCH_ConfigCommon(PUCCH_ConfigCommon & value)
{
    value.set_deltaPUCCH_Shift(ds1);
    value.set_nRB_CQI(0);
    value.set_nCS_AN(0);
    value.set_n1PUCCH_AN(0);
}

static void fill_SoundingRS_UL_ConfigCommon(SoundingRS_UL_ConfigCommon & value)
{
    value.set_release(0);
}

static void fill_DeltaFList_PUCCH(DeltaFList_PUCCH & value)
{
    value.set_deltaF_PUCCH_Format1(deltaF_PUCCH_Format1_deltaF_2);
    value.set_deltaF_PUCCH_Format1b(deltaF_PUCCH_Format1b_deltaF1);
    value.set_deltaF_PUCCH_Format2(deltaF_PUCCH_Format2_deltaF_2);
    value.set_deltaF_PUCCH_Format2a(deltaF_PUCCH_Format2a_deltaF_2);
    value.set_deltaF_PUCCH_Format2b(deltaF_PUCCH_Format2b_deltaF_2);
}

static void fill_PUSCH_ConfigCommon_v1270(PUSCH_ConfigCommon_v1270 & value)
{
    value.set_enable64QAM_v1270(enable64QAM_v1270_true);
}

static void fill_PRACH_ParametersCE_r13(PRACH_ParametersCE_r13 & value)
{
    value.set_prach_ConfigIndex_r13(0);
    value.set_prach_FreqOffset_r13(0);
    value.set_prach_StartingSubframe_r13(prach_StartingSubframe_r13_sf2);
    value.set_maxNumPreambleAttemptCE_r13(PRACH_ParametersCE_r13_maxNumPreambleAttemptCE_r13_n3);
    value.set_numRepetitionPerPreambleAttempt_r13(numRepetitionPerPreambleAttempt_r13_n1);
    /* Setting 'mpdcch_NarrowbandsToMonitor_r13' field */
    PRACH_ParametersCE_r13::mpdcch_NarrowbandsToMonitor_r13 mpdcch_NarrowbandsToMonitor_r13;
    mpdcch_NarrowbandsToMonitor_r13.prepend(1);
    mpdcch_NarrowbandsToMonitor_r13.prepend(1);
    value.set_mpdcch_NarrowbandsToMonitor_r13(mpdcch_NarrowbandsToMonitor_r13);

    value.set_mpdcch_NumRepetition_RA_r13(mpdcch_NumRepetition_RA_r13_r1);
    value.set_prach_HoppingConfig_r13(prach_HoppingConfig_r13_on);
}

static void fill_PRACH_Config_v1430(PRACH_Config_v1430 & value)
{
    value.set_rootSequenceIndexHighSpeed_r14(0);
    value.set_zeroCorrelationZoneConfigHighSpeed_r14(0);
    value.set_prach_ConfigIndexHighSpeed_r14(0);
    value.set_prach_FreqOffsetHighSpeed_r14(0);
}

static void fill_EDT_PRACH_ParametersCE_r15(EDT_PRACH_ParametersCE_r15 & value)
{
    /* Setting 'edt_PRACH_ParametersCE_r15' field */
    /* Creating 'mpdcch_NarrowbandsToMonitor_r15' field of 'edt_PRACH_ParametersCE_r15' field */
    EDT_PRACH_ParametersCE_r15::edt_PRACH_ParametersCE_r15::mpdcch_NarrowbandsToMonitor_r15 mpdcch_NarrowbandsToMonitor_r15;
    mpdcch_NarrowbandsToMonitor_r15.prepend(1);
    mpdcch_NarrowbandsToMonitor_r15.prepend(1);

    /* Calling a fully-initializing constructor */
    EDT_PRACH_ParametersCE_r15::edt_PRACH_ParametersCE_r15 edt_PRACH_ParametersCE_r15(0, 0, prach_StartingSubframe_r15_sf2, mpdcch_NarrowbandsToMonitor_r15);

    value.set_edt_PRACH_ParametersCE_r15(edt_PRACH_ParametersCE_r15);
}

static void fill_RadioResourceConfigCommonSIB(RadioResourceConfigCommonSIB & value)
{
    /* Setting 'rach_ConfigCommon' field */
    RACH_ConfigCommon rach_ConfigCommon;
    fill_RACH_ConfigCommon(rach_ConfigCommon);
    value.set_rach_ConfigCommon(rach_ConfigCommon);

    /* Setting 'bcch_Config' field */

    /* Calling a fully-initializing constructor */
    BCCH_Config bcch_Config(modificationPeriodCoeff_n2);

    value.set_bcch_Config(bcch_Config);

    /* Setting 'pcch_Config' field */

    /* Calling a fully-initializing constructor */
    PCCH_Config pcch_Config(defaultPagingCycle_rf32, nB_fourT);

    value.set_pcch_Config(pcch_Config);

    /* Setting 'prach_Config' field */
    /* Creating 'prach_ConfigInfo' field of 'prach_Config' field */
    PRACH_ConfigInfo prach_ConfigInfo;
    fill_PRACH_ConfigInfo(prach_ConfigInfo);

    /* Calling a fully-initializing constructor */
    PRACH_ConfigSIB prach_Config(0, prach_ConfigInfo);

    value.set_prach_Config(prach_Config);

    /* Setting 'pdsch_ConfigCommon' field */
    PDSCH_ConfigCommon pdsch_ConfigCommon;
    fill_PDSCH_ConfigCommon(pdsch_ConfigCommon);
    value.set_pdsch_ConfigCommon(pdsch_ConfigCommon);

    /* Setting 'pusch_ConfigCommon' field */
    PUSCH_ConfigCommon pusch_ConfigCommon;
    fill_PUSCH_ConfigCommon(pusch_ConfigCommon);
    value.set_pusch_ConfigCommon(pusch_ConfigCommon);

    /* Setting 'pucch_ConfigCommon' field */
    PUCCH_ConfigCommon pucch_ConfigCommon;
    fill_PUCCH_ConfigCommon(pucch_ConfigCommon);
    value.set_pucch_ConfigCommon(pucch_ConfigCommon);

    /* Setting 'soundingRS_UL_ConfigCommon' field */
    SoundingRS_UL_ConfigCommon soundingRS_UL_ConfigCommon;
    fill_SoundingRS_UL_ConfigCommon(soundingRS_UL_ConfigCommon);
    value.set_soundingRS_UL_ConfigCommon(soundingRS_UL_ConfigCommon);

    /* Setting 'uplinkPowerControlCommon' field */
    /* Creating 'deltaFList_PUCCH' field of 'uplinkPowerControlCommon' field */
    DeltaFList_PUCCH deltaFList_PUCCH;
    fill_DeltaFList_PUCCH(deltaFList_PUCCH);

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommon uplinkPowerControlCommon(24, Alpha_r12_al0, -96, deltaFList_PUCCH, -1);

    value.set_uplinkPowerControlCommon(uplinkPowerControlCommon);

    value.set_ul_CyclicPrefixLength(len1);
    /* Setting 'uplinkPowerControlCommon_v1020' field */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommon_v1020 uplinkPowerControlCommon_v1020(deltaF_PUCCH_Format3_r10_deltaF_1, deltaF_PUCCH_Format1bCS_r10_deltaF1);

    value.set_uplinkPowerControlCommon_v1020(uplinkPowerControlCommon_v1020);

    /* Setting 'rach_ConfigCommon_v1250' field */
    /* Creating 'txFailParams_r12' field of 'rach_ConfigCommon_v1250' field */

    /* Calling a fully-initializing constructor */
    RACH_ConfigCommon_v1250::txFailParams_r12 txFailParams_r12(connEstFailCount_r12_n1, connEstFailOffsetValidity_r12_s30, 0);

    /* Calling a fully-initializing constructor */
    RACH_ConfigCommon_v1250 rach_ConfigCommon_v1250(txFailParams_r12);

    value.set_rach_ConfigCommon_v1250(rach_ConfigCommon_v1250);

    /* Setting 'pusch_ConfigCommon_v1270' field */
    PUSCH_ConfigCommon_v1270 pusch_ConfigCommon_v1270;
    fill_PUSCH_ConfigCommon_v1270(pusch_ConfigCommon_v1270);
    value.set_pusch_ConfigCommon_v1270(pusch_ConfigCommon_v1270);

    /* Setting 'bcch_Config_v1310' field */

    /* Calling a fully-initializing constructor */
    BCCH_Config_v1310 bcch_Config_v1310(modificationPeriodCoeff_v1310_n64);

    value.set_bcch_Config_v1310(bcch_Config_v1310);

    /* Setting 'pcch_Config_v1310' field */

    /* Calling a fully-initializing constructor */
    PCCH_Config_v1310 pcch_Config_v1310(1, mpdcch_NumRepetition_Paging_r13_r1, nB_v1310_one64thT);

    value.set_pcch_Config_v1310(pcch_Config_v1310);

    /* Setting 'freqHoppingParameters_r13' field */
    /* Creating 'dummy2' field of 'freqHoppingParameters_r13' field */
    FreqHoppingParameters_r13::dummy2 dummy2;
    dummy2.set_interval_FDD_r13(dummy2_interval_FDD_r13_int1);

    /* Creating 'dummy3' field of 'freqHoppingParameters_r13' field */
    FreqHoppingParameters_r13::dummy3 dummy3;
    dummy3.set_interval_FDD_r13(dummy3_interval_FDD_r13_int2);

    /* Creating 'interval_ULHoppingConfigCommonModeA_r13' field of 'freqHoppingParameters_r13' field */
    FreqHoppingParameters_r13::interval_ULHoppingConfigCommonModeA_r13 interval_ULHoppingConfigCommonModeA_r13;
    interval_ULHoppingConfigCommonModeA_r13.set_interval_FDD_r13(interval_ULHoppingConfigCommonModeA_r13_interval_FDD_r13_int1);

    /* Creating 'interval_ULHoppingConfigCommonModeB_r13' field of 'freqHoppingParameters_r13' field */
    FreqHoppingParameters_r13::interval_ULHoppingConfigCommonModeB_r13 interval_ULHoppingConfigCommonModeB_r13;
    interval_ULHoppingConfigCommonModeB_r13.set_interval_FDD_r13(interval_ULHoppingConfigCommonModeB_r13_interval_FDD_r13_int2);

    /* Calling a fully-initializing constructor */
    FreqHoppingParameters_r13 freqHoppingParameters_r13(dummy_nb2, dummy2, dummy3, interval_ULHoppingConfigCommonModeA_r13, interval_ULHoppingConfigCommonModeB_r13, 1);

    value.set_freqHoppingParameters_r13(freqHoppingParameters_r13);

    /* Setting 'pdsch_ConfigCommon_v1310' field */

    /* Calling a fully-initializing constructor */
    PDSCH_ConfigCommon_v1310 pdsch_ConfigCommon_v1310(pdsch_maxNumRepetitionCEmodeA_r13_r16, pdsch_maxNumRepetitionCEmodeB_r13_r192);

    value.set_pdsch_ConfigCommon_v1310(pdsch_ConfigCommon_v1310);

    /* Setting 'pusch_ConfigCommon_v1310' field */

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigCommon_v1310 pusch_ConfigCommon_v1310(pusch_maxNumRepetitionCEmodeA_r13_r8, pusch_maxNumRepetitionCEmodeB_r13_r192, 1);

    value.set_pusch_ConfigCommon_v1310(pusch_ConfigCommon_v1310);

    /* Setting 'prach_ConfigCommon_v1310' field */
    /* Creating 'rsrp_ThresholdsPrachInfoList_r13' field of 'prach_ConfigCommon_v1310' field */
    RSRP_ThresholdsPrachInfoList_r13 rsrp_ThresholdsPrachInfoList_r13;
    rsrp_ThresholdsPrachInfoList_r13.prepend((OSS_UINT32)0);
    rsrp_ThresholdsPrachInfoList_r13.prepend((OSS_UINT32)0);

    /* Creating 'mpdcch_startSF_CSS_RA_r13' field of 'prach_ConfigCommon_v1310' field */
    PRACH_ConfigSIB_v1310::mpdcch_startSF_CSS_RA_r13 mpdcch_startSF_CSS_RA_r13;
    mpdcch_startSF_CSS_RA_r13.set_fdd_r13(PRACH_ConfigSIB_v1310_mpdcch_startSF_CSS_RA_r13_fdd_r13_v1);

    /* Creating 'prach_ParametersListCE_r13' field of 'prach_ConfigCommon_v1310' field */
    PRACH_ParametersListCE_r13 prach_ParametersListCE_r13;
    {
	/* Adding component #2 */
	PRACH_ParametersCE_r13 comp2;
	fill_PRACH_ParametersCE_r13(comp2);
	prach_ParametersListCE_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PRACH_ParametersCE_r13 comp1;
	fill_PRACH_ParametersCE_r13(comp1);
	prach_ParametersListCE_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    PRACH_ConfigSIB_v1310 prach_ConfigCommon_v1310(rsrp_ThresholdsPrachInfoList_r13, mpdcch_startSF_CSS_RA_r13, 0, prach_ParametersListCE_r13);

    value.set_prach_ConfigCommon_v1310(prach_ConfigCommon_v1310);

    /* Setting 'pucch_ConfigCommon_v1310' field */
    /* Creating 'n1PUCCH_AN_InfoList_r13' field of 'pucch_ConfigCommon_v1310' field */
    N1PUCCH_AN_InfoList_r13 n1PUCCH_AN_InfoList_r13;
    n1PUCCH_AN_InfoList_r13.prepend((OSS_UINT32)0);
    n1PUCCH_AN_InfoList_r13.prepend((OSS_UINT32)0);

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigCommon_v1310 pucch_ConfigCommon_v1310(n1PUCCH_AN_InfoList_r13, pucch_NumRepetitionCE_Msg4_Level0_r13_n1, pucch_NumRepetitionCE_Msg4_Level1_r13_n1, pucch_NumRepetitionCE_Msg4_Level2_r13_n4, pucch_NumRepetitionCE_Msg4_Level3_r13_n4);

    value.set_pucch_ConfigCommon_v1310(pucch_ConfigCommon_v1310);

    /* Setting 'highSpeedConfig_r14' field */

    /* Calling a fully-initializing constructor */
    HighSpeedConfig_r14 highSpeedConfig_r14(highSpeedEnhancedMeasFlag_r14_true, HighSpeedConfig_r14_highSpeedEnhancedDemodulationFlag_r14_true);

    value.set_highSpeedConfig_r14(highSpeedConfig_r14);

    /* Setting 'prach_Config_v1430' field */
    PRACH_Config_v1430 prach_Config_v1430;
    fill_PRACH_Config_v1430(prach_Config_v1430);
    value.set_prach_Config_v1430(prach_Config_v1430);

    /* Setting 'pucch_ConfigCommon_v1430' field */

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigCommon_v1430 pucch_ConfigCommon_v1430(pucch_NumRepetitionCE_Msg4_Level3_r14_n64);

    value.set_pucch_ConfigCommon_v1430(pucch_ConfigCommon_v1430);

    /* Setting 'prach_Config_v1530' field */
    /* Creating 'edt_PRACH_ParametersListCE_r15' field of 'prach_Config_v1530' field */
    PRACH_ConfigSIB_v1530::edt_PRACH_ParametersListCE_r15 edt_PRACH_ParametersListCE_r15;
    {
	/* Adding component #2 */
	EDT_PRACH_ParametersCE_r15 comp2;
	fill_EDT_PRACH_ParametersCE_r15(comp2);
	edt_PRACH_ParametersListCE_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	EDT_PRACH_ParametersCE_r15 comp1;
	fill_EDT_PRACH_ParametersCE_r15(comp1);
	edt_PRACH_ParametersListCE_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    PRACH_ConfigSIB_v1530 prach_Config_v1530(edt_PRACH_ParametersListCE_r15);

    value.set_prach_Config_v1530(prach_Config_v1530);

    /* Setting 'ce_RSS_Config_r15' field */

    /* Calling a fully-initializing constructor */
    RSS_Config_r15 ce_RSS_Config_r15(duration_r15_sf8, 0, periodicity_r15_ms160, powerBoost_r15_dB0, 0);

    value.set_ce_RSS_Config_r15(ce_RSS_Config_r15);

    /* Setting 'wus_Config_r15' field */

    /* Calling a fully-initializing constructor */
    WUS_Config_r15 wus_Config_r15(maxDurationFactor_r15_one32th, WUS_Config_r15_numPOs_r15_n1, freqLocation_r15_n0, WUS_Config_r15_timeOffsetDRX_r15_ms40, WUS_Config_r15_timeOffset_eDRX_Short_r15_ms40, WUS_Config_r15_timeOffset_eDRX_Long_r15_ms1000);

    value.set_wus_Config_r15(wus_Config_r15);

    /* Setting 'highSpeedConfig_v1530' field */

    /* Calling a fully-initializing constructor */
    HighSpeedConfig_v1530 highSpeedConfig_v1530(highSpeedMeasGapCE_ModeA_r15_true);

    value.set_highSpeedConfig_v1530(highSpeedConfig_v1530);
}

static void fill_UE_TimersAndConstants(UE_TimersAndConstants & value)
{
    value.set_t300(t300_ms100);
    value.set_t301(t301_ms100);
    value.set_t310(t310_ms0);
    value.set_n310(n310_n1);
    value.set_t311(t311_ms1000);
    value.set_n311(n311_n1);
    value.set_t300_v1310(t300_v1310_ms2500);
    value.set_t301_v1310(UE_TimersAndConstants_t301_v1310_ms2500);
    value.set_t310_v1330(UE_TimersAndConstants_t310_v1330_ms4000);
    value.set_t300_r15(t300_r15_ms4000);
}

static void fill_data_22(SystemInformationBlockType2::freqInfo & value)
{
    value.set_ul_CarrierFreq(0);
    value.set_ul_Bandwidth(SystemInformationBlockType2_freqInfo_ul_Bandwidth_n6);
    value.set_additionalSpectrumEmission(1);
}

static void fill_MBSFN_SubframeConfig(MBSFN_SubframeConfig & value)
{
    value.set_radioframeAllocationPeriod(radioframeAllocationPeriod_n1);
    value.set_radioframeAllocationOffset(0);
    /* Setting 'subframeAllocation' field */
    MBSFN_SubframeConfig::subframeAllocation subframeAllocation;
    /* Setting 'oneFrame' alternative of 'subframeAllocation' field */
    static unsigned char oneFrame_value[] = {
	0x00
    };
    OssBitString oneFrame(6, oneFrame_value);
    subframeAllocation.set_oneFrame(oneFrame);

    value.set_subframeAllocation(subframeAllocation);
}

static void fill_MBSFN_SubframeConfigList(MBSFN_SubframeConfigList & value)
{
    {
	/* Adding component #2 */
	MBSFN_SubframeConfig comp2;
	fill_MBSFN_SubframeConfig(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MBSFN_SubframeConfig comp1;
	fill_MBSFN_SubframeConfig(comp1);
	value.prepend(comp1);
    }
}

static void fill_decoded_3(SystemInformationBlockType2_v8h0_IEs & value)
{
    /* Setting 'multiBandInfoList' field */
    SystemInformationBlockType2_v8h0_IEs::multiBandInfoList multiBandInfoList;
    multiBandInfoList.prepend(1);
    multiBandInfoList.prepend(1);
    value.set_multiBandInfoList(multiBandInfoList);

    /* Setting 'nonCriticalExtension' field */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    SystemInformationBlockType2_v9i0_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;
    /* Creating 'freqInfo_v10l0' field */

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2_v10m0_IEs::freqInfo_v10l0 freqInfo_v10l0(33);

    /* Creating 'multiBandInfoList_v10l0' field */
    SystemInformationBlockType2_v10m0_IEs::multiBandInfoList_v10l0 multiBandInfoList_v10l0;
    multiBandInfoList_v10l0.prepend(33);
    multiBandInfoList_v10l0.prepend(33);

    /* Creating 'nonCriticalExtension' field */
    SystemInformationBlockType2_v10m0_IEs::nonCriticalExtension decoded_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2_v10m0_IEs decoded(freqInfo_v10l0, multiBandInfoList_v10l0, decoded_nonCriticalExtension);

    nonCriticalExtension_nonCriticalExtension_nonCriticalExtension.set_decoded(decoded);

    /* Creating 'dummy' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    SystemInformationBlockType2_v9i0_IEs::dummy dummy;

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2_v9i0_IEs nonCriticalExtension_nonCriticalExtension(nonCriticalExtension_nonCriticalExtension_nonCriticalExtension, dummy);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2_v9e0_IEs nonCriticalExtension(65536, nonCriticalExtension_nonCriticalExtension);

    value.set_nonCriticalExtension(nonCriticalExtension);
}

static void fill_AC_BarringPerPLMN_r12(AC_BarringPerPLMN_r12 & value)
{
    value.set_plmn_IdentityIndex_r12(1);
    /* Setting 'ac_BarringInfo_r12' field */
    /* Creating 'ac_BarringForMO_Signalling_r12' field of 'ac_BarringInfo_r12' field */
    AC_BarringConfig ac_BarringForMO_Signalling_r12;
    fill_AC_BarringConfig(ac_BarringForMO_Signalling_r12);

    /* Creating 'ac_BarringForMO_Data_r12' field of 'ac_BarringInfo_r12' field */
    AC_BarringConfig ac_BarringForMO_Data_r12;
    fill_AC_BarringConfig(ac_BarringForMO_Data_r12);

    /* Calling a fully-initializing constructor */
    AC_BarringPerPLMN_r12::ac_BarringInfo_r12 ac_BarringInfo_r12(TRUE, ac_BarringForMO_Signalling_r12, ac_BarringForMO_Data_r12);

    value.set_ac_BarringInfo_r12(ac_BarringInfo_r12);

    value.set_ac_BarringSkipForMMTELVoice_r12(AC_BarringPerPLMN_r12_ac_BarringSkipForMMTELVoice_r12_true);
    value.set_ac_BarringSkipForMMTELVideo_r12(AC_BarringPerPLMN_r12_ac_BarringSkipForMMTELVideo_r12_true);
    value.set_ac_BarringSkipForSMS_r12(AC_BarringPerPLMN_r12_ac_BarringSkipForSMS_r12_true);
    /* Setting 'ac_BarringForCSFB_r12' field */
    AC_BarringConfig ac_BarringForCSFB_r12;
    fill_AC_BarringConfig(ac_BarringForCSFB_r12);
    value.set_ac_BarringForCSFB_r12(ac_BarringForCSFB_r12);

    /* Setting 'ssac_BarringForMMTEL_Voice_r12' field */
    AC_BarringConfig ssac_BarringForMMTEL_Voice_r12;
    fill_AC_BarringConfig(ssac_BarringForMMTEL_Voice_r12);
    value.set_ssac_BarringForMMTEL_Voice_r12(ssac_BarringForMMTEL_Voice_r12);

    /* Setting 'ssac_BarringForMMTEL_Video_r12' field */
    AC_BarringConfig ssac_BarringForMMTEL_Video_r12;
    fill_AC_BarringConfig(ssac_BarringForMMTEL_Video_r12);
    value.set_ssac_BarringForMMTEL_Video_r12(ssac_BarringForMMTEL_Video_r12);
}

static void fill_AC_BarringPerPLMN_List_r12(AC_BarringPerPLMN_List_r12 & value)
{
    {
	/* Adding component #2 */
	AC_BarringPerPLMN_r12 comp2;
	fill_AC_BarringPerPLMN_r12(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	AC_BarringPerPLMN_r12 comp1;
	fill_AC_BarringPerPLMN_r12(comp1);
	value.prepend(comp1);
    }
}

static void fill_BarringPerACDC_Category_r13(BarringPerACDC_Category_r13 & value)
{
    value.set_acdc_Category_r13(1);
    /* Setting 'acdc_BarringConfig_r13' field */

    /* Calling a fully-initializing constructor */
    BarringPerACDC_Category_r13::acdc_BarringConfig_r13 acdc_BarringConfig_r13(ac_BarringFactor_r13_p00, ac_BarringTime_r13_s4);

    value.set_acdc_BarringConfig_r13(acdc_BarringConfig_r13);
}

static void fill_BarringPerACDC_CategoryList_r13(BarringPerACDC_CategoryList_r13 & value)
{
    {
	/* Adding component #2 */
	BarringPerACDC_Category_r13 comp2;
	fill_BarringPerACDC_Category_r13(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BarringPerACDC_Category_r13 comp1;
	fill_BarringPerACDC_Category_r13(comp1);
	value.prepend(comp1);
    }
}

static void fill_ACDC_BarringForCommon_r13(ACDC_BarringForCommon_r13 & value)
{
    value.set_acdc_HPLMNonly_r13(TRUE);
    /* Setting 'barringPerACDC_CategoryList_r13' field */
    BarringPerACDC_CategoryList_r13 barringPerACDC_CategoryList_r13;
    fill_BarringPerACDC_CategoryList_r13(barringPerACDC_CategoryList_r13);
    value.set_barringPerACDC_CategoryList_r13(barringPerACDC_CategoryList_r13);
}

static void fill_ACDC_BarringPerPLMN_r13(ACDC_BarringPerPLMN_r13 & value)
{
    value.set_plmn_IdentityIndex_r13(1);
    value.set_acdc_OnlyForHPLMN_r13(TRUE);
    /* Setting 'barringPerACDC_CategoryList_r13' field */
    BarringPerACDC_CategoryList_r13 barringPerACDC_CategoryList_r13;
    fill_BarringPerACDC_CategoryList_r13(barringPerACDC_CategoryList_r13);
    value.set_barringPerACDC_CategoryList_r13(barringPerACDC_CategoryList_r13);
}

static void fill_ACDC_BarringPerPLMN_List_r13(ACDC_BarringPerPLMN_List_r13 & value)
{
    {
	/* Adding component #2 */
	ACDC_BarringPerPLMN_r13 comp2;
	fill_ACDC_BarringPerPLMN_r13(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	ACDC_BarringPerPLMN_r13 comp1;
	fill_ACDC_BarringPerPLMN_r13(comp1);
	value.prepend(comp1);
    }
}

static void fill_UDT_Restricting_r13(UDT_Restricting_r13 & value)
{
    value.set_udt_Restricting_r13(udt_Restricting_r13_true);
    value.set_udt_RestrictingTime_r13(udt_RestrictingTime_r13_s4);
}

static void fill_UDT_RestrictingPerPLMN_r13(UDT_RestrictingPerPLMN_r13 & value)
{
    value.set_plmn_IdentityIndex_r13(1);
    /* Setting 'udt_Restricting_r13' field */
    UDT_Restricting_r13 udt_Restricting_r13;
    fill_UDT_Restricting_r13(udt_Restricting_r13);
    value.set_udt_Restricting_r13(udt_Restricting_r13);
}

static void fill_UDT_RestrictingPerPLMN_List_r13(UDT_RestrictingPerPLMN_List_r13 & value)
{
    {
	/* Adding component #2 */
	UDT_RestrictingPerPLMN_r13 comp2;
	fill_UDT_RestrictingPerPLMN_r13(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	UDT_RestrictingPerPLMN_r13 comp1;
	fill_UDT_RestrictingPerPLMN_r13(comp1);
	value.prepend(comp1);
    }
}

static void fill_CIOT_OptimisationPLMN_r13(CIOT_OptimisationPLMN_r13 & value)
{
    value.set_up_CIoT_EPS_Optimisation_r13(CIOT_OptimisationPLMN_r13_up_CIoT_EPS_Optimisation_r13_true);
    value.set_cp_CIoT_EPS_Optimisation_r13(CIOT_OptimisationPLMN_r13_cp_CIoT_EPS_Optimisation_r13_true);
    value.set_attachWithoutPDN_Connectivity_r13(CIOT_OptimisationPLMN_r13_attachWithoutPDN_Connectivity_r13_true);
}

static void fill_CIOT_EPS_OptimisationInfo_r13(CIOT_EPS_OptimisationInfo_r13 & value)
{
    {
	/* Adding component #2 */
	CIOT_OptimisationPLMN_r13 comp2;
	fill_CIOT_OptimisationPLMN_r13(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CIOT_OptimisationPLMN_r13 comp1;
	fill_CIOT_OptimisationPLMN_r13(comp1);
	value.prepend(comp1);
    }
}

static void fill_MBSFN_SubframeConfig_v1430(MBSFN_SubframeConfig_v1430 & value)
{
    /* Setting 'subframeAllocation_v1430' field */
    MBSFN_SubframeConfig_v1430::subframeAllocation_v1430 subframeAllocation_v1430;
    /* Setting 'oneFrame_v1430' alternative of 'subframeAllocation_v1430' field */
    static unsigned char oneFrame_v1430_value[] = {
	0x00
    };
    OssBitString oneFrame_v1430(2, oneFrame_v1430_value);
    subframeAllocation_v1430.set_oneFrame_v1430(oneFrame_v1430);

    value.set_subframeAllocation_v1430(subframeAllocation_v1430);
}

static void fill_MBSFN_SubframeConfigList_v1430(MBSFN_SubframeConfigList_v1430 & value)
{
    {
	/* Adding component #2 */
	MBSFN_SubframeConfig_v1430 comp2;
	fill_MBSFN_SubframeConfig_v1430(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MBSFN_SubframeConfig_v1430 comp1;
	fill_MBSFN_SubframeConfig_v1430(comp1);
	value.prepend(comp1);
    }
}

static void fill_PLMN_Info_r15(PLMN_Info_r15 & value)
{
    value.set_upperLayerIndication_r15(upperLayerIndication_r15_true);
}

static void fill_PLMN_InfoList_r15(PLMN_InfoList_r15 & value)
{
    {
	/* Adding component #2 */
	PLMN_Info_r15 comp2;
	fill_PLMN_Info_r15(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_Info_r15 comp1;
	fill_PLMN_Info_r15(comp1);
	value.prepend(comp1);
    }
}

static void fill_data_24(SystemInformation_r8_IEs::sib_TypeAndInfo::component & value)
{
    /* Setting 'sib2' alternative */
    /* Creating 'ac_BarringInfo' field of 'sib2' alternative */
    SystemInformationBlockType2::ac_BarringInfo ac_BarringInfo;
    fill_data_23(ac_BarringInfo);

    /* Creating 'radioResourceConfigCommon' field of 'sib2' alternative */
    RadioResourceConfigCommonSIB radioResourceConfigCommon;
    fill_RadioResourceConfigCommonSIB(radioResourceConfigCommon);

    /* Creating 'ue_TimersAndConstants' field of 'sib2' alternative */
    UE_TimersAndConstants ue_TimersAndConstants;
    fill_UE_TimersAndConstants(ue_TimersAndConstants);

    /* Creating 'freqInfo' field of 'sib2' alternative */
    SystemInformationBlockType2::freqInfo freqInfo;
    fill_data_22(freqInfo);

    /* Creating 'mbsfn_SubframeConfigList' field of 'sib2' alternative */
    MBSFN_SubframeConfigList mbsfn_SubframeConfigList;
    fill_MBSFN_SubframeConfigList(mbsfn_SubframeConfigList);

    /* Creating 'lateNonCriticalExtension' field of 'sib2' alternative */
    SystemInformationBlockType2::lateNonCriticalExtension lateNonCriticalExtension;
    SystemInformationBlockType2_v8h0_IEs decoded;
    fill_decoded_3(decoded);
    lateNonCriticalExtension.set_decoded(decoded);

    /* Creating 'ssac_BarringForMMTEL_Voice_r9' field of 'sib2' alternative */
    AC_BarringConfig ssac_BarringForMMTEL_Voice_r9;
    fill_AC_BarringConfig(ssac_BarringForMMTEL_Voice_r9);

    /* Creating 'ssac_BarringForMMTEL_Video_r9' field of 'sib2' alternative */
    AC_BarringConfig ssac_BarringForMMTEL_Video_r9;
    fill_AC_BarringConfig(ssac_BarringForMMTEL_Video_r9);

    /* Creating 'ac_BarringForCSFB_r10' field of 'sib2' alternative */
    AC_BarringConfig ac_BarringForCSFB_r10;
    fill_AC_BarringConfig(ac_BarringForCSFB_r10);

    /* Creating 'ac_BarringPerPLMN_List_r12' field of 'sib2' alternative */
    AC_BarringPerPLMN_List_r12 ac_BarringPerPLMN_List_r12;
    fill_AC_BarringPerPLMN_List_r12(ac_BarringPerPLMN_List_r12);

    /* Creating 'acdc_BarringForCommon_r13' field of 'sib2' alternative */
    ACDC_BarringForCommon_r13 acdc_BarringForCommon_r13;
    fill_ACDC_BarringForCommon_r13(acdc_BarringForCommon_r13);

    /* Creating 'acdc_BarringPerPLMN_List_r13' field of 'sib2' alternative */
    ACDC_BarringPerPLMN_List_r13 acdc_BarringPerPLMN_List_r13;
    fill_ACDC_BarringPerPLMN_List_r13(acdc_BarringPerPLMN_List_r13);

    /* Creating 'udt_RestrictingForCommon_r13' field of 'sib2' alternative */
    UDT_Restricting_r13 udt_RestrictingForCommon_r13;
    fill_UDT_Restricting_r13(udt_RestrictingForCommon_r13);

    /* Creating 'udt_RestrictingPerPLMN_List_r13' field of 'sib2' alternative */
    UDT_RestrictingPerPLMN_List_r13 udt_RestrictingPerPLMN_List_r13;
    fill_UDT_RestrictingPerPLMN_List_r13(udt_RestrictingPerPLMN_List_r13);

    /* Creating 'cIoT_EPS_OptimisationInfo_r13' field of 'sib2' alternative */
    CIOT_EPS_OptimisationInfo_r13 cIoT_EPS_OptimisationInfo_r13;
    fill_CIOT_EPS_OptimisationInfo_r13(cIoT_EPS_OptimisationInfo_r13);

    /* Creating 'mbsfn_SubframeConfigList_v1430' field of 'sib2' alternative */
    MBSFN_SubframeConfigList_v1430 mbsfn_SubframeConfigList_v1430;
    fill_MBSFN_SubframeConfigList_v1430(mbsfn_SubframeConfigList_v1430);

    /* Creating 'plmn_InfoList_r15' field of 'sib2' alternative */
    PLMN_InfoList_r15 plmn_InfoList_r15;
    fill_PLMN_InfoList_r15(plmn_InfoList_r15);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2 sib2(ac_BarringInfo, radioResourceConfigCommon, ue_TimersAndConstants, freqInfo, mbsfn_SubframeConfigList, TimeAlignmentTimer_sf500, lateNonCriticalExtension, ssac_BarringForMMTEL_Voice_r9, ssac_BarringForMMTEL_Video_r9, ac_BarringForCSFB_r10, SystemInformationBlockType2_ac_BarringSkipForMMTELVoice_r12_true, SystemInformationBlockType2_ac_BarringSkipForMMTELVideo_r12_true, SystemInformationBlockType2_ac_BarringSkipForSMS_r12_true, ac_BarringPerPLMN_List_r12, voiceServiceCauseIndication_r12_true, acdc_BarringForCommon_r13, acdc_BarringPerPLMN_List_r13, udt_RestrictingForCommon_r13, udt_RestrictingPerPLMN_List_r13, cIoT_EPS_OptimisationInfo_r13, useFullResumeID_r13_true, unicastFreqHoppingInd_r13_true, mbsfn_SubframeConfigList_v1430, videoServiceCauseIndication_r14_true, plmn_InfoList_r15, SystemInformationBlockType2_cp_EDT_r15_true, SystemInformationBlockType2_up_EDT_r15_true, idleModeMeasurements_r15_true, reducedCP_LatencyEnabled_r15_true);

    value.set_sib2(sib2);
}

static void fill_data_21(SystemInformation_v8a0_IEs::nonCriticalExtension & value)
{
}

static void fill_SystemInformation_v8a0_IEs(SystemInformation_v8a0_IEs & value)
{
    /* Setting 'lateNonCriticalExtension' field */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);
    value.set_lateNonCriticalExtension(lateNonCriticalExtension);

    /* Setting 'nonCriticalExtension' field */
    SystemInformation_v8a0_IEs::nonCriticalExtension nonCriticalExtension;
    fill_data_21(nonCriticalExtension);
    value.set_nonCriticalExtension(nonCriticalExtension);
}

static void fill_SystemInformation(SystemInformation & value)
{
    /* Setting 'criticalExtensions' field */
    SystemInformation::criticalExtensions criticalExtensions;
    /* Setting 'systemInformation_r8' alternative of 'criticalExtensions' field */
    /* Creating 'sib_TypeAndInfo' field of 'systemInformation_r8' alternative of 'criticalExtensions' field */
    SystemInformation_r8_IEs::sib_TypeAndInfo sib_TypeAndInfo;
    {
	/* Adding component #2 */
	SystemInformation_r8_IEs::sib_TypeAndInfo::component comp2;
	fill_data_24(comp2);
	sib_TypeAndInfo.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SystemInformation_r8_IEs::sib_TypeAndInfo::component comp1;
	fill_data_24(comp1);
	sib_TypeAndInfo.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'systemInformation_r8' alternative of 'criticalExtensions' field */
    SystemInformation_v8a0_IEs nonCriticalExtension;
    fill_SystemInformation_v8a0_IEs(nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformation_r8_IEs systemInformation_r8(sib_TypeAndInfo, nonCriticalExtension);

    criticalExtensions.set_systemInformation_r8(systemInformation_r8);

    value.set_criticalExtensions(criticalExtensions);
}

BCCH_DL_SCH_Message *create_samplevalue_BCCH_DL_SCH_Message()
{
    /* Creating 'message' field */
    BCCH_DL_SCH_MessageType message;
    /* Setting 'c1' alternative of 'message' field */
    BCCH_DL_SCH_MessageType::c1 c1;
    /* Setting 'systemInformation' alternative of 'c1' alternative of 'message' field */
    SystemInformation systemInformation;
    fill_SystemInformation(systemInformation);
    c1.set_systemInformation(systemInformation);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new BCCH_DL_SCH_Message(message);
}

BCCH_DL_SCH_Message_BR *create_samplevalue_BCCH_DL_SCH_Message_BR()
{
    /* Creating 'message' field */
    BCCH_DL_SCH_MessageType_BR_r13 message;
    /* Setting 'c1' alternative of 'message' field */
    BCCH_DL_SCH_MessageType_BR_r13::c1 c1;
    /* Setting 'systemInformation_BR_r13' alternative of 'c1' alternative of 'message' field */
    SystemInformation_BR_r13 systemInformation_BR_r13;
    fill_SystemInformation(systemInformation_BR_r13);
    c1.set_systemInformation_BR_r13(systemInformation_BR_r13);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new BCCH_DL_SCH_Message_BR(message);
}

BCCH_DL_SCH_Message_MBMS *create_samplevalue_BCCH_DL_SCH_Message_MBMS()
{
    /* Creating 'message' field */
    BCCH_DL_SCH_MessageType_MBMS_r14 message;
    /* Setting 'c1' alternative of 'message' field */
    BCCH_DL_SCH_MessageType_MBMS_r14::c1 c1;
    /* Setting 'systemInformation_MBMS_r14' alternative of 'c1' alternative of 'message' field */
    SystemInformation_MBMS_r14 systemInformation_MBMS_r14;
    fill_SystemInformation(systemInformation_MBMS_r14);
    c1.set_systemInformation_MBMS_r14(systemInformation_MBMS_r14);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new BCCH_DL_SCH_Message_MBMS(message);
}

static void fill_TMGI_r9(TMGI_r9 & value)
{
    /* Setting 'plmn_Id_r9' field */
    TMGI_r9::plmn_Id_r9 plmn_Id_r9;
    plmn_Id_r9.set_plmn_Index_r9(1);
    value.set_plmn_Id_r9(plmn_Id_r9);

    /* Setting 'serviceId_r9' field */
    static unsigned char serviceId_r9_value[] = {
	0x00, 0x00, 0x00
    };
    OssString serviceId_r9(sizeof(serviceId_r9_value), (char *)serviceId_r9_value);
    value.set_serviceId_r9(serviceId_r9);
}

static void fill_MBMS_SessionInfo_r9(MBMS_SessionInfo_r9 & value)
{
    /* Setting 'tmgi_r9' field */
    TMGI_r9 tmgi_r9;
    fill_TMGI_r9(tmgi_r9);
    value.set_tmgi_r9(tmgi_r9);

    /* Setting 'sessionId_r9' field */
    static unsigned char sessionId_r9_value[] = {
	0x00
    };
    OssString sessionId_r9(sizeof(sessionId_r9_value), (char *)sessionId_r9_value);
    value.set_sessionId_r9(sessionId_r9);

    value.set_logicalChannelIdentity_r9(0);
}

static void fill_MBMS_SessionInfoList_r9(MBMS_SessionInfoList_r9 & value)
{
    {
	/* Adding component #2 */
	MBMS_SessionInfo_r9 comp2;
	fill_MBMS_SessionInfo_r9(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MBMS_SessionInfo_r9 comp1;
	fill_MBMS_SessionInfo_r9(comp1);
	value.prepend(comp1);
    }
}

static void fill_PMCH_Info_r9(PMCH_Info_r9 & value)
{
    /* Setting 'pmch_Config_r9' field */

    /* Calling a fully-initializing constructor */
    PMCH_Config_r9 pmch_Config_r9(0, 0, mch_SchedulingPeriod_r9_rf8);

    value.set_pmch_Config_r9(pmch_Config_r9);

    /* Setting 'mbms_SessionInfoList_r9' field */
    MBMS_SessionInfoList_r9 mbms_SessionInfoList_r9;
    fill_MBMS_SessionInfoList_r9(mbms_SessionInfoList_r9);
    value.set_mbms_SessionInfoList_r9(mbms_SessionInfoList_r9);
}

static void fill_PMCH_InfoExt_r12(PMCH_InfoExt_r12 & value)
{
    /* Setting 'pmch_Config_r12' field */
    /* Creating 'dataMCS_r12' field of 'pmch_Config_r12' field */
    PMCH_Config_r12::dataMCS_r12 dataMCS_r12;
    dataMCS_r12.set_normal_r12(0);

    /* Calling a fully-initializing constructor */
    PMCH_Config_r12 pmch_Config_r12(0, dataMCS_r12, mch_SchedulingPeriod_r12_rf4, mch_SchedulingPeriod_v1430_rf1);

    value.set_pmch_Config_r12(pmch_Config_r12);

    /* Setting 'mbms_SessionInfoList_r12' field */
    MBMS_SessionInfoList_r9 mbms_SessionInfoList_r12;
    fill_MBMS_SessionInfoList_r9(mbms_SessionInfoList_r12);
    value.set_mbms_SessionInfoList_r12(mbms_SessionInfoList_r12);
}

MCCH_Message *create_samplevalue_MCCH_Message()
{
    /* Creating 'message' field */
    MCCH_MessageType message;
    /* Setting 'c1' alternative of 'message' field */
    MCCH_MessageType::c1 c1;
    /* Setting 'mbsfnAreaConfiguration_r9' alternative of 'c1' alternative of 'message' field */
    /* Creating 'commonSF_Alloc_r9' field of 'mbsfnAreaConfiguration_r9' alternative of 'c1' alternative of 'message' field... */
    CommonSF_AllocPatternList_r9 commonSF_Alloc_r9;
    {
	/* Adding component #2 */
	MBSFN_SubframeConfig comp2;
	fill_MBSFN_SubframeConfig(comp2);
	commonSF_Alloc_r9.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MBSFN_SubframeConfig comp1;
	fill_MBSFN_SubframeConfig(comp1);
	commonSF_Alloc_r9.prepend(comp1);
    }

    /* Creating 'pmch_InfoList_r9' field of 'mbsfnAreaConfiguration_r9' alternative of 'c1' alternative of 'message' field... */
    PMCH_InfoList_r9 pmch_InfoList_r9;
    {
	/* Adding component #2 */
	PMCH_Info_r9 comp2;
	fill_PMCH_Info_r9(comp2);
	pmch_InfoList_r9.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PMCH_Info_r9 comp1;
	fill_PMCH_Info_r9(comp1);
	pmch_InfoList_r9.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'mbsfnAreaConfiguration_r9' alternative of 'c1' alternative of 'message' field... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'mbsfnAreaConfiguration_r9' alternative of 'c1' alternative... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'mbsfnAreaConfiguration_r9' alternative of 'c1' alternative... */
    /* Creating 'pmch_InfoListExt_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'mbsfnAreaConfiguration_r9' alternative... */
    PMCH_InfoListExt_r12 pmch_InfoListExt_r12;
    {
	/* Adding component #2 */
	PMCH_InfoExt_r12 comp2;
	fill_PMCH_InfoExt_r12(comp2);
	pmch_InfoListExt_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PMCH_InfoExt_r12 comp1;
	fill_PMCH_InfoExt_r12(comp1);
	pmch_InfoListExt_r12.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'mbsfnAreaConfiguration_r9' alternative... */
    /* Creating 'commonSF_Alloc_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    CommonSF_AllocPatternList_r14 commonSF_Alloc_r14;
    {
	/* Adding component #2 */
	MBSFN_SubframeConfig_v1430 comp2;
	fill_MBSFN_SubframeConfig_v1430(comp2);
	commonSF_Alloc_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MBSFN_SubframeConfig_v1430 comp1;
	fill_MBSFN_SubframeConfig_v1430(comp1);
	commonSF_Alloc_r14.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MBSFNAreaConfiguration_v1430_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    MBSFNAreaConfiguration_v1430_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(commonSF_Alloc_r14, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    MBSFNAreaConfiguration_v1250_IEs nonCriticalExtension_nonCriticalExtension(pmch_InfoListExt_r12, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    MBSFNAreaConfiguration_v930_IEs nonCriticalExtension(lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    MBSFNAreaConfiguration_r9 mbsfnAreaConfiguration_r9(commonSF_Alloc_r9, commonSF_AllocPeriod_r9_rf4, pmch_InfoList_r9, nonCriticalExtension);

    c1.set_mbsfnAreaConfiguration_r9(mbsfnAreaConfiguration_r9);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new MCCH_Message(message);
}

static void fill_PagingUE_Identity(PagingUE_Identity & value)
{
    /* Setting 's_TMSI' alternative */
    /* Creating 'mmec' field of 's_TMSI' alternative */
    static unsigned char mmec_value[] = {
	0x00
    };
    OssBitString mmec(8, mmec_value);

    /* Creating 'm_TMSI' field of 's_TMSI' alternative */
    static unsigned char m_TMSI_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString m_TMSI(32, m_TMSI_value);

    /* Calling a fully-initializing constructor */
    S_TMSI s_TMSI(mmec, m_TMSI);

    value.set_s_TMSI(s_TMSI);
}

static void fill_PagingRecord(PagingRecord & value)
{
    /* Setting 'ue_Identity' field */
    PagingUE_Identity ue_Identity;
    fill_PagingUE_Identity(ue_Identity);
    value.set_ue_Identity(ue_Identity);

    value.set_cn_Domain(ps);
}

PCCH_Message *create_samplevalue_PCCH_Message()
{
    /* Creating 'message' field */
    PCCH_MessageType message;
    /* Setting 'c1' alternative of 'message' field */
    PCCH_MessageType::c1 c1;
    /* Setting 'paging' alternative of 'c1' alternative of 'message' field */
    /* Creating 'pagingRecordList' field of 'paging' alternative of 'c1' alternative of 'message' field... */
    PagingRecordList pagingRecordList;
    {
	/* Adding component #2 */
	PagingRecord comp2;
	fill_PagingRecord(comp2);
	pagingRecordList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PagingRecord comp1;
	fill_PagingRecord(comp1);
	pagingRecordList.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'paging' alternative of 'c1' alternative of 'message' field... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'paging' alternative of 'c1' alternative... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'paging' alternative of 'c1' alternative... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'paging' alternative... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    Paging_v1530_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    Paging_v1530_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(non3GPP, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    Paging_v1310_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(redistributionIndication_r13_true, Paging_v1310_IEs_systemInfoModification_eDRX_r13_true, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    Paging_v1130_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(eab_ParamModification_r11_true, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    Paging_v920_IEs nonCriticalExtension_nonCriticalExtension(cmas_Indication_r9_true, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    Paging_v890_IEs nonCriticalExtension(lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    Paging paging(pagingRecordList, systemInfoModification_true, etws_Indication_true, nonCriticalExtension);

    c1.set_paging(paging);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new PCCH_Message(message);
}

static void fill_data_20(RLC_Config::am & value)
{
    /* Setting 'ul_AM_RLC' field */

    /* Calling a fully-initializing constructor */
    UL_AM_RLC ul_AM_RLC(T_PollRetransmit_ms5, PollPDU_p4, kB25, maxRetxThreshold_t1);

    value.set_ul_AM_RLC(ul_AM_RLC);

    /* Setting 'dl_AM_RLC' field */

    /* Calling a fully-initializing constructor */
    DL_AM_RLC dl_AM_RLC(T_Reordering_ms0, T_StatusProhibit_ms0);

    value.set_dl_AM_RLC(dl_AM_RLC);
}

static void fill_data_19(LogicalChannelConfig::ul_SpecificParameters & value)
{
    value.set_priority(1);
    value.set_prioritisedBitRate(kBps0);
    value.set_bucketSizeDuration(bucketSizeDuration_ms50);
    value.set_logicalChannelGroup(0);
}

static void fill_data_18(LogicalChannelConfig::allowedTTI_Lengths_r15 & value)
{
    value.set_release(0);
}

static void fill_data_17(LogicalChannelConfig::logicalChannelSR_Restriction_r15 & value)
{
    value.set_release(0);
}

static void fill_data_16(LogicalChannelConfig::channellAccessPriority_r15 & value)
{
    value.set_release(0);
}

static void fill_RLC_Config_v1530(RLC_Config_v1530 & value)
{
    value.set_release(0);
}

static void fill_RLC_BearerConfig_r15(RLC_BearerConfig_r15 & value)
{
    value.set_release(0);
}

static void fill_SRB_ToAddMod(SRB_ToAddMod & value)
{
    value.set_srb_Identity(1);
    /* Setting 'rlc_Config' field */
    SRB_ToAddMod::rlc_Config rlc_Config;
    /* Setting 'explicitValue' alternative of 'rlc_Config' field */
    RLC_Config explicitValue;
    /* Setting 'am' alternative of 'explicitValue' alternative of 'rlc_Config' field */
    RLC_Config::am am;
    fill_data_20(am);
    explicitValue.set_am(am);

    rlc_Config.set_explicitValue(explicitValue);

    value.set_rlc_Config(rlc_Config);

    /* Setting 'logicalChannelConfig' field */
    SRB_ToAddMod::logicalChannelConfig logicalChannelConfig;
    /* Setting 'explicitValue' alternative of 'logicalChannelConfig' field */
    /* Creating 'ul_SpecificParameters' field of 'explicitValue' alternative of 'logicalChannelConfig' field */
    LogicalChannelConfig::ul_SpecificParameters ul_SpecificParameters;
    fill_data_19(ul_SpecificParameters);

    /* Creating 'allowedTTI_Lengths_r15' field of 'explicitValue' alternative of 'logicalChannelConfig' field */
    LogicalChannelConfig::allowedTTI_Lengths_r15 allowedTTI_Lengths_r15;
    fill_data_18(allowedTTI_Lengths_r15);

    /* Creating 'logicalChannelSR_Restriction_r15' field of 'explicitValue' alternative of 'logicalChannelConfig' field */
    LogicalChannelConfig::logicalChannelSR_Restriction_r15 logicalChannelSR_Restriction_r15;
    fill_data_17(logicalChannelSR_Restriction_r15);

    /* Creating 'channellAccessPriority_r15' field of 'explicitValue' alternative of 'logicalChannelConfig' field */
    LogicalChannelConfig::channellAccessPriority_r15 channellAccessPriority_r15;
    fill_data_16(channellAccessPriority_r15);

    /* Creating 'lch_CellRestriction_r15' field of 'explicitValue' alternative of 'logicalChannelConfig' field */
    static unsigned char lch_CellRestriction_r15_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString lch_CellRestriction_r15(32, lch_CellRestriction_r15_value);

    /* Calling a fully-initializing constructor */
    LogicalChannelConfig logicalChannelConfig_explicitValue(ul_SpecificParameters, logicalChannelSR_Mask_r9_setup, TRUE, TRUE, bitRateQueryProhibitTimer_r14_s0, allowedTTI_Lengths_r15, logicalChannelSR_Restriction_r15, channellAccessPriority_r15, lch_CellRestriction_r15);

    logicalChannelConfig.set_explicitValue(logicalChannelConfig_explicitValue);

    value.set_logicalChannelConfig(logicalChannelConfig);

    value.set_pdcp_verChange_r15(pdcp_verChange_r15_true);
    /* Setting 'rlc_Config_v1530' field */
    RLC_Config_v1530 rlc_Config_v1530;
    fill_RLC_Config_v1530(rlc_Config_v1530);
    value.set_rlc_Config_v1530(rlc_Config_v1530);

    /* Setting 'rlc_BearerConfigDupl_r15' field */
    RLC_BearerConfig_r15 rlc_BearerConfigDupl_r15;
    fill_RLC_BearerConfig_r15(rlc_BearerConfigDupl_r15);
    value.set_rlc_BearerConfigDupl_r15(rlc_BearerConfigDupl_r15);

    value.set_srb_Identity_v1530(4);
}

static void fill_RLC_Config(RLC_Config & value)
{
    /* Setting 'am' alternative of 'pdcp_DuplicationConfig_r15' field of 'rlc_Config' field */
    RLC_Config::am am;
    fill_data_20(am);
    value.set_am(am);
}

static void fill_LogicalChannelConfig(LogicalChannelConfig & value)
{
    /* Setting 'ul_SpecificParameters' field of 'pdcp_DuplicationConfig_r15' field of 'logicalChannelConfig' field */
    LogicalChannelConfig::ul_SpecificParameters ul_SpecificParameters;
    fill_data_19(ul_SpecificParameters);
    value.set_ul_SpecificParameters(ul_SpecificParameters);

    value.set_logicalChannelSR_Mask_r9(logicalChannelSR_Mask_r9_setup);
    value.set_logicalChannelSR_Prohibit_r12(TRUE);
    value.set_laa_UL_Allowed_r14(TRUE);
    value.set_bitRateQueryProhibitTimer_r14(bitRateQueryProhibitTimer_r14_s0);
    /* Setting 'allowedTTI_Lengths_r15' field of 'pdcp_DuplicationConfig_r15' field of 'logicalChannelConfig' field */
    LogicalChannelConfig::allowedTTI_Lengths_r15 allowedTTI_Lengths_r15;
    fill_data_18(allowedTTI_Lengths_r15);
    value.set_allowedTTI_Lengths_r15(allowedTTI_Lengths_r15);

    /* Setting 'logicalChannelSR_Restriction_r15' field of 'pdcp_DuplicationConfig_r15' field of 'logicalChannelConfig' field */
    LogicalChannelConfig::logicalChannelSR_Restriction_r15 logicalChannelSR_Restriction_r15;
    fill_data_17(logicalChannelSR_Restriction_r15);
    value.set_logicalChannelSR_Restriction_r15(logicalChannelSR_Restriction_r15);

    /* Setting 'channellAccessPriority_r15' field of 'pdcp_DuplicationConfig_r15' field of 'logicalChannelConfig' field */
    LogicalChannelConfig::channellAccessPriority_r15 channellAccessPriority_r15;
    fill_data_16(channellAccessPriority_r15);
    value.set_channellAccessPriority_r15(channellAccessPriority_r15);

    /* Setting 'lch_CellRestriction_r15' field of 'pdcp_DuplicationConfig_r15' field of 'logicalChannelConfig' field */
    static unsigned char lch_CellRestriction_r15_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString lch_CellRestriction_r15(32, lch_CellRestriction_r15_value);
    value.set_lch_CellRestriction_r15(lch_CellRestriction_r15);
}

static void fill_RLC_Config_v1250(RLC_Config_v1250 & value)
{
    value.set_ul_extended_RLC_LI_Field_r12(TRUE);
    value.set_dl_extended_RLC_LI_Field_r12(TRUE);
}

static void fill_RLC_Config_v1430(RLC_Config_v1430 & value)
{
    value.set_release(0);
}

static void fill_DRB_ToAddMod(DRB_ToAddMod & value)
{
    value.set_eps_BearerIdentity(0);
    value.set_drb_Identity(1);
    /* Setting 'pdcp_Config' field */
    /* Creating 'rlc_AM' field of 'pdcp_Config' field */

    /* Calling a fully-initializing constructor */
    PDCP_Config::rlc_AM rlc_AM(TRUE);

    /* Creating 'rlc_UM' field of 'pdcp_Config' field */

    /* Calling a fully-initializing constructor */
    PDCP_Config::rlc_UM rlc_UM(len7bits);

    /* Creating 'headerCompression' field of 'pdcp_Config' field */
    PDCP_Config::headerCompression headerCompression;
    headerCompression.set_notUsed(0);

    /* Creating 'ul_DataSplitThreshold_r13' field of 'pdcp_Config' field */
    PDCP_Config::ul_DataSplitThreshold_r13 ul_DataSplitThreshold_r13;
    ul_DataSplitThreshold_r13.set_release(0);

    /* Creating 'statusFeedback_r13' field of 'pdcp_Config' field */
    PDCP_Config::statusFeedback_r13 statusFeedback_r13;
    statusFeedback_r13.set_release(0);

    /* Creating 'ul_LWA_Config_r14' field of 'pdcp_Config' field */
    PDCP_Config::ul_LWA_Config_r14 ul_LWA_Config_r14;
    ul_LWA_Config_r14.set_release(0);

    /* Creating 'uplinkOnlyHeaderCompression_r14' field of 'pdcp_Config' field */
    PDCP_Config::uplinkOnlyHeaderCompression_r14 uplinkOnlyHeaderCompression_r14;
    uplinkOnlyHeaderCompression_r14.set_notUsed_r14(0);

    /* Creating 'uplinkDataCompression_r15' field of 'pdcp_Config' field */

    /* Calling a fully-initializing constructor */
    PDCP_Config::uplinkDataCompression_r15 uplinkDataCompression_r15(kbyte2, sip_SDP);

    /* Creating 'pdcp_DuplicationConfig_r15' field of 'pdcp_Config' field */
    PDCP_Config::pdcp_DuplicationConfig_r15 pdcp_DuplicationConfig_r15;
    pdcp_DuplicationConfig_r15.set_release(0);

    /* Calling a fully-initializing constructor */
    PDCP_Config pdcp_Config(discardTimer_ms50, rlc_AM, rlc_UM, headerCompression, rn_IntegrityProtection_r10_enabled, len15bits, TRUE, t_Reordering_r12_ms0, ul_DataSplitThreshold_r13, len18bits, statusFeedback_r13, ul_LWA_Config_r14, uplinkOnlyHeaderCompression_r14, uplinkDataCompression_r15, pdcp_DuplicationConfig_r15);

    value.set_pdcp_Config(pdcp_Config);

    /* Setting 'rlc_Config' field */
    RLC_Config rlc_Config;
    fill_RLC_Config(rlc_Config);
    value.set_rlc_Config(rlc_Config);

    value.set_logicalChannelIdentity(3);
    /* Setting 'logicalChannelConfig' field */
    LogicalChannelConfig logicalChannelConfig;
    fill_LogicalChannelConfig(logicalChannelConfig);
    value.set_logicalChannelConfig(logicalChannelConfig);

    value.set_drb_TypeChange_r12(toMCG);
    /* Setting 'rlc_Config_v1250' field */
    RLC_Config_v1250 rlc_Config_v1250;
    fill_RLC_Config_v1250(rlc_Config_v1250);
    value.set_rlc_Config_v1250(rlc_Config_v1250);

    /* Setting 'rlc_Config_v1310' field */

    /* Calling a fully-initializing constructor */
    RLC_Config_v1310 rlc_Config_v1310(TRUE, TRUE, PollPDU_v1310_p512);

    value.set_rlc_Config_v1310(rlc_Config_v1310);

    value.set_drb_TypeLWA_r13(TRUE);
    value.set_drb_TypeLWIP_r13(lwip);
    /* Setting 'rlc_Config_v1430' field */
    RLC_Config_v1430 rlc_Config_v1430;
    fill_RLC_Config_v1430(rlc_Config_v1430);
    value.set_rlc_Config_v1430(rlc_Config_v1430);

    value.set_lwip_UL_Aggregation_r14(TRUE);
    value.set_lwip_DL_Aggregation_r14(TRUE);
    value.set_lwa_WLAN_AC_r14(ac_bk);
    /* Setting 'rlc_Config_v1510' field */

    /* Calling a fully-initializing constructor */
    RLC_Config_v1510 rlc_Config_v1510(RLC_Config_v1510_reestablishRLC_r15_true);

    value.set_rlc_Config_v1510(rlc_Config_v1510);

    /* Setting 'rlc_Config_v1530' field */
    RLC_Config_v1530 rlc_Config_v1530;
    fill_RLC_Config_v1530(rlc_Config_v1530);
    value.set_rlc_Config_v1530(rlc_Config_v1530);

    /* Setting 'rlc_BearerConfigDupl_r15' field */
    RLC_BearerConfig_r15 rlc_BearerConfigDupl_r15;
    fill_RLC_BearerConfig_r15(rlc_BearerConfigDupl_r15);
    value.set_rlc_BearerConfigDupl_r15(rlc_BearerConfigDupl_r15);

    value.set_logicalChannelIdentity_r15(32);
}

static void fill_DRB_ToReleaseList(DRB_ToReleaseList & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_data_15(MAC_MainConfig::ul_SCH_Config & value)
{
    value.set_maxHARQ_Tx(maxHARQ_Tx_n1);
    value.set_periodicBSR_Timer(PeriodicBSR_Timer_r12_sf5);
    value.set_retxBSR_Timer(RetxBSR_Timer_r12_sf320);
    value.set_ttiBundling(TRUE);
}

static void fill_DRX_Config(DRX_Config & value)
{
    value.set_release(0);
}

static void fill_data_14(MAC_MainConfig::phr_Config & value)
{
    value.set_release(0);
}

static void fill_data_13(MAC_MainConfig::mac_MainConfig_v1020 & value)
{
    value.set_sCellDeactivationTimer_r10(sCellDeactivationTimer_r10_rf2);
    value.set_extendedBSR_Sizes_r10(extendedBSR_Sizes_r10_setup);
    value.set_extendedPHR_r10(extendedPHR_r10_setup);
}

static void fill_STAG_ToAddMod_r11(STAG_ToAddMod_r11 & value)
{
    value.set_stag_Id_r11(1);
    value.set_timeAlignmentTimerSTAG_r11(TimeAlignmentTimer_sf500);
}

static void fill_STAG_ToAddModList_r11(STAG_ToAddModList_r11 & value)
{
    {
	/* Adding component #2 */
	STAG_ToAddMod_r11 comp2;
	fill_STAG_ToAddMod_r11(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	STAG_ToAddMod_r11 comp1;
	fill_STAG_ToAddMod_r11(comp1);
	value.prepend(comp1);
    }
}

static void fill_DRX_Config_v1130(DRX_Config_v1130 & value)
{
    value.set_drx_RetransmissionTimer_v1130(psf0_v1130);
    /* Setting 'longDRX_CycleStartOffset_v1130' field */
    DRX_Config_v1130::longDRX_CycleStartOffset_v1130 longDRX_CycleStartOffset_v1130;
    longDRX_CycleStartOffset_v1130.set_sf60_v1130(0);
    value.set_longDRX_CycleStartOffset_v1130(longDRX_CycleStartOffset_v1130);

    value.set_shortDRX_Cycle_v1130(sf4_v1130);
}

static void fill_data_12(MAC_MainConfig::dualConnectivityPHR & value)
{
    value.set_release(0);
}

static void fill_data_11(MAC_MainConfig::logicalChannelSR_Config_r12 & value)
{
    value.set_release(0);
}

static void fill_DRX_Config_v1310(DRX_Config_v1310 & value)
{
    /* Setting 'longDRX_CycleStartOffset_v1310' field */

    /* Calling a fully-initializing constructor */
    DRX_Config_v1310::longDRX_CycleStartOffset_v1310 longDRX_CycleStartOffset_v1310(0);

    value.set_longDRX_CycleStartOffset_v1310(longDRX_CycleStartOffset_v1310);
}

static void fill_data_10(MAC_MainConfig::eDRX_Config_CycleStartOffset_r13 & value)
{
    value.set_release(0);
}

static void fill_data_9(MAC_MainConfig::drx_Config_r13 & value)
{
    value.set_release(0);
}

static void fill_data_8(MAC_MainConfig::skipUplinkTx_r14 & value)
{
    value.set_release(0);
}

static void fill_data_7(MAC_MainConfig::dataInactivityTimerConfig_r14 & value)
{
    value.set_release(0);
}

static void fill_data_6(MAC_MainConfig::shortTTI_AndSPT_r15 & value)
{
    value.set_release(0);
}

static void fill_data_5(MAC_MainConfig::dormantStateTimers_r15 & value)
{
    value.set_release(0);
}

static void fill_SPS_ConfigDL(SPS_ConfigDL & value)
{
    value.set_release(0);
}

static void fill_SPS_ConfigUL(SPS_ConfigUL & value)
{
    value.set_release(0);
}

static void fill_SPS_Config(SPS_Config & value)
{
    /* Setting 'semiPersistSchedC_RNTI' field of 'explicitValue' alternative of 'sps_Config' field */
    static unsigned char semiPersistSchedC_RNTI_value[] = {
	0x00, 0x00
    };
    OssBitString semiPersistSchedC_RNTI(16, semiPersistSchedC_RNTI_value);
    value.set_semiPersistSchedC_RNTI(semiPersistSchedC_RNTI);

    /* Setting 'sps_ConfigDL' field of 'explicitValue' alternative of 'sps_Config' field */
    SPS_ConfigDL sps_ConfigDL;
    fill_SPS_ConfigDL(sps_ConfigDL);
    value.set_sps_ConfigDL(sps_ConfigDL);

    /* Setting 'sps_ConfigUL' field of 'explicitValue' alternative of 'sps_Config' field */
    SPS_ConfigUL sps_ConfigUL;
    fill_SPS_ConfigUL(sps_ConfigUL);
    value.set_sps_ConfigUL(sps_ConfigUL);
}

static void fill_PDSCH_ConfigDedicated(PDSCH_ConfigDedicated & value)
{
    value.set_p_a(p_a_dB_6);
}

static void fill_TPC_PDCCH_Config(TPC_PDCCH_Config & value)
{
    value.set_release(0);
}

static void fill_SoundingRS_UL_ConfigDedicated(SoundingRS_UL_ConfigDedicated & value)
{
    value.set_release(0);
}

static void fill_data_4(AntennaInfoDedicated_r10::ue_TransmitAntennaSelection & value)
{
    value.set_release(0);
}

static void fill_AntennaInfoUL_r10(AntennaInfoUL_r10 & value)
{
    value.set_transmissionModeUL_r10(transmissionModeUL_r10_tm1);
    value.set_fourAntennaPortActivated_r10(fourAntennaPortActivated_r10_setup);
}

static void fill_CQI_ReportPeriodic_r10(CQI_ReportPeriodic_r10 & value)
{
    value.set_release(0);
}

static void fill_ZeroTxPowerCSI_RS_Conf_r12(ZeroTxPowerCSI_RS_Conf_r12 & value)
{
    value.set_release(0);
}

static void fill_CSI_RS_Config_r10(CSI_RS_Config_r10 & value)
{
    /* Setting 'csi_RS_r10' field of 'csi_SubframePatternConfig_r10' field of 'csi_RS_Config_r10' field of 'explicitValue' alternative... */
    CSI_RS_Config_r10::csi_RS_r10 csi_RS_r10;
    csi_RS_r10.set_release(0);
    value.set_csi_RS_r10(csi_RS_r10);

    /* Setting 'zeroTxPowerCSI_RS_r10' field of 'csi_SubframePatternConfig_r10' field of 'csi_RS_Config_r10' field of 'explicitValue' alternative... */
    ZeroTxPowerCSI_RS_Conf_r12 zeroTxPowerCSI_RS_r10;
    fill_ZeroTxPowerCSI_RS_Conf_r12(zeroTxPowerCSI_RS_r10);
    value.set_zeroTxPowerCSI_RS_r10(zeroTxPowerCSI_RS_r10);
}

static void fill_SoundingRS_UL_ConfigDedicated_v1020(SoundingRS_UL_ConfigDedicated_v1020 & value)
{
    value.set_srs_AntennaPort_r10(SRS_AntennaPort_an1);
}

static void fill_CSI_RS_ConfigNZP_r11(CSI_RS_ConfigNZP_r11 & value)
{
    value.set_csi_RS_ConfigNZPId_r11(1);
    value.set_antennaPortsCount_r11(CSI_RS_ConfigNZP_r11_antennaPortsCount_r11_an1);
    value.set_resourceConfig_r11(0);
    value.set_subframeConfig_r11(0);
    value.set_scramblingIdentity_r11(0);
    /* Setting 'qcl_CRS_Info_r11' field */
    /* Creating 'mbsfn_SubframeConfigList_r11' field of 'qcl_CRS_Info_r11' field */
    CSI_RS_ConfigNZP_r11::qcl_CRS_Info_r11::mbsfn_SubframeConfigList_r11 mbsfn_SubframeConfigList_r11;
    mbsfn_SubframeConfigList_r11.set_release(0);

    /* Calling a fully-initializing constructor */
    CSI_RS_ConfigNZP_r11::qcl_CRS_Info_r11 qcl_CRS_Info_r11(0, qcl_CRS_Info_r11_crs_PortsCount_r11_n1, mbsfn_SubframeConfigList_r11);

    value.set_qcl_CRS_Info_r11(qcl_CRS_Info_r11);

    value.set_csi_RS_ConfigNZPId_v1310(4);
    value.set_transmissionComb_r14(0);
    value.set_frequencyDensity_r14(d1);
    /* Setting 'mbsfn_SubframeConfigList_v1430' field */
    CSI_RS_ConfigNZP_r11::mbsfn_SubframeConfigList_v1430 mbsfn_SubframeConfigList_v1430;
    mbsfn_SubframeConfigList_v1430.set_release(0);
    value.set_mbsfn_SubframeConfigList_v1430(mbsfn_SubframeConfigList_v1430);
}

static void fill_CSI_RS_ConfigNZPToAddModList_r11(CSI_RS_ConfigNZPToAddModList_r11 & value)
{
    {
	/* Adding component #2 */
	CSI_RS_ConfigNZP_r11 comp2;
	fill_CSI_RS_ConfigNZP_r11(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CSI_RS_ConfigNZP_r11 comp1;
	fill_CSI_RS_ConfigNZP_r11(comp1);
	value.prepend(comp1);
    }
}

static void fill_CSI_RS_ConfigZP_r11(CSI_RS_ConfigZP_r11 & value)
{
    value.set_csi_RS_ConfigZPId_r11(1);
    /* Setting 'resourceConfigList_r11' field */
    static unsigned char resourceConfigList_r11_value[] = {
	0x00, 0x00
    };
    OssBitString resourceConfigList_r11(16, resourceConfigList_r11_value);
    value.set_resourceConfigList_r11(resourceConfigList_r11);

    value.set_subframeConfig_r11(0);
}

static void fill_CSI_RS_ConfigZPToAddModList_r11(CSI_RS_ConfigZPToAddModList_r11 & value)
{
    {
	/* Adding component #2 */
	CSI_RS_ConfigZP_r11 comp2;
	fill_CSI_RS_ConfigZP_r11(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CSI_RS_ConfigZP_r11 comp1;
	fill_CSI_RS_ConfigZP_r11(comp1);
	value.prepend(comp1);
    }
}

static void fill_EPDCCH_Config_r11(EPDCCH_Config_r11 & value)
{
    /* Setting 'config_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'epdcch_Config_r11' field of 'explicitValue' alternative... */
    EPDCCH_Config_r11::config_r11 config_r11;
    config_r11.set_release(0);
    value.set_config_r11(config_r11);
}

static void fill_PDSCH_RE_MappingQCL_Config_r11(PDSCH_RE_MappingQCL_Config_r11 & value)
{
    value.set_pdsch_RE_MappingQCL_ConfigId_r11(1);
    /* Setting 'optionalSetOfFields_r11' field */
    /* Creating 'mbsfn_SubframeConfigList_r11' field of 'optionalSetOfFields_r11' field */
    PDSCH_RE_MappingQCL_Config_r11::optionalSetOfFields_r11::mbsfn_SubframeConfigList_r11 mbsfn_SubframeConfigList_r11;
    mbsfn_SubframeConfigList_r11.set_release(0);

    /* Calling a fully-initializing constructor */
    PDSCH_RE_MappingQCL_Config_r11::optionalSetOfFields_r11 optionalSetOfFields_r11(optionalSetOfFields_r11_crs_PortsCount_r11_n1, 0, mbsfn_SubframeConfigList_r11, pdsch_Start_r11_reserved);

    value.set_optionalSetOfFields_r11(optionalSetOfFields_r11);

    value.set_csi_RS_ConfigZPId_r11(1);
    value.set_qcl_CSI_RS_ConfigNZPId_r11(1);
    /* Setting 'mbsfn_SubframeConfigList_v1430' field */
    PDSCH_RE_MappingQCL_Config_r11::mbsfn_SubframeConfigList_v1430 mbsfn_SubframeConfigList_v1430;
    mbsfn_SubframeConfigList_v1430.set_release(0);
    value.set_mbsfn_SubframeConfigList_v1430(mbsfn_SubframeConfigList_v1430);

    /* Setting 'codewordOneConfig_v1530' field */
    PDSCH_RE_MappingQCL_Config_r11::codewordOneConfig_v1530 codewordOneConfig_v1530;
    codewordOneConfig_v1530.set_release(0);
    value.set_codewordOneConfig_v1530(codewordOneConfig_v1530);
}

static void fill_PDSCH_ConfigDedicated_v1130(PDSCH_ConfigDedicated_v1130 & value)
{
    /* Setting 'dmrs_ConfigPDSCH_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'pdsch_ConfigDedicated_v1130' field of 'explicitValue' alternative... */
    DMRS_Config_r11 dmrs_ConfigPDSCH_r11;
    dmrs_ConfigPDSCH_r11.set_release(0);
    value.set_dmrs_ConfigPDSCH_r11(dmrs_ConfigPDSCH_r11);

    value.set_qcl_Operation(typeA);
    /* Setting 're_MappingQCLConfigToReleaseList_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'pdsch_ConfigDedicated_v1130' field of 'explicitValue' alternative... */
    RE_MappingQCLConfigToReleaseList_r11 re_MappingQCLConfigToReleaseList_r11;
    re_MappingQCLConfigToReleaseList_r11.prepend(1);
    re_MappingQCLConfigToReleaseList_r11.prepend(1);
    value.set_re_MappingQCLConfigToReleaseList_r11(re_MappingQCLConfigToReleaseList_r11);

    /* Setting 're_MappingQCLConfigToAddModList_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'pdsch_ConfigDedicated_v1130' field of 'explicitValue' alternative... */
    RE_MappingQCLConfigToAddModList_r11 re_MappingQCLConfigToAddModList_r11;
    {
	/* Adding component #2 */
	PDSCH_RE_MappingQCL_Config_r11 comp2;
	fill_PDSCH_RE_MappingQCL_Config_r11(comp2);
	re_MappingQCLConfigToAddModList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PDSCH_RE_MappingQCL_Config_r11 comp1;
	fill_PDSCH_RE_MappingQCL_Config_r11(comp1);
	re_MappingQCLConfigToAddModList_r11.prepend(comp1);
    }
    value.set_re_MappingQCLConfigToAddModList_r11(re_MappingQCLConfigToAddModList_r11);
}

static void fill_CRI_ReportConfig_r13(CRI_ReportConfig_r13 & value)
{
    value.set_release(0);
}

static void fill_CQI_ReportPeriodicProcExt_r11(CQI_ReportPeriodicProcExt_r11 & value)
{
    value.set_cqi_ReportPeriodicProcExtId_r11(1);
    value.set_cqi_pmi_ConfigIndex_r11(0);
    /* Setting 'cqi_FormatIndicatorPeriodic_r11' field */
    CQI_ReportPeriodicProcExt_r11::cqi_FormatIndicatorPeriodic_r11 cqi_FormatIndicatorPeriodic_r11;
    /* Setting 'widebandCQI_r11' alternative of 'cqi_FormatIndicatorPeriodic_r11' field */

    /* Calling a fully-initializing constructor */
    CQI_ReportPeriodicProcExt_r11::cqi_FormatIndicatorPeriodic_r11::widebandCQI_r11 widebandCQI_r11(csi_ReportMode_r11_submode1);

    cqi_FormatIndicatorPeriodic_r11.set_widebandCQI_r11(widebandCQI_r11);

    value.set_cqi_FormatIndicatorPeriodic_r11(cqi_FormatIndicatorPeriodic_r11);

    value.set_ri_ConfigIndex_r11(0);
    /* Setting 'csi_ConfigIndex_r11' field */
    CQI_ReportPeriodicProcExt_r11::csi_ConfigIndex_r11 csi_ConfigIndex_r11;
    csi_ConfigIndex_r11.set_release(0);
    value.set_csi_ConfigIndex_r11(csi_ConfigIndex_r11);

    /* Setting 'cri_ReportConfig_r13' field */
    CRI_ReportConfig_r13 cri_ReportConfig_r13;
    fill_CRI_ReportConfig_r13(cri_ReportConfig_r13);
    value.set_cri_ReportConfig_r13(cri_ReportConfig_r13);

    value.set_periodicityFactorWB_r13(CQI_ReportPeriodicProcExt_r11_periodicityFactorWB_r13_n2);
}

static void fill_CSI_IM_Config_r11(CSI_IM_Config_r11 & value)
{
    value.set_csi_IM_ConfigId_r11(1);
    value.set_resourceConfig_r11(0);
    value.set_subframeConfig_r11(0);
    value.set_interferenceMeasRestriction_r13(TRUE);
}

static void fill_P_C_AndCBSR_r11(P_C_AndCBSR_r11 & value)
{
    value.set_p_C_r11(-8);
    /* Setting 'codebookSubsetRestriction_r11' field */
    static unsigned char codebookSubsetRestriction_r11_value[] = {
	0x00
    };
    OssBitString codebookSubsetRestriction_r11(1, codebookSubsetRestriction_r11_value);
    value.set_codebookSubsetRestriction_r11(codebookSubsetRestriction_r11);
}

static void fill_CSI_RS_ConfigEMIMO_r13(CSI_RS_ConfigEMIMO_r13 & value)
{
    value.set_release(0);
}

static void fill_CSI_RS_ConfigEMIMO_v1430(CSI_RS_ConfigEMIMO_v1430 & value)
{
    value.set_release(0);
}

static void fill_CSI_RS_ConfigEMIMO_Hybrid_r14(CSI_RS_ConfigEMIMO_Hybrid_r14 & value)
{
    value.set_release(0);
}

static void fill_CSI_RS_ConfigEMIMO_v1480(CSI_RS_ConfigEMIMO_v1480 & value)
{
    value.set_release(0);
}

static void fill_CSI_Process_r11(CSI_Process_r11 & value)
{
    value.set_csi_ProcessId_r11(1);
    value.set_csi_RS_ConfigNZPId_r11(1);
    value.set_csi_IM_ConfigId_r11(1);
    /* Setting 'p_C_AndCBSRList_r11' field */
    P_C_AndCBSR_Pair_r13a p_C_AndCBSRList_r11;
    {
	/* Adding component #2 */
	P_C_AndCBSR_r11 comp2;
	fill_P_C_AndCBSR_r11(comp2);
	p_C_AndCBSRList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	P_C_AndCBSR_r11 comp1;
	fill_P_C_AndCBSR_r11(comp1);
	p_C_AndCBSRList_r11.prepend(comp1);
    }
    value.set_p_C_AndCBSRList_r11(p_C_AndCBSRList_r11);

    /* Setting 'cqi_ReportBothProc_r11' field */

    /* Calling a fully-initializing constructor */
    CQI_ReportBothProc_r11 cqi_ReportBothProc_r11(1, pmi_RI_Report_r11_setup);

    value.set_cqi_ReportBothProc_r11(cqi_ReportBothProc_r11);

    value.set_cqi_ReportPeriodicProcId_r11(0);
    /* Setting 'cqi_ReportAperiodicProc_r11' field */

    /* Calling a fully-initializing constructor */
    CQI_ReportAperiodicProc_r11 cqi_ReportAperiodicProc_r11(rm12, TRUE, TRUE, TRUE);

    value.set_cqi_ReportAperiodicProc_r11(cqi_ReportAperiodicProc_r11);

    value.set_alternativeCodebookEnabledFor4TXProc_r12(alternativeCodebookEnabledFor4TXProc_r12_true);
    /* Setting 'csi_IM_ConfigIdList_r12' field */
    CSI_Process_r11::csi_IM_ConfigIdList_r12 csi_IM_ConfigIdList_r12;
    csi_IM_ConfigIdList_r12.set_release(0);
    value.set_csi_IM_ConfigIdList_r12(csi_IM_ConfigIdList_r12);

    /* Setting 'cqi_ReportAperiodicProc2_r12' field */
    CSI_Process_r11::cqi_ReportAperiodicProc2_r12 cqi_ReportAperiodicProc2_r12;
    cqi_ReportAperiodicProc2_r12.set_release(0);
    value.set_cqi_ReportAperiodicProc2_r12(cqi_ReportAperiodicProc2_r12);

    /* Setting 'cqi_ReportAperiodicProc_v1310' field */
    CSI_Process_r11::cqi_ReportAperiodicProc_v1310 cqi_ReportAperiodicProc_v1310;
    cqi_ReportAperiodicProc_v1310.set_release(0);
    value.set_cqi_ReportAperiodicProc_v1310(cqi_ReportAperiodicProc_v1310);

    /* Setting 'cqi_ReportAperiodicProc2_v1310' field */
    CSI_Process_r11::cqi_ReportAperiodicProc2_v1310 cqi_ReportAperiodicProc2_v1310;
    cqi_ReportAperiodicProc2_v1310.set_release(0);
    value.set_cqi_ReportAperiodicProc2_v1310(cqi_ReportAperiodicProc2_v1310);

    /* Setting 'eMIMO_Type_r13' field */
    CSI_RS_ConfigEMIMO_r13 eMIMO_Type_r13;
    fill_CSI_RS_ConfigEMIMO_r13(eMIMO_Type_r13);
    value.set_eMIMO_Type_r13(eMIMO_Type_r13);

    /* Setting 'dummy' field */
    CSI_RS_ConfigEMIMO_v1430 dummy;
    fill_CSI_RS_ConfigEMIMO_v1430(dummy);
    value.set_dummy(dummy);

    /* Setting 'eMIMO_Hybrid_r14' field */
    CSI_RS_ConfigEMIMO_Hybrid_r14 eMIMO_Hybrid_r14;
    fill_CSI_RS_ConfigEMIMO_Hybrid_r14(eMIMO_Hybrid_r14);
    value.set_eMIMO_Hybrid_r14(eMIMO_Hybrid_r14);

    value.set_advancedCodebookEnabled_r14(TRUE);
    /* Setting 'eMIMO_Type_v1480' field */
    CSI_RS_ConfigEMIMO_v1480 eMIMO_Type_v1480;
    fill_CSI_RS_ConfigEMIMO_v1480(eMIMO_Type_v1480);
    value.set_eMIMO_Type_v1480(eMIMO_Type_v1480);

    value.set_feCOMP_CSI_Enabled_v1530(TRUE);
    /* Setting 'eMIMO_Type_v1530' field */
    CSI_RS_ConfigEMIMO_v1530 eMIMO_Type_v1530;
    eMIMO_Type_v1530.set_release(0);
    value.set_eMIMO_Type_v1530(eMIMO_Type_v1530);
}

static void fill_CQI_ReportConfig_v1130(CQI_ReportConfig_v1130 & value)
{
    /* Setting 'cqi_ReportPeriodic_v1130' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'cqi_ReportConfig_v1130' field of 'explicitValue' alternative... */
    /* Creating 'cqi_ReportPeriodicProcExtToReleaseList_r11' field of 'cqi_ReportPeriodic_v1130' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'cqi_ReportConfig_v1130' field... */
    CQI_ReportPeriodicProcExtToReleaseList_r11 cqi_ReportPeriodicProcExtToReleaseList_r11;
    cqi_ReportPeriodicProcExtToReleaseList_r11.prepend(1);
    cqi_ReportPeriodicProcExtToReleaseList_r11.prepend(1);

    /* Creating 'cqi_ReportPeriodicProcExtToAddModList_r11' field of 'cqi_ReportPeriodic_v1130' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'cqi_ReportConfig_v1130' field... */
    CQI_ReportPeriodicProcExtToAddModList_r11 cqi_ReportPeriodicProcExtToAddModList_r11;
    {
	/* Adding component #2 */
	CQI_ReportPeriodicProcExt_r11 comp2;
	fill_CQI_ReportPeriodicProcExt_r11(comp2);
	cqi_ReportPeriodicProcExtToAddModList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CQI_ReportPeriodicProcExt_r11 comp1;
	fill_CQI_ReportPeriodicProcExt_r11(comp1);
	cqi_ReportPeriodicProcExtToAddModList_r11.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    CQI_ReportPeriodic_v1130 cqi_ReportPeriodic_v1130(simultaneousAckNackAndCQI_Format3_r11_setup, cqi_ReportPeriodicProcExtToReleaseList_r11, cqi_ReportPeriodicProcExtToAddModList_r11);

    value.set_cqi_ReportPeriodic_v1130(cqi_ReportPeriodic_v1130);

    /* Setting 'cqi_ReportBoth_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'cqi_ReportConfig_v1130' field of 'explicitValue' alternative... */
    /* Creating 'csi_IM_ConfigToReleaseList_r11' field of 'cqi_ReportBoth_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'cqi_ReportConfig_v1130' field... */
    CSI_IM_ConfigToReleaseList_r11 csi_IM_ConfigToReleaseList_r11;
    csi_IM_ConfigToReleaseList_r11.prepend(1);
    csi_IM_ConfigToReleaseList_r11.prepend(1);

    /* Creating 'csi_IM_ConfigToAddModList_r11' field of 'cqi_ReportBoth_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'cqi_ReportConfig_v1130' field... */
    CSI_IM_ConfigToAddModList_r11 csi_IM_ConfigToAddModList_r11;
    {
	/* Adding component #2 */
	CSI_IM_Config_r11 comp2;
	fill_CSI_IM_Config_r11(comp2);
	csi_IM_ConfigToAddModList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CSI_IM_Config_r11 comp1;
	fill_CSI_IM_Config_r11(comp1);
	csi_IM_ConfigToAddModList_r11.prepend(comp1);
    }

    /* Creating 'csi_ProcessToReleaseList_r11' field of 'cqi_ReportBoth_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'cqi_ReportConfig_v1130' field... */
    CSI_ProcessToReleaseList_r11 csi_ProcessToReleaseList_r11;
    csi_ProcessToReleaseList_r11.prepend(1);
    csi_ProcessToReleaseList_r11.prepend(1);

    /* Creating 'csi_ProcessToAddModList_r11' field of 'cqi_ReportBoth_r11' field of 'deltaTxD_OffsetListPUCCH_r10' field of 'cqi_ReportConfig_v1130' field... */
    CSI_ProcessToAddModList_r11 csi_ProcessToAddModList_r11;
    {
	/* Adding component #2 */
	CSI_Process_r11 comp2;
	fill_CSI_Process_r11(comp2);
	csi_ProcessToAddModList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CSI_Process_r11 comp1;
	fill_CSI_Process_r11(comp1);
	csi_ProcessToAddModList_r11.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    CQI_ReportBoth_r11 cqi_ReportBoth_r11(csi_IM_ConfigToReleaseList_r11, csi_IM_ConfigToAddModList_r11, csi_ProcessToReleaseList_r11, csi_ProcessToAddModList_r11);

    value.set_cqi_ReportBoth_r11(cqi_ReportBoth_r11);
}

static void fill_PUSCH_ConfigDedicated_v1130(PUSCH_ConfigDedicated_v1130 & value)
{
    /* Setting 'pusch_DMRS_r11' field of 'nPUCCH_Param_r11' field of 'pusch_ConfigDedicated_v1130' field of 'explicitValue' alternative... */
    PUSCH_ConfigDedicated_v1130::pusch_DMRS_r11 pusch_DMRS_r11;
    pusch_DMRS_r11.set_release(0);
    value.set_pusch_DMRS_r11(pusch_DMRS_r11);
}

static void fill_UplinkPowerControlDedicated_v1130(UplinkPowerControlDedicated_v1130 & value)
{
    value.set_pSRS_Offset_v1130(16);
    value.set_pSRS_OffsetAp_v1130(16);
    /* Setting 'deltaTxD_OffsetListPUCCH_v1130' field of 'nPUCCH_Param_r11' field of 'uplinkPowerControlDedicated_v1130' field of 'explicitValue' alternative... */

    /* Calling a fully-initializing constructor */
    DeltaTxD_OffsetListPUCCH_v1130 deltaTxD_OffsetListPUCCH_v1130(deltaTxD_OffsetPUCCH_Format1bCS_r11_dB0);

    value.set_deltaTxD_OffsetListPUCCH_v1130(deltaTxD_OffsetListPUCCH_v1130);
}

static void fill_AntennaInfoDedicated_v1250(AntennaInfoDedicated_v1250 & value)
{
    value.set_alternativeCodebookEnabledFor4TX_r12(TRUE);
}

static void fill_EIMTA_MainConfigServCell_r12(EIMTA_MainConfigServCell_r12 & value)
{
    value.set_release(0);
}

static void fill_CSI_IM_ConfigExt_r12(CSI_IM_ConfigExt_r12 & value)
{
    value.set_csi_IM_ConfigId_v1250(4);
    value.set_resourceConfig_r12(0);
    value.set_subframeConfig_r12(0);
    value.set_interferenceMeasRestriction_r13(TRUE);
    value.set_csi_IM_ConfigId_v1310(5);
}

static void fill_CQI_ReportConfig_v1250(CQI_ReportConfig_v1250 & value)
{
    /* Setting 'csi_SubframePatternConfig_r12' field of 'nkaPUCCH_Param_r12' field of 'cqi_ReportConfigPCell_v1250' field of 'explicitValue' alternative... */
    CQI_ReportConfig_v1250::csi_SubframePatternConfig_r12 csi_SubframePatternConfig_r12;
    csi_SubframePatternConfig_r12.set_release(0);
    value.set_csi_SubframePatternConfig_r12(csi_SubframePatternConfig_r12);

    /* Setting 'cqi_ReportBoth_v1250' field of 'nkaPUCCH_Param_r12' field of 'cqi_ReportConfigPCell_v1250' field of 'explicitValue' alternative... */
    /* Creating 'csi_IM_ConfigToAddModListExt_r12' field of 'cqi_ReportBoth_v1250' field of 'nkaPUCCH_Param_r12' field of 'cqi_ReportConfigPCell_v1250' field... */
    CSI_IM_ConfigExt_r12 csi_IM_ConfigToAddModListExt_r12;
    fill_CSI_IM_ConfigExt_r12(csi_IM_ConfigToAddModListExt_r12);

    /* Calling a fully-initializing constructor */
    CQI_ReportBoth_v1250 cqi_ReportBoth_v1250(4, csi_IM_ConfigToAddModListExt_r12);

    value.set_cqi_ReportBoth_v1250(cqi_ReportBoth_v1250);

    /* Setting 'cqi_ReportAperiodic_v1250' field of 'nkaPUCCH_Param_r12' field of 'cqi_ReportConfigPCell_v1250' field of 'explicitValue' alternative... */
    CQI_ReportAperiodic_v1250 cqi_ReportAperiodic_v1250;
    cqi_ReportAperiodic_v1250.set_release(0);
    value.set_cqi_ReportAperiodic_v1250(cqi_ReportAperiodic_v1250);

    value.set_altCQI_Table_r12(altCQI_Table_r12_allSubframes);
}

static void fill_UplinkPowerControlDedicated_v1250(UplinkPowerControlDedicated_v1250 & value)
{
    /* Setting 'set2PowerControlParameter' field of 'nkaPUCCH_Param_r12' field of 'uplinkPowerControlDedicated_v1250' field of 'explicitValue' alternative... */
    UplinkPowerControlDedicated_v1250::set2PowerControlParameter set2PowerControlParameter;
    set2PowerControlParameter.set_release(0);
    value.set_set2PowerControlParameter(set2PowerControlParameter);
}

static void fill_CSI_RS_Config_v1250(CSI_RS_Config_v1250 & value)
{
    /* Setting 'zeroTxPowerCSI_RS2_r12' field of 'uciOnPUSCH' field of 'csi_RS_Config_v1250' field of 'explicitValue' alternative... */
    ZeroTxPowerCSI_RS_Conf_r12 zeroTxPowerCSI_RS2_r12;
    fill_ZeroTxPowerCSI_RS_Conf_r12(zeroTxPowerCSI_RS2_r12);
    value.set_zeroTxPowerCSI_RS2_r12(zeroTxPowerCSI_RS2_r12);

    /* Setting 'ds_ZeroTxPowerCSI_RS_r12' field of 'uciOnPUSCH' field of 'csi_RS_Config_v1250' field of 'explicitValue' alternative... */
    CSI_RS_Config_v1250::ds_ZeroTxPowerCSI_RS_r12 ds_ZeroTxPowerCSI_RS_r12;
    ds_ZeroTxPowerCSI_RS_r12.set_release(0);
    value.set_ds_ZeroTxPowerCSI_RS_r12(ds_ZeroTxPowerCSI_RS_r12);
}

static void fill_PDSCH_ConfigDedicated_v1280(PDSCH_ConfigDedicated_v1280 & value)
{
    value.set_tbsIndexAlt_r12(a26);
}

static void fill_PDSCH_ConfigDedicated_v1310(PDSCH_ConfigDedicated_v1310 & value)
{
    /* Setting 'dmrs_ConfigPDSCH_v1310' field of 'uciOnPUSCH' field of 'pdsch_ConfigDedicated_v1310' field of 'explicitValue' alternative... */

    /* Calling a fully-initializing constructor */
    DMRS_Config_v1310 dmrs_ConfigPDSCH_v1310(dmrs_tableAlt_r13_true);

    value.set_dmrs_ConfigPDSCH_v1310(dmrs_ConfigPDSCH_v1310);
}

static void fill_PDCCH_CandidateReductions_r13(PDCCH_CandidateReductions_r13 & value)
{
    value.set_release(0);
}

static void fill_CQI_ReportConfig_v1310(CQI_ReportConfig_v1310 & value)
{
    /* Setting 'cqi_ReportBoth_v1310' field of 'uciOnPUSCH' field of 'cqi_ReportConfig_v1310' field of 'explicitValue' alternative... */
    /* Creating 'csi_IM_ConfigToReleaseListExt_r13' field of 'cqi_ReportBoth_v1310' field of 'uciOnPUSCH' field of 'cqi_ReportConfig_v1310' field... */
    CSI_IM_ConfigToReleaseListExt_r13 csi_IM_ConfigToReleaseListExt_r13;
    csi_IM_ConfigToReleaseListExt_r13.prepend(5);
    csi_IM_ConfigToReleaseListExt_r13.prepend(5);

    /* Creating 'csi_IM_ConfigToAddModListExt_r13' field of 'cqi_ReportBoth_v1310' field of 'uciOnPUSCH' field of 'cqi_ReportConfig_v1310' field... */
    CSI_IM_ConfigToAddModListExt_r13 csi_IM_ConfigToAddModListExt_r13;
    {
	/* Adding component #2 */
	CSI_IM_ConfigExt_r12 comp2;
	fill_CSI_IM_ConfigExt_r12(comp2);
	csi_IM_ConfigToAddModListExt_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CSI_IM_ConfigExt_r12 comp1;
	fill_CSI_IM_ConfigExt_r12(comp1);
	csi_IM_ConfigToAddModListExt_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    CQI_ReportBoth_v1310 cqi_ReportBoth_v1310(csi_IM_ConfigToReleaseListExt_r13, csi_IM_ConfigToAddModListExt_r13);

    value.set_cqi_ReportBoth_v1310(cqi_ReportBoth_v1310);

    /* Setting 'cqi_ReportAperiodic_v1310' field of 'uciOnPUSCH' field of 'cqi_ReportConfig_v1310' field of 'explicitValue' alternative... */
    CQI_ReportAperiodic_v1310 cqi_ReportAperiodic_v1310;
    cqi_ReportAperiodic_v1310.set_release(0);
    value.set_cqi_ReportAperiodic_v1310(cqi_ReportAperiodic_v1310);

    /* Setting 'cqi_ReportPeriodic_v1310' field of 'uciOnPUSCH' field of 'cqi_ReportConfig_v1310' field of 'explicitValue' alternative... */
    /* Creating 'cri_ReportConfig_r13' field of 'cqi_ReportPeriodic_v1310' field of 'uciOnPUSCH' field of 'cqi_ReportConfig_v1310' field... */
    CRI_ReportConfig_r13 cri_ReportConfig_r13;
    fill_CRI_ReportConfig_r13(cri_ReportConfig_r13);

    /* Calling a fully-initializing constructor */
    CQI_ReportPeriodic_v1310 cqi_ReportPeriodic_v1310(cri_ReportConfig_r13, simultaneousAckNackAndCQI_Format4_Format5_r13_setup);

    value.set_cqi_ReportPeriodic_v1310(cqi_ReportPeriodic_v1310);
}

static void fill_SoundingRS_UL_ConfigDedicated_v1310(SoundingRS_UL_ConfigDedicated_v1310 & value)
{
    value.set_release(0);
}

static void fill_SoundingRS_UL_ConfigDedicatedUpPTsExt_r13(SoundingRS_UL_ConfigDedicatedUpPTsExt_r13 & value)
{
    value.set_release(0);
}

static void fill_SoundingRS_UL_ConfigDedicatedAperiodic_v1310(SoundingRS_UL_ConfigDedicatedAperiodic_v1310 & value)
{
    value.set_release(0);
}

static void fill_SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13(SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13 & value)
{
    value.set_release(0);
}

static void fill_CSI_RS_Config_v1310(CSI_RS_Config_v1310 & value)
{
    /* Setting 'eMIMO_Type_r13' field of 'uciOnPUSCH' field of 'csi_RS_Config_v1310' field of 'explicitValue' alternative... */
    CSI_RS_ConfigEMIMO_r13 eMIMO_Type_r13;
    fill_CSI_RS_ConfigEMIMO_r13(eMIMO_Type_r13);
    value.set_eMIMO_Type_r13(eMIMO_Type_r13);
}

static void fill_CSI_RS_ConfigNZPToAddModListExt_r13(CSI_RS_ConfigNZPToAddModListExt_r13 & value)
{
    {
	/* Adding component #2 */
	CSI_RS_ConfigNZP_r11 comp2;
	fill_CSI_RS_ConfigNZP_r11(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CSI_RS_ConfigNZP_r11 comp1;
	fill_CSI_RS_ConfigNZP_r11(comp1);
	value.prepend(comp1);
    }
}

static void fill_CSI_RS_ConfigNZPToReleaseListExt_r13(CSI_RS_ConfigNZPToReleaseListExt_r13 & value)
{
    value.prepend(4);
    value.prepend(4);
}

static void fill_CQI_ReportConfig_v1320(CQI_ReportConfig_v1320 & value)
{
    /* Setting 'cqi_ReportPeriodic_v1320' field of 'uciOnPUSCH' field of 'cqi_ReportConfig_v1320' field of 'explicitValue' alternative... */

    /* Calling a fully-initializing constructor */
    CQI_ReportPeriodic_v1320 cqi_ReportPeriodic_v1320(CQI_ReportPeriodic_v1320_periodicityFactorWB_r13_n2);

    value.set_cqi_ReportPeriodic_v1320(cqi_ReportPeriodic_v1320);
}

static void fill_Enable256QAM_r14(Enable256QAM_r14 & value)
{
    value.set_release(0);
}

static void fill_SoundingRS_UL_ConfigDedicatedAperiodic_r10(SoundingRS_UL_ConfigDedicatedAperiodic_r10 & value)
{
    value.set_release(0);
}

static void fill_CSI_RS_Config_v1430(CSI_RS_Config_v1430 & value)
{
    /* Setting 'dummy' field of 'enable256QAM_r14' field of 'csi_RS_Config_v1430' field of 'explicitValue' alternative... */
    CSI_RS_ConfigEMIMO_v1430 dummy;
    fill_CSI_RS_ConfigEMIMO_v1430(dummy);
    value.set_dummy(dummy);

    /* Setting 'eMIMO_Hybrid_r14' field of 'enable256QAM_r14' field of 'csi_RS_Config_v1430' field of 'explicitValue' alternative... */
    CSI_RS_ConfigEMIMO_Hybrid_r14 eMIMO_Hybrid_r14;
    fill_CSI_RS_ConfigEMIMO_Hybrid_r14(eMIMO_Hybrid_r14);
    value.set_eMIMO_Hybrid_r14(eMIMO_Hybrid_r14);

    value.set_advancedCodebookEnabled_r14(TRUE);
}

static void fill_CSI_RS_ConfigZP_ApList_r14(CSI_RS_ConfigZP_ApList_r14 & value)
{
    value.set_release(0);
}

static void fill_CQI_ReportConfig_v1430(CQI_ReportConfig_v1430 & value)
{
    /* Setting 'cqi_ReportAperiodicHybrid_r14' field of 'enable256QAM_r14' field of 'cqi_ReportConfig_v1430' field of 'explicitValue' alternative... */
    /* Creating 'triggers_r14' field of 'cqi_ReportAperiodicHybrid_r14' field of 'enable256QAM_r14' field of 'cqi_ReportConfig_v1430' field... */
    CQI_ReportAperiodicHybrid_r14::triggers_r14 triggers_r14;
    /* Setting 'oneBit_r14' alternative of 'triggers_r14' field of 'cqi_ReportAperiodicHybrid_r14' field of 'enable256QAM_r14' field... */
    /* Creating 'trigger1_Indicator_r14' field of 'oneBit_r14' alternative of 'triggers_r14' field of 'cqi_ReportAperiodicHybrid_r14' field... */
    static unsigned char trigger1_Indicator_r14_value[] = {
	0x00
    };
    OssBitString trigger1_Indicator_r14(8, trigger1_Indicator_r14_value);

    /* Calling a fully-initializing constructor */
    CQI_ReportAperiodicHybrid_r14::triggers_r14::oneBit_r14 oneBit_r14(trigger1_Indicator_r14);

    triggers_r14.set_oneBit_r14(oneBit_r14);

    /* Calling a fully-initializing constructor */
    CQI_ReportAperiodicHybrid_r14 cqi_ReportAperiodicHybrid_r14(triggers_r14);

    value.set_cqi_ReportAperiodicHybrid_r14(cqi_ReportAperiodicHybrid_r14);
}

static void fill_CSI_RS_Config_v1480(CSI_RS_Config_v1480 & value)
{
    /* Setting 'eMIMO_Type_v1480' field of 'enable256QAM_r14' field of 'csi_RS_Config_v1480' field of 'explicitValue' alternative... */
    CSI_RS_ConfigEMIMO_v1480 eMIMO_Type_v1480;
    fill_CSI_RS_ConfigEMIMO_v1480(eMIMO_Type_v1480);
    value.set_eMIMO_Type_v1480(eMIMO_Type_v1480);
}

static void fill_PhysicalConfigDedicatedSTTI_r15(PhysicalConfigDedicatedSTTI_r15 & value)
{
    value.set_release(0);
}

static void fill_PDSCH_ConfigDedicated_v1530(PDSCH_ConfigDedicated_v1530 & value)
{
    value.set_qcl_Operation_v1530(typeC);
    value.set_tbs_IndexAlt3_r15(tbs_IndexAlt3_r15_a37);
    value.set_ce_CQI_AlternativeTableConfig_r15(ce_CQI_AlternativeTableConfig_r15_on);
    value.set_ce_PDSCH_64QAM_Config_r15(ce_PDSCH_64QAM_Config_r15_on);
    value.set_ce_PDSCH_FlexibleStartPRB_AllocConfig_r15(ce_PDSCH_FlexibleStartPRB_AllocConfig_r15_on);
    value.set_altMCS_TableScalingConfig_r15(altMCS_TableScalingConfig_r15_oDot5);
}

static void fill_CQI_ReportConfig_v1530(CQI_ReportConfig_v1530 & value)
{
    value.set_altCQI_Table_1024QAM_r15(CQI_ReportConfig_v1530_altCQI_Table_1024QAM_r15_allSubframes);
}

static void fill_CSI_RS_Config_v1530(CSI_RS_Config_v1530 & value)
{
    /* Setting 'eMIMO_Type_v1530' field of 'ce_PUSCH_SubPRB_Config_r15' field of 'csi_RS_Config_v1530' field of 'explicitValue' alternative... */
    CSI_RS_ConfigEMIMO_v1530 eMIMO_Type_v1530;
    eMIMO_Type_v1530.set_release(0);
    value.set_eMIMO_Type_v1530(eMIMO_Type_v1530);
}

static void fill_UplinkPowerControlDedicated_v1530(UplinkPowerControlDedicated_v1530 & value)
{
    value.set_alpha_UE_r15(Alpha_r12_al0);
    value.set_p0_UE_PUSCH_r15(15);
}

static void fill_PhysicalConfigDedicated(PhysicalConfigDedicated & value)
{
    /* Setting 'pdsch_ConfigDedicated' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PDSCH_ConfigDedicated pdsch_ConfigDedicated;
    fill_PDSCH_ConfigDedicated(pdsch_ConfigDedicated);
    value.set_pdsch_ConfigDedicated(pdsch_ConfigDedicated);

    /* Setting 'pucch_ConfigDedicated' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'ackNackRepetition' field of 'pucch_ConfigDedicated' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated::ackNackRepetition ackNackRepetition;
    ackNackRepetition.set_release(0);

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigDedicated pucch_ConfigDedicated(ackNackRepetition, tdd_AckNackFeedbackMode_bundling);

    value.set_pucch_ConfigDedicated(pucch_ConfigDedicated);

    /* Setting 'pusch_ConfigDedicated' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicated pusch_ConfigDedicated(0, 0, 0);

    value.set_pusch_ConfigDedicated(pusch_ConfigDedicated);

    /* Setting 'uplinkPowerControlDedicated' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlDedicated uplinkPowerControlDedicated(7, deltaMCS_Enabled_en0, TRUE, 7, 0, fc0);

    value.set_uplinkPowerControlDedicated(uplinkPowerControlDedicated);

    /* Setting 'tpc_PDCCH_ConfigPUCCH' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    TPC_PDCCH_Config tpc_PDCCH_ConfigPUCCH;
    fill_TPC_PDCCH_Config(tpc_PDCCH_ConfigPUCCH);
    value.set_tpc_PDCCH_ConfigPUCCH(tpc_PDCCH_ConfigPUCCH);

    /* Setting 'tpc_PDCCH_ConfigPUSCH' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    TPC_PDCCH_Config tpc_PDCCH_ConfigPUSCH;
    fill_TPC_PDCCH_Config(tpc_PDCCH_ConfigPUSCH);
    value.set_tpc_PDCCH_ConfigPUSCH(tpc_PDCCH_ConfigPUSCH);

    /* Setting 'cqi_ReportConfig' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'cqi_ReportPeriodic' field of 'cqi_ReportConfig' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    CQI_ReportPeriodic cqi_ReportPeriodic;
    cqi_ReportPeriodic.set_release(0);

    /* Calling a fully-initializing constructor */
    CQI_ReportConfig cqi_ReportConfig(rm12, -1, cqi_ReportPeriodic);

    value.set_cqi_ReportConfig(cqi_ReportConfig);

    /* Setting 'soundingRS_UL_ConfigDedicated' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    SoundingRS_UL_ConfigDedicated soundingRS_UL_ConfigDedicated;
    fill_SoundingRS_UL_ConfigDedicated(soundingRS_UL_ConfigDedicated);
    value.set_soundingRS_UL_ConfigDedicated(soundingRS_UL_ConfigDedicated);

    /* Setting 'antennaInfo' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::antennaInfo antennaInfo;
    /* Setting 'explicitValue' alternative of 'antennaInfo' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    /* Creating 'codebookSubsetRestriction' field of 'explicitValue' alternative of 'antennaInfo' field of 'explicitValue' alternative... */
    AntennaInfoDedicated::codebookSubsetRestriction codebookSubsetRestriction;
    /* Setting 'n2TxAntenna_tm3' alternative of 'codebookSubsetRestriction' field of 'explicitValue' alternative of 'antennaInfo' field... */
    static unsigned char n2TxAntenna_tm3_value[] = {
	0x00
    };
    OssBitString n2TxAntenna_tm3(2, n2TxAntenna_tm3_value);
    codebookSubsetRestriction.set_n2TxAntenna_tm3(n2TxAntenna_tm3);

    /* Creating 'ue_TransmitAntennaSelection' field of 'explicitValue' alternative of 'antennaInfo' field of 'explicitValue' alternative... */
    AntennaInfoDedicated::ue_TransmitAntennaSelection ue_TransmitAntennaSelection;
    ue_TransmitAntennaSelection.set_release(0);

    /* Calling a fully-initializing constructor */
    AntennaInfoDedicated explicitValue(transmissionMode_tm1, codebookSubsetRestriction, ue_TransmitAntennaSelection);

    antennaInfo.set_explicitValue(explicitValue);

    value.set_antennaInfo(antennaInfo);

    /* Setting 'schedulingRequestConfig' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    SchedulingRequestConfig schedulingRequestConfig;
    schedulingRequestConfig.set_release(0);
    value.set_schedulingRequestConfig(schedulingRequestConfig);

    /* Setting 'cqi_ReportConfig_v920' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */

    /* Calling a fully-initializing constructor */
    CQI_ReportConfig_v920 cqi_ReportConfig_v920(CQI_ReportConfig_v920_cqi_Mask_r9_setup, CQI_ReportConfig_v920_pmi_RI_Report_r9_setup);

    value.set_cqi_ReportConfig_v920(cqi_ReportConfig_v920);

    /* Setting 'antennaInfo_v920' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'codebookSubsetRestriction_v920' field of 'antennaInfo_v920' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    AntennaInfoDedicated_v920::codebookSubsetRestriction_v920 codebookSubsetRestriction_v920;
    /* Setting 'n2TxAntenna_tm8_r9' alternative of 'codebookSubsetRestriction_v920' field of 'antennaInfo_v920' field of 'explicitValue' alternative... */
    static unsigned char n2TxAntenna_tm8_r9_value[] = {
	0x00
    };
    OssBitString n2TxAntenna_tm8_r9(6, n2TxAntenna_tm8_r9_value);
    codebookSubsetRestriction_v920.set_n2TxAntenna_tm8_r9(n2TxAntenna_tm8_r9);

    /* Calling a fully-initializing constructor */
    AntennaInfoDedicated_v920 antennaInfo_v920(codebookSubsetRestriction_v920);

    value.set_antennaInfo_v920(antennaInfo_v920);

    /* Setting 'antennaInfo_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::antennaInfo_r10 antennaInfo_r10;
    /* Setting 'explicitValue_r10' alternative of 'antennaInfo_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    /* Creating 'codebookSubsetRestriction_r10' field of 'explicitValue_r10' alternative of 'antennaInfo_r10' field of 'explicitValue' alternative... */
    static unsigned char codebookSubsetRestriction_r10_value[] = {
	0x00
    };
    OssBitString codebookSubsetRestriction_r10(1, codebookSubsetRestriction_r10_value);

    /* Creating 'ue_TransmitAntennaSelection' field of 'explicitValue_r10' alternative of 'antennaInfo_r10' field of 'explicitValue' alternative... */
    AntennaInfoDedicated_r10::ue_TransmitAntennaSelection explicitValue_r10_ue_TransmitAntennaSelection;
    fill_data_4(explicitValue_r10_ue_TransmitAntennaSelection);

    /* Calling a fully-initializing constructor */
    AntennaInfoDedicated_r10 explicitValue_r10(transmissionMode_r10_tm1, codebookSubsetRestriction_r10, explicitValue_r10_ue_TransmitAntennaSelection);

    antennaInfo_r10.set_explicitValue_r10(explicitValue_r10);

    value.set_antennaInfo_r10(antennaInfo_r10);

    /* Setting 'antennaInfoUL_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    AntennaInfoUL_r10 antennaInfoUL_r10;
    fill_AntennaInfoUL_r10(antennaInfoUL_r10);
    value.set_antennaInfoUL_r10(antennaInfoUL_r10);

    value.set_cif_Presence_r10(TRUE);
    /* Setting 'cqi_ReportConfig_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'cqi_ReportAperiodic_r10' field of 'cqi_ReportConfig_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    CQI_ReportAperiodic_r10 cqi_ReportAperiodic_r10;
    cqi_ReportAperiodic_r10.set_release(0);

    /* Creating 'cqi_ReportPeriodic_r10' field of 'cqi_ReportConfig_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    CQI_ReportPeriodic_r10 cqi_ReportPeriodic_r10;
    fill_CQI_ReportPeriodic_r10(cqi_ReportPeriodic_r10);

    /* Creating 'csi_SubframePatternConfig_r10' field of 'cqi_ReportConfig_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    CQI_ReportConfig_r10::csi_SubframePatternConfig_r10 csi_SubframePatternConfig_r10;
    csi_SubframePatternConfig_r10.set_release(0);

    /* Calling a fully-initializing constructor */
    CQI_ReportConfig_r10 cqi_ReportConfig_r10(cqi_ReportAperiodic_r10, -1, cqi_ReportPeriodic_r10, CQI_ReportConfig_r10_pmi_RI_Report_r9_setup, csi_SubframePatternConfig_r10);

    value.set_cqi_ReportConfig_r10(cqi_ReportConfig_r10);

    /* Setting 'csi_RS_Config_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_Config_r10 csi_RS_Config_r10;
    fill_CSI_RS_Config_r10(csi_RS_Config_r10);
    value.set_csi_RS_Config_r10(csi_RS_Config_r10);

    /* Setting 'pucch_ConfigDedicated_v1020' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'pucch_Format_r10' field of 'pucch_ConfigDedicated_v1020' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_v1020::pucch_Format_r10 pucch_Format_r10;
    /* Setting 'format3_r10' alternative of 'pucch_Format_r10' field of 'pucch_ConfigDedicated_v1020' field of 'explicitValue' alternative... */
    /* Creating 'n3PUCCH_AN_List_r13' field of 'format3_r10' alternative of 'pucch_Format_r10' field of 'pucch_ConfigDedicated_v1020' field... */
    PUCCH_Format3_Conf_r13::n3PUCCH_AN_List_r13 n3PUCCH_AN_List_r13;
    n3PUCCH_AN_List_r13.prepend((OSS_UINT32)0);
    n3PUCCH_AN_List_r13.prepend((OSS_UINT32)0);

    /* Creating 'twoAntennaPortActivatedPUCCH_Format3_r13' field of 'format3_r10' alternative of 'pucch_Format_r10' field of 'pucch_ConfigDedicated_v1020' field... */
    PUCCH_Format3_Conf_r13::twoAntennaPortActivatedPUCCH_Format3_r13 twoAntennaPortActivatedPUCCH_Format3_r13;
    twoAntennaPortActivatedPUCCH_Format3_r13.set_release(0);

    /* Calling a fully-initializing constructor */
    PUCCH_Format3_Conf_r13 format3_r10(n3PUCCH_AN_List_r13, twoAntennaPortActivatedPUCCH_Format3_r13);

    pucch_Format_r10.set_format3_r10(format3_r10);

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigDedicated_v1020 pucch_ConfigDedicated_v1020(pucch_Format_r10, twoAntennaPortActivatedPUCCH_Format1a1b_r10_true, simultaneousPUCCH_PUSCH_r10_true, 0);

    value.set_pucch_ConfigDedicated_v1020(pucch_ConfigDedicated_v1020);

    /* Setting 'pusch_ConfigDedicated_v1020' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'betaOffsetMC_r10' field of 'pusch_ConfigDedicated_v1020' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicated_v1020::betaOffsetMC_r10 betaOffsetMC_r10(0, 0, 0);

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicated_v1020 pusch_ConfigDedicated_v1020(betaOffsetMC_r10, PUSCH_ConfigDedicated_v1020_groupHoppingDisabled_r10_true, PUSCH_ConfigDedicated_v1020_dmrs_WithOCC_Activated_r10_true);

    value.set_pusch_ConfigDedicated_v1020(pusch_ConfigDedicated_v1020);

    /* Setting 'schedulingRequestConfig_v1020' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */

    /* Calling a fully-initializing constructor */
    SchedulingRequestConfig_v1020 schedulingRequestConfig_v1020(0);

    value.set_schedulingRequestConfig_v1020(schedulingRequestConfig_v1020);

    /* Setting 'soundingRS_UL_ConfigDedicated_v1020' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    SoundingRS_UL_ConfigDedicated_v1020 soundingRS_UL_ConfigDedicated_v1020;
    fill_SoundingRS_UL_ConfigDedicated_v1020(soundingRS_UL_ConfigDedicated_v1020);
    value.set_soundingRS_UL_ConfigDedicated_v1020(soundingRS_UL_ConfigDedicated_v1020);

    /* Setting 'soundingRS_UL_ConfigDedicatedAperiodic_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    SoundingRS_UL_ConfigDedicatedAperiodic_r10 soundingRS_UL_ConfigDedicatedAperiodic_r10;
    soundingRS_UL_ConfigDedicatedAperiodic_r10.set_release(0);
    value.set_soundingRS_UL_ConfigDedicatedAperiodic_r10(soundingRS_UL_ConfigDedicatedAperiodic_r10);

    /* Setting 'uplinkPowerControlDedicated_v1020' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'deltaTxD_OffsetListPUCCH_r10' field of 'uplinkPowerControlDedicated_v1020' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */

    /* Calling a fully-initializing constructor */
    DeltaTxD_OffsetListPUCCH_r10 deltaTxD_OffsetListPUCCH_r10(deltaTxD_OffsetPUCCH_Format1_r10_dB0, deltaTxD_OffsetPUCCH_Format1a1b_r10_dB0, deltaTxD_OffsetPUCCH_Format22a2b_r10_dB0, deltaTxD_OffsetPUCCH_Format3_r10_dB0);

    /* Calling a fully-initializing constructor */
    UplinkPowerControlDedicated_v1020 uplinkPowerControlDedicated_v1020(deltaTxD_OffsetListPUCCH_r10, 0);

    value.set_uplinkPowerControlDedicated_v1020(uplinkPowerControlDedicated_v1020);

    /* Setting 'additionalSpectrumEmissionCA_r10' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::additionalSpectrumEmissionCA_r10 additionalSpectrumEmissionCA_r10;
    additionalSpectrumEmissionCA_r10.set_release(0);
    value.set_additionalSpectrumEmissionCA_r10(additionalSpectrumEmissionCA_r10);

    /* Setting 'csi_RS_ConfigNZPToReleaseList_r11' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_ConfigNZPToReleaseList_r11 csi_RS_ConfigNZPToReleaseList_r11;
    csi_RS_ConfigNZPToReleaseList_r11.prepend(1);
    csi_RS_ConfigNZPToReleaseList_r11.prepend(1);
    value.set_csi_RS_ConfigNZPToReleaseList_r11(csi_RS_ConfigNZPToReleaseList_r11);

    /* Setting 'csi_RS_ConfigNZPToAddModList_r11' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_ConfigNZPToAddModList_r11 csi_RS_ConfigNZPToAddModList_r11;
    fill_CSI_RS_ConfigNZPToAddModList_r11(csi_RS_ConfigNZPToAddModList_r11);
    value.set_csi_RS_ConfigNZPToAddModList_r11(csi_RS_ConfigNZPToAddModList_r11);

    /* Setting 'csi_RS_ConfigZPToReleaseList_r11' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_ConfigZPToReleaseList_r11 csi_RS_ConfigZPToReleaseList_r11;
    csi_RS_ConfigZPToReleaseList_r11.prepend(1);
    csi_RS_ConfigZPToReleaseList_r11.prepend(1);
    value.set_csi_RS_ConfigZPToReleaseList_r11(csi_RS_ConfigZPToReleaseList_r11);

    /* Setting 'csi_RS_ConfigZPToAddModList_r11' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_ConfigZPToAddModList_r11 csi_RS_ConfigZPToAddModList_r11;
    fill_CSI_RS_ConfigZPToAddModList_r11(csi_RS_ConfigZPToAddModList_r11);
    value.set_csi_RS_ConfigZPToAddModList_r11(csi_RS_ConfigZPToAddModList_r11);

    /* Setting 'epdcch_Config_r11' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    EPDCCH_Config_r11 epdcch_Config_r11;
    fill_EPDCCH_Config_r11(epdcch_Config_r11);
    value.set_epdcch_Config_r11(epdcch_Config_r11);

    /* Setting 'pdsch_ConfigDedicated_v1130' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PDSCH_ConfigDedicated_v1130 pdsch_ConfigDedicated_v1130;
    fill_PDSCH_ConfigDedicated_v1130(pdsch_ConfigDedicated_v1130);
    value.set_pdsch_ConfigDedicated_v1130(pdsch_ConfigDedicated_v1130);

    /* Setting 'cqi_ReportConfig_v1130' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CQI_ReportConfig_v1130 cqi_ReportConfig_v1130;
    fill_CQI_ReportConfig_v1130(cqi_ReportConfig_v1130);
    value.set_cqi_ReportConfig_v1130(cqi_ReportConfig_v1130);

    /* Setting 'pucch_ConfigDedicated_v1130' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'n1PUCCH_AN_CS_v1130' field of 'pucch_ConfigDedicated_v1130' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_v1130::n1PUCCH_AN_CS_v1130 n1PUCCH_AN_CS_v1130;
    n1PUCCH_AN_CS_v1130.set_release(0);

    /* Creating 'nPUCCH_Param_r11' field of 'pucch_ConfigDedicated_v1130' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_v1130::nPUCCH_Param_r11 nPUCCH_Param_r11;
    nPUCCH_Param_r11.set_release(0);

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigDedicated_v1130 pucch_ConfigDedicated_v1130(n1PUCCH_AN_CS_v1130, nPUCCH_Param_r11);

    value.set_pucch_ConfigDedicated_v1130(pucch_ConfigDedicated_v1130);

    /* Setting 'pusch_ConfigDedicated_v1130' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PUSCH_ConfigDedicated_v1130 pusch_ConfigDedicated_v1130;
    fill_PUSCH_ConfigDedicated_v1130(pusch_ConfigDedicated_v1130);
    value.set_pusch_ConfigDedicated_v1130(pusch_ConfigDedicated_v1130);

    /* Setting 'uplinkPowerControlDedicated_v1130' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    UplinkPowerControlDedicated_v1130 uplinkPowerControlDedicated_v1130;
    fill_UplinkPowerControlDedicated_v1130(uplinkPowerControlDedicated_v1130);
    value.set_uplinkPowerControlDedicated_v1130(uplinkPowerControlDedicated_v1130);

    /* Setting 'antennaInfo_v1250' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    AntennaInfoDedicated_v1250 antennaInfo_v1250;
    fill_AntennaInfoDedicated_v1250(antennaInfo_v1250);
    value.set_antennaInfo_v1250(antennaInfo_v1250);

    /* Setting 'eimta_MainConfig_r12' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    EIMTA_MainConfig_r12 eimta_MainConfig_r12;
    eimta_MainConfig_r12.set_release(0);
    value.set_eimta_MainConfig_r12(eimta_MainConfig_r12);

    /* Setting 'eimta_MainConfigPCell_r12' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    EIMTA_MainConfigServCell_r12 eimta_MainConfigPCell_r12;
    fill_EIMTA_MainConfigServCell_r12(eimta_MainConfigPCell_r12);
    value.set_eimta_MainConfigPCell_r12(eimta_MainConfigPCell_r12);

    /* Setting 'pucch_ConfigDedicated_v1250' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'nkaPUCCH_Param_r12' field of 'pucch_ConfigDedicated_v1250' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_v1250::nkaPUCCH_Param_r12 nkaPUCCH_Param_r12;
    nkaPUCCH_Param_r12.set_release(0);

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigDedicated_v1250 pucch_ConfigDedicated_v1250(nkaPUCCH_Param_r12);

    value.set_pucch_ConfigDedicated_v1250(pucch_ConfigDedicated_v1250);

    /* Setting 'cqi_ReportConfigPCell_v1250' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CQI_ReportConfig_v1250 cqi_ReportConfigPCell_v1250;
    fill_CQI_ReportConfig_v1250(cqi_ReportConfigPCell_v1250);
    value.set_cqi_ReportConfigPCell_v1250(cqi_ReportConfigPCell_v1250);

    /* Setting 'uplinkPowerControlDedicated_v1250' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    UplinkPowerControlDedicated_v1250 uplinkPowerControlDedicated_v1250;
    fill_UplinkPowerControlDedicated_v1250(uplinkPowerControlDedicated_v1250);
    value.set_uplinkPowerControlDedicated_v1250(uplinkPowerControlDedicated_v1250);

    /* Setting 'pusch_ConfigDedicated_v1250' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'uciOnPUSCH' field of 'pusch_ConfigDedicated_v1250' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUSCH_ConfigDedicated_v1250::uciOnPUSCH uciOnPUSCH;
    uciOnPUSCH.set_release(0);

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicated_v1250 pusch_ConfigDedicated_v1250(uciOnPUSCH);

    value.set_pusch_ConfigDedicated_v1250(pusch_ConfigDedicated_v1250);

    /* Setting 'csi_RS_Config_v1250' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_Config_v1250 csi_RS_Config_v1250;
    fill_CSI_RS_Config_v1250(csi_RS_Config_v1250);
    value.set_csi_RS_Config_v1250(csi_RS_Config_v1250);

    /* Setting 'pdsch_ConfigDedicated_v1280' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PDSCH_ConfigDedicated_v1280 pdsch_ConfigDedicated_v1280;
    fill_PDSCH_ConfigDedicated_v1280(pdsch_ConfigDedicated_v1280);
    value.set_pdsch_ConfigDedicated_v1280(pdsch_ConfigDedicated_v1280);

    /* Setting 'pdsch_ConfigDedicated_v1310' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PDSCH_ConfigDedicated_v1310 pdsch_ConfigDedicated_v1310;
    fill_PDSCH_ConfigDedicated_v1310(pdsch_ConfigDedicated_v1310);
    value.set_pdsch_ConfigDedicated_v1310(pdsch_ConfigDedicated_v1310);

    /* Setting 'pucch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'ackNackRepetition_r13' field of 'pucch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_r13::ackNackRepetition_r13 ackNackRepetition_r13;
    ackNackRepetition_r13.set_release(0);

    /* Creating 'pucch_Format_r13' field of 'pucch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_r13::pucch_Format_r13 pucch_Format_r13;
    /* Setting 'format3_r13' alternative of 'pucch_Format_r13' field of 'pucch_ConfigDedicated_r13' field of 'explicitValue' alternative... */
    /* Creating 'n3PUCCH_AN_List_r13' field of 'format3_r13' alternative of 'pucch_Format_r13' field of 'pucch_ConfigDedicated_r13' field... */
    PUCCH_ConfigDedicated_r13::pucch_Format_r13::format3_r13::n3PUCCH_AN_List_r13 format3_r13_n3PUCCH_AN_List_r13;
    format3_r13_n3PUCCH_AN_List_r13.prepend((OSS_UINT32)0);
    format3_r13_n3PUCCH_AN_List_r13.prepend((OSS_UINT32)0);

    /* Creating 'twoAntennaPortActivatedPUCCH_Format3_r13' field of 'format3_r13' alternative of 'pucch_Format_r13' field of 'pucch_ConfigDedicated_r13' field... */
    PUCCH_ConfigDedicated_r13::pucch_Format_r13::format3_r13::twoAntennaPortActivatedPUCCH_Format3_r13 format3_r13_twoAntennaPortActivatedPUCCH_Format3_r13;
    format3_r13_twoAntennaPortActivatedPUCCH_Format3_r13.set_release(0);

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigDedicated_r13::pucch_Format_r13::format3_r13 format3_r13(format3_r13_n3PUCCH_AN_List_r13, format3_r13_twoAntennaPortActivatedPUCCH_Format3_r13);

    pucch_Format_r13.set_format3_r13(format3_r13);

    /* Creating 'nPUCCH_Param_r13' field of 'pucch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_r13::nPUCCH_Param_r13 nPUCCH_Param_r13;
    nPUCCH_Param_r13.set_release(0);

    /* Creating 'nkaPUCCH_Param_r13' field of 'pucch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_r13::nkaPUCCH_Param_r13 nkaPUCCH_Param_r13;
    nkaPUCCH_Param_r13.set_release(0);

    /* Creating 'pucch_NumRepetitionCE_r13' field of 'pucch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUCCH_ConfigDedicated_r13::pucch_NumRepetitionCE_r13 pucch_NumRepetitionCE_r13;
    pucch_NumRepetitionCE_r13.set_release(0);

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigDedicated_r13 pucch_ConfigDedicated_r13(ackNackRepetition_r13, tdd_AckNackFeedbackMode_r13_bundling, pucch_Format_r13, twoAntennaPortActivatedPUCCH_Format1a1b_r13_true, simultaneousPUCCH_PUSCH_r13_true, 0, nPUCCH_Param_r13, nkaPUCCH_Param_r13, TRUE, TRUE, TRUE, codebooksizeDetermination_r13_dai, 0, pucch_NumRepetitionCE_r13);

    value.set_pucch_ConfigDedicated_r13(pucch_ConfigDedicated_r13);

    /* Setting 'pusch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'betaOffsetMC_r13' field of 'pusch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicated_r13::betaOffsetMC_r13 betaOffsetMC_r13(0, 0, 0, 0);

    /* Creating 'pusch_DMRS_r11' field of 'pusch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUSCH_ConfigDedicated_r13::pusch_DMRS_r11 pusch_DMRS_r11;
    pusch_DMRS_r11.set_release(0);

    /* Creating 'uciOnPUSCH' field of 'pusch_ConfigDedicated_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUSCH_ConfigDedicated_r13::uciOnPUSCH pusch_ConfigDedicated_r13_uciOnPUSCH;
    pusch_ConfigDedicated_r13_uciOnPUSCH.set_release(0);

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicated_r13 pusch_ConfigDedicated_r13(0, 0, 0, 0, betaOffsetMC_r13, PUSCH_ConfigDedicated_r13_groupHoppingDisabled_r13_true, dmrs_WithOCC_Activated_r13_true, pusch_DMRS_r11, pusch_ConfigDedicated_r13_uciOnPUSCH, pusch_HoppingConfig_r13_on);

    value.set_pusch_ConfigDedicated_r13(pusch_ConfigDedicated_r13);

    /* Setting 'pdcch_CandidateReductions_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PDCCH_CandidateReductions_r13 pdcch_CandidateReductions_r13;
    fill_PDCCH_CandidateReductions_r13(pdcch_CandidateReductions_r13);
    value.set_pdcch_CandidateReductions_r13(pdcch_CandidateReductions_r13);

    /* Setting 'cqi_ReportConfig_v1310' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CQI_ReportConfig_v1310 cqi_ReportConfig_v1310;
    fill_CQI_ReportConfig_v1310(cqi_ReportConfig_v1310);
    value.set_cqi_ReportConfig_v1310(cqi_ReportConfig_v1310);

    /* Setting 'soundingRS_UL_ConfigDedicated_v1310' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    SoundingRS_UL_ConfigDedicated_v1310 soundingRS_UL_ConfigDedicated_v1310;
    fill_SoundingRS_UL_ConfigDedicated_v1310(soundingRS_UL_ConfigDedicated_v1310);
    value.set_soundingRS_UL_ConfigDedicated_v1310(soundingRS_UL_ConfigDedicated_v1310);

    /* Setting 'soundingRS_UL_ConfigDedicatedUpPTsExt_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    SoundingRS_UL_ConfigDedicatedUpPTsExt_r13 soundingRS_UL_ConfigDedicatedUpPTsExt_r13;
    fill_SoundingRS_UL_ConfigDedicatedUpPTsExt_r13(soundingRS_UL_ConfigDedicatedUpPTsExt_r13);
    value.set_soundingRS_UL_ConfigDedicatedUpPTsExt_r13(soundingRS_UL_ConfigDedicatedUpPTsExt_r13);

    /* Setting 'soundingRS_UL_ConfigDedicatedAperiodic_v1310' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    SoundingRS_UL_ConfigDedicatedAperiodic_v1310 soundingRS_UL_ConfigDedicatedAperiodic_v1310;
    fill_SoundingRS_UL_ConfigDedicatedAperiodic_v1310(soundingRS_UL_ConfigDedicatedAperiodic_v1310);
    value.set_soundingRS_UL_ConfigDedicatedAperiodic_v1310(soundingRS_UL_ConfigDedicatedAperiodic_v1310);

    /* Setting 'soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13 soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13;
    fill_SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13(soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13);
    value.set_soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13(soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13);

    /* Setting 'csi_RS_Config_v1310' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_Config_v1310 csi_RS_Config_v1310;
    fill_CSI_RS_Config_v1310(csi_RS_Config_v1310);
    value.set_csi_RS_Config_v1310(csi_RS_Config_v1310);

    /* Setting 'ce_Mode_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::ce_Mode_r13 ce_Mode_r13;
    ce_Mode_r13.set_release(0);
    value.set_ce_Mode_r13(ce_Mode_r13);

    /* Setting 'csi_RS_ConfigNZPToAddModListExt_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_ConfigNZPToAddModListExt_r13 csi_RS_ConfigNZPToAddModListExt_r13;
    fill_CSI_RS_ConfigNZPToAddModListExt_r13(csi_RS_ConfigNZPToAddModListExt_r13);
    value.set_csi_RS_ConfigNZPToAddModListExt_r13(csi_RS_ConfigNZPToAddModListExt_r13);

    /* Setting 'csi_RS_ConfigNZPToReleaseListExt_r13' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_ConfigNZPToReleaseListExt_r13 csi_RS_ConfigNZPToReleaseListExt_r13;
    fill_CSI_RS_ConfigNZPToReleaseListExt_r13(csi_RS_ConfigNZPToReleaseListExt_r13);
    value.set_csi_RS_ConfigNZPToReleaseListExt_r13(csi_RS_ConfigNZPToReleaseListExt_r13);

    /* Setting 'cqi_ReportConfig_v1320' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CQI_ReportConfig_v1320 cqi_ReportConfig_v1320;
    fill_CQI_ReportConfig_v1320(cqi_ReportConfig_v1320);
    value.set_cqi_ReportConfig_v1320(cqi_ReportConfig_v1320);

    /* Setting 'typeA_SRS_TPC_PDCCH_Group_r14' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::typeA_SRS_TPC_PDCCH_Group_r14 typeA_SRS_TPC_PDCCH_Group_r14;
    typeA_SRS_TPC_PDCCH_Group_r14.set_release(0);
    value.set_typeA_SRS_TPC_PDCCH_Group_r14(typeA_SRS_TPC_PDCCH_Group_r14);

    /* Setting 'must_Config_r14' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::must_Config_r14 must_Config_r14;
    must_Config_r14.set_release(0);
    value.set_must_Config_r14(must_Config_r14);

    /* Setting 'pusch_EnhancementsConfig_r14' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PUSCH_EnhancementsConfig_r14 pusch_EnhancementsConfig_r14;
    pusch_EnhancementsConfig_r14.set_release(0);
    value.set_pusch_EnhancementsConfig_r14(pusch_EnhancementsConfig_r14);

    value.set_ce_pdsch_pusch_EnhancementConfig_r14(ce_pdsch_pusch_EnhancementConfig_r14_on);
    /* Setting 'antennaInfo_v1430' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */

    /* Calling a fully-initializing constructor */
    AntennaInfoDedicated_v1430 antennaInfo_v1430(ce_UE_TxAntennaSelection_config_r14_on);

    value.set_antennaInfo_v1430(antennaInfo_v1430);

    /* Setting 'pucch_ConfigDedicated_v1430' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigDedicated_v1430 pucch_ConfigDedicated_v1430(pucch_NumRepetitionCE_format1_r14_r64);

    value.set_pucch_ConfigDedicated_v1430(pucch_ConfigDedicated_v1430);

    /* Setting 'pdsch_ConfigDedicated_v1430' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */

    /* Calling a fully-initializing constructor */
    PDSCH_ConfigDedicated_v1430 pdsch_ConfigDedicated_v1430(ce_PDSCH_MaxBandwidth_r14_bw5, ce_PDSCH_TenProcesses_r14_on, ce_HARQ_AckBundling_r14_on, range1, PDSCH_ConfigDedicated_v1430_tbsIndexAlt2_r14_b33);

    value.set_pdsch_ConfigDedicated_v1430(pdsch_ConfigDedicated_v1430);

    /* Setting 'pusch_ConfigDedicated_v1430' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'tdd_PUSCH_UpPTS_r14' field of 'pusch_ConfigDedicated_v1430' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    TDD_PUSCH_UpPTS_r14 tdd_PUSCH_UpPTS_r14;
    tdd_PUSCH_UpPTS_r14.set_release(0);

    /* Creating 'enable256QAM_r14' field of 'pusch_ConfigDedicated_v1430' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    Enable256QAM_r14 enable256QAM_r14;
    fill_Enable256QAM_r14(enable256QAM_r14);

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicated_v1430 pusch_ConfigDedicated_v1430(ce_PUSCH_NB_MaxTBS_r14_on, ce_PUSCH_MaxBandwidth_r14_bw5, tdd_PUSCH_UpPTS_r14, TRUE, enable256QAM_r14);

    value.set_pusch_ConfigDedicated_v1430(pusch_ConfigDedicated_v1430);

    /* Setting 'soundingRS_UL_PeriodicConfigDedicatedList_r14' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::soundingRS_UL_PeriodicConfigDedicatedList_r14 soundingRS_UL_PeriodicConfigDedicatedList_r14;
    {
	/* Adding component #2 */
	SoundingRS_UL_ConfigDedicated comp2;
	fill_SoundingRS_UL_ConfigDedicated(comp2);
	soundingRS_UL_PeriodicConfigDedicatedList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SoundingRS_UL_ConfigDedicated comp1;
	fill_SoundingRS_UL_ConfigDedicated(comp1);
	soundingRS_UL_PeriodicConfigDedicatedList_r14.prepend(comp1);
    }
    value.set_soundingRS_UL_PeriodicConfigDedicatedList_r14(soundingRS_UL_PeriodicConfigDedicatedList_r14);

    /* Setting 'soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14 soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14;
    {
	/* Adding component #2 */
	SoundingRS_UL_ConfigDedicatedUpPTsExt_r13 comp2;
	fill_SoundingRS_UL_ConfigDedicatedUpPTsExt_r13(comp2);
	soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SoundingRS_UL_ConfigDedicatedUpPTsExt_r13 comp1;
	fill_SoundingRS_UL_ConfigDedicatedUpPTsExt_r13(comp1);
	soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14.prepend(comp1);
    }
    value.set_soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14(soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14);

    /* Setting 'soundingRS_UL_AperiodicConfigDedicatedList_r14' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::soundingRS_UL_AperiodicConfigDedicatedList_r14 soundingRS_UL_AperiodicConfigDedicatedList_r14;
    {
	/* Adding component #2 */
	SoundingRS_UL_ConfigDedicatedAperiodic_r10 comp2;
	fill_SoundingRS_UL_ConfigDedicatedAperiodic_r10(comp2);
	soundingRS_UL_AperiodicConfigDedicatedList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SoundingRS_UL_ConfigDedicatedAperiodic_r10 comp1;
	fill_SoundingRS_UL_ConfigDedicatedAperiodic_r10(comp1);
	soundingRS_UL_AperiodicConfigDedicatedList_r14.prepend(comp1);
    }
    value.set_soundingRS_UL_AperiodicConfigDedicatedList_r14(soundingRS_UL_AperiodicConfigDedicatedList_r14);

    /* Setting 'soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14 soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14;
    {
	/* Adding component #2 */
	SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13 comp2;
	fill_SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13(comp2);
	soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13 comp1;
	fill_SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13(comp1);
	soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14.prepend(comp1);
    }
    value.set_soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14(soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14);

    /* Setting 'csi_RS_Config_v1430' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_Config_v1430 csi_RS_Config_v1430;
    fill_CSI_RS_Config_v1430(csi_RS_Config_v1430);
    value.set_csi_RS_Config_v1430(csi_RS_Config_v1430);

    /* Setting 'csi_RS_ConfigZP_ApList_r14' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_ConfigZP_ApList_r14 csi_RS_ConfigZP_ApList_r14;
    fill_CSI_RS_ConfigZP_ApList_r14(csi_RS_ConfigZP_ApList_r14);
    value.set_csi_RS_ConfigZP_ApList_r14(csi_RS_ConfigZP_ApList_r14);

    /* Setting 'cqi_ReportConfig_v1430' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CQI_ReportConfig_v1430 cqi_ReportConfig_v1430;
    fill_CQI_ReportConfig_v1430(cqi_ReportConfig_v1430);
    value.set_cqi_ReportConfig_v1430(cqi_ReportConfig_v1430);

    value.set_semiOpenLoop_r14(TRUE);
    /* Setting 'csi_RS_Config_v1480' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_Config_v1480 csi_RS_Config_v1480;
    fill_CSI_RS_Config_v1480(csi_RS_Config_v1480);
    value.set_csi_RS_Config_v1480(csi_RS_Config_v1480);

    /* Setting 'physicalConfigDedicatedSTTI_r15' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicatedSTTI_r15 physicalConfigDedicatedSTTI_r15;
    fill_PhysicalConfigDedicatedSTTI_r15(physicalConfigDedicatedSTTI_r15);
    value.set_physicalConfigDedicatedSTTI_r15(physicalConfigDedicatedSTTI_r15);

    /* Setting 'pdsch_ConfigDedicated_v1530' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PDSCH_ConfigDedicated_v1530 pdsch_ConfigDedicated_v1530;
    fill_PDSCH_ConfigDedicated_v1530(pdsch_ConfigDedicated_v1530);
    value.set_pdsch_ConfigDedicated_v1530(pdsch_ConfigDedicated_v1530);

    /* Setting 'pusch_ConfigDedicated_v1530' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    /* Creating 'ce_PUSCH_FlexibleStartPRB_AllocConfig_r15' field of 'pusch_ConfigDedicated_v1530' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUSCH_ConfigDedicated_v1530::ce_PUSCH_FlexibleStartPRB_AllocConfig_r15 ce_PUSCH_FlexibleStartPRB_AllocConfig_r15;
    ce_PUSCH_FlexibleStartPRB_AllocConfig_r15.set_release(0);

    /* Creating 'ce_PUSCH_SubPRB_Config_r15' field of 'pusch_ConfigDedicated_v1530' field of 'explicitValue' alternative of 'physicalConfigDedicated' field... */
    PUSCH_ConfigDedicated_v1530::ce_PUSCH_SubPRB_Config_r15 ce_PUSCH_SubPRB_Config_r15;
    ce_PUSCH_SubPRB_Config_r15.set_release(0);

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicated_v1530 pusch_ConfigDedicated_v1530(ce_PUSCH_FlexibleStartPRB_AllocConfig_r15, ce_PUSCH_SubPRB_Config_r15);

    value.set_pusch_ConfigDedicated_v1530(pusch_ConfigDedicated_v1530);

    /* Setting 'cqi_ReportConfig_v1530' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CQI_ReportConfig_v1530 cqi_ReportConfig_v1530;
    fill_CQI_ReportConfig_v1530(cqi_ReportConfig_v1530);
    value.set_cqi_ReportConfig_v1530(cqi_ReportConfig_v1530);

    /* Setting 'antennaInfo_v1530' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    AntennaInfoDedicated_v1530 antennaInfo_v1530;
    antennaInfo_v1530.set_release(0);
    value.set_antennaInfo_v1530(antennaInfo_v1530);

    /* Setting 'csi_RS_Config_v1530' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    CSI_RS_Config_v1530 csi_RS_Config_v1530;
    fill_CSI_RS_Config_v1530(csi_RS_Config_v1530);
    value.set_csi_RS_Config_v1530(csi_RS_Config_v1530);

    /* Setting 'uplinkPowerControlDedicated_v1530' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    UplinkPowerControlDedicated_v1530 uplinkPowerControlDedicated_v1530;
    fill_UplinkPowerControlDedicated_v1530(uplinkPowerControlDedicated_v1530);
    value.set_uplinkPowerControlDedicated_v1530(uplinkPowerControlDedicated_v1530);

    /* Setting 'semiStaticCFI_Config_r15' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::semiStaticCFI_Config_r15 semiStaticCFI_Config_r15;
    semiStaticCFI_Config_r15.set_release(0);
    value.set_semiStaticCFI_Config_r15(semiStaticCFI_Config_r15);

    /* Setting 'blindPDSCH_Repetition_Config_r15' field of 'explicitValue' alternative of 'physicalConfigDedicated' field */
    PhysicalConfigDedicated::blindPDSCH_Repetition_Config_r15 blindPDSCH_Repetition_Config_r15;
    blindPDSCH_Repetition_Config_r15.set_release(0);
    value.set_blindPDSCH_Repetition_Config_r15(blindPDSCH_Repetition_Config_r15);
}

static void fill_NAICS_AssistanceInfo_r12(NAICS_AssistanceInfo_r12 & value)
{
    value.set_release(0);
}

static void fill_NeighCellsCRS_Info_r13(NeighCellsCRS_Info_r13 & value)
{
    value.set_release(0);
}

static void fill_SPS_ConfigUL_ToReleaseList_r14(SPS_ConfigUL_ToReleaseList_r14 & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_SPS_ConfigSL_r14(SPS_ConfigSL_r14 & value)
{
    value.set_sps_ConfigIndex_r14(1);
    value.set_semiPersistSchedIntervalSL_r14(semiPersistSchedIntervalSL_r14_sf20);
}

static void fill_SPS_Config_v1430(SPS_Config_v1430 & value)
{
    /* Setting 'ul_SPS_V_RNTI_r14' field of 'explicitValue' alternative of 'sps_Config_v1430' field */
    static unsigned char ul_SPS_V_RNTI_r14_value[] = {
	0x00, 0x00
    };
    OssBitString ul_SPS_V_RNTI_r14(16, ul_SPS_V_RNTI_r14_value);
    value.set_ul_SPS_V_RNTI_r14(ul_SPS_V_RNTI_r14);

    /* Setting 'sl_SPS_V_RNTI_r14' field of 'explicitValue' alternative of 'sps_Config_v1430' field */
    static unsigned char sl_SPS_V_RNTI_r14_value[] = {
	0x00, 0x00
    };
    OssBitString sl_SPS_V_RNTI_r14(16, sl_SPS_V_RNTI_r14_value);
    value.set_sl_SPS_V_RNTI_r14(sl_SPS_V_RNTI_r14);

    /* Setting 'sps_ConfigUL_ToAddModList_r14' field of 'explicitValue' alternative of 'sps_Config_v1430' field */
    SPS_ConfigUL_ToAddModList_r14 sps_ConfigUL_ToAddModList_r14;
    {
	/* Adding component #2 */
	SPS_ConfigUL comp2;
	fill_SPS_ConfigUL(comp2);
	sps_ConfigUL_ToAddModList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SPS_ConfigUL comp1;
	fill_SPS_ConfigUL(comp1);
	sps_ConfigUL_ToAddModList_r14.prepend(comp1);
    }
    value.set_sps_ConfigUL_ToAddModList_r14(sps_ConfigUL_ToAddModList_r14);

    /* Setting 'sps_ConfigUL_ToReleaseList_r14' field of 'explicitValue' alternative of 'sps_Config_v1430' field */
    SPS_ConfigUL_ToReleaseList_r14 sps_ConfigUL_ToReleaseList_r14;
    fill_SPS_ConfigUL_ToReleaseList_r14(sps_ConfigUL_ToReleaseList_r14);
    value.set_sps_ConfigUL_ToReleaseList_r14(sps_ConfigUL_ToReleaseList_r14);

    /* Setting 'sps_ConfigSL_ToAddModList_r14' field of 'explicitValue' alternative of 'sps_Config_v1430' field */
    SPS_ConfigSL_ToAddModList_r14 sps_ConfigSL_ToAddModList_r14;
    {
	/* Adding component #2 */
	SPS_ConfigSL_r14 comp2;
	fill_SPS_ConfigSL_r14(comp2);
	sps_ConfigSL_ToAddModList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SPS_ConfigSL_r14 comp1;
	fill_SPS_ConfigSL_r14(comp1);
	sps_ConfigSL_ToAddModList_r14.prepend(comp1);
    }
    value.set_sps_ConfigSL_ToAddModList_r14(sps_ConfigSL_ToAddModList_r14);

    /* Setting 'sps_ConfigSL_ToReleaseList_r14' field of 'explicitValue' alternative of 'sps_Config_v1430' field */
    SPS_ConfigSL_ToReleaseList_r14 sps_ConfigSL_ToReleaseList_r14;
    fill_SPS_ConfigUL_ToReleaseList_r14(sps_ConfigSL_ToReleaseList_r14);
    value.set_sps_ConfigSL_ToReleaseList_r14(sps_ConfigSL_ToReleaseList_r14);
}

static void fill_SPS_ConfigUL_STTI_r15(SPS_ConfigUL_STTI_r15 & value)
{
    value.set_release(0);
}

static void fill_SPS_ConfigUL_STTI_ToReleaseList_r15(SPS_ConfigUL_STTI_ToReleaseList_r15 & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_SPS_Config_v1530(SPS_Config_v1530 & value)
{
    /* Setting 'semiPersistSchedC_RNTI_r15' field of 'explicitValue' alternative of 'sps_Config_v1530' field */
    static unsigned char semiPersistSchedC_RNTI_r15_value[] = {
	0x00, 0x00
    };
    OssBitString semiPersistSchedC_RNTI_r15(16, semiPersistSchedC_RNTI_r15_value);
    value.set_semiPersistSchedC_RNTI_r15(semiPersistSchedC_RNTI_r15);

    /* Setting 'sps_ConfigDL' field of 'explicitValue' alternative of 'sps_Config_v1530' field */
    SPS_ConfigDL sps_ConfigDL;
    fill_SPS_ConfigDL(sps_ConfigDL);
    value.set_sps_ConfigDL(sps_ConfigDL);

    /* Setting 'sps_ConfigUL_STTI_ToAddModList_r15' field of 'explicitValue' alternative of 'sps_Config_v1530' field */
    SPS_ConfigUL_STTI_ToAddModList_r15 sps_ConfigUL_STTI_ToAddModList_r15;
    {
	/* Adding component #2 */
	SPS_ConfigUL_STTI_r15 comp2;
	fill_SPS_ConfigUL_STTI_r15(comp2);
	sps_ConfigUL_STTI_ToAddModList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SPS_ConfigUL_STTI_r15 comp1;
	fill_SPS_ConfigUL_STTI_r15(comp1);
	sps_ConfigUL_STTI_ToAddModList_r15.prepend(comp1);
    }
    value.set_sps_ConfigUL_STTI_ToAddModList_r15(sps_ConfigUL_STTI_ToAddModList_r15);

    /* Setting 'sps_ConfigUL_STTI_ToReleaseList_r15' field of 'explicitValue' alternative of 'sps_Config_v1530' field */
    SPS_ConfigUL_STTI_ToReleaseList_r15 sps_ConfigUL_STTI_ToReleaseList_r15;
    fill_SPS_ConfigUL_STTI_ToReleaseList_r15(sps_ConfigUL_STTI_ToReleaseList_r15);
    value.set_sps_ConfigUL_STTI_ToReleaseList_r15(sps_ConfigUL_STTI_ToReleaseList_r15);

    /* Setting 'sps_ConfigUL_ToAddModList_r15' field of 'explicitValue' alternative of 'sps_Config_v1530' field */
    SPS_ConfigUL_ToAddModList_r15 sps_ConfigUL_ToAddModList_r15;
    {
	/* Adding component #2 */
	SPS_ConfigUL comp2;
	fill_SPS_ConfigUL(comp2);
	sps_ConfigUL_ToAddModList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SPS_ConfigUL comp1;
	fill_SPS_ConfigUL(comp1);
	sps_ConfigUL_ToAddModList_r15.prepend(comp1);
    }
    value.set_sps_ConfigUL_ToAddModList_r15(sps_ConfigUL_ToAddModList_r15);

    /* Setting 'sps_ConfigUL_ToReleaseList_r15' field of 'explicitValue' alternative of 'sps_Config_v1530' field */
    SPS_ConfigUL_ToReleaseList_r15 sps_ConfigUL_ToReleaseList_r15;
    fill_SPS_ConfigUL_STTI_ToReleaseList_r15(sps_ConfigUL_ToReleaseList_r15);
    value.set_sps_ConfigUL_ToReleaseList_r15(sps_ConfigUL_ToReleaseList_r15);
}

static void fill_NeighCellsCRS_Info_r15(NeighCellsCRS_Info_r15 & value)
{
    value.set_release(0);
}

static void fill_DRB_ToReleaseList_r15(DRB_ToReleaseList_r15 & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_RadioResourceConfigDedicated(RadioResourceConfigDedicated & value)
{
    /* Setting 'srb_ToAddModList' field */
    SRB_ToAddModList srb_ToAddModList;
    {
	/* Adding component #2 */
	SRB_ToAddMod comp2;
	fill_SRB_ToAddMod(comp2);
	srb_ToAddModList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SRB_ToAddMod comp1;
	fill_SRB_ToAddMod(comp1);
	srb_ToAddModList.prepend(comp1);
    }
    value.set_srb_ToAddModList(srb_ToAddModList);

    /* Setting 'drb_ToAddModList' field */
    DRB_ToAddModList drb_ToAddModList;
    {
	/* Adding component #2 */
	DRB_ToAddMod comp2;
	fill_DRB_ToAddMod(comp2);
	drb_ToAddModList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DRB_ToAddMod comp1;
	fill_DRB_ToAddMod(comp1);
	drb_ToAddModList.prepend(comp1);
    }
    value.set_drb_ToAddModList(drb_ToAddModList);

    /* Setting 'drb_ToReleaseList' field */
    DRB_ToReleaseList drb_ToReleaseList;
    fill_DRB_ToReleaseList(drb_ToReleaseList);
    value.set_drb_ToReleaseList(drb_ToReleaseList);

    /* Setting 'mac_MainConfig' field */
    RadioResourceConfigDedicated::mac_MainConfig mac_MainConfig;
    /* Setting 'explicitValue' alternative of 'mac_MainConfig' field */
    /* Creating 'ul_SCH_Config' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::ul_SCH_Config ul_SCH_Config;
    fill_data_15(ul_SCH_Config);

    /* Creating 'drx_Config' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    DRX_Config drx_Config;
    fill_DRX_Config(drx_Config);

    /* Creating 'phr_Config' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::phr_Config phr_Config;
    fill_data_14(phr_Config);

    /* Creating 'mac_MainConfig_v1020' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::mac_MainConfig_v1020 mac_MainConfig_v1020;
    fill_data_13(mac_MainConfig_v1020);

    /* Creating 'stag_ToReleaseList_r11' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    STAG_ToReleaseList_r11 stag_ToReleaseList_r11;
    stag_ToReleaseList_r11.prepend(1);
    stag_ToReleaseList_r11.prepend(1);

    /* Creating 'stag_ToAddModList_r11' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    STAG_ToAddModList_r11 stag_ToAddModList_r11;
    fill_STAG_ToAddModList_r11(stag_ToAddModList_r11);

    /* Creating 'drx_Config_v1130' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    DRX_Config_v1130 drx_Config_v1130;
    fill_DRX_Config_v1130(drx_Config_v1130);

    /* Creating 'dualConnectivityPHR' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::dualConnectivityPHR dualConnectivityPHR;
    fill_data_12(dualConnectivityPHR);

    /* Creating 'logicalChannelSR_Config_r12' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::logicalChannelSR_Config_r12 logicalChannelSR_Config_r12;
    fill_data_11(logicalChannelSR_Config_r12);

    /* Creating 'drx_Config_v1310' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    DRX_Config_v1310 drx_Config_v1310;
    fill_DRX_Config_v1310(drx_Config_v1310);

    /* Creating 'eDRX_Config_CycleStartOffset_r13' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::eDRX_Config_CycleStartOffset_r13 eDRX_Config_CycleStartOffset_r13;
    fill_data_10(eDRX_Config_CycleStartOffset_r13);

    /* Creating 'drx_Config_r13' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::drx_Config_r13 drx_Config_r13;
    fill_data_9(drx_Config_r13);

    /* Creating 'skipUplinkTx_r14' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::skipUplinkTx_r14 skipUplinkTx_r14;
    fill_data_8(skipUplinkTx_r14);

    /* Creating 'dataInactivityTimerConfig_r14' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::dataInactivityTimerConfig_r14 dataInactivityTimerConfig_r14;
    fill_data_7(dataInactivityTimerConfig_r14);

    /* Creating 'shortTTI_AndSPT_r15' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::shortTTI_AndSPT_r15 shortTTI_AndSPT_r15;
    fill_data_6(shortTTI_AndSPT_r15);

    /* Creating 'dormantStateTimers_r15' field of 'explicitValue' alternative of 'mac_MainConfig' field */
    MAC_MainConfig::dormantStateTimers_r15 dormantStateTimers_r15;
    fill_data_5(dormantStateTimers_r15);

    /* Calling a fully-initializing constructor */
    MAC_MainConfig explicitValue(ul_SCH_Config, drx_Config, TimeAlignmentTimer_sf500, phr_Config, 0, mac_MainConfig_v1020, stag_ToReleaseList_r11, stag_ToAddModList_r11, drx_Config_v1130, TRUE, dualConnectivityPHR, logicalChannelSR_Config_r12, drx_Config_v1310, TRUE, eDRX_Config_CycleStartOffset_r13, drx_Config_r13, skipUplinkTx_r14, dataInactivityTimerConfig_r14, MAC_MainConfig_rai_Activation_r14_true, shortTTI_AndSPT_r15, TRUE, dormantStateTimers_r15);

    mac_MainConfig.set_explicitValue(explicitValue);

    value.set_mac_MainConfig(mac_MainConfig);

    /* Setting 'sps_Config' field */
    SPS_Config sps_Config;
    fill_SPS_Config(sps_Config);
    value.set_sps_Config(sps_Config);

    /* Setting 'physicalConfigDedicated' field */
    PhysicalConfigDedicated physicalConfigDedicated;
    fill_PhysicalConfigDedicated(physicalConfigDedicated);
    value.set_physicalConfigDedicated(physicalConfigDedicated);

    /* Setting 'rlf_TimersAndConstants_r9' field */
    RLF_TimersAndConstants_r9 rlf_TimersAndConstants_r9;
    rlf_TimersAndConstants_r9.set_release(0);
    value.set_rlf_TimersAndConstants_r9(rlf_TimersAndConstants_r9);

    /* Setting 'measSubframePatternPCell_r10' field */
    MeasSubframePatternPCell_r10 measSubframePatternPCell_r10;
    measSubframePatternPCell_r10.set_release(0);
    value.set_measSubframePatternPCell_r10(measSubframePatternPCell_r10);

    /* Setting 'neighCellsCRS_Info_r11' field */
    NeighCellsCRS_Info_r11 neighCellsCRS_Info_r11;
    neighCellsCRS_Info_r11.set_release(0);
    value.set_neighCellsCRS_Info_r11(neighCellsCRS_Info_r11);

    /* Setting 'naics_Info_r12' field */
    NAICS_AssistanceInfo_r12 naics_Info_r12;
    fill_NAICS_AssistanceInfo_r12(naics_Info_r12);
    value.set_naics_Info_r12(naics_Info_r12);

    /* Setting 'neighCellsCRS_Info_r13' field */
    NeighCellsCRS_Info_r13 neighCellsCRS_Info_r13;
    fill_NeighCellsCRS_Info_r13(neighCellsCRS_Info_r13);
    value.set_neighCellsCRS_Info_r13(neighCellsCRS_Info_r13);

    /* Setting 'rlf_TimersAndConstants_r13' field */
    RLF_TimersAndConstants_r13 rlf_TimersAndConstants_r13;
    rlf_TimersAndConstants_r13.set_release(0);
    value.set_rlf_TimersAndConstants_r13(rlf_TimersAndConstants_r13);

    /* Setting 'sps_Config_v1430' field */
    SPS_Config_v1430 sps_Config_v1430;
    fill_SPS_Config_v1430(sps_Config_v1430);
    value.set_sps_Config_v1430(sps_Config_v1430);

    /* Setting 'srb_ToAddModExtList_r15' field */
    SRB_ToAddModExtList_r15 srb_ToAddModExtList_r15;
    {
	/* Adding component #1 */
	SRB_ToAddMod comp1;
	fill_SRB_ToAddMod(comp1);
	srb_ToAddModExtList_r15.prepend(comp1);
    }
    value.set_srb_ToAddModExtList_r15(srb_ToAddModExtList_r15);

    value.set_srb_ToReleaseExtList_r15(4);
    /* Setting 'sps_Config_v1530' field */
    SPS_Config_v1530 sps_Config_v1530;
    fill_SPS_Config_v1530(sps_Config_v1530);
    value.set_sps_Config_v1530(sps_Config_v1530);

    /* Setting 'crs_IntfMitigConfig_r15' field */
    RadioResourceConfigDedicated::crs_IntfMitigConfig_r15 crs_IntfMitigConfig_r15;
    crs_IntfMitigConfig_r15.set_release(0);
    value.set_crs_IntfMitigConfig_r15(crs_IntfMitigConfig_r15);

    /* Setting 'neighCellsCRS_Info_r15' field */
    NeighCellsCRS_Info_r15 neighCellsCRS_Info_r15;
    fill_NeighCellsCRS_Info_r15(neighCellsCRS_Info_r15);
    value.set_neighCellsCRS_Info_r15(neighCellsCRS_Info_r15);

    /* Setting 'drb_ToAddModList_r15' field */
    DRB_ToAddModList_r15 drb_ToAddModList_r15;
    {
	/* Adding component #2 */
	DRB_ToAddMod comp2;
	fill_DRB_ToAddMod(comp2);
	drb_ToAddModList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DRB_ToAddMod comp1;
	fill_DRB_ToAddMod(comp1);
	drb_ToAddModList_r15.prepend(comp1);
    }
    value.set_drb_ToAddModList_r15(drb_ToAddModList_r15);

    /* Setting 'drb_ToReleaseList_r15' field */
    DRB_ToReleaseList_r15 drb_ToReleaseList_r15;
    fill_DRB_ToReleaseList_r15(drb_ToReleaseList_r15);
    value.set_drb_ToReleaseList_r15(drb_ToReleaseList_r15);

    /* Setting 'srb_ToReleaseListDupl_r15' field */
    SRB_ToReleaseListDupl_r15 srb_ToReleaseListDupl_r15;
    srb_ToReleaseListDupl_r15.prepend(1);
    srb_ToReleaseListDupl_r15.prepend(1);
    value.set_srb_ToReleaseListDupl_r15(srb_ToReleaseListDupl_r15);
}

DL_CCCH_Message *create_samplevalue_DL_CCCH_Message()
{
    /* Creating 'message' field */
    DL_CCCH_MessageType message;
    /* Setting 'c1' alternative of 'message' field */
    DL_CCCH_MessageType::c1 c1;
    /* Setting 'rrcConnectionReestablishment' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'rrcConnectionReestablishment' alternative of 'c1' alternative of 'message' field... */
    RRCConnectionReestablishment::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishment' alternative of 'c1' alternative... */
    RRCConnectionReestablishment::criticalExtensions::c1 criticalExtensions_c1;
    /* Setting 'rrcConnectionReestablishment_r8' alternative of 'c1' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishment' alternative... */
    /* Creating 'radioResourceConfigDedicated' field of 'rrcConnectionReestablishment_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    RadioResourceConfigDedicated radioResourceConfigDedicated;
    fill_RadioResourceConfigDedicated(radioResourceConfigDedicated);

    /* Creating 'nonCriticalExtension' field of 'rrcConnectionReestablishment_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    RRCConnectionReestablishment_v8a0_IEs nonCriticalExtension;
    fill_SystemInformation_v8a0_IEs(nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishment_r8_IEs rrcConnectionReestablishment_r8(radioResourceConfigDedicated, 0, nonCriticalExtension);

    criticalExtensions_c1.set_rrcConnectionReestablishment_r8(rrcConnectionReestablishment_r8);

    criticalExtensions.set_c1(criticalExtensions_c1);

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishment rrcConnectionReestablishment(0, criticalExtensions);

    c1.set_rrcConnectionReestablishment(rrcConnectionReestablishment);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new DL_CCCH_Message(message);
}

static void fill_ReestabUE_Identity(ReestabUE_Identity & value)
{
    /* Setting 'c_RNTI' field */
    static unsigned char c_RNTI_value[] = {
	0x00, 0x00
    };
    OssBitString c_RNTI(16, c_RNTI_value);
    value.set_c_RNTI(c_RNTI);

    value.set_physCellId(0);
    /* Setting 'shortMAC_I' field */
    static unsigned char shortMAC_I_value[] = {
	0x00, 0x00
    };
    OssBitString shortMAC_I(16, shortMAC_I_value);
    value.set_shortMAC_I(shortMAC_I);
}

UL_CCCH_Message *create_samplevalue_UL_CCCH_Message()
{
    /* Creating 'message' field */
    UL_CCCH_MessageType message;
    /* Setting 'c1' alternative of 'message' field */
    UL_CCCH_MessageType::c1 c1;
    /* Setting 'rrcConnectionReestablishmentRequest' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'rrcConnectionReestablishmentRequest' alternative of 'c1' alternative of 'message' field... */
    RRCConnectionReestablishmentRequest::criticalExtensions criticalExtensions;
    /* Setting 'rrcConnectionReestablishmentRequest_r8' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishmentRequest' alternative of 'c1' alternative... */
    /* Creating 'ue_Identity' field of 'rrcConnectionReestablishmentRequest_r8' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishmentRequest' alternative... */
    ReestabUE_Identity ue_Identity;
    fill_ReestabUE_Identity(ue_Identity);

    /* Creating 'spare' field of 'rrcConnectionReestablishmentRequest_r8' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishmentRequest' alternative... */
    static unsigned char spare_value[] = {
	0x00
    };
    OssBitString spare(2, spare_value);

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishmentRequest_r8_IEs rrcConnectionReestablishmentRequest_r8(ue_Identity, ReestablishmentCause_reconfigurationFailure, spare);

    criticalExtensions.set_rrcConnectionReestablishmentRequest_r8(rrcConnectionReestablishmentRequest_r8);

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishmentRequest rrcConnectionReestablishmentRequest(criticalExtensions);

    c1.set_rrcConnectionReestablishmentRequest(rrcConnectionReestablishmentRequest);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UL_CCCH_Message(message);
}

UL_DCCH_Message *create_samplevalue_UL_DCCH_Message()
{
    /* Creating 'message' field */
    UL_DCCH_MessageType message;
    /* Setting 'c1' alternative of 'message' field */
    UL_DCCH_MessageType::c1 c1;
    /* Setting 'csfbParametersRequestCDMA2000' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'csfbParametersRequestCDMA2000' alternative of 'c1' alternative of 'message' field... */
    CSFBParametersRequestCDMA2000::criticalExtensions criticalExtensions;
    /* Setting 'csfbParametersRequestCDMA2000_r8' alternative of 'criticalExtensions' field of 'csfbParametersRequestCDMA2000' alternative of 'c1' alternative... */
    /* Creating 'nonCriticalExtension' field of 'csfbParametersRequestCDMA2000_r8' alternative of 'criticalExtensions' field of 'csfbParametersRequestCDMA2000' alternative... */
    CSFBParametersRequestCDMA2000_v8a0_IEs nonCriticalExtension;
    fill_SystemInformation_v8a0_IEs(nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    CSFBParametersRequestCDMA2000_r8_IEs csfbParametersRequestCDMA2000_r8(nonCriticalExtension);

    criticalExtensions.set_csfbParametersRequestCDMA2000_r8(csfbParametersRequestCDMA2000_r8);

    /* Calling a fully-initializing constructor */
    CSFBParametersRequestCDMA2000 csfbParametersRequestCDMA2000(criticalExtensions);

    c1.set_csfbParametersRequestCDMA2000(csfbParametersRequestCDMA2000);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UL_DCCH_Message(message);
}

static void fill_MBMSSessionInfo_r13(MBMSSessionInfo_r13 & value)
{
    /* Setting 'tmgi_r13' field */
    TMGI_r9 tmgi_r13;
    fill_TMGI_r9(tmgi_r13);
    value.set_tmgi_r13(tmgi_r13);

    /* Setting 'sessionId_r13' field */
    static unsigned char sessionId_r13_value[] = {
	0x00
    };
    OssString sessionId_r13(sizeof(sessionId_r13_value), (char *)sessionId_r13_value);
    value.set_sessionId_r13(sessionId_r13);
}

static void fill_SC_MTCH_Info_r13(SC_MTCH_Info_r13 & value)
{
    /* Setting 'mbmsSessionInfo_r13' field */
    MBMSSessionInfo_r13 mbmsSessionInfo_r13;
    fill_MBMSSessionInfo_r13(mbmsSessionInfo_r13);
    value.set_mbmsSessionInfo_r13(mbmsSessionInfo_r13);

    /* Setting 'g_RNTI_r13' field */
    static unsigned char g_RNTI_r13_value[] = {
	0x00, 0x00
    };
    OssBitString g_RNTI_r13(16, g_RNTI_r13_value);
    value.set_g_RNTI_r13(g_RNTI_r13);

    /* Setting 'sc_mtch_schedulingInfo_r13' field */
    /* Creating 'schedulingPeriodStartOffsetSCPTM_r13' field of 'sc_mtch_schedulingInfo_r13' field */
    SC_MTCH_SchedulingInfo_r13::schedulingPeriodStartOffsetSCPTM_r13 schedulingPeriodStartOffsetSCPTM_r13;
    schedulingPeriodStartOffsetSCPTM_r13.set_sf10(0);

    /* Calling a fully-initializing constructor */
    SC_MTCH_SchedulingInfo_r13 sc_mtch_schedulingInfo_r13(onDurationTimerSCPTM_r13_psf1, drx_InactivityTimerSCPTM_r13_psf0, schedulingPeriodStartOffsetSCPTM_r13);

    value.set_sc_mtch_schedulingInfo_r13(sc_mtch_schedulingInfo_r13);

    /* Setting 'sc_mtch_neighbourCell_r13' field */
    static unsigned char sc_mtch_neighbourCell_r13_value[] = {
	0x00
    };
    OssBitString sc_mtch_neighbourCell_r13(8, sc_mtch_neighbourCell_r13_value);
    value.set_sc_mtch_neighbourCell_r13(sc_mtch_neighbourCell_r13);

    value.set_p_a_r13(p_a_r13_dB_6);
}

static void fill_PCI_ARFCN_r13(PCI_ARFCN_r13 & value)
{
    value.set_physCellId_r13(0);
    value.set_carrierFreq_r13(0);
}

SC_MCCH_Message_r13 *create_samplevalue_SC_MCCH_Message_r13()
{
    /* Creating 'message' field */
    SC_MCCH_MessageType_r13 message;
    /* Setting 'c1' alternative of 'message' field */
    SC_MCCH_MessageType_r13::c1 c1;
    /* Setting 'scptmConfiguration_r13' alternative of 'c1' alternative of 'message' field */
    /* Creating 'sc_mtch_InfoList_r13' field of 'scptmConfiguration_r13' alternative of 'c1' alternative of 'message' field... */
    SC_MTCH_InfoList_r13 sc_mtch_InfoList_r13;
    {
	/* Adding component #2 */
	SC_MTCH_Info_r13 comp2;
	fill_SC_MTCH_Info_r13(comp2);
	sc_mtch_InfoList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SC_MTCH_Info_r13 comp1;
	fill_SC_MTCH_Info_r13(comp1);
	sc_mtch_InfoList_r13.prepend(comp1);
    }

    /* Creating 'scptm_NeighbourCellList_r13' field of 'scptmConfiguration_r13' alternative of 'c1' alternative of 'message' field... */
    SCPTM_NeighbourCellList_r13 scptm_NeighbourCellList_r13;
    {
	/* Adding component #2 */
	PCI_ARFCN_r13 comp2;
	fill_PCI_ARFCN_r13(comp2);
	scptm_NeighbourCellList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PCI_ARFCN_r13 comp1;
	fill_PCI_ARFCN_r13(comp1);
	scptm_NeighbourCellList_r13.prepend(comp1);
    }

    /* Creating 'lateNonCriticalExtension' field of 'scptmConfiguration_r13' alternative of 'c1' alternative of 'message' field... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'scptmConfiguration_r13' alternative of 'c1' alternative of 'message' field... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'scptmConfiguration_r13' alternative of 'c1' alternative... */
    SCPTMConfiguration_v1340::nonCriticalExtension nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SCPTMConfiguration_v1340 nonCriticalExtension(0, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SCPTMConfiguration_r13 scptmConfiguration_r13(sc_mtch_InfoList_r13, scptm_NeighbourCellList_r13, lateNonCriticalExtension, nonCriticalExtension);

    c1.set_scptmConfiguration_r13(scptmConfiguration_r13);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new SC_MCCH_Message_r13(message);
}

SPS_ConfigDL_STTI_r15 *create_samplevalue_SPS_ConfigDL_STTI_r15()
{
    SPS_ConfigDL_STTI_r15 *result = new SPS_ConfigDL_STTI_r15;

    result->set_release(0);

    return result;
}

static void fill_ROHC_ProfileSupportList_r15(ROHC_ProfileSupportList_r15 & value)
{
    value.set_profile0x0001_r15(TRUE);
    value.set_profile0x0002_r15(TRUE);
    value.set_profile0x0003_r15(TRUE);
    value.set_profile0x0004_r15(TRUE);
    value.set_profile0x0006_r15(TRUE);
    value.set_profile0x0101_r15(TRUE);
    value.set_profile0x0102_r15(TRUE);
    value.set_profile0x0103_r15(TRUE);
    value.set_profile0x0104_r15(TRUE);
}

static void fill_SupportedBandEUTRA(SupportedBandEUTRA & value)
{
    value.set_bandEUTRA(1);
    value.set_halfDuplex(TRUE);
}

static void fill_InterFreqBandInfo(InterFreqBandInfo & value)
{
    value.set_interFreqNeedForGaps(TRUE);
}

static void fill_InterRAT_BandInfo(InterRAT_BandInfo & value)
{
    value.set_interRAT_NeedForGaps(TRUE);
}

static void fill_BandInfoEUTRA(BandInfoEUTRA & value)
{
    /* Setting 'interFreqBandList' field */
    InterFreqBandList interFreqBandList;
    {
	/* Adding component #2 */
	InterFreqBandInfo comp2;
	fill_InterFreqBandInfo(comp2);
	interFreqBandList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	InterFreqBandInfo comp1;
	fill_InterFreqBandInfo(comp1);
	interFreqBandList.prepend(comp1);
    }
    value.set_interFreqBandList(interFreqBandList);

    /* Setting 'interRAT_BandList' field */
    InterRAT_BandList interRAT_BandList;
    {
	/* Adding component #2 */
	InterRAT_BandInfo comp2;
	fill_InterRAT_BandInfo(comp2);
	interRAT_BandList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	InterRAT_BandInfo comp1;
	fill_InterRAT_BandInfo(comp1);
	interRAT_BandList.prepend(comp1);
    }
    value.set_interRAT_BandList(interRAT_BandList);
}

static void fill_SupportedBandEUTRA_v9e0(SupportedBandEUTRA_v9e0 & value)
{
    value.set_bandEUTRA_v9e0(65);
}

static void fill_CA_MIMO_ParametersDL_v10i0(CA_MIMO_ParametersDL_v10i0 & value)
{
    value.set_fourLayerTM3_TM4_r10(fourLayerTM3_TM4_r10_supported);
}

static void fill_BandParameters_v10i0(BandParameters_v10i0 & value)
{
    /* Setting 'bandParametersDL_v10i0' field */
    BandParameters_v10i0::bandParametersDL_v10i0 bandParametersDL_v10i0;
    {
	/* Adding component #2 */
	CA_MIMO_ParametersDL_v10i0 comp2;
	fill_CA_MIMO_ParametersDL_v10i0(comp2);
	bandParametersDL_v10i0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CA_MIMO_ParametersDL_v10i0 comp1;
	fill_CA_MIMO_ParametersDL_v10i0(comp1);
	bandParametersDL_v10i0.prepend(comp1);
    }
    value.set_bandParametersDL_v10i0(bandParametersDL_v10i0);
}

static void fill_BandCombinationParameters_v10i0(BandCombinationParameters_v10i0 & value)
{
    /* Setting 'bandParameterList_v10i0' field */
    BandCombinationParameters_v10i0::bandParameterList_v10i0 bandParameterList_v10i0;
    {
	/* Adding component #2 */
	BandParameters_v10i0 comp2;
	fill_BandParameters_v10i0(comp2);
	bandParameterList_v10i0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v10i0 comp1;
	fill_BandParameters_v10i0(comp1);
	bandParameterList_v10i0.prepend(comp1);
    }
    value.set_bandParameterList_v10i0(bandParameterList_v10i0);
}

static void fill_BandParameters_v1380(BandParameters_v1380 & value)
{
    value.set_txAntennaSwitchDL_r13(1);
    value.set_txAntennaSwitchUL_r13(1);
}

static void fill_BandCombinationParameters_v1380(BandCombinationParameters_v1380 & value)
{
    /* Setting 'bandParameterList_v1380' field */
    BandCombinationParameters_v1380::bandParameterList_v1380 bandParameterList_v1380;
    {
	/* Adding component #2 */
	BandParameters_v1380 comp2;
	fill_BandParameters_v1380(comp2);
	bandParameterList_v1380.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1380 comp1;
	fill_BandParameters_v1380(comp1);
	bandParameterList_v1380.prepend(comp1);
    }
    value.set_bandParameterList_v1380(bandParameterList_v1380);
}

static void fill_BandCombinationParameters_v1390(BandCombinationParameters_v1390 & value)
{
    value.set_ue_CA_PowerClass_N_r13(ue_CA_PowerClass_N_r13_class2);
}

static void fill_BandParameters_v1470(BandParameters_v1470 & value)
{
    /* Setting 'bandParametersDL_v1470' field */
    /* Creating 'parametersTM9_v1470' field of 'bandParametersDL_v1470' field */

    /* Calling a fully-initializing constructor */
    MIMO_CA_ParametersPerBoBCPerTM_v1470 parametersTM9_v1470(MIMO_CA_ParametersPerBoBCPerTM_v1470_csi_ReportingAdvancedMaxPorts_r14_n8);

    /* Creating 'parametersTM10_v1470' field of 'bandParametersDL_v1470' field */

    /* Calling a fully-initializing constructor */
    MIMO_CA_ParametersPerBoBCPerTM_v1470 parametersTM10_v1470(MIMO_CA_ParametersPerBoBCPerTM_v1470_csi_ReportingAdvancedMaxPorts_r14_n8);

    /* Calling a fully-initializing constructor */
    MIMO_CA_ParametersPerBoBC_v1470 bandParametersDL_v1470(parametersTM9_v1470, parametersTM10_v1470);

    value.set_bandParametersDL_v1470(bandParametersDL_v1470);
}

static void fill_BandCombinationParameters_v1470(BandCombinationParameters_v1470 & value)
{
    /* Setting 'bandParameterList_v1470' field */
    BandCombinationParameters_v1470::bandParameterList_v1470 bandParameterList_v1470;
    {
	/* Adding component #2 */
	BandParameters_v1470 comp2;
	fill_BandParameters_v1470(comp2);
	bandParameterList_v1470.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1470 comp1;
	fill_BandParameters_v1470(comp1);
	bandParameterList_v1470.prepend(comp1);
    }
    value.set_bandParameterList_v1470(bandParameterList_v1470);

    value.set_srs_MaxSimultaneousCCs_r14(1);
}

static void fill_NonContiguousUL_RA_WithinCC_r10(NonContiguousUL_RA_WithinCC_r10 & value)
{
    value.set_nonContiguousUL_RA_WithinCC_Info_r10(nonContiguousUL_RA_WithinCC_Info_r10_supported);
}

static void fill_PhyLayerParameters_v1020(PhyLayerParameters_v1020 & value)
{
    value.set_twoAntennaPortsForPUCCH_r10(twoAntennaPortsForPUCCH_r10_supported);
    value.set_tm9_With_8Tx_FDD_r10(tm9_With_8Tx_FDD_r10_supported);
    value.set_pmi_Disabling_r10(pmi_Disabling_r10_supported);
    value.set_crossCarrierScheduling_r10(crossCarrierScheduling_r10_supported);
    value.set_simultaneousPUCCH_PUSCH_r10(simultaneousPUCCH_PUSCH_r10_supported);
    value.set_multiClusterPUSCH_WithinCC_r10(multiClusterPUSCH_WithinCC_r10_supported);
    /* Setting 'nonContiguousUL_RA_WithinCC_List_r10' field */
    NonContiguousUL_RA_WithinCC_List_r10 nonContiguousUL_RA_WithinCC_List_r10;
    {
	/* Adding component #2 */
	NonContiguousUL_RA_WithinCC_r10 comp2;
	fill_NonContiguousUL_RA_WithinCC_r10(comp2);
	nonContiguousUL_RA_WithinCC_List_r10.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NonContiguousUL_RA_WithinCC_r10 comp1;
	fill_NonContiguousUL_RA_WithinCC_r10(comp1);
	nonContiguousUL_RA_WithinCC_List_r10.prepend(comp1);
    }
    value.set_nonContiguousUL_RA_WithinCC_List_r10(nonContiguousUL_RA_WithinCC_List_r10);
}

static void fill_CA_MIMO_ParametersUL_r10(CA_MIMO_ParametersUL_r10 & value)
{
    value.set_ca_BandwidthClassUL_r10(CA_BandwidthClass_r10_a);
    value.set_supportedMIMO_CapabilityUL_r10(MIMO_CapabilityUL_r10_twoLayers);
}

static void fill_BandParametersUL_r10(BandParametersUL_r10 & value)
{
    {
	/* Adding component #2 */
	CA_MIMO_ParametersUL_r10 comp2;
	fill_CA_MIMO_ParametersUL_r10(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CA_MIMO_ParametersUL_r10 comp1;
	fill_CA_MIMO_ParametersUL_r10(comp1);
	value.prepend(comp1);
    }
}

static void fill_CA_MIMO_ParametersDL_r10(CA_MIMO_ParametersDL_r10 & value)
{
    value.set_ca_BandwidthClassDL_r10(CA_BandwidthClass_r10_a);
    value.set_supportedMIMO_CapabilityDL_r10(MIMO_CapabilityDL_r10_twoLayers);
}

static void fill_BandParametersDL_r10(BandParametersDL_r10 & value)
{
    {
	/* Adding component #2 */
	CA_MIMO_ParametersDL_r10 comp2;
	fill_CA_MIMO_ParametersDL_r10(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CA_MIMO_ParametersDL_r10 comp1;
	fill_CA_MIMO_ParametersDL_r10(comp1);
	value.prepend(comp1);
    }
}

static void fill_BandParameters_r10(BandParameters_r10 & value)
{
    value.set_bandEUTRA_r10(1);
    /* Setting 'bandParametersUL_r10' field */
    BandParametersUL_r10 bandParametersUL_r10;
    fill_BandParametersUL_r10(bandParametersUL_r10);
    value.set_bandParametersUL_r10(bandParametersUL_r10);

    /* Setting 'bandParametersDL_r10' field */
    BandParametersDL_r10 bandParametersDL_r10;
    fill_BandParametersDL_r10(bandParametersDL_r10);
    value.set_bandParametersDL_r10(bandParametersDL_r10);
}

static void fill_BandCombinationParameters_r10(BandCombinationParameters_r10 & value)
{
    {
	/* Adding component #2 */
	BandParameters_r10 comp2;
	fill_BandParameters_r10(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_r10 comp1;
	fill_BandParameters_r10(comp1);
	value.prepend(comp1);
    }
}

static void fill_IRAT_ParametersCDMA2000_1XRTT_v1020(IRAT_ParametersCDMA2000_1XRTT_v1020 & value)
{
    value.set_e_CSFB_dual_1XRTT_r10(e_CSFB_dual_1XRTT_r10_supported);
}

static void fill_IRAT_ParametersUTRA_TDD_v1020(IRAT_ParametersUTRA_TDD_v1020 & value)
{
    value.set_e_RedirectionUTRA_TDD_r10(e_RedirectionUTRA_TDD_r10_supported);
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1060(UE_EUTRA_CapabilityAddXDD_Mode_v1060 & value)
{
    /* Setting 'phyLayerParameters_v1060' field */
    PhyLayerParameters_v1020 phyLayerParameters_v1060;
    fill_PhyLayerParameters_v1020(phyLayerParameters_v1060);
    value.set_phyLayerParameters_v1060(phyLayerParameters_v1060);

    /* Setting 'featureGroupIndRel10_v1060' field */
    static unsigned char featureGroupIndRel10_v1060_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString featureGroupIndRel10_v1060(32, featureGroupIndRel10_v1060_value);
    value.set_featureGroupIndRel10_v1060(featureGroupIndRel10_v1060);

    /* Setting 'interRAT_ParametersCDMA2000_v1060' field */
    IRAT_ParametersCDMA2000_1XRTT_v1020 interRAT_ParametersCDMA2000_v1060;
    fill_IRAT_ParametersCDMA2000_1XRTT_v1020(interRAT_ParametersCDMA2000_v1060);
    value.set_interRAT_ParametersCDMA2000_v1060(interRAT_ParametersCDMA2000_v1060);

    /* Setting 'interRAT_ParametersUTRA_TDD_v1060' field */
    IRAT_ParametersUTRA_TDD_v1020 interRAT_ParametersUTRA_TDD_v1060;
    fill_IRAT_ParametersUTRA_TDD_v1020(interRAT_ParametersUTRA_TDD_v1060);
    value.set_interRAT_ParametersUTRA_TDD_v1060(interRAT_ParametersUTRA_TDD_v1060);

    /* Setting 'otdoa_PositioningCapabilities_r10' field */

    /* Calling a fully-initializing constructor */
    OTDOA_PositioningCapabilities_r10 otdoa_PositioningCapabilities_r10(otdoa_UE_Assisted_r10_supported, interFreqRSTD_Measurement_r10_supported);

    value.set_otdoa_PositioningCapabilities_r10(otdoa_PositioningCapabilities_r10);
}

static void fill_BandCombinationParametersExt_r10(BandCombinationParametersExt_r10 & value)
{
    /* Setting 'supportedBandwidthCombinationSet_r10' field */
    static unsigned char supportedBandwidthCombinationSet_r10_value[] = {
	0x00
    };
    OssBitString supportedBandwidthCombinationSet_r10(1, supportedBandwidthCombinationSet_r10_value);
    value.set_supportedBandwidthCombinationSet_r10(supportedBandwidthCombinationSet_r10);
}

static void fill_BandParameters_v1090(BandParameters_v1090 & value)
{
    value.set_bandEUTRA_v1090(65);
}

static void fill_BandCombinationParameters_v1090(BandCombinationParameters_v1090 & value)
{
    {
	/* Adding component #2 */
	BandParameters_v1090 comp2;
	fill_BandParameters_v1090(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1090 comp1;
	fill_BandParameters_v1090(comp1);
	value.prepend(comp1);
    }
}

static void fill_PhyLayerParameters_v1130(PhyLayerParameters_v1130 & value)
{
    value.set_crs_InterfHandl_r11(crs_InterfHandl_r11_supported);
    value.set_ePDCCH_r11(ePDCCH_r11_supported);
    value.set_multiACK_CSI_Reporting_r11(multiACK_CSI_Reporting_r11_supported);
    value.set_ss_CCH_InterfHandl_r11(ss_CCH_InterfHandl_r11_supported);
    value.set_tdd_SpecialSubframe_r11(tdd_SpecialSubframe_r11_supported);
    value.set_txDiv_PUCCH1b_ChSelect_r11(txDiv_PUCCH1b_ChSelect_r11_supported);
    value.set_ul_CoMP_r11(ul_CoMP_r11_supported);
}

static void fill_BandParameters_v1130(BandParameters_v1130 & value)
{
    value.set_supportedCSI_Proc_r11(BandParameters_v1130_supportedCSI_Proc_r11_n1);
}

static void fill_BandCombinationParameters_v1130(BandCombinationParameters_v1130 & value)
{
    value.set_multipleTimingAdvance_r11(BandCombinationParameters_v1130_multipleTimingAdvance_r11_supported);
    value.set_simultaneousRx_Tx_r11(BandCombinationParameters_v1130_simultaneousRx_Tx_r11_supported);
    /* Setting 'bandParameterList_r11' field */
    BandCombinationParameters_v1130::bandParameterList_r11 bandParameterList_r11;
    {
	/* Adding component #2 */
	BandParameters_v1130 comp2;
	fill_BandParameters_v1130(comp2);
	bandParameterList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1130 comp1;
	fill_BandParameters_v1130(comp1);
	bandParameterList_r11.prepend(comp1);
    }
    value.set_bandParameterList_r11(bandParameterList_r11);
}

static void fill_MeasParameters_v1130(MeasParameters_v1130 & value)
{
    value.set_rsrqMeasWideband_r11(rsrqMeasWideband_r11_supported);
}

static void fill_Other_Parameters_r11(Other_Parameters_r11 & value)
{
    value.set_inDeviceCoexInd_r11(inDeviceCoexInd_r11_supported);
    value.set_powerPrefInd_r11(powerPrefInd_r11_supported);
    value.set_ue_Rx_TxTimeDiffMeasurements_r11(ue_Rx_TxTimeDiffMeasurements_r11_supported);
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1130(UE_EUTRA_CapabilityAddXDD_Mode_v1130 & value)
{
    /* Setting 'phyLayerParameters_v1130' field of 'supportedBandCombination_v1130' field of 'fdd_Add_UE_EUTRA_Capabilities_v1130' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1130 phyLayerParameters_v1130;
    fill_PhyLayerParameters_v1130(phyLayerParameters_v1130);
    value.set_phyLayerParameters_v1130(phyLayerParameters_v1130);

    /* Setting 'measParameters_v1130' field of 'supportedBandCombination_v1130' field of 'fdd_Add_UE_EUTRA_Capabilities_v1130' field of 'nonCriticalExtension' field... */
    MeasParameters_v1130 measParameters_v1130;
    fill_MeasParameters_v1130(measParameters_v1130);
    value.set_measParameters_v1130(measParameters_v1130);

    /* Setting 'otherParameters_r11' field of 'supportedBandCombination_v1130' field of 'fdd_Add_UE_EUTRA_Capabilities_v1130' field of 'nonCriticalExtension' field... */
    Other_Parameters_r11 otherParameters_r11;
    fill_Other_Parameters_r11(otherParameters_r11);
    value.set_otherParameters_r11(otherParameters_r11);
}

static void fill_BandParameters_r11(BandParameters_r11 & value)
{
    value.set_bandEUTRA_r11(1);
    /* Setting 'bandParametersUL_r11' field */
    BandParametersUL_r10 bandParametersUL_r11;
    fill_BandParametersUL_r10(bandParametersUL_r11);
    value.set_bandParametersUL_r11(bandParametersUL_r11);

    /* Setting 'bandParametersDL_r11' field */
    BandParametersDL_r10 bandParametersDL_r11;
    fill_BandParametersDL_r10(bandParametersDL_r11);
    value.set_bandParametersDL_r11(bandParametersDL_r11);

    value.set_supportedCSI_Proc_r11(BandParameters_r11_supportedCSI_Proc_r11_n1);
}

static void fill_BandCombinationParameters_r11(BandCombinationParameters_r11 & value)
{
    /* Setting 'bandParameterList_r11' field */
    BandCombinationParameters_r11::bandParameterList_r11 bandParameterList_r11;
    {
	/* Adding component #2 */
	BandParameters_r11 comp2;
	fill_BandParameters_r11(comp2);
	bandParameterList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_r11 comp1;
	fill_BandParameters_r11(comp1);
	bandParameterList_r11.prepend(comp1);
    }
    value.set_bandParameterList_r11(bandParameterList_r11);

    /* Setting 'supportedBandwidthCombinationSet_r11' field */
    static unsigned char supportedBandwidthCombinationSet_r11_value[] = {
	0x00
    };
    OssBitString supportedBandwidthCombinationSet_r11(1, supportedBandwidthCombinationSet_r11_value);
    value.set_supportedBandwidthCombinationSet_r11(supportedBandwidthCombinationSet_r11);

    value.set_multipleTimingAdvance_r11(BandCombinationParameters_r11_multipleTimingAdvance_r11_supported);
    value.set_simultaneousRx_Tx_r11(BandCombinationParameters_r11_simultaneousRx_Tx_r11_supported);
    /* Setting 'bandInfoEUTRA_r11' field */
    BandInfoEUTRA bandInfoEUTRA_r11;
    fill_BandInfoEUTRA(bandInfoEUTRA_r11);
    value.set_bandInfoEUTRA_r11(bandInfoEUTRA_r11);
}

static void fill_MBMS_Parameters_r11(MBMS_Parameters_r11 & value)
{
    value.set_mbms_SCell_r11(mbms_SCell_r11_supported);
    value.set_mbms_NonServingCell_r11(mbms_NonServingCell_r11_supported);
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1180(UE_EUTRA_CapabilityAddXDD_Mode_v1180 & value)
{
    /* Setting 'mbms_Parameters_r11' field of 'supportedBandCombinationAdd_r11' field of 'fdd_Add_UE_EUTRA_Capabilities_v1180' field of 'nonCriticalExtension' field... */
    MBMS_Parameters_r11 mbms_Parameters_r11;
    fill_MBMS_Parameters_r11(mbms_Parameters_r11);
    value.set_mbms_Parameters_r11(mbms_Parameters_r11);
}

static void fill_NAICS_Capability_Entry_r12(NAICS_Capability_Entry_r12 & value)
{
    value.set_numberOfNAICS_CapableCC_r12(1);
    value.set_numberOfAggregatedPRB_r12(numberOfAggregatedPRB_r12_n50);
}

static void fill_PhyLayerParameters_v1250(PhyLayerParameters_v1250 & value)
{
    value.set_e_HARQ_Pattern_FDD_r12(e_HARQ_Pattern_FDD_r12_supported);
    value.set_enhanced_4TxCodebook_r12(enhanced_4TxCodebook_r12_supported);
    /* Setting 'tdd_FDD_CA_PCellDuplex_r12' field */
    static unsigned char tdd_FDD_CA_PCellDuplex_r12_value[] = {
	0x00
    };
    OssBitString tdd_FDD_CA_PCellDuplex_r12(2, tdd_FDD_CA_PCellDuplex_r12_value);
    value.set_tdd_FDD_CA_PCellDuplex_r12(tdd_FDD_CA_PCellDuplex_r12);

    value.set_phy_TDD_ReConfig_TDD_PCell_r12(phy_TDD_ReConfig_TDD_PCell_r12_supported);
    value.set_phy_TDD_ReConfig_FDD_PCell_r12(phy_TDD_ReConfig_FDD_PCell_r12_supported);
    value.set_pusch_FeedbackMode_r12(pusch_FeedbackMode_r12_supported);
    value.set_pusch_SRS_PowerControl_SubframeSet_r12(pusch_SRS_PowerControl_SubframeSet_r12_supported);
    value.set_csi_SubframeSet_r12(csi_SubframeSet_r12_supported);
    value.set_noResourceRestrictionForTTIBundling_r12(noResourceRestrictionForTTIBundling_r12_supported);
    value.set_discoverySignalsInDeactSCell_r12(discoverySignalsInDeactSCell_r12_supported);
    /* Setting 'naics_Capability_List_r12' field */
    NAICS_Capability_List_r12 naics_Capability_List_r12;
    {
	/* Adding component #2 */
	NAICS_Capability_Entry_r12 comp2;
	fill_NAICS_Capability_Entry_r12(comp2);
	naics_Capability_List_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NAICS_Capability_Entry_r12 comp1;
	fill_NAICS_Capability_Entry_r12(comp1);
	naics_Capability_List_r12.prepend(comp1);
    }
    value.set_naics_Capability_List_r12(naics_Capability_List_r12);
}

static void fill_SupportedBandEUTRA_v1250(SupportedBandEUTRA_v1250 & value)
{
    value.set_dl_256QAM_r12(dl_256QAM_r12_supported);
    value.set_ul_64QAM_r12(ul_64QAM_r12_supported);
}

static void fill_BandCombinationParameters_v1250(BandCombinationParameters_v1250 & value)
{
    /* Setting 'dc_Support_r12' field */
    /* Creating 'supportedCellGrouping_r12' field of 'dc_Support_r12' field */
    BandCombinationParameters_v1250::dc_Support_r12::supportedCellGrouping_r12 supportedCellGrouping_r12;
    /* Setting 'threeEntries_r12' alternative of 'supportedCellGrouping_r12' field of 'dc_Support_r12' field */
    static unsigned char threeEntries_r12_value[] = {
	0x00
    };
    OssBitString threeEntries_r12(3, threeEntries_r12_value);
    supportedCellGrouping_r12.set_threeEntries_r12(threeEntries_r12);

    /* Calling a fully-initializing constructor */
    BandCombinationParameters_v1250::dc_Support_r12 dc_Support_r12(asynchronous_r12_supported, supportedCellGrouping_r12);

    value.set_dc_Support_r12(dc_Support_r12);

    /* Setting 'supportedNAICS_2CRS_AP_r12' field */
    static unsigned char supportedNAICS_2CRS_AP_r12_value[] = {
	0x00
    };
    OssBitString supportedNAICS_2CRS_AP_r12(1, supportedNAICS_2CRS_AP_r12_value);
    value.set_supportedNAICS_2CRS_AP_r12(supportedNAICS_2CRS_AP_r12);

    /* Setting 'commSupportedBandsPerBC_r12' field */
    static unsigned char commSupportedBandsPerBC_r12_value[] = {
	0x00
    };
    OssBitString commSupportedBandsPerBC_r12(1, commSupportedBandsPerBC_r12_value);
    value.set_commSupportedBandsPerBC_r12(commSupportedBandsPerBC_r12);
}

static void fill_SupportedBandCombination_v1250(SupportedBandCombination_v1250 & value)
{
    {
	/* Adding component #2 */
	BandCombinationParameters_v1250 comp2;
	fill_BandCombinationParameters_v1250(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1250 comp1;
	fill_BandCombinationParameters_v1250(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasParameters_v1250(MeasParameters_v1250 & value)
{
    value.set_timerT312_r12(timerT312_r12_supported);
    value.set_alternativeTimeToTrigger_r12(alternativeTimeToTrigger_r12_supported);
    value.set_incMonEUTRA_r12(incMonEUTRA_r12_supported);
    value.set_incMonUTRA_r12(incMonUTRA_r12_supported);
    value.set_extendedMaxMeasId_r12(extendedMaxMeasId_r12_supported);
    value.set_extendedRSRQ_LowerRange_r12(extendedRSRQ_LowerRange_r12_supported);
    value.set_rsrq_OnAllSymbols_r12(rsrq_OnAllSymbols_r12_supported);
    value.set_crs_DiscoverySignalsMeas_r12(crs_DiscoverySignalsMeas_r12_supported);
    value.set_csi_RS_DiscoverySignalsMeas_r12(csi_RS_DiscoverySignalsMeas_r12_supported);
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1250(UE_EUTRA_CapabilityAddXDD_Mode_v1250 & value)
{
    /* Setting 'phyLayerParameters_v1250' field of 'supportedBandCombinationAdd_v1250' field of 'fdd_Add_UE_EUTRA_Capabilities_v1250' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1250 phyLayerParameters_v1250;
    fill_PhyLayerParameters_v1250(phyLayerParameters_v1250);
    value.set_phyLayerParameters_v1250(phyLayerParameters_v1250);

    /* Setting 'measParameters_v1250' field of 'supportedBandCombinationAdd_v1250' field of 'fdd_Add_UE_EUTRA_Capabilities_v1250' field of 'nonCriticalExtension' field... */
    MeasParameters_v1250 measParameters_v1250;
    fill_MeasParameters_v1250(measParameters_v1250);
    value.set_measParameters_v1250(measParameters_v1250);
}

static void fill_SupportedBandInfo_r12(SupportedBandInfo_r12 & value)
{
    value.set_support_r12(support_r12_supported);
}

static void fill_IntraBandContiguousCC_Info_r12(IntraBandContiguousCC_Info_r12 & value)
{
    value.set_fourLayerTM3_TM4_perCC_r12(fourLayerTM3_TM4_perCC_r12_supported);
    value.set_supportedMIMO_CapabilityDL_r12(MIMO_CapabilityDL_r10_twoLayers);
    value.set_supportedCSI_Proc_r12(supportedCSI_Proc_r12_n1);
}

static void fill_CA_MIMO_ParametersDL_v1270(CA_MIMO_ParametersDL_v1270 & value)
{
    /* Setting 'intraBandContiguousCC_InfoList_r12' field */
    CA_MIMO_ParametersDL_v1270::intraBandContiguousCC_InfoList_r12 intraBandContiguousCC_InfoList_r12;
    {
	/* Adding component #2 */
	IntraBandContiguousCC_Info_r12 comp2;
	fill_IntraBandContiguousCC_Info_r12(comp2);
	intraBandContiguousCC_InfoList_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	IntraBandContiguousCC_Info_r12 comp1;
	fill_IntraBandContiguousCC_Info_r12(comp1);
	intraBandContiguousCC_InfoList_r12.prepend(comp1);
    }
    value.set_intraBandContiguousCC_InfoList_r12(intraBandContiguousCC_InfoList_r12);
}

static void fill_BandParameters_v1270(BandParameters_v1270 & value)
{
    /* Setting 'bandParametersDL_v1270' field */
    BandParameters_v1270::bandParametersDL_v1270 bandParametersDL_v1270;
    {
	/* Adding component #2 */
	CA_MIMO_ParametersDL_v1270 comp2;
	fill_CA_MIMO_ParametersDL_v1270(comp2);
	bandParametersDL_v1270.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CA_MIMO_ParametersDL_v1270 comp1;
	fill_CA_MIMO_ParametersDL_v1270(comp1);
	bandParametersDL_v1270.prepend(comp1);
    }
    value.set_bandParametersDL_v1270(bandParametersDL_v1270);
}

static void fill_BandCombinationParameters_v1270(BandCombinationParameters_v1270 & value)
{
    /* Setting 'bandParameterList_v1270' field */
    BandCombinationParameters_v1270::bandParameterList_v1270 bandParameterList_v1270;
    {
	/* Adding component #2 */
	BandParameters_v1270 comp2;
	fill_BandParameters_v1270(comp2);
	bandParameterList_v1270.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1270 comp1;
	fill_BandParameters_v1270(comp1);
	bandParameterList_v1270.prepend(comp1);
    }
    value.set_bandParameterList_v1270(bandParameterList_v1270);
}

static void fill_SupportedBandCombination_v1270(SupportedBandCombination_v1270 & value)
{
    {
	/* Adding component #2 */
	BandCombinationParameters_v1270 comp2;
	fill_BandCombinationParameters_v1270(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1270 comp1;
	fill_BandCombinationParameters_v1270(comp1);
	value.prepend(comp1);
    }
}

static void fill_PhyLayerParameters_v1310(PhyLayerParameters_v1310 & value)
{
    /* Setting 'aperiodicCSI_Reporting_r13' field */
    static unsigned char aperiodicCSI_Reporting_r13_value[] = {
	0x00
    };
    OssBitString aperiodicCSI_Reporting_r13(2, aperiodicCSI_Reporting_r13_value);
    value.set_aperiodicCSI_Reporting_r13(aperiodicCSI_Reporting_r13);

    /* Setting 'codebook_HARQ_ACK_r13' field */
    static unsigned char codebook_HARQ_ACK_r13_value[] = {
	0x00
    };
    OssBitString codebook_HARQ_ACK_r13(2, codebook_HARQ_ACK_r13_value);
    value.set_codebook_HARQ_ACK_r13(codebook_HARQ_ACK_r13);

    value.set_crossCarrierScheduling_B5C_r13(crossCarrierScheduling_B5C_r13_supported);
    value.set_fdd_HARQ_TimingTDD_r13(fdd_HARQ_TimingTDD_r13_supported);
    value.set_maxNumberUpdatedCSI_Proc_r13(5);
    value.set_pucch_Format4_r13(pucch_Format4_r13_supported);
    value.set_pucch_Format5_r13(pucch_Format5_r13_supported);
    value.set_pucch_SCell_r13(pucch_SCell_r13_supported);
    value.set_spatialBundling_HARQ_ACK_r13(spatialBundling_HARQ_ACK_r13_supported);
    /* Setting 'supportedBlindDecoding_r13' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1310::supportedBlindDecoding_r13 supportedBlindDecoding_r13(1, pdcch_CandidateReductions_r13_supported, skipMonitoringDCI_Format0_1A_r13_supported);

    value.set_supportedBlindDecoding_r13(supportedBlindDecoding_r13);

    value.set_uci_PUSCH_Ext_r13(uci_PUSCH_Ext_r13_supported);
    value.set_crs_InterfMitigationTM10_r13(crs_InterfMitigationTM10_r13_supported);
    value.set_pdsch_CollisionHandling_r13(pdsch_CollisionHandling_r13_supported);
}

static void fill_SupportedBandEUTRA_v1310(SupportedBandEUTRA_v1310 & value)
{
    value.set_ue_PowerClass_5_r13(ue_PowerClass_5_r13_supported);
}

static void fill_BandParameters_r13(BandParameters_r13 & value)
{
    value.set_bandEUTRA_r13(1);
    /* Setting 'bandParametersUL_r13' field */
    BandParametersUL_r13 bandParametersUL_r13;
    fill_CA_MIMO_ParametersUL_r10(bandParametersUL_r13);
    value.set_bandParametersUL_r13(bandParametersUL_r13);

    /* Setting 'bandParametersDL_r13' field */
    /* Creating 'intraBandContiguousCC_InfoList_r13' field of 'bandParametersDL_r13' field */
    BandParametersDL_r13::intraBandContiguousCC_InfoList_r13 intraBandContiguousCC_InfoList_r13;
    {
	/* Adding component #2 */
	IntraBandContiguousCC_Info_r12 comp2;
	fill_IntraBandContiguousCC_Info_r12(comp2);
	intraBandContiguousCC_InfoList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	IntraBandContiguousCC_Info_r12 comp1;
	fill_IntraBandContiguousCC_Info_r12(comp1);
	intraBandContiguousCC_InfoList_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    BandParametersDL_r13 bandParametersDL_r13(CA_BandwidthClass_r10_a, MIMO_CapabilityDL_r10_twoLayers, fourLayerTM3_TM4_r13_supported, intraBandContiguousCC_InfoList_r13);

    value.set_bandParametersDL_r13(bandParametersDL_r13);

    value.set_supportedCSI_Proc_r13(supportedCSI_Proc_r13_n1);
}

static void fill_BandCombinationParameters_r13(BandCombinationParameters_r13 & value)
{
    value.set_differentFallbackSupported_r13(differentFallbackSupported_r13_true);
    /* Setting 'bandParameterList_r13' field */
    BandCombinationParameters_r13::bandParameterList_r13 bandParameterList_r13;
    {
	/* Adding component #2 */
	BandParameters_r13 comp2;
	fill_BandParameters_r13(comp2);
	bandParameterList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_r13 comp1;
	fill_BandParameters_r13(comp1);
	bandParameterList_r13.prepend(comp1);
    }
    value.set_bandParameterList_r13(bandParameterList_r13);

    /* Setting 'supportedBandwidthCombinationSet_r13' field */
    static unsigned char supportedBandwidthCombinationSet_r13_value[] = {
	0x00
    };
    OssBitString supportedBandwidthCombinationSet_r13(1, supportedBandwidthCombinationSet_r13_value);
    value.set_supportedBandwidthCombinationSet_r13(supportedBandwidthCombinationSet_r13);

    value.set_multipleTimingAdvance_r13(multipleTimingAdvance_r13_supported);
    value.set_simultaneousRx_Tx_r13(simultaneousRx_Tx_r13_supported);
    /* Setting 'bandInfoEUTRA_r13' field */
    BandInfoEUTRA bandInfoEUTRA_r13;
    fill_BandInfoEUTRA(bandInfoEUTRA_r13);
    value.set_bandInfoEUTRA_r13(bandInfoEUTRA_r13);

    /* Setting 'dc_Support_r13' field */
    /* Creating 'supportedCellGrouping_r13' field of 'dc_Support_r13' field */
    BandCombinationParameters_r13::dc_Support_r13::supportedCellGrouping_r13 supportedCellGrouping_r13;
    /* Setting 'threeEntries_r13' alternative of 'supportedCellGrouping_r13' field of 'dc_Support_r13' field */
    static unsigned char threeEntries_r13_value[] = {
	0x00
    };
    OssBitString threeEntries_r13(3, threeEntries_r13_value);
    supportedCellGrouping_r13.set_threeEntries_r13(threeEntries_r13);

    /* Calling a fully-initializing constructor */
    BandCombinationParameters_r13::dc_Support_r13 dc_Support_r13(asynchronous_r13_supported, supportedCellGrouping_r13);

    value.set_dc_Support_r13(dc_Support_r13);

    /* Setting 'supportedNAICS_2CRS_AP_r13' field */
    static unsigned char supportedNAICS_2CRS_AP_r13_value[] = {
	0x00
    };
    OssBitString supportedNAICS_2CRS_AP_r13(1, supportedNAICS_2CRS_AP_r13_value);
    value.set_supportedNAICS_2CRS_AP_r13(supportedNAICS_2CRS_AP_r13);

    /* Setting 'commSupportedBandsPerBC_r13' field */
    static unsigned char commSupportedBandsPerBC_r13_value[] = {
	0x00
    };
    OssBitString commSupportedBandsPerBC_r13(1, commSupportedBandsPerBC_r13_value);
    value.set_commSupportedBandsPerBC_r13(commSupportedBandsPerBC_r13);
}

static void fill_SCPTM_Parameters_r13(SCPTM_Parameters_r13 & value)
{
    value.set_scptm_ParallelReception_r13(scptm_ParallelReception_r13_supported);
    value.set_scptm_SCell_r13(scptm_SCell_r13_supported);
    value.set_scptm_NonServingCell_r13(scptm_NonServingCell_r13_supported);
    value.set_scptm_AsyncDC_r13(scptm_AsyncDC_r13_supported);
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1310(UE_EUTRA_CapabilityAddXDD_Mode_v1310 & value)
{
    /* Setting 'phyLayerParameters_v1310' field of 'wlan_MAC_Address_r13' field of 'fdd_Add_UE_EUTRA_Capabilities_v1310' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1310 phyLayerParameters_v1310;
    fill_PhyLayerParameters_v1310(phyLayerParameters_v1310);
    value.set_phyLayerParameters_v1310(phyLayerParameters_v1310);
}

static void fill_MIMO_NonPrecodedCapabilities_r13(MIMO_NonPrecodedCapabilities_r13 & value)
{
    value.set_config1_r13(config1_r13_supported);
    value.set_config2_r13(config2_r13_supported);
    value.set_config3_r13(config3_r13_supported);
    value.set_config4_r13(config4_r13_supported);
}

static void fill_MIMO_BeamformedCapabilities_r13(MIMO_BeamformedCapabilities_r13 & value)
{
    value.set_k_Max_r13(1);
    /* Setting 'n_MaxList_r13' field */
    static unsigned char n_MaxList_r13_value[] = {
	0x00
    };
    OssBitString n_MaxList_r13(1, n_MaxList_r13_value);
    value.set_n_MaxList_r13(n_MaxList_r13);
}

static void fill_MIMO_BeamformedCapabilityList_r13(MIMO_BeamformedCapabilityList_r13 & value)
{
    {
	/* Adding component #2 */
	MIMO_BeamformedCapabilities_r13 comp2;
	fill_MIMO_BeamformedCapabilities_r13(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MIMO_BeamformedCapabilities_r13 comp1;
	fill_MIMO_BeamformedCapabilities_r13(comp1);
	value.prepend(comp1);
    }
}

static void fill_MIMO_UE_ParametersPerTM_r13(MIMO_UE_ParametersPerTM_r13 & value)
{
    /* Setting 'nonPrecoded_r13' field */
    MIMO_NonPrecodedCapabilities_r13 nonPrecoded_r13;
    fill_MIMO_NonPrecodedCapabilities_r13(nonPrecoded_r13);
    value.set_nonPrecoded_r13(nonPrecoded_r13);

    /* Setting 'beamformed_r13' field */
    /* Creating 'mimo_BeamformedCapabilities_r13' field of 'beamformed_r13' field */
    MIMO_BeamformedCapabilityList_r13 mimo_BeamformedCapabilities_r13;
    fill_MIMO_BeamformedCapabilityList_r13(mimo_BeamformedCapabilities_r13);

    /* Calling a fully-initializing constructor */
    MIMO_UE_BeamformedCapabilities_r13 beamformed_r13(altCodebook_r13_supported, mimo_BeamformedCapabilities_r13);

    value.set_beamformed_r13(beamformed_r13);

    value.set_channelMeasRestriction_r13(channelMeasRestriction_r13_supported);
    value.set_dmrs_Enhancements_r13(dmrs_Enhancements_r13_supported);
    value.set_csi_RS_EnhancementsTDD_r13(csi_RS_EnhancementsTDD_r13_supported);
}

static void fill_MIMO_UE_Parameters_r13(MIMO_UE_Parameters_r13 & value)
{
    /* Setting 'parametersTM9_r13' field */
    MIMO_UE_ParametersPerTM_r13 parametersTM9_r13;
    fill_MIMO_UE_ParametersPerTM_r13(parametersTM9_r13);
    value.set_parametersTM9_r13(parametersTM9_r13);

    /* Setting 'parametersTM10_r13' field */
    MIMO_UE_ParametersPerTM_r13 parametersTM10_r13;
    fill_MIMO_UE_ParametersPerTM_r13(parametersTM10_r13);
    value.set_parametersTM10_r13(parametersTM10_r13);

    value.set_srs_EnhancementsTDD_r13(srs_EnhancementsTDD_r13_supported);
    value.set_srs_Enhancements_r13(srs_Enhancements_r13_supported);
    value.set_interferenceMeasRestriction_r13(interferenceMeasRestriction_r13_supported);
}

static void fill_PhyLayerParameters_v1320(PhyLayerParameters_v1320 & value)
{
    /* Setting 'mimo_UE_Parameters_r13' field */
    MIMO_UE_Parameters_r13 mimo_UE_Parameters_r13;
    fill_MIMO_UE_Parameters_r13(mimo_UE_Parameters_r13);
    value.set_mimo_UE_Parameters_r13(mimo_UE_Parameters_r13);
}

static void fill_SupportedBandEUTRA_v1320(SupportedBandEUTRA_v1320 & value)
{
    value.set_intraFreq_CE_NeedForGaps_r13(intraFreq_CE_NeedForGaps_r13_supported);
    value.set_ue_PowerClass_N_r13(class1);
}

static void fill_MIMO_CA_ParametersPerBoBCPerTM_r13(MIMO_CA_ParametersPerBoBCPerTM_r13 & value)
{
    /* Setting 'nonPrecoded_r13' field */
    MIMO_NonPrecodedCapabilities_r13 nonPrecoded_r13;
    fill_MIMO_NonPrecodedCapabilities_r13(nonPrecoded_r13);
    value.set_nonPrecoded_r13(nonPrecoded_r13);

    /* Setting 'beamformed_r13' field */
    MIMO_BeamformedCapabilityList_r13 beamformed_r13;
    fill_MIMO_BeamformedCapabilityList_r13(beamformed_r13);
    value.set_beamformed_r13(beamformed_r13);

    value.set_dmrs_Enhancements_r13(MIMO_CA_ParametersPerBoBCPerTM_r13_dmrs_Enhancements_r13_different);
}

static void fill_MIMO_CA_ParametersPerBoBC_r13(MIMO_CA_ParametersPerBoBC_r13 & value)
{
    /* Setting 'parametersTM9_r13' field */
    MIMO_CA_ParametersPerBoBCPerTM_r13 parametersTM9_r13;
    fill_MIMO_CA_ParametersPerBoBCPerTM_r13(parametersTM9_r13);
    value.set_parametersTM9_r13(parametersTM9_r13);

    /* Setting 'parametersTM10_r13' field */
    MIMO_CA_ParametersPerBoBCPerTM_r13 parametersTM10_r13;
    fill_MIMO_CA_ParametersPerBoBCPerTM_r13(parametersTM10_r13);
    value.set_parametersTM10_r13(parametersTM10_r13);
}

static void fill_BandParameters_v1320(BandParameters_v1320 & value)
{
    /* Setting 'bandParametersDL_v1320' field */
    MIMO_CA_ParametersPerBoBC_r13 bandParametersDL_v1320;
    fill_MIMO_CA_ParametersPerBoBC_r13(bandParametersDL_v1320);
    value.set_bandParametersDL_v1320(bandParametersDL_v1320);
}

static void fill_BandCombinationParameters_v1320(BandCombinationParameters_v1320 & value)
{
    /* Setting 'bandParameterList_v1320' field */
    BandCombinationParameters_v1320::bandParameterList_v1320 bandParameterList_v1320;
    {
	/* Adding component #2 */
	BandParameters_v1320 comp2;
	fill_BandParameters_v1320(comp2);
	bandParameterList_v1320.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1320 comp1;
	fill_BandParameters_v1320(comp1);
	bandParameterList_v1320.prepend(comp1);
    }
    value.set_bandParameterList_v1320(bandParameterList_v1320);

    value.set_additionalRx_Tx_PerformanceReq_r13(additionalRx_Tx_PerformanceReq_r13_supported);
}

static void fill_SupportedBandCombination_v1320(SupportedBandCombination_v1320 & value)
{
    {
	/* Adding component #2 */
	BandCombinationParameters_v1320 comp2;
	fill_BandCombinationParameters_v1320(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1320 comp1;
	fill_BandCombinationParameters_v1320(comp1);
	value.prepend(comp1);
    }
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1320(UE_EUTRA_CapabilityAddXDD_Mode_v1320 & value)
{
    /* Setting 'phyLayerParameters_v1320' field of 'supportedBandCombinationReduced_v1320' field of 'fdd_Add_UE_EUTRA_Capabilities_v1320' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1320 phyLayerParameters_v1320;
    fill_PhyLayerParameters_v1320(phyLayerParameters_v1320);
    value.set_phyLayerParameters_v1320(phyLayerParameters_v1320);

    /* Setting 'scptm_Parameters_r13' field of 'supportedBandCombinationReduced_v1320' field of 'fdd_Add_UE_EUTRA_Capabilities_v1320' field of 'nonCriticalExtension' field... */
    SCPTM_Parameters_r13 scptm_Parameters_r13;
    fill_SCPTM_Parameters_r13(scptm_Parameters_r13);
    value.set_scptm_Parameters_r13(scptm_Parameters_r13);
}

static void fill_MIMO_UE_ParametersPerTM_v1430(MIMO_UE_ParametersPerTM_v1430 & value)
{
    /* Setting 'nzp_CSI_RS_AperiodicInfo_r14' field */

    /* Calling a fully-initializing constructor */
    MIMO_UE_ParametersPerTM_v1430::nzp_CSI_RS_AperiodicInfo_r14 nzp_CSI_RS_AperiodicInfo_r14(5, nzp_CSI_RS_AperiodicInfo_r14_nMaxResource_r14_ffs1);

    value.set_nzp_CSI_RS_AperiodicInfo_r14(nzp_CSI_RS_AperiodicInfo_r14);

    /* Setting 'nzp_CSI_RS_PeriodicInfo_r14' field */

    /* Calling a fully-initializing constructor */
    MIMO_UE_ParametersPerTM_v1430::nzp_CSI_RS_PeriodicInfo_r14 nzp_CSI_RS_PeriodicInfo_r14(nzp_CSI_RS_PeriodicInfo_r14_nMaxResource_r14_ffs1);

    value.set_nzp_CSI_RS_PeriodicInfo_r14(nzp_CSI_RS_PeriodicInfo_r14);

    value.set_zp_CSI_RS_AperiodicInfo_r14(zp_CSI_RS_AperiodicInfo_r14_supported);
    value.set_ul_dmrs_Enhancements_r14(ul_dmrs_Enhancements_r14_supported);
    value.set_densityReductionNP_r14(densityReductionNP_r14_supported);
    value.set_densityReductionBF_r14(densityReductionBF_r14_supported);
    value.set_hybridCSI_r14(hybridCSI_r14_supported);
    value.set_semiOL_r14(semiOL_r14_supported);
    value.set_csi_ReportingNP_r14(csi_ReportingNP_r14_supported);
    value.set_csi_ReportingAdvanced_r14(csi_ReportingAdvanced_r14_supported);
}

static void fill_MIMO_UE_Parameters_v1430(MIMO_UE_Parameters_v1430 & value)
{
    /* Setting 'parametersTM9_v1430' field */
    MIMO_UE_ParametersPerTM_v1430 parametersTM9_v1430;
    fill_MIMO_UE_ParametersPerTM_v1430(parametersTM9_v1430);
    value.set_parametersTM9_v1430(parametersTM9_v1430);

    /* Setting 'parametersTM10_v1430' field */
    MIMO_UE_ParametersPerTM_v1430 parametersTM10_v1430;
    fill_MIMO_UE_ParametersPerTM_v1430(parametersTM10_v1430);
    value.set_parametersTM10_v1430(parametersTM10_v1430);
}

static void fill_PhyLayerParameters_v1430(PhyLayerParameters_v1430 & value)
{
    value.set_ce_PUSCH_NB_MaxTBS_r14(ce_PUSCH_NB_MaxTBS_r14_supported);
    value.set_ce_PDSCH_PUSCH_MaxBandwidth_r14(ce_PDSCH_PUSCH_MaxBandwidth_r14_bw5);
    value.set_ce_HARQ_AckBundling_r14(ce_HARQ_AckBundling_r14_supported);
    value.set_ce_PDSCH_TenProcesses_r14(ce_PDSCH_TenProcesses_r14_supported);
    value.set_ce_RetuningSymbols_r14(ce_RetuningSymbols_r14_n0);
    value.set_ce_PDSCH_PUSCH_Enhancement_r14(ce_PDSCH_PUSCH_Enhancement_r14_supported);
    value.set_ce_SchedulingEnhancement_r14(ce_SchedulingEnhancement_r14_supported);
    value.set_ce_SRS_Enhancement_r14(ce_SRS_Enhancement_r14_supported);
    value.set_ce_PUCCH_Enhancement_r14(ce_PUCCH_Enhancement_r14_supported);
    value.set_ce_ClosedLoopTxAntennaSelection_r14(ce_ClosedLoopTxAntennaSelection_r14_supported);
    value.set_tdd_SpecialSubframe_r14(tdd_SpecialSubframe_r14_supported);
    value.set_tdd_TTI_Bundling_r14(tdd_TTI_Bundling_r14_supported);
    value.set_dmrs_LessUpPTS_r14(dmrs_LessUpPTS_r14_supported);
    /* Setting 'mimo_UE_Parameters_v1430' field */
    MIMO_UE_Parameters_v1430 mimo_UE_Parameters_v1430;
    fill_MIMO_UE_Parameters_v1430(mimo_UE_Parameters_v1430);
    value.set_mimo_UE_Parameters_v1430(mimo_UE_Parameters_v1430);

    value.set_alternativeTBS_Index_r14(alternativeTBS_Index_r14_supported);
    /* Setting 'feMBMS_Unicast_Parameters_r14' field */

    /* Calling a fully-initializing constructor */
    FeMBMS_Unicast_Parameters_r14 feMBMS_Unicast_Parameters_r14(unicast_fembmsMixedSCell_r14_supported, emptyUnicastRegion_r14_supported);

    value.set_feMBMS_Unicast_Parameters_r14(feMBMS_Unicast_Parameters_r14);
}

static void fill_MIMO_CA_ParametersPerBoBCPerTM_v1430(MIMO_CA_ParametersPerBoBCPerTM_v1430 & value)
{
    value.set_csi_ReportingNP_r14(MIMO_CA_ParametersPerBoBCPerTM_v1430_csi_ReportingNP_r14_different);
    value.set_csi_ReportingAdvanced_r14(MIMO_CA_ParametersPerBoBCPerTM_v1430_csi_ReportingAdvanced_r14_different);
}

static void fill_MIMO_CA_ParametersPerBoBC_v1430(MIMO_CA_ParametersPerBoBC_v1430 & value)
{
    /* Setting 'parametersTM9_v1430' field */
    MIMO_CA_ParametersPerBoBCPerTM_v1430 parametersTM9_v1430;
    fill_MIMO_CA_ParametersPerBoBCPerTM_v1430(parametersTM9_v1430);
    value.set_parametersTM9_v1430(parametersTM9_v1430);

    /* Setting 'parametersTM10_v1430' field */
    MIMO_CA_ParametersPerBoBCPerTM_v1430 parametersTM10_v1430;
    fill_MIMO_CA_ParametersPerBoBCPerTM_v1430(parametersTM10_v1430);
    value.set_parametersTM10_v1430(parametersTM10_v1430);
}

static void fill_UL_256QAM_perCC_Info_r14(UL_256QAM_perCC_Info_r14 & value)
{
    value.set_ul_256QAM_perCC_r14(ul_256QAM_perCC_r14_supported);
}

static void fill_RetuningTimeInfo_r14(RetuningTimeInfo_r14 & value)
{
    /* Setting 'retuningInfo' field */

    /* Calling a fully-initializing constructor */
    RetuningTimeInfo_r14::retuningInfo retuningInfo(rf_RetuningTimeDL_r14_n0, rf_RetuningTimeUL_r14_n0);

    value.set_retuningInfo(retuningInfo);
}

static void fill_BandParameters_v1430(BandParameters_v1430 & value)
{
    /* Setting 'bandParametersDL_v1430' field */
    MIMO_CA_ParametersPerBoBC_v1430 bandParametersDL_v1430;
    fill_MIMO_CA_ParametersPerBoBC_v1430(bandParametersDL_v1430);
    value.set_bandParametersDL_v1430(bandParametersDL_v1430);

    value.set_ul_256QAM_r14(ul_256QAM_r14_supported);
    /* Setting 'ul_256QAM_perCC_InfoList_r14' field */
    BandParameters_v1430::ul_256QAM_perCC_InfoList_r14 ul_256QAM_perCC_InfoList_r14;
    {
	/* Adding component #2 */
	UL_256QAM_perCC_Info_r14 comp2;
	fill_UL_256QAM_perCC_Info_r14(comp2);
	ul_256QAM_perCC_InfoList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	UL_256QAM_perCC_Info_r14 comp1;
	fill_UL_256QAM_perCC_Info_r14(comp1);
	ul_256QAM_perCC_InfoList_r14.prepend(comp1);
    }
    value.set_ul_256QAM_perCC_InfoList_r14(ul_256QAM_perCC_InfoList_r14);

    /* Setting 'retuningTimeInfoBandList_r14' field */
    BandParameters_v1430::retuningTimeInfoBandList_r14 retuningTimeInfoBandList_r14;
    {
	/* Adding component #2 */
	RetuningTimeInfo_r14 comp2;
	fill_RetuningTimeInfo_r14(comp2);
	retuningTimeInfoBandList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	RetuningTimeInfo_r14 comp1;
	fill_RetuningTimeInfo_r14(comp1);
	retuningTimeInfoBandList_r14.prepend(comp1);
    }
    value.set_retuningTimeInfoBandList_r14(retuningTimeInfoBandList_r14);
}

static void fill_BandCombinationParameters_v1430(BandCombinationParameters_v1430 & value)
{
    /* Setting 'bandParameterList_v1430' field */
    BandCombinationParameters_v1430::bandParameterList_v1430 bandParameterList_v1430;
    {
	/* Adding component #2 */
	BandParameters_v1430 comp2;
	fill_BandParameters_v1430(comp2);
	bandParameterList_v1430.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1430 comp1;
	fill_BandParameters_v1430(comp1);
	bandParameterList_v1430.prepend(comp1);
    }
    value.set_bandParameterList_v1430(bandParameterList_v1430);

    /* Setting 'v2x_SupportedTxBandCombListPerBC_r14' field */
    static unsigned char v2x_SupportedTxBandCombListPerBC_r14_value[] = {
	0x00
    };
    OssBitString v2x_SupportedTxBandCombListPerBC_r14(1, v2x_SupportedTxBandCombListPerBC_r14_value);
    value.set_v2x_SupportedTxBandCombListPerBC_r14(v2x_SupportedTxBandCombListPerBC_r14);

    /* Setting 'v2x_SupportedRxBandCombListPerBC_r14' field */
    static unsigned char v2x_SupportedRxBandCombListPerBC_r14_value[] = {
	0x00
    };
    OssBitString v2x_SupportedRxBandCombListPerBC_r14(1, v2x_SupportedRxBandCombListPerBC_r14_value);
    value.set_v2x_SupportedRxBandCombListPerBC_r14(v2x_SupportedRxBandCombListPerBC_r14);
}

static void fill_SupportedBandCombination_v1430(SupportedBandCombination_v1430 & value)
{
    {
	/* Adding component #2 */
	BandCombinationParameters_v1430 comp2;
	fill_BandCombinationParameters_v1430(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1430 comp1;
	fill_BandCombinationParameters_v1430(comp1);
	value.prepend(comp1);
    }
}

static void fill_BandIndication_r14(BandIndication_r14 & value)
{
    value.set_bandEUTRA_r14(1);
    value.set_ca_BandwidthClassDL_r14(CA_BandwidthClass_r10_a);
    value.set_ca_BandwidthClassUL_r14(CA_BandwidthClass_r10_a);
}

static void fill_BandCombination_r14(BandCombination_r14 & value)
{
    {
	/* Adding component #2 */
	BandIndication_r14 comp2;
	fill_BandIndication_r14(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandIndication_r14 comp1;
	fill_BandIndication_r14(comp1);
	value.prepend(comp1);
    }
}

static void fill_MMTEL_Parameters_r14(MMTEL_Parameters_r14 & value)
{
    value.set_delayBudgetReporting_r14(delayBudgetReporting_r14_supported);
    value.set_pusch_Enhancements_r14(pusch_Enhancements_r14_supported);
    value.set_recommendedBitRate_r14(recommendedBitRate_r14_supported);
    value.set_recommendedBitRateQuery_r14(recommendedBitRateQuery_r14_supported);
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1430(UE_EUTRA_CapabilityAddXDD_Mode_v1430 & value)
{
    /* Setting 'phyLayerParameters_v1430' field of 'eNB_RequestedParameters_v1430' field of 'fdd_Add_UE_EUTRA_Capabilities_v1430' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1430 phyLayerParameters_v1430;
    fill_PhyLayerParameters_v1430(phyLayerParameters_v1430);
    value.set_phyLayerParameters_v1430(phyLayerParameters_v1430);

    /* Setting 'mmtel_Parameters_r14' field of 'eNB_RequestedParameters_v1430' field of 'fdd_Add_UE_EUTRA_Capabilities_v1430' field of 'nonCriticalExtension' field... */
    MMTEL_Parameters_r14 mmtel_Parameters_r14;
    fill_MMTEL_Parameters_r14(mmtel_Parameters_r14);
    value.set_mmtel_Parameters_r14(mmtel_Parameters_r14);
}

static void fill_V2X_BandwidthClassSL_r14(V2X_BandwidthClassSL_r14 & value)
{
    value.prepend(V2X_BandwidthClass_r14_a);
    value.prepend(V2X_BandwidthClass_r14_a);
}

static void fill_V2X_BandParameters_r14(V2X_BandParameters_r14 & value)
{
    value.set_v2x_FreqBandEUTRA_r14(1);
    /* Setting 'bandParametersTxSL_r14' field */
    /* Creating 'v2x_BandwidthClassTxSL_r14' field of 'bandParametersTxSL_r14' field */
    V2X_BandwidthClassSL_r14 v2x_BandwidthClassTxSL_r14;
    fill_V2X_BandwidthClassSL_r14(v2x_BandwidthClassTxSL_r14);

    /* Calling a fully-initializing constructor */
    BandParametersTxSL_r14 bandParametersTxSL_r14(v2x_BandwidthClassTxSL_r14, v2x_eNB_Scheduled_r14_supported, v2x_HighPower_r14_supported);

    value.set_bandParametersTxSL_r14(bandParametersTxSL_r14);

    /* Setting 'bandParametersRxSL_r14' field */
    /* Creating 'v2x_BandwidthClassRxSL_r14' field of 'bandParametersRxSL_r14' field */
    V2X_BandwidthClassSL_r14 v2x_BandwidthClassRxSL_r14;
    fill_V2X_BandwidthClassSL_r14(v2x_BandwidthClassRxSL_r14);

    /* Calling a fully-initializing constructor */
    BandParametersRxSL_r14 bandParametersRxSL_r14(v2x_BandwidthClassRxSL_r14, v2x_HighReception_r14_supported);

    value.set_bandParametersRxSL_r14(bandParametersRxSL_r14);
}

static void fill_V2X_BandCombinationParameters_r14(V2X_BandCombinationParameters_r14 & value)
{
    {
	/* Adding component #2 */
	V2X_BandParameters_r14 comp2;
	fill_V2X_BandParameters_r14(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	V2X_BandParameters_r14 comp1;
	fill_V2X_BandParameters_r14(comp1);
	value.prepend(comp1);
    }
}

static void fill_BandParameters_v1450(BandParameters_v1450 & value)
{
    /* Setting 'must_CapabilityPerBand_r14' field */

    /* Calling a fully-initializing constructor */
    MUST_Parameters_r14 must_CapabilityPerBand_r14(must_TM234_UpTo2Tx_r14_supported, must_TM89_UpToOneInterferingLayer_r14_supported, must_TM10_UpToOneInterferingLayer_r14_supported, must_TM89_UpToThreeInterferingLayers_r14_supported, must_TM10_UpToThreeInterferingLayers_r14_supported);

    value.set_must_CapabilityPerBand_r14(must_CapabilityPerBand_r14);
}

static void fill_BandCombinationParameters_v1450(BandCombinationParameters_v1450 & value)
{
    /* Setting 'bandParameterList_v1450' field */
    BandCombinationParameters_v1450::bandParameterList_v1450 bandParameterList_v1450;
    {
	/* Adding component #2 */
	BandParameters_v1450 comp2;
	fill_BandParameters_v1450(comp2);
	bandParameterList_v1450.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1450 comp1;
	fill_BandParameters_v1450(comp1);
	bandParameterList_v1450.prepend(comp1);
    }
    value.set_bandParameterList_v1450(bandParameterList_v1450);
}

static void fill_SupportedBandCombination_v1450(SupportedBandCombination_v1450 & value)
{
    {
	/* Adding component #2 */
	BandCombinationParameters_v1450 comp2;
	fill_BandCombinationParameters_v1450(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1450 comp1;
	fill_BandCombinationParameters_v1450(comp1);
	value.prepend(comp1);
    }
}

static void fill_SupportedBandNR_r15(SupportedBandNR_r15 & value)
{
    value.set_bandNR_r15(1);
}

static void fill_MIMO_CA_ParametersPerBoBCPerTM_r15(MIMO_CA_ParametersPerBoBCPerTM_r15 & value)
{
    /* Setting 'nonPrecoded_r13' field */
    MIMO_NonPrecodedCapabilities_r13 nonPrecoded_r13;
    fill_MIMO_NonPrecodedCapabilities_r13(nonPrecoded_r13);
    value.set_nonPrecoded_r13(nonPrecoded_r13);

    /* Setting 'beamformed_r13' field */
    MIMO_BeamformedCapabilityList_r13 beamformed_r13;
    fill_MIMO_BeamformedCapabilityList_r13(beamformed_r13);
    value.set_beamformed_r13(beamformed_r13);

    value.set_dmrs_Enhancements_r13(MIMO_CA_ParametersPerBoBCPerTM_r15_dmrs_Enhancements_r13_different);
    value.set_csi_ReportingNP_r14(MIMO_CA_ParametersPerBoBCPerTM_r15_csi_ReportingNP_r14_different);
    value.set_csi_ReportingAdvanced_r14(MIMO_CA_ParametersPerBoBCPerTM_r15_csi_ReportingAdvanced_r14_different);
}

static void fill_FeatureSetDL_r15(FeatureSetDL_r15 & value)
{
    /* Setting 'mimo_CA_ParametersPerBoBC_r15' field */
    /* Creating 'parametersTM9_r15' field of 'mimo_CA_ParametersPerBoBC_r15' field */
    MIMO_CA_ParametersPerBoBCPerTM_r15 parametersTM9_r15;
    fill_MIMO_CA_ParametersPerBoBCPerTM_r15(parametersTM9_r15);

    /* Creating 'parametersTM10_r15' field of 'mimo_CA_ParametersPerBoBC_r15' field */
    MIMO_CA_ParametersPerBoBCPerTM_r15 parametersTM10_r15;
    fill_MIMO_CA_ParametersPerBoBCPerTM_r15(parametersTM10_r15);

    /* Calling a fully-initializing constructor */
    MIMO_CA_ParametersPerBoBC_r15 mimo_CA_ParametersPerBoBC_r15(parametersTM9_r15, parametersTM10_r15);

    value.set_mimo_CA_ParametersPerBoBC_r15(mimo_CA_ParametersPerBoBC_r15);

    /* Setting 'featureSetPerCC_ListDL_r15' field */
    FeatureSetDL_r15::featureSetPerCC_ListDL_r15 featureSetPerCC_ListDL_r15;
    featureSetPerCC_ListDL_r15.prepend((OSS_UINT32)0);
    featureSetPerCC_ListDL_r15.prepend((OSS_UINT32)0);
    value.set_featureSetPerCC_ListDL_r15(featureSetPerCC_ListDL_r15);
}

static void fill_FeatureSetDL_PerCC_r15(FeatureSetDL_PerCC_r15 & value)
{
    value.set_fourLayerTM3_TM4_r15(FeatureSetDL_PerCC_r15_fourLayerTM3_TM4_r15_supported);
    value.set_supportedMIMO_CapabilityDL_r15(MIMO_CapabilityDL_r10_twoLayers);
    value.set_supportedCSI_Proc_r15(supportedCSI_Proc_r15_n1);
}

static void fill_FeatureSetUL_r15(FeatureSetUL_r15 & value)
{
    /* Setting 'featureSetPerCC_ListUL_r15' field */
    FeatureSetUL_r15::featureSetPerCC_ListUL_r15 featureSetPerCC_ListUL_r15;
    featureSetPerCC_ListUL_r15.prepend((OSS_UINT32)0);
    featureSetPerCC_ListUL_r15.prepend((OSS_UINT32)0);
    value.set_featureSetPerCC_ListUL_r15(featureSetPerCC_ListUL_r15);
}

static void fill_FeatureSetUL_PerCC_r15(FeatureSetUL_PerCC_r15 & value)
{
    value.set_supportedMIMO_CapabilityUL_r15(MIMO_CapabilityUL_r10_twoLayers);
    value.set_ul_256QAM_r15(ul_256QAM_r15_supported);
}

static void fill_PDCP_ParametersNR_r15(PDCP_ParametersNR_r15 & value)
{
    /* Setting 'rohc_Profiles_r15' field of 'featureSetsUL_PerCC_r15' field of 'pdcp_ParametersNR_r15' field of 'nonCriticalExtension' field... */
    ROHC_ProfileSupportList_r15 rohc_Profiles_r15;
    fill_ROHC_ProfileSupportList_r15(rohc_Profiles_r15);
    value.set_rohc_Profiles_r15(rohc_Profiles_r15);

    value.set_rohc_ContextMaxSessions_r15(rohc_ContextMaxSessions_r15_cs2);
    /* Setting 'rohc_ProfilesUL_Only_r15' field of 'featureSetsUL_PerCC_r15' field of 'pdcp_ParametersNR_r15' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PDCP_ParametersNR_r15::rohc_ProfilesUL_Only_r15 rohc_ProfilesUL_Only_r15(TRUE);

    value.set_rohc_ProfilesUL_Only_r15(rohc_ProfilesUL_Only_r15);

    value.set_rohc_ContextContinue_r15(rohc_ContextContinue_r15_supported);
    value.set_outOfOrderDelivery_r15(outOfOrderDelivery_r15_supported);
    value.set_sn_SizeLo_r15(sn_SizeLo_r15_supported);
    value.set_ims_VoiceOverNR_PDCP_MCG_Bearer_r15(ims_VoiceOverNR_PDCP_MCG_Bearer_r15_supported);
    value.set_ims_VoiceOverNR_PDCP_SCG_Bearer_r15(ims_VoiceOverNR_PDCP_SCG_Bearer_r15_supported);
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1510(UE_EUTRA_CapabilityAddXDD_Mode_v1510 & value)
{
    /* Setting 'pdcp_ParametersNR_r15' field of 'featureSetsUL_PerCC_r15' field of 'fdd_Add_UE_EUTRA_Capabilities_v1510' field of 'nonCriticalExtension' field... */
    PDCP_ParametersNR_r15 pdcp_ParametersNR_r15;
    fill_PDCP_ParametersNR_r15(pdcp_ParametersNR_r15);
    value.set_pdcp_ParametersNR_r15(pdcp_ParametersNR_r15);
}

static void fill_NeighCellSI_AcquisitionParameters_v1530(NeighCellSI_AcquisitionParameters_v1530 & value)
{
    value.set_reportCGI_NR_EN_DC_r15(reportCGI_NR_EN_DC_r15_supported);
    value.set_reportCGI_NR_NoEN_DC_r15(reportCGI_NR_NoEN_DC_r15_supported);
}

static void fill_DL_UL_CCs_r15(DL_UL_CCs_r15 & value)
{
    value.set_maxNumberDL_CCs_r15(1);
    value.set_maxNumberUL_CCs_r15(1);
}

static void fill_BandParameters_v1530(BandParameters_v1530 & value)
{
    value.set_ue_TxAntennaSelection_SRS_1T4R_r15(ue_TxAntennaSelection_SRS_1T4R_r15_supported);
    value.set_ue_TxAntennaSelection_SRS_2T4R_2Pairs_r15(ue_TxAntennaSelection_SRS_2T4R_2Pairs_r15_supported);
    value.set_ue_TxAntennaSelection_SRS_2T4R_3Pairs_r15(ue_TxAntennaSelection_SRS_2T4R_3Pairs_r15_supported);
    value.set_dl_1024QAM_r15(dl_1024QAM_r15_supported);
    value.set_qcl_TypeC_Operation_r15(qcl_TypeC_Operation_r15_supported);
    value.set_qcl_CRI_BasedCSI_Reporting_r15(qcl_CRI_BasedCSI_Reporting_r15_supported);
    /* Setting 'stti_SPT_BandParameters_r15' field */
    /* Creating 'sTTI_CA_MIMO_ParametersDL_r15' field of 'stti_SPT_BandParameters_r15' field */
    /* Creating 'intraBandContiguousCC_InfoList_r15' field of 'sTTI_CA_MIMO_ParametersDL_r15' field of 'stti_SPT_BandParameters_r15' field */
    CA_MIMO_ParametersDL_r15::intraBandContiguousCC_InfoList_r15 intraBandContiguousCC_InfoList_r15;
    {
	/* Adding component #2 */
	IntraBandContiguousCC_Info_r12 comp2;
	fill_IntraBandContiguousCC_Info_r12(comp2);
	intraBandContiguousCC_InfoList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	IntraBandContiguousCC_Info_r12 comp1;
	fill_IntraBandContiguousCC_Info_r12(comp1);
	intraBandContiguousCC_InfoList_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    CA_MIMO_ParametersDL_r15 sTTI_CA_MIMO_ParametersDL_r15(MIMO_CapabilityDL_r10_twoLayers, CA_MIMO_ParametersDL_r15_fourLayerTM3_TM4_r15_supported, intraBandContiguousCC_InfoList_r15);

    /* Creating 'sTTI_CA_MIMO_ParametersUL_r15' field of 'stti_SPT_BandParameters_r15' field */

    /* Calling a fully-initializing constructor */
    CA_MIMO_ParametersUL_r15 sTTI_CA_MIMO_ParametersUL_r15(MIMO_CapabilityUL_r10_twoLayers);

    /* Creating 'sTTI_MIMO_CA_ParametersPerBoBCs_r15' field of 'stti_SPT_BandParameters_r15' field */
    MIMO_CA_ParametersPerBoBC_r13 sTTI_MIMO_CA_ParametersPerBoBCs_r15;
    fill_MIMO_CA_ParametersPerBoBC_r13(sTTI_MIMO_CA_ParametersPerBoBCs_r15);

    /* Creating 'sTTI_MIMO_CA_ParametersPerBoBCs_v1530' field of 'stti_SPT_BandParameters_r15' field */
    MIMO_CA_ParametersPerBoBC_v1430 sTTI_MIMO_CA_ParametersPerBoBCs_v1530;
    fill_MIMO_CA_ParametersPerBoBC_v1430(sTTI_MIMO_CA_ParametersPerBoBCs_v1530);

    /* Creating 'sTTI_SupportedCombinations_r15' field of 'stti_SPT_BandParameters_r15' field */
    /* Creating 'combination_22_r15' field of 'sTTI_SupportedCombinations_r15' field of 'stti_SPT_BandParameters_r15' field */
    DL_UL_CCs_r15 combination_22_r15;
    fill_DL_UL_CCs_r15(combination_22_r15);

    /* Creating 'combination_77_r15' field of 'sTTI_SupportedCombinations_r15' field of 'stti_SPT_BandParameters_r15' field */
    DL_UL_CCs_r15 combination_77_r15;
    fill_DL_UL_CCs_r15(combination_77_r15);

    /* Creating 'combination_27_r15' field of 'sTTI_SupportedCombinations_r15' field of 'stti_SPT_BandParameters_r15' field */
    DL_UL_CCs_r15 combination_27_r15;
    fill_DL_UL_CCs_r15(combination_27_r15);

    /* Creating 'combination_22_27_r15' field of 'sTTI_SupportedCombinations_r15' field of 'stti_SPT_BandParameters_r15' field */
    STTI_SupportedCombinations_r15::combination_22_27_r15 combination_22_27_r15;
    {
	/* Adding component #2 */
	DL_UL_CCs_r15 comp2;
	fill_DL_UL_CCs_r15(comp2);
	combination_22_27_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DL_UL_CCs_r15 comp1;
	fill_DL_UL_CCs_r15(comp1);
	combination_22_27_r15.prepend(comp1);
    }

    /* Creating 'combination_77_22_r15' field of 'sTTI_SupportedCombinations_r15' field of 'stti_SPT_BandParameters_r15' field */
    STTI_SupportedCombinations_r15::combination_77_22_r15 combination_77_22_r15;
    {
	/* Adding component #2 */
	DL_UL_CCs_r15 comp2;
	fill_DL_UL_CCs_r15(comp2);
	combination_77_22_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DL_UL_CCs_r15 comp1;
	fill_DL_UL_CCs_r15(comp1);
	combination_77_22_r15.prepend(comp1);
    }

    /* Creating 'combination_77_27_r15' field of 'sTTI_SupportedCombinations_r15' field of 'stti_SPT_BandParameters_r15' field */
    STTI_SupportedCombinations_r15::combination_77_27_r15 combination_77_27_r15;
    {
	/* Adding component #2 */
	DL_UL_CCs_r15 comp2;
	fill_DL_UL_CCs_r15(comp2);
	combination_77_27_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DL_UL_CCs_r15 comp1;
	fill_DL_UL_CCs_r15(comp1);
	combination_77_27_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    STTI_SupportedCombinations_r15 sTTI_SupportedCombinations_r15(combination_22_r15, combination_77_r15, combination_27_r15, combination_22_27_r15, combination_77_22_r15, combination_77_27_r15);

    /* Calling a fully-initializing constructor */
    STTI_SPT_BandParameters_r15 stti_SPT_BandParameters_r15(dl_1024QAM_Slot_r15_supported, dl_1024QAM_SubslotTA_1_r15_supported, dl_1024QAM_SubslotTA_2_r15_supported, simultaneousTx_differentTx_duration_r15_supported, sTTI_CA_MIMO_ParametersDL_r15, sTTI_CA_MIMO_ParametersUL_r15, sTTI_FD_MIMO_Coexistence_supported, sTTI_MIMO_CA_ParametersPerBoBCs_r15, sTTI_MIMO_CA_ParametersPerBoBCs_v1530, sTTI_SupportedCombinations_r15, sTTI_SupportedCSI_Proc_r15_n1, ul_256QAM_Slot_r15_supported, ul_256QAM_Subslot_r15_supported);

    value.set_stti_SPT_BandParameters_r15(stti_SPT_BandParameters_r15);
}

static void fill_BandCombinationParameters_v1530(BandCombinationParameters_v1530 & value)
{
    /* Setting 'bandParameterList_v1530' field */
    BandCombinationParameters_v1530::bandParameterList_v1530 bandParameterList_v1530;
    {
	/* Adding component #2 */
	BandParameters_v1530 comp2;
	fill_BandParameters_v1530(comp2);
	bandParameterList_v1530.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandParameters_v1530 comp1;
	fill_BandParameters_v1530(comp1);
	bandParameterList_v1530.prepend(comp1);
    }
    value.set_bandParameterList_v1530(bandParameterList_v1530);

    /* Setting 'spt_Parameters_r15' field */
    /* Creating 'frameStructureType_SPT_r15' field of 'spt_Parameters_r15' field */
    static unsigned char frameStructureType_SPT_r15_value[] = {
	0x00
    };
    OssBitString frameStructureType_SPT_r15(3, frameStructureType_SPT_r15_value);

    /* Calling a fully-initializing constructor */
    SPT_Parameters_r15 spt_Parameters_r15(frameStructureType_SPT_r15, 1);

    value.set_spt_Parameters_r15(spt_Parameters_r15);
}

static void fill_SupportedBandCombination_v1530(SupportedBandCombination_v1530 & value)
{
    {
	/* Adding component #2 */
	BandCombinationParameters_v1530 comp2;
	fill_BandCombinationParameters_v1530(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1530 comp1;
	fill_BandCombinationParameters_v1530(comp1);
	value.prepend(comp1);
    }
}

static void fill_MCC(MCC & value)
{
    value.prepend((OSS_UINT32)0);
    value.prepend((OSS_UINT32)0);
    value.prepend((OSS_UINT32)0);
}

static void fill_MNC(MNC & value)
{
    value.prepend((OSS_UINT32)0);
    value.prepend((OSS_UINT32)0);
}

static void fill_PLMN_Identity(PLMN_Identity & value)
{
    /* Setting 'mcc' field */
    MCC mcc;
    fill_MCC(mcc);
    value.set_mcc(mcc);

    /* Setting 'mnc' field */
    MNC mnc;
    fill_MNC(mnc);
    value.set_mnc(mnc);
}

static void fill_V2X_BandParameters_v1530(V2X_BandParameters_v1530 & value)
{
    value.set_v2x_EnhancedHighReception_r15(v2x_EnhancedHighReception_r15_supported);
}

static void fill_V2X_BandCombinationParameters_v1530(V2X_BandCombinationParameters_v1530 & value)
{
    {
	/* Adding component #2 */
	V2X_BandParameters_v1530 comp2;
	fill_V2X_BandParameters_v1530(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	V2X_BandParameters_v1530 comp1;
	fill_V2X_BandParameters_v1530(comp1);
	value.prepend(comp1);
    }
}

static void fill_UE_EUTRA_CapabilityAddXDD_Mode_v1530(UE_EUTRA_CapabilityAddXDD_Mode_v1530 & value)
{
    /* Setting 'neighCellSI_AcquisitionParameters_v1530' field of 'v2x_SupportedBandCombinationList_v1530' field of 'fdd_Add_UE_EUTRA_Capabilities_v1530' field of 'nonCriticalExtension' field... */
    NeighCellSI_AcquisitionParameters_v1530 neighCellSI_AcquisitionParameters_v1530;
    fill_NeighCellSI_AcquisitionParameters_v1530(neighCellSI_AcquisitionParameters_v1530);
    value.set_neighCellSI_AcquisitionParameters_v1530(neighCellSI_AcquisitionParameters_v1530);

    value.set_reducedCP_Latency_r15(UE_EUTRA_CapabilityAddXDD_Mode_v1530_reducedCP_Latency_r15_supported);
}

UE_EUTRA_Capability *create_samplevalue_UE_EUTRA_Capability()
{
    /* Creating 'pdcp_Parameters' field */
    /* Creating 'supportedROHC_Profiles' field of 'pdcp_Parameters' field */
    ROHC_ProfileSupportList_r15 supportedROHC_Profiles;
    fill_ROHC_ProfileSupportList_r15(supportedROHC_Profiles);

    /* Calling a fully-initializing constructor */
    PDCP_Parameters pdcp_Parameters(supportedROHC_Profiles, maxNumberROHC_ContextSessions_cs2);

    /* Creating 'phyLayerParameters' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters phyLayerParameters(TRUE, TRUE);

    /* Creating 'rf_Parameters' field */
    /* Creating 'supportedBandListEUTRA' field of 'rf_Parameters' field */
    SupportedBandListEUTRA supportedBandListEUTRA;
    {
	/* Adding component #2 */
	SupportedBandEUTRA comp2;
	fill_SupportedBandEUTRA(comp2);
	supportedBandListEUTRA.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBandEUTRA comp1;
	fill_SupportedBandEUTRA(comp1);
	supportedBandListEUTRA.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters rf_Parameters(supportedBandListEUTRA);

    /* Creating 'measParameters' field */
    /* Creating 'bandListEUTRA' field of 'measParameters' field */
    BandListEUTRA bandListEUTRA;
    {
	/* Adding component #2 */
	BandInfoEUTRA comp2;
	fill_BandInfoEUTRA(comp2);
	bandListEUTRA.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandInfoEUTRA comp1;
	fill_BandInfoEUTRA(comp1);
	bandListEUTRA.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    MeasParameters measParameters(bandListEUTRA);

    /* Creating 'featureGroupIndicators' field */
    static unsigned char featureGroupIndicators_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString featureGroupIndicators(32, featureGroupIndicators_value);

    /* Creating 'interRAT_Parameters' field */
    /* Creating 'utraFDD' field of 'interRAT_Parameters' field */
    /* Creating 'supportedBandListUTRA_FDD' field of 'utraFDD' field of 'interRAT_Parameters' field */
    SupportedBandListUTRA_FDD supportedBandListUTRA_FDD;
    supportedBandListUTRA_FDD.prepend(bandI);
    supportedBandListUTRA_FDD.prepend(bandI);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_FDD utraFDD(supportedBandListUTRA_FDD);

    /* Creating 'utraTDD128' field of 'interRAT_Parameters' field */
    /* Creating 'supportedBandListUTRA_TDD128' field of 'utraTDD128' field of 'interRAT_Parameters' field */
    SupportedBandListUTRA_TDD128 supportedBandListUTRA_TDD128;
    supportedBandListUTRA_TDD128.prepend(SupportedBandUTRA_TDD128_a);
    supportedBandListUTRA_TDD128.prepend(SupportedBandUTRA_TDD128_a);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_TDD128 utraTDD128(supportedBandListUTRA_TDD128);

    /* Creating 'utraTDD384' field of 'interRAT_Parameters' field */
    /* Creating 'supportedBandListUTRA_TDD384' field of 'utraTDD384' field of 'interRAT_Parameters' field */
    SupportedBandListUTRA_TDD384 supportedBandListUTRA_TDD384;
    supportedBandListUTRA_TDD384.prepend(SupportedBandUTRA_TDD384_a);
    supportedBandListUTRA_TDD384.prepend(SupportedBandUTRA_TDD384_a);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_TDD384 utraTDD384(supportedBandListUTRA_TDD384);

    /* Creating 'utraTDD768' field of 'interRAT_Parameters' field */
    /* Creating 'supportedBandListUTRA_TDD768' field of 'utraTDD768' field of 'interRAT_Parameters' field */
    SupportedBandListUTRA_TDD768 supportedBandListUTRA_TDD768;
    supportedBandListUTRA_TDD768.prepend(SupportedBandUTRA_TDD768_a);
    supportedBandListUTRA_TDD768.prepend(SupportedBandUTRA_TDD768_a);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_TDD768 utraTDD768(supportedBandListUTRA_TDD768);

    /* Creating 'geran' field of 'interRAT_Parameters' field */
    /* Creating 'supportedBandListGERAN' field of 'geran' field of 'interRAT_Parameters' field */
    SupportedBandListGERAN supportedBandListGERAN;
    supportedBandListGERAN.prepend(gsm450);
    supportedBandListGERAN.prepend(gsm450);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersGERAN geran(supportedBandListGERAN, TRUE);

    /* Creating 'cdma2000_HRPD' field of 'interRAT_Parameters' field */
    /* Creating 'supportedBandListHRPD' field of 'cdma2000_HRPD' field of 'interRAT_Parameters' field */
    SupportedBandListHRPD supportedBandListHRPD;
    supportedBandListHRPD.prepend(bc0);
    supportedBandListHRPD.prepend(bc0);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersCDMA2000_HRPD cdma2000_HRPD(supportedBandListHRPD, tx_ConfigHRPD_single, rx_ConfigHRPD_single);

    /* Creating 'cdma2000_1xRTT' field of 'interRAT_Parameters' field */
    /* Creating 'supportedBandList1XRTT' field of 'cdma2000_1xRTT' field of 'interRAT_Parameters' field */
    SupportedBandList1XRTT supportedBandList1XRTT;
    supportedBandList1XRTT.prepend(bc0);
    supportedBandList1XRTT.prepend(bc0);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersCDMA2000_1XRTT cdma2000_1xRTT(supportedBandList1XRTT, tx_Config1XRTT_single, rx_Config1XRTT_single);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability::interRAT_Parameters interRAT_Parameters(utraFDD, utraTDD128, utraTDD384, utraTDD768, geran, cdma2000_HRPD, cdma2000_1xRTT);

    /* Creating 'nonCriticalExtension' field */
    /* Creating 'phyLayerParameters_v920' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v920 phyLayerParameters_v920(enhancedDualLayerFDD_r9_supported, enhancedDualLayerTDD_r9_supported);

    /* Creating 'interRAT_ParametersGERAN_v920' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersGERAN_v920 interRAT_ParametersGERAN_v920(dtm_r9_supported, e_RedirectionGERAN_r9_supported);

    /* Creating 'interRAT_ParametersUTRA_v920' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_v920 interRAT_ParametersUTRA_v920(e_RedirectionUTRA_r9_supported);

    /* Creating 'interRAT_ParametersCDMA2000_v920' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersCDMA2000_1XRTT_v920 interRAT_ParametersCDMA2000_v920(e_CSFB_1XRTT_r9_supported, e_CSFB_ConcPS_Mob1XRTT_r9_supported);

    /* Creating 'csg_ProximityIndicationParameters_r9' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    CSG_ProximityIndicationParameters_r9 csg_ProximityIndicationParameters_r9(intraFreqProximityIndication_r9_supported, interFreqProximityIndication_r9_supported, utran_ProximityIndication_r9_supported);

    /* Creating 'neighCellSI_AcquisitionParameters_r9' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    NeighCellSI_AcquisitionParameters_r9 neighCellSI_AcquisitionParameters_r9(intraFreqSI_AcquisitionForHO_r9_supported, interFreqSI_AcquisitionForHO_r9_supported, utran_SI_AcquisitionForHO_r9_supported);

    /* Creating 'son_Parameters_r9' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    SON_Parameters_r9 son_Parameters_r9(rach_Report_r9_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    UE_EUTRA_Capability_v940_IEs::lateNonCriticalExtension lateNonCriticalExtension;
    /* Creating 'featureGroupIndRel9Add_r9' field */
    static unsigned char featureGroupIndRel9Add_r9_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString featureGroupIndRel9Add_r9(32, featureGroupIndRel9Add_r9_value);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_r9' field */
    /* Creating 'phyLayerParameters_r9' field of 'fdd_Add_UE_EUTRA_Capabilities_r9' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters phyLayerParameters_r9(TRUE, TRUE);

    /* Creating 'featureGroupIndicators_r9' field of 'fdd_Add_UE_EUTRA_Capabilities_r9' field */
    static unsigned char featureGroupIndicators_r9_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString featureGroupIndicators_r9(32, featureGroupIndicators_r9_value);

    /* Creating 'featureGroupIndRel9Add_r9' field of 'fdd_Add_UE_EUTRA_Capabilities_r9' field */
    static unsigned char fdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndRel9Add_r9_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString fdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndRel9Add_r9(32, fdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndRel9Add_r9_value);

    /* Creating 'interRAT_ParametersGERAN_r9' field of 'fdd_Add_UE_EUTRA_Capabilities_r9' field */
    /* Creating 'supportedBandListGERAN' field of 'interRAT_ParametersGERAN_r9' field of 'fdd_Add_UE_EUTRA_Capabilities_r9' field */
    SupportedBandListGERAN interRAT_ParametersGERAN_r9_supportedBandListGERAN;
    interRAT_ParametersGERAN_r9_supportedBandListGERAN.prepend(gsm450);
    interRAT_ParametersGERAN_r9_supportedBandListGERAN.prepend(gsm450);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersGERAN interRAT_ParametersGERAN_r9(interRAT_ParametersGERAN_r9_supportedBandListGERAN, TRUE);

    /* Creating 'interRAT_ParametersUTRA_r9' field of 'fdd_Add_UE_EUTRA_Capabilities_r9' field */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_v920 interRAT_ParametersUTRA_r9(e_RedirectionUTRA_r9_supported);

    /* Creating 'interRAT_ParametersCDMA2000_r9' field of 'fdd_Add_UE_EUTRA_Capabilities_r9' field */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersCDMA2000_1XRTT_v920 interRAT_ParametersCDMA2000_r9(e_CSFB_1XRTT_r9_supported, e_CSFB_ConcPS_Mob1XRTT_r9_supported);

    /* Creating 'neighCellSI_AcquisitionParameters_r9' field of 'fdd_Add_UE_EUTRA_Capabilities_r9' field */

    /* Calling a fully-initializing constructor */
    NeighCellSI_AcquisitionParameters_r9 fdd_Add_UE_EUTRA_Capabilities_r9_neighCellSI_AcquisitionParameters_r9(intraFreqSI_AcquisitionForHO_r9_supported, interFreqSI_AcquisitionForHO_r9_supported, utran_SI_AcquisitionForHO_r9_supported);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_CapabilityAddXDD_Mode_r9 fdd_Add_UE_EUTRA_Capabilities_r9(phyLayerParameters_r9, featureGroupIndicators_r9, fdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndRel9Add_r9, interRAT_ParametersGERAN_r9, interRAT_ParametersUTRA_r9, interRAT_ParametersCDMA2000_r9, fdd_Add_UE_EUTRA_Capabilities_r9_neighCellSI_AcquisitionParameters_r9);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_r9' field */
    /* Creating 'phyLayerParameters_r9' field of 'tdd_Add_UE_EUTRA_Capabilities_r9' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters tdd_Add_UE_EUTRA_Capabilities_r9_phyLayerParameters_r9(TRUE, TRUE);

    /* Creating 'featureGroupIndicators_r9' field of 'tdd_Add_UE_EUTRA_Capabilities_r9' field */
    static unsigned char tdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndicators_r9_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString tdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndicators_r9(32, tdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndicators_r9_value);

    /* Creating 'featureGroupIndRel9Add_r9' field of 'tdd_Add_UE_EUTRA_Capabilities_r9' field */
    static unsigned char tdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndRel9Add_r9_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString tdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndRel9Add_r9(32, tdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndRel9Add_r9_value);

    /* Creating 'interRAT_ParametersGERAN_r9' field of 'tdd_Add_UE_EUTRA_Capabilities_r9' field */
    /* Creating 'supportedBandListGERAN' field of 'interRAT_ParametersGERAN_r9' field of 'tdd_Add_UE_EUTRA_Capabilities_r9' field */
    SupportedBandListGERAN tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersGERAN_r9_supportedBandListGERAN;
    tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersGERAN_r9_supportedBandListGERAN.prepend(gsm450);
    tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersGERAN_r9_supportedBandListGERAN.prepend(gsm450);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersGERAN tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersGERAN_r9(tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersGERAN_r9_supportedBandListGERAN, TRUE);

    /* Creating 'interRAT_ParametersUTRA_r9' field of 'tdd_Add_UE_EUTRA_Capabilities_r9' field */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_v920 tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersUTRA_r9(e_RedirectionUTRA_r9_supported);

    /* Creating 'interRAT_ParametersCDMA2000_r9' field of 'tdd_Add_UE_EUTRA_Capabilities_r9' field */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersCDMA2000_1XRTT_v920 tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersCDMA2000_r9(e_CSFB_1XRTT_r9_supported, e_CSFB_ConcPS_Mob1XRTT_r9_supported);

    /* Creating 'neighCellSI_AcquisitionParameters_r9' field of 'tdd_Add_UE_EUTRA_Capabilities_r9' field */

    /* Calling a fully-initializing constructor */
    NeighCellSI_AcquisitionParameters_r9 tdd_Add_UE_EUTRA_Capabilities_r9_neighCellSI_AcquisitionParameters_r9(intraFreqSI_AcquisitionForHO_r9_supported, interFreqSI_AcquisitionForHO_r9_supported, utran_SI_AcquisitionForHO_r9_supported);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_CapabilityAddXDD_Mode_r9 tdd_Add_UE_EUTRA_Capabilities_r9(tdd_Add_UE_EUTRA_Capabilities_r9_phyLayerParameters_r9, tdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndicators_r9, tdd_Add_UE_EUTRA_Capabilities_r9_featureGroupIndRel9Add_r9, tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersGERAN_r9, tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersUTRA_r9, tdd_Add_UE_EUTRA_Capabilities_r9_interRAT_ParametersCDMA2000_r9, tdd_Add_UE_EUTRA_Capabilities_r9_neighCellSI_AcquisitionParameters_r9);

    /* Creating 'nonCriticalExtension' field */
    /* Creating 'interRAT_ParametersUTRA_v9c0' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_v9c0 interRAT_ParametersUTRA_v9c0(voiceOverPS_HS_UTRA_FDD_r9_supported, voiceOverPS_HS_UTRA_TDD128_r9_supported, srvcc_FromUTRA_FDD_ToUTRA_FDD_r9_supported, srvcc_FromUTRA_FDD_ToGERAN_r9_supported, srvcc_FromUTRA_TDD128_ToUTRA_TDD128_r9_supported, srvcc_FromUTRA_TDD128_ToGERAN_r9_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'phyLayerParameters_v9d0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v9d0 phyLayerParameters_v9d0(tm5_FDD_r9_supported, tm5_TDD_r9_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'rf_Parameters_v9e0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandListEUTRA_v9e0' field of 'rf_Parameters_v9e0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandListEUTRA_v9e0 supportedBandListEUTRA_v9e0;
    {
	/* Adding component #2 */
	SupportedBandEUTRA_v9e0 comp2;
	fill_SupportedBandEUTRA_v9e0(comp2);
	supportedBandListEUTRA_v9e0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBandEUTRA_v9e0 comp1;
	fill_SupportedBandEUTRA_v9e0(comp1);
	supportedBandListEUTRA_v9e0.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v9e0 rf_Parameters_v9e0(supportedBandListEUTRA_v9e0);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'interRAT_ParametersUTRA_v9h0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersUTRA_v9h0 interRAT_ParametersUTRA_v9h0(mfbi_UTRA_r9_supported);

    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char nonCriticalExtension_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString nonCriticalExtension_lateNonCriticalExtension(sizeof(nonCriticalExtension_lateNonCriticalExtension_value), (char *)nonCriticalExtension_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'otdoa_PositioningCapabilities_r10' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    OTDOA_PositioningCapabilities_r10 otdoa_PositioningCapabilities_r10(otdoa_UE_Assisted_r10_supported, interFreqRSTD_Measurement_r10_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v10f0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'modifiedMPR_Behavior_r10' field of 'rf_Parameters_v10f0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char modifiedMPR_Behavior_r10_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString modifiedMPR_Behavior_r10(32, modifiedMPR_Behavior_r10_value);

    /* Calling a fully-initializing constructor */
    RF_Parameters_v10f0 rf_Parameters_v10f0(modifiedMPR_Behavior_r10);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v10i0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v10i0' field of 'rf_Parameters_v10i0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v10i0 supportedBandCombination_v10i0;
    {
	/* Adding component #2 */
	BandCombinationParameters_v10i0 comp2;
	fill_BandCombinationParameters_v10i0(comp2);
	supportedBandCombination_v10i0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v10i0 comp1;
	fill_BandCombinationParameters_v10i0(comp1);
	supportedBandCombination_v10i0.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v10i0 rf_Parameters_v10i0(supportedBandCombination_v10i0);

    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_Capability_v10i0_IEs::lateNonCriticalExtension nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension;
    /* Creating 'rf_Parameters_v10j0' field of 'supportedBandCombination_v10i0' field of 'lateNonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    RF_Parameters_v10j0 rf_Parameters_v10j0(multiNS_Pmax_r10_supported);

    /* Creating 'nonCriticalExtension' field of 'supportedBandCombination_v10i0' field of 'lateNonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_Capability_v10j0_IEs::nonCriticalExtension lateNonCriticalExtension_decoded_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v10j0_IEs lateNonCriticalExtension_decoded(rf_Parameters_v10j0, lateNonCriticalExtension_decoded_nonCriticalExtension);

    nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension.set_decoded(lateNonCriticalExtension_decoded);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v11d0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombinationAdd_v11d0' field of 'rf_Parameters_v11d0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v11d0 supportedBandCombinationAdd_v11d0;
    {
	/* Adding component #2 */
	BandCombinationParameters_v10i0 comp2;
	fill_BandCombinationParameters_v10i0(comp2);
	supportedBandCombinationAdd_v11d0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v10i0 comp1;
	fill_BandCombinationParameters_v10i0(comp1);
	supportedBandCombinationAdd_v11d0.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v11d0 rf_Parameters_v11d0(supportedBandCombinationAdd_v11d0);

    /* Creating 'otherParameters_v11d0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    Other_Parameters_v11d0 otherParameters_v11d0(inDeviceCoexInd_UL_CA_r11_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension(sizeof(nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value), (char *)nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v12b0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    RF_Parameters_v12b0 rf_Parameters_v12b0(maxLayersMIMO_Indication_r12_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension(sizeof(nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value), (char *)nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'ce_Parameters_v1370' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1370 ce_Parameters_v1370(tm9_CE_ModeA_r13_supported, tm9_CE_ModeB_r13_supported);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1370' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'ce_Parameters_v1370' field of 'fdd_Add_UE_EUTRA_Capabilities_v1370' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1370 fdd_Add_UE_EUTRA_Capabilities_v1370_ce_Parameters_v1370(tm9_CE_ModeA_r13_supported, tm9_CE_ModeB_r13_supported);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_CapabilityAddXDD_Mode_v1370 fdd_Add_UE_EUTRA_Capabilities_v1370(fdd_Add_UE_EUTRA_Capabilities_v1370_ce_Parameters_v1370);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1370' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'ce_Parameters_v1370' field of 'tdd_Add_UE_EUTRA_Capabilities_v1370' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1370 tdd_Add_UE_EUTRA_Capabilities_v1370_ce_Parameters_v1370(tm9_CE_ModeA_r13_supported, tm9_CE_ModeB_r13_supported);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_CapabilityAddXDD_Mode_v1370 tdd_Add_UE_EUTRA_Capabilities_v1370(tdd_Add_UE_EUTRA_Capabilities_v1370_ce_Parameters_v1370);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1380' field of 'rf_Parameters_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1380 supportedBandCombination_v1380;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1380 comp2;
	fill_BandCombinationParameters_v1380(comp2);
	supportedBandCombination_v1380.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1380 comp1;
	fill_BandCombinationParameters_v1380(comp1);
	supportedBandCombination_v1380.prepend(comp1);
    }

    /* Creating 'supportedBandCombinationAdd_v1380' field of 'rf_Parameters_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1380 supportedBandCombinationAdd_v1380;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1380 comp2;
	fill_BandCombinationParameters_v1380(comp2);
	supportedBandCombinationAdd_v1380.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1380 comp1;
	fill_BandCombinationParameters_v1380(comp1);
	supportedBandCombinationAdd_v1380.prepend(comp1);
    }

    /* Creating 'supportedBandCombinationReduced_v1380' field of 'rf_Parameters_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationReduced_v1380 supportedBandCombinationReduced_v1380;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1380 comp2;
	fill_BandCombinationParameters_v1380(comp2);
	supportedBandCombinationReduced_v1380.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1380 comp1;
	fill_BandCombinationParameters_v1380(comp1);
	supportedBandCombinationReduced_v1380.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1380 rf_Parameters_v1380(supportedBandCombination_v1380, supportedBandCombinationAdd_v1380, supportedBandCombinationReduced_v1380);

    /* Creating 'ce_Parameters_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1380 ce_Parameters_v1380(tm6_CE_ModeA_r13_supported);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'ce_Parameters_v1380' field of 'fdd_Add_UE_EUTRA_Capabilities_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1380 fdd_Add_UE_EUTRA_Capabilities_v1380_ce_Parameters_v1380(tm6_CE_ModeA_r13_supported);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_CapabilityAddXDD_Mode_v1380 fdd_Add_UE_EUTRA_Capabilities_v1380(fdd_Add_UE_EUTRA_Capabilities_v1380_ce_Parameters_v1380);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'ce_Parameters_v1380' field of 'tdd_Add_UE_EUTRA_Capabilities_v1380' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1380 tdd_Add_UE_EUTRA_Capabilities_v1380_ce_Parameters_v1380(tm6_CE_ModeA_r13_supported);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_CapabilityAddXDD_Mode_v1380 tdd_Add_UE_EUTRA_Capabilities_v1380(tdd_Add_UE_EUTRA_Capabilities_v1380_ce_Parameters_v1380);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v1390' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1390' field of 'rf_Parameters_v1390' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1390 supportedBandCombination_v1390;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1390 comp2;
	fill_BandCombinationParameters_v1390(comp2);
	supportedBandCombination_v1390.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1390 comp1;
	fill_BandCombinationParameters_v1390(comp1);
	supportedBandCombination_v1390.prepend(comp1);
    }

    /* Creating 'supportedBandCombinationAdd_v1390' field of 'rf_Parameters_v1390' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1390 supportedBandCombinationAdd_v1390;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1390 comp2;
	fill_BandCombinationParameters_v1390(comp2);
	supportedBandCombinationAdd_v1390.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1390 comp1;
	fill_BandCombinationParameters_v1390(comp1);
	supportedBandCombinationAdd_v1390.prepend(comp1);
    }

    /* Creating 'supportedBandCombinationReduced_v1390' field of 'rf_Parameters_v1390' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationReduced_v1390 supportedBandCombinationReduced_v1390;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1390 comp2;
	fill_BandCombinationParameters_v1390(comp2);
	supportedBandCombinationReduced_v1390.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1390 comp1;
	fill_BandCombinationParameters_v1390(comp1);
	supportedBandCombinationReduced_v1390.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1390 rf_Parameters_v1390(supportedBandCombination_v1390, supportedBandCombinationAdd_v1390, supportedBandCombinationReduced_v1390);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension(sizeof(nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value), (char *)nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'mbms_Parameters_v1470' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'mbms_MaxBW_r14' field of 'mbms_Parameters_v1470' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MBMS_Parameters_v1470::mbms_MaxBW_r14 mbms_MaxBW_r14;
    mbms_MaxBW_r14.set_implicitValue(0);

    /* Calling a fully-initializing constructor */
    MBMS_Parameters_v1470 mbms_Parameters_v1470(mbms_MaxBW_r14, mbms_ScalingFactor1dot25_r14_n3, mbms_ScalingFactor7dot5_r14_n1);

    /* Creating 'phyLayerParameters_v1470' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'mimo_UE_Parameters_v1470' field of 'phyLayerParameters_v1470' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'parametersTM9_v1470' field of 'mimo_UE_Parameters_v1470' field of 'phyLayerParameters_v1470' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MIMO_UE_ParametersPerTM_v1470 parametersTM9_v1470(MIMO_UE_ParametersPerTM_v1470_csi_ReportingAdvancedMaxPorts_r14_n8);

    /* Creating 'parametersTM10_v1470' field of 'mimo_UE_Parameters_v1470' field of 'phyLayerParameters_v1470' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MIMO_UE_ParametersPerTM_v1470 parametersTM10_v1470(MIMO_UE_ParametersPerTM_v1470_csi_ReportingAdvancedMaxPorts_r14_n8);

    /* Calling a fully-initializing constructor */
    MIMO_UE_Parameters_v1470 mimo_UE_Parameters_v1470(parametersTM9_v1470, parametersTM10_v1470);

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1470 phyLayerParameters_v1470(mimo_UE_Parameters_v1470, srs_UpPTS_6sym_r14_supported);

    /* Creating 'rf_Parameters_v1470' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1470' field of 'rf_Parameters_v1470' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1470 supportedBandCombination_v1470;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1470 comp2;
	fill_BandCombinationParameters_v1470(comp2);
	supportedBandCombination_v1470.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1470 comp1;
	fill_BandCombinationParameters_v1470(comp1);
	supportedBandCombination_v1470.prepend(comp1);
    }

    /* Creating 'supportedBandCombinationAdd_v1470' field of 'rf_Parameters_v1470' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1470 supportedBandCombinationAdd_v1470;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1470 comp2;
	fill_BandCombinationParameters_v1470(comp2);
	supportedBandCombinationAdd_v1470.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1470 comp1;
	fill_BandCombinationParameters_v1470(comp1);
	supportedBandCombinationAdd_v1470.prepend(comp1);
    }

    /* Creating 'supportedBandCombinationReduced_v1470' field of 'rf_Parameters_v1470' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationReduced_v1470 supportedBandCombinationReduced_v1470;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1470 comp2;
	fill_BandCombinationParameters_v1470(comp2);
	supportedBandCombinationReduced_v1470.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1470 comp1;
	fill_BandCombinationParameters_v1470(comp1);
	supportedBandCombinationReduced_v1470.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1470 rf_Parameters_v1470(supportedBandCombination_v1470, supportedBandCombinationAdd_v1470, supportedBandCombinationReduced_v1470);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_Capability_v1470_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1470_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(mbms_Parameters_v1470, phyLayerParameters_v1470, rf_Parameters_v1470, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v13x0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1390_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v1390, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1380_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v1380, ce_Parameters_v1380, fdd_Add_UE_EUTRA_Capabilities_v1380, tdd_Add_UE_EUTRA_Capabilities_v1380, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1370_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(ce_Parameters_v1370, fdd_Add_UE_EUTRA_Capabilities_v1370, tdd_Add_UE_EUTRA_Capabilities_v1370, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v12x0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v12b0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v12b0, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v11x0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v11d0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v11d0, otherParameters_v11d0, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v10i0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v10i0, nonCriticalExtension_nonCriticalExtension_lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v10f0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v10f0, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v10c0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(otdoa_PositioningCapabilities_r10, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v9h0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(interRAT_ParametersUTRA_v9h0, nonCriticalExtension_lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v9e0_IEs decoded_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v9e0, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v9d0_IEs decoded_nonCriticalExtension_nonCriticalExtension(phyLayerParameters_v9d0, decoded_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v9c0_IEs decoded_nonCriticalExtension(interRAT_ParametersUTRA_v9c0, decoded_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v9a0_IEs decoded(featureGroupIndRel9Add_r9, fdd_Add_UE_EUTRA_Capabilities_r9, tdd_Add_UE_EUTRA_Capabilities_r9, decoded_nonCriticalExtension);

    lateNonCriticalExtension.set_decoded(decoded);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'phyLayerParameters_v1020' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1020 phyLayerParameters_v1020;
    fill_PhyLayerParameters_v1020(phyLayerParameters_v1020);

    /* Creating 'rf_Parameters_v1020' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_r10' field of 'rf_Parameters_v1020' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_r10 supportedBandCombination_r10;
    {
	/* Adding component #2 */
	BandCombinationParameters_r10 comp2;
	fill_BandCombinationParameters_r10(comp2);
	supportedBandCombination_r10.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_r10 comp1;
	fill_BandCombinationParameters_r10(comp1);
	supportedBandCombination_r10.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1020 rf_Parameters_v1020(supportedBandCombination_r10);

    /* Creating 'measParameters_v1020' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'bandCombinationListEUTRA_r10' field of 'measParameters_v1020' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    BandCombinationListEUTRA_r10 bandCombinationListEUTRA_r10;
    {
	/* Adding component #2 */
	BandInfoEUTRA comp2;
	fill_BandInfoEUTRA(comp2);
	bandCombinationListEUTRA_r10.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandInfoEUTRA comp1;
	fill_BandInfoEUTRA(comp1);
	bandCombinationListEUTRA_r10.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    MeasParameters_v1020 measParameters_v1020(bandCombinationListEUTRA_r10);

    /* Creating 'featureGroupIndRel10_r10' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char featureGroupIndRel10_r10_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString featureGroupIndRel10_r10(32, featureGroupIndRel10_r10_value);

    /* Creating 'interRAT_ParametersCDMA2000_v1020' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    IRAT_ParametersCDMA2000_1XRTT_v1020 interRAT_ParametersCDMA2000_v1020;
    fill_IRAT_ParametersCDMA2000_1XRTT_v1020(interRAT_ParametersCDMA2000_v1020);

    /* Creating 'ue_BasedNetwPerfMeasParameters_r10' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    UE_BasedNetwPerfMeasParameters_r10 ue_BasedNetwPerfMeasParameters_r10(loggedMeasurementsIdle_r10_supported, standaloneGNSS_Location_r10_supported);

    /* Creating 'interRAT_ParametersUTRA_TDD_v1020' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    IRAT_ParametersUTRA_TDD_v1020 interRAT_ParametersUTRA_TDD_v1020;
    fill_IRAT_ParametersUTRA_TDD_v1020(interRAT_ParametersUTRA_TDD_v1020);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1060' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1060 fdd_Add_UE_EUTRA_Capabilities_v1060;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1060(fdd_Add_UE_EUTRA_Capabilities_v1060);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1060' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1060 tdd_Add_UE_EUTRA_Capabilities_v1060;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1060(tdd_Add_UE_EUTRA_Capabilities_v1060);

    /* Creating 'rf_Parameters_v1060' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombinationExt_r10' field of 'rf_Parameters_v1060' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationExt_r10 supportedBandCombinationExt_r10;
    {
	/* Adding component #2 */
	BandCombinationParametersExt_r10 comp2;
	fill_BandCombinationParametersExt_r10(comp2);
	supportedBandCombinationExt_r10.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParametersExt_r10 comp1;
	fill_BandCombinationParametersExt_r10(comp1);
	supportedBandCombinationExt_r10.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1060 rf_Parameters_v1060(supportedBandCombinationExt_r10);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v1090' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1090' field of 'rf_Parameters_v1090' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1090 supportedBandCombination_v1090;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1090 comp2;
	fill_BandCombinationParameters_v1090(comp2);
	supportedBandCombination_v1090.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1090 comp1;
	fill_BandCombinationParameters_v1090(comp1);
	supportedBandCombination_v1090.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1090 rf_Parameters_v1090(supportedBandCombination_v1090);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'pdcp_Parameters_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_v1130 pdcp_Parameters_v1130(pdcp_SN_Extension_r11_supported, supportRohcContextContinue_r11_supported);

    /* Creating 'phyLayerParameters_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1130 phyLayerParameters_v1130;
    fill_PhyLayerParameters_v1130(phyLayerParameters_v1130);

    /* Creating 'rf_Parameters_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1130' field of 'rf_Parameters_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1130 supportedBandCombination_v1130;
    {
	/* Adding component #2 */
	BandCombinationParameters_v1130 comp2;
	fill_BandCombinationParameters_v1130(comp2);
	supportedBandCombination_v1130.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_v1130 comp1;
	fill_BandCombinationParameters_v1130(comp1);
	supportedBandCombination_v1130.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1130 rf_Parameters_v1130(supportedBandCombination_v1130);

    /* Creating 'measParameters_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MeasParameters_v1130 measParameters_v1130;
    fill_MeasParameters_v1130(measParameters_v1130);

    /* Creating 'interRAT_ParametersCDMA2000_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    IRAT_ParametersCDMA2000_v1130 interRAT_ParametersCDMA2000_v1130(cdma2000_NW_Sharing_r11_supported);

    /* Creating 'otherParameters_r11' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    Other_Parameters_r11 otherParameters_r11;
    fill_Other_Parameters_r11(otherParameters_r11);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1130 fdd_Add_UE_EUTRA_Capabilities_v1130;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1130(fdd_Add_UE_EUTRA_Capabilities_v1130);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1130 tdd_Add_UE_EUTRA_Capabilities_v1130;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1130(tdd_Add_UE_EUTRA_Capabilities_v1130);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'phyLayerParameters_v1170' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'interBandTDD_CA_WithDifferentConfig_r11' field of 'phyLayerParameters_v1170' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char interBandTDD_CA_WithDifferentConfig_r11_value[] = {
	0x00
    };
    OssBitString interBandTDD_CA_WithDifferentConfig_r11(2, interBandTDD_CA_WithDifferentConfig_r11_value);

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1170 phyLayerParameters_v1170(interBandTDD_CA_WithDifferentConfig_r11);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v1180' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'requestedBands_r11' field of 'rf_Parameters_v1180' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    RF_Parameters_v1180::requestedBands_r11 requestedBands_r11;
    requestedBands_r11.prepend(1);
    requestedBands_r11.prepend(1);

    /* Creating 'supportedBandCombinationAdd_r11' field of 'rf_Parameters_v1180' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_r11 supportedBandCombinationAdd_r11;
    {
	/* Adding component #2 */
	BandCombinationParameters_r11 comp2;
	fill_BandCombinationParameters_r11(comp2);
	supportedBandCombinationAdd_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_r11 comp1;
	fill_BandCombinationParameters_r11(comp1);
	supportedBandCombinationAdd_r11.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1180 rf_Parameters_v1180(freqBandRetrieval_r11_supported, requestedBands_r11, supportedBandCombinationAdd_r11);

    /* Creating 'mbms_Parameters_r11' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MBMS_Parameters_r11 mbms_Parameters_r11;
    fill_MBMS_Parameters_r11(mbms_Parameters_r11);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1180' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1180 fdd_Add_UE_EUTRA_Capabilities_v1180;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1180(fdd_Add_UE_EUTRA_Capabilities_v1180);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1180' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1180 tdd_Add_UE_EUTRA_Capabilities_v1180;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1180(tdd_Add_UE_EUTRA_Capabilities_v1180);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'measParameters_v11a0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MeasParameters_v11a0 measParameters_v11a0(benefitsFromInterruption_r11_true);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'phyLayerParameters_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1250 phyLayerParameters_v1250;
    fill_PhyLayerParameters_v1250(phyLayerParameters_v1250);

    /* Creating 'rf_Parameters_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandListEUTRA_v1250' field of 'rf_Parameters_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandListEUTRA_v1250 supportedBandListEUTRA_v1250;
    {
	/* Adding component #2 */
	SupportedBandEUTRA_v1250 comp2;
	fill_SupportedBandEUTRA_v1250(comp2);
	supportedBandListEUTRA_v1250.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBandEUTRA_v1250 comp1;
	fill_SupportedBandEUTRA_v1250(comp1);
	supportedBandListEUTRA_v1250.prepend(comp1);
    }

    /* Creating 'supportedBandCombination_v1250' field of 'rf_Parameters_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1250 supportedBandCombination_v1250;
    fill_SupportedBandCombination_v1250(supportedBandCombination_v1250);

    /* Creating 'supportedBandCombinationAdd_v1250' field of 'rf_Parameters_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1250 supportedBandCombinationAdd_v1250;
    fill_SupportedBandCombination_v1250(supportedBandCombinationAdd_v1250);

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1250 rf_Parameters_v1250(supportedBandListEUTRA_v1250, supportedBandCombination_v1250, supportedBandCombinationAdd_v1250, freqBandPriorityAdjustment_r12_supported);

    /* Creating 'rlc_Parameters_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    RLC_Parameters_r12 rlc_Parameters_r12(extended_RLC_LI_Field_r12_supported);

    /* Creating 'ue_BasedNetwPerfMeasParameters_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    UE_BasedNetwPerfMeasParameters_v1250 ue_BasedNetwPerfMeasParameters_v1250(loggedMBSFNMeasurements_r12_supported);

    /* Creating 'wlan_IW_Parameters_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_IW_Parameters_r12 wlan_IW_Parameters_r12(wlan_IW_RAN_Rules_r12_supported, wlan_IW_ANDSF_Policies_r12_supported);

    /* Creating 'measParameters_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MeasParameters_v1250 measParameters_v1250;
    fill_MeasParameters_v1250(measParameters_v1250);

    /* Creating 'dc_Parameters_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    DC_Parameters_r12 dc_Parameters_r12(drb_TypeSplit_r12_supported, drb_TypeSCG_r12_supported);

    /* Creating 'mbms_Parameters_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MBMS_Parameters_v1250 mbms_Parameters_v1250(mbms_AsyncDC_r12_supported);

    /* Creating 'mac_Parameters_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MAC_Parameters_r12 mac_Parameters_r12(logicalChannelSR_ProhibitTimer_r12_supported, longDRX_Command_r12_supported);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1250 fdd_Add_UE_EUTRA_Capabilities_v1250;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1250(fdd_Add_UE_EUTRA_Capabilities_v1250);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1250 tdd_Add_UE_EUTRA_Capabilities_v1250;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1250(tdd_Add_UE_EUTRA_Capabilities_v1250);

    /* Creating 'sl_Parameters_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'commSupportedBands_r12' field of 'sl_Parameters_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    FreqBandIndicatorListEUTRA_r12 commSupportedBands_r12;
    commSupportedBands_r12.prepend(1);
    commSupportedBands_r12.prepend(1);

    /* Creating 'discSupportedBands_r12' field of 'sl_Parameters_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandInfoList_r12 discSupportedBands_r12;
    {
	/* Adding component #2 */
	SupportedBandInfo_r12 comp2;
	fill_SupportedBandInfo_r12(comp2);
	discSupportedBands_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBandInfo_r12 comp1;
	fill_SupportedBandInfo_r12(comp1);
	discSupportedBands_r12.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_Parameters_r12 sl_Parameters_r12(commSimultaneousTx_r12_supported, commSupportedBands_r12, discSupportedBands_r12, discScheduledResourceAlloc_r12_supported, disc_UE_SelectedResourceAlloc_r12_supported, disc_SLSS_r12_supported, discSupportedProc_r12_n50);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'rf_Parameters_v1270' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1270' field of 'rf_Parameters_v1270' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1270 supportedBandCombination_v1270;
    fill_SupportedBandCombination_v1270(supportedBandCombination_v1270);

    /* Creating 'supportedBandCombinationAdd_v1270' field of 'rf_Parameters_v1270' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1270 supportedBandCombinationAdd_v1270;
    fill_SupportedBandCombination_v1270(supportedBandCombinationAdd_v1270);

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1270 rf_Parameters_v1270(supportedBandCombination_v1270, supportedBandCombinationAdd_v1270);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'phyLayerParameters_v1280' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1280 phyLayerParameters_v1280(alternativeTBS_Indices_r12_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'pdcp_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_v1310 pdcp_Parameters_v1310(pdcp_SN_Extension_18bits_r13_supported);

    /* Creating 'rlc_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    RLC_Parameters_v1310 rlc_Parameters_v1310(extendedRLC_SN_SO_Field_r13_supported);

    /* Creating 'mac_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MAC_Parameters_v1310 mac_Parameters_v1310(extendedMAC_LengthField_r13_supported, extendedLongDRX_r13_supported);

    /* Creating 'phyLayerParameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1310 phyLayerParameters_v1310;
    fill_PhyLayerParameters_v1310(phyLayerParameters_v1310);

    /* Creating 'rf_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'eNB_RequestedParameters_r13' field of 'rf_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1310::eNB_RequestedParameters_r13 eNB_RequestedParameters_r13(reducedIntNonContCombRequested_r13_true, 2, 2, skipFallbackCombRequested_r13_true);

    /* Creating 'supportedBandListEUTRA_v1310' field of 'rf_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandListEUTRA_v1310 supportedBandListEUTRA_v1310;
    {
	/* Adding component #2 */
	SupportedBandEUTRA_v1310 comp2;
	fill_SupportedBandEUTRA_v1310(comp2);
	supportedBandListEUTRA_v1310.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBandEUTRA_v1310 comp1;
	fill_SupportedBandEUTRA_v1310(comp1);
	supportedBandListEUTRA_v1310.prepend(comp1);
    }

    /* Creating 'supportedBandCombinationReduced_r13' field of 'rf_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationReduced_r13 supportedBandCombinationReduced_r13;
    {
	/* Adding component #2 */
	BandCombinationParameters_r13 comp2;
	fill_BandCombinationParameters_r13(comp2);
	supportedBandCombinationReduced_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombinationParameters_r13 comp1;
	fill_BandCombinationParameters_r13(comp1);
	supportedBandCombinationReduced_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1310 rf_Parameters_v1310(eNB_RequestedParameters_r13, maximumCCsRetrieval_r13_supported, skipFallbackCombinations_r13_supported, reducedIntNonContComb_r13_supported, supportedBandListEUTRA_v1310, supportedBandCombinationReduced_r13);

    /* Creating 'measParameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MeasParameters_v1310 measParameters_v1310(rs_SINR_Meas_r13_supported, whiteCellList_r13_supported, extendedMaxObjectId_r13_supported, ul_PDCP_Delay_r13_supported, extendedFreqPriorities_r13_supported, multiBandInfoReport_r13_supported, rssi_AndChannelOccupancyReporting_r13_supported);

    /* Creating 'dc_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    DC_Parameters_v1310 dc_Parameters_v1310(pdcp_TransferSplitUL_r13_supported, ue_SSTD_Meas_r13_supported);

    /* Creating 'sl_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    SL_Parameters_v1310 sl_Parameters_v1310(discSysInfoReporting_r13_supported, commMultipleTx_r13_supported, discInterFreqTx_r13_supported, discPeriodicSLSS_r13_supported);

    /* Creating 'scptm_Parameters_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SCPTM_Parameters_r13 scptm_Parameters_r13;
    fill_SCPTM_Parameters_r13(scptm_Parameters_r13);

    /* Creating 'ce_Parameters_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_r13 ce_Parameters_r13(ce_ModeA_r13_supported, CE_Parameters_r13_ce_ModeB_r13_supported);

    /* Creating 'interRAT_ParametersWLAN_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandListWLAN_r13' field of 'interRAT_ParametersWLAN_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    IRAT_ParametersWLAN_r13::supportedBandListWLAN_r13 supportedBandListWLAN_r13;
    supportedBandListWLAN_r13.prepend(band2dot4);
    supportedBandListWLAN_r13.prepend(band2dot4);

    /* Calling a fully-initializing constructor */
    IRAT_ParametersWLAN_r13 interRAT_ParametersWLAN_r13(supportedBandListWLAN_r13);

    /* Creating 'laa_Parameters_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    LAA_Parameters_r13 laa_Parameters_r13(crossCarrierSchedulingLAA_DL_r13_supported, csi_RS_DRS_RRM_MeasurementsLAA_r13_supported, downlinkLAA_r13_supported, endingDwPTS_r13_supported, secondSlotStartingPosition_r13_supported, tm9_LAA_r13_supported, tm10_LAA_r13_supported);

    /* Creating 'lwa_Parameters_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'wlan_MAC_Address_r13' field of 'lwa_Parameters_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char wlan_MAC_Address_r13_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssString wlan_MAC_Address_r13(sizeof(wlan_MAC_Address_r13_value), (char *)wlan_MAC_Address_r13_value);

    /* Calling a fully-initializing constructor */
    LWA_Parameters_r13 lwa_Parameters_r13(lwa_r13_supported, lwa_SplitBearer_r13_supported, wlan_MAC_Address_r13, lwa_BufferSize_r13_supported);

    /* Creating 'wlan_IW_Parameters_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_IW_Parameters_v1310 wlan_IW_Parameters_v1310(rclwi_r13_supported);

    /* Creating 'lwip_Parameters_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    LWIP_Parameters_r13 lwip_Parameters_r13(lwip_r13_supported);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1310 fdd_Add_UE_EUTRA_Capabilities_v1310;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1310(fdd_Add_UE_EUTRA_Capabilities_v1310);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1310 tdd_Add_UE_EUTRA_Capabilities_v1310;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1310(tdd_Add_UE_EUTRA_Capabilities_v1310);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'ce_Parameters_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1320 ce_Parameters_v1320(intraFreqA3_CE_ModeA_r13_supported, intraFreqA3_CE_ModeB_r13_supported, intraFreqHO_CE_ModeA_r13_supported, intraFreqHO_CE_ModeB_r13_supported);

    /* Creating 'phyLayerParameters_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1320 phyLayerParameters_v1320;
    fill_PhyLayerParameters_v1320(phyLayerParameters_v1320);

    /* Creating 'rf_Parameters_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandListEUTRA_v1320' field of 'rf_Parameters_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandListEUTRA_v1320 supportedBandListEUTRA_v1320;
    {
	/* Adding component #2 */
	SupportedBandEUTRA_v1320 comp2;
	fill_SupportedBandEUTRA_v1320(comp2);
	supportedBandListEUTRA_v1320.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBandEUTRA_v1320 comp1;
	fill_SupportedBandEUTRA_v1320(comp1);
	supportedBandListEUTRA_v1320.prepend(comp1);
    }

    /* Creating 'supportedBandCombination_v1320' field of 'rf_Parameters_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1320 supportedBandCombination_v1320;
    fill_SupportedBandCombination_v1320(supportedBandCombination_v1320);

    /* Creating 'supportedBandCombinationAdd_v1320' field of 'rf_Parameters_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1320 supportedBandCombinationAdd_v1320;
    fill_SupportedBandCombination_v1320(supportedBandCombinationAdd_v1320);

    /* Creating 'supportedBandCombinationReduced_v1320' field of 'rf_Parameters_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationReduced_v1320 supportedBandCombinationReduced_v1320;
    fill_SupportedBandCombination_v1320(supportedBandCombinationReduced_v1320);

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1320 rf_Parameters_v1320(supportedBandListEUTRA_v1320, supportedBandCombination_v1320, supportedBandCombinationAdd_v1320, supportedBandCombinationReduced_v1320);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1320 fdd_Add_UE_EUTRA_Capabilities_v1320;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1320(fdd_Add_UE_EUTRA_Capabilities_v1320);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1320 tdd_Add_UE_EUTRA_Capabilities_v1320;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1320(tdd_Add_UE_EUTRA_Capabilities_v1320);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'phyLayerParameters_v1330' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1330 phyLayerParameters_v1330(cch_InterfMitigation_RefRecTypeA_r13_supported, cch_InterfMitigation_RefRecTypeB_r13_supported, 1, 1);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'ce_Parameters_v1350' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1350 ce_Parameters_v1350(unicastFrequencyHopping_r13_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'other_Parameters_v1360' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    Other_Parameters_v1360 other_Parameters_v1360(inDeviceCoexInd_HardwareSharingInd_r13_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'phyLayerParameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PhyLayerParameters_v1430 phyLayerParameters_v1430;
    fill_PhyLayerParameters_v1430(phyLayerParameters_v1430);

    /* Creating 'mac_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MAC_Parameters_v1430 mac_Parameters_v1430(shortSPS_IntervalFDD_r14_supported, shortSPS_IntervalTDD_r14_supported, skipUplinkDynamic_r14_supported, skipUplinkSPS_r14_supported, multipleUplinkSPS_r14_supported, MAC_Parameters_v1430_dataInactMon_r14_supported);

    /* Creating 'measParameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MeasParameters_v1430 measParameters_v1430(ceMeasurements_r14_supported, ncsg_r14_supported, shortMeasurementGap_r14_supported, perServingCellMeasurementGap_r14_supported, nonUniformGap_r14_supported);

    /* Creating 'pdcp_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedUplinkOnlyROHC_Profiles_r14' field of 'pdcp_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_v1430::supportedUplinkOnlyROHC_Profiles_r14 supportedUplinkOnlyROHC_Profiles_r14(TRUE);

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_v1430 pdcp_Parameters_v1430(supportedUplinkOnlyROHC_Profiles_r14, maxNumberROHC_ContextSessions_r14_cs2);

    /* Creating 'rlc_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    RLC_Parameters_v1430 rlc_Parameters_v1430(extendedPollByte_r14_supported);

    /* Creating 'rf_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1430' field of 'rf_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1430 supportedBandCombination_v1430;
    fill_SupportedBandCombination_v1430(supportedBandCombination_v1430);

    /* Creating 'supportedBandCombinationAdd_v1430' field of 'rf_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1430 supportedBandCombinationAdd_v1430;
    fill_SupportedBandCombination_v1430(supportedBandCombinationAdd_v1430);

    /* Creating 'supportedBandCombinationReduced_v1430' field of 'rf_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationReduced_v1430 supportedBandCombinationReduced_v1430;
    fill_SupportedBandCombination_v1430(supportedBandCombinationReduced_v1430);

    /* Creating 'eNB_RequestedParameters_v1430' field of 'rf_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'requestedDiffFallbackCombList_r14' field of 'eNB_RequestedParameters_v1430' field of 'rf_Parameters_v1430' field of 'nonCriticalExtension' field... */
    BandCombinationList_r14 requestedDiffFallbackCombList_r14;
    {
	/* Adding component #2 */
	BandCombination_r14 comp2;
	fill_BandCombination_r14(comp2);
	requestedDiffFallbackCombList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BandCombination_r14 comp1;
	fill_BandCombination_r14(comp1);
	requestedDiffFallbackCombList_r14.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1430::eNB_RequestedParameters_v1430 eNB_RequestedParameters_v1430(requestedDiffFallbackCombList_r14);

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1430 rf_Parameters_v1430(supportedBandCombination_v1430, supportedBandCombinationAdd_v1430, supportedBandCombinationReduced_v1430, eNB_RequestedParameters_v1430, diffFallbackCombReport_r14_supported);

    /* Creating 'laa_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    LAA_Parameters_v1430 laa_Parameters_v1430(crossCarrierSchedulingLAA_UL_r14_supported, uplinkLAA_r14_supported, nPlus1, uss_BlindDecodingAdjustment_r14_supported, uss_BlindDecodingReduction_r14_supported, outOfSequenceGrantHandling_r14_supported);

    /* Creating 'lwa_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    LWA_Parameters_v1430 lwa_Parameters_v1430(lwa_HO_WithoutWT_Change_r14_supported, lwa_UL_r14_supported, wlan_PeriodicMeas_r14_supported, wlan_ReportAnyWLAN_r14_supported, 1);

    /* Creating 'lwip_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    LWIP_Parameters_v1430 lwip_Parameters_v1430(lwip_Aggregation_DL_r14_supported, lwip_Aggregation_UL_r14_supported);

    /* Creating 'otherParameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    Other_Parameters_v1430 otherParameters_v1430(bwPrefInd_r14_supported, rlm_ReportSupport_r14_supported);

    /* Creating 'mmtel_Parameters_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MMTEL_Parameters_r14 mmtel_Parameters_r14;
    fill_MMTEL_Parameters_r14(mmtel_Parameters_r14);

    /* Creating 'mobilityParameters_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MobilityParameters_r14 mobilityParameters_r14(makeBeforeBreak_r14_supported, rach_Less_r14_supported);

    /* Creating 'ce_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CE_Parameters_v1430 ce_Parameters_v1430(ce_SwitchWithoutHO_r14_supported);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1430 fdd_Add_UE_EUTRA_Capabilities_v1430;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1430(fdd_Add_UE_EUTRA_Capabilities_v1430);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1430 tdd_Add_UE_EUTRA_Capabilities_v1430;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1430(tdd_Add_UE_EUTRA_Capabilities_v1430);

    /* Creating 'mbms_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MBMS_Parameters_v1430 mbms_Parameters_v1430(fembmsDedicatedCell_r14_supported, fembmsMixedCell_r14_supported, subcarrierSpacingMBMS_khz7dot5_r14_supported, subcarrierSpacingMBMS_khz1dot25_r14_supported);

    /* Creating 'sl_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'v2x_SupportedBandCombinationList_r14' field of 'sl_Parameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    V2X_SupportedBandCombination_r14 v2x_SupportedBandCombinationList_r14;
    {
	/* Adding component #2 */
	V2X_BandCombinationParameters_r14 comp2;
	fill_V2X_BandCombinationParameters_r14(comp2);
	v2x_SupportedBandCombinationList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	V2X_BandCombinationParameters_r14 comp1;
	fill_V2X_BandCombinationParameters_r14(comp1);
	v2x_SupportedBandCombinationList_r14.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_Parameters_v1430 sl_Parameters_v1430(zoneBasedPoolSelection_r14_supported, ue_AutonomousWithFullSensing_r14_supported, ue_AutonomousWithPartialSensing_r14_supported, sl_CongestionControl_r14_supported, v2x_TxWithShortResvInterval_r14_supported, 1, v2x_nonAdjacentPSCCH_PSSCH_r14_supported, slss_TxRx_r14_supported, v2x_SupportedBandCombinationList_r14);

    /* Creating 'ue_BasedNetwPerfMeasParameters_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    UE_BasedNetwPerfMeasParameters_v1430 ue_BasedNetwPerfMeasParameters_v1430(locationReport_r14_supported);

    /* Creating 'highSpeedEnhParameters_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    HighSpeedEnhParameters_r14 highSpeedEnhParameters_r14(measurementEnhancements_r14_supported, demodulationEnhancements_r14_supported, prach_Enhancements_r14_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'lwa_Parameters_v1440' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    LWA_Parameters_v1440 lwa_Parameters_v1440(lwa_RLC_UM_r14_supported);

    /* Creating 'mac_Parameters_v1440' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MAC_Parameters_v1440 mac_Parameters_v1440(MAC_Parameters_v1440_rai_Support_r14_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'phyLayerParameters_v1450' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1450 phyLayerParameters_v1450(ce_SRS_EnhancementWithoutComb4_r14_supported, crs_LessDwPTS_r14_supported);

    /* Creating 'rf_Parameters_v1450' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1450' field of 'rf_Parameters_v1450' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1450 supportedBandCombination_v1450;
    fill_SupportedBandCombination_v1450(supportedBandCombination_v1450);

    /* Creating 'supportedBandCombinationAdd_v1450' field of 'rf_Parameters_v1450' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1450 supportedBandCombinationAdd_v1450;
    fill_SupportedBandCombination_v1450(supportedBandCombinationAdd_v1450);

    /* Creating 'supportedBandCombinationReduced_v1450' field of 'rf_Parameters_v1450' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationReduced_v1450 supportedBandCombinationReduced_v1450;
    fill_SupportedBandCombination_v1450(supportedBandCombinationReduced_v1450);

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1450 rf_Parameters_v1450(supportedBandCombination_v1450, supportedBandCombinationAdd_v1450, supportedBandCombinationReduced_v1450);

    /* Creating 'otherParameters_v1450' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    OtherParameters_v1450 otherParameters_v1450(overheatingInd_r14_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'otherParameters_v1460' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    Other_Parameters_v1460 otherParameters_v1460(nonCSG_SI_Reporting_r14_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'irat_ParametersNR_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandListNR_r15' field of 'irat_ParametersNR_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandListNR_r15 supportedBandListNR_r15;
    {
	/* Adding component #2 */
	SupportedBandNR_r15 comp2;
	fill_SupportedBandNR_r15(comp2);
	supportedBandListNR_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBandNR_r15 comp1;
	fill_SupportedBandNR_r15(comp1);
	supportedBandListNR_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    IRAT_ParametersNR_r15 irat_ParametersNR_r15(en_DC_r15_supported, eventB2_r15_supported, supportedBandListNR_r15);

    /* Creating 'featureSetsEUTRA_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'featureSetsDL_r15' field of 'featureSetsEUTRA_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    FeatureSetsEUTRA_r15::featureSetsDL_r15 featureSetsDL_r15;
    {
	/* Adding component #2 */
	FeatureSetDL_r15 comp2;
	fill_FeatureSetDL_r15(comp2);
	featureSetsDL_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	FeatureSetDL_r15 comp1;
	fill_FeatureSetDL_r15(comp1);
	featureSetsDL_r15.prepend(comp1);
    }

    /* Creating 'featureSetsDL_PerCC_r15' field of 'featureSetsEUTRA_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    FeatureSetsEUTRA_r15::featureSetsDL_PerCC_r15 featureSetsDL_PerCC_r15;
    {
	/* Adding component #2 */
	FeatureSetDL_PerCC_r15 comp2;
	fill_FeatureSetDL_PerCC_r15(comp2);
	featureSetsDL_PerCC_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	FeatureSetDL_PerCC_r15 comp1;
	fill_FeatureSetDL_PerCC_r15(comp1);
	featureSetsDL_PerCC_r15.prepend(comp1);
    }

    /* Creating 'featureSetsUL_r15' field of 'featureSetsEUTRA_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    FeatureSetsEUTRA_r15::featureSetsUL_r15 featureSetsUL_r15;
    {
	/* Adding component #2 */
	FeatureSetUL_r15 comp2;
	fill_FeatureSetUL_r15(comp2);
	featureSetsUL_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	FeatureSetUL_r15 comp1;
	fill_FeatureSetUL_r15(comp1);
	featureSetsUL_r15.prepend(comp1);
    }

    /* Creating 'featureSetsUL_PerCC_r15' field of 'featureSetsEUTRA_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    FeatureSetsEUTRA_r15::featureSetsUL_PerCC_r15 featureSetsUL_PerCC_r15;
    {
	/* Adding component #2 */
	FeatureSetUL_PerCC_r15 comp2;
	fill_FeatureSetUL_PerCC_r15(comp2);
	featureSetsUL_PerCC_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	FeatureSetUL_PerCC_r15 comp1;
	fill_FeatureSetUL_PerCC_r15(comp1);
	featureSetsUL_PerCC_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    FeatureSetsEUTRA_r15 featureSetsEUTRA_r15(featureSetsDL_r15, featureSetsDL_PerCC_r15, featureSetsUL_r15, featureSetsUL_PerCC_r15);

    /* Creating 'pdcp_ParametersNR_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PDCP_ParametersNR_r15 pdcp_ParametersNR_r15;
    fill_PDCP_ParametersNR_r15(pdcp_ParametersNR_r15);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1510' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1510 fdd_Add_UE_EUTRA_Capabilities_v1510;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1510(fdd_Add_UE_EUTRA_Capabilities_v1510);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1510' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1510 tdd_Add_UE_EUTRA_Capabilities_v1510;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1510(tdd_Add_UE_EUTRA_Capabilities_v1510);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'measParameters_v1520' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'measGapPatterns_v1520' field of 'measParameters_v1520' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char measGapPatterns_v1520_value[] = {
	0x00
    };
    OssBitString measGapPatterns_v1520(8, measGapPatterns_v1520_value);

    /* Calling a fully-initializing constructor */
    MeasParameters_v1520 measParameters_v1520(measGapPatterns_v1520);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'measParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MeasParameters_v1530 measParameters_v1530(qoe_MeasReport_r15_supported, qoe_MTSI_MeasReport_r15_supported, ca_IdleModeMeasurements_r15_supported, ca_IdleModeValidityArea_r15_supported, heightMeas_r15_supported, multipleCellsMeasExtension_r15_supported);

    /* Creating 'otherParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    Other_Parameters_v1530 otherParameters_v1530(assistInfoBitForLC_r15_supported, timeReferenceProvision_r15_supported, flightPathPlan_r15_supported);

    /* Creating 'neighCellSI_AcquisitionParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    NeighCellSI_AcquisitionParameters_v1530 neighCellSI_AcquisitionParameters_v1530;
    fill_NeighCellSI_AcquisitionParameters_v1530(neighCellSI_AcquisitionParameters_v1530);

    /* Creating 'mac_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'min_Proc_TimelineSubslot_r15' field of 'mac_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MAC_Parameters_v1530::min_Proc_TimelineSubslot_r15 min_Proc_TimelineSubslot_r15;
    min_Proc_TimelineSubslot_r15.prepend(set1);
    min_Proc_TimelineSubslot_r15.prepend(set1);

    /* Creating 'skipSubframeProcessing_r15' field of 'mac_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    SkipSubframeProcessing_r15 skipSubframeProcessing_r15(0, 0, 0, 0);

    /* Calling a fully-initializing constructor */
    MAC_Parameters_v1530 mac_Parameters_v1530(min_Proc_TimelineSubslot_r15, skipSubframeProcessing_r15, MAC_Parameters_v1530_earlyData_UP_r15_supported, dormantSCellState_r15_supported, directSCellActivation_r15_supported, directSCellHibernation_r15_supported, extendedLCID_Duplication_r15_supported, sps_ServingCell_r15_supported);

    /* Creating 'phyLayerParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'stti_SPT_Capabilities_r15' field of 'phyLayerParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'mimo_UE_ParametersSTTI_r15' field of 'stti_SPT_Capabilities_r15' field of 'phyLayerParameters_v1530' field of 'nonCriticalExtension' field... */
    MIMO_UE_Parameters_r13 mimo_UE_ParametersSTTI_r15;
    fill_MIMO_UE_Parameters_r13(mimo_UE_ParametersSTTI_r15);

    /* Creating 'mimo_UE_ParametersSTTI_v1530' field of 'stti_SPT_Capabilities_r15' field of 'phyLayerParameters_v1530' field of 'nonCriticalExtension' field... */
    MIMO_UE_Parameters_v1430 mimo_UE_ParametersSTTI_v1530;
    fill_MIMO_UE_Parameters_v1430(mimo_UE_ParametersSTTI_v1530);

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1530::stti_SPT_Capabilities_r15 stti_SPT_Capabilities_r15(aperiodicCsi_ReportingSTTI_r15_supported, dmrs_BasedSPDCCH_MBSFN_r15_supported, dmrs_BasedSPDCCH_nonMBSFN_r15_supported, dmrs_PositionPattern_r15_supported, dmrs_SharingSubslotPDSCH_r15_supported, dmrs_RepetitionSubslotPDSCH_r15_supported, epdcch_SPT_differentCells_r15_supported, epdcch_STTI_differentCells_r15_supported, oneLayer, 5, 1, 1, 1, 1, mimo_UE_ParametersSTTI_r15, mimo_UE_ParametersSTTI_v1530, 4, pdsch_SlotSubslotPDSCH_Decoding_r15_supported, powerUCI_SlotPUSCH_supported, powerUCI_SubslotPUSCH_supported, slotPDSCH_TxDiv_TM9and10_supported, subslotPDSCH_TxDiv_TM9and10_supported, spdcch_differentRS_types_r15_supported, srs_DCI7_TriggeringFS2_r15_supported, sps_cyclicShift_r15_supported, spdcch_Reuse_r15_supported, sps_STTI_r15_slot, tm8_slotPDSCH_r15_supported, tm9_slotSubslot_r15_supported, tm9_slotSubslotMBSFN_r15_supported, tm10_slotSubslot_r15_supported, tm10_slotSubslotMBSFN_r15_supported, txDiv_SPUCCH_r15_supported, ul_AsyncHarqSharingDiff_TTI_Lengths_r15_supported);

    /* Creating 'ce_Capabilities_r15' field of 'phyLayerParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1530::ce_Capabilities_r15 ce_Capabilities_r15(ce_CRS_IntfMitig_r15_supported, ce_CQI_AlternativeTable_r15_supported, ce_PDSCH_FlexibleStartPRB_CE_ModeA_r15_supported, ce_PDSCH_FlexibleStartPRB_CE_ModeB_r15_supported, ce_PDSCH_64QAM_r15_supported, ce_PUSCH_FlexibleStartPRB_CE_ModeA_r15_supported, ce_PUSCH_FlexibleStartPRB_CE_ModeB_r15_supported, ce_PUSCH_SubPRB_Allocation_r15_supported, ce_UL_HARQ_ACK_Feedback_r15_supported);

    /* Creating 'urllc_Capabilities_r15' field of 'phyLayerParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1530::urllc_Capabilities_r15 urllc_Capabilities_r15(pdsch_RepSubframe_r15_supported, pdsch_RepSlot_r15_supported, pdsch_RepSubslot_r15_supported, 0, 0, 0, 0, 0, 0, pusch_SPS_SlotRepPCell_r15_supported, pusch_SPS_SlotRepPSCell_r15_supported, pusch_SPS_SlotRepSCell_r15_supported, pusch_SPS_SubframeRepPCell_r15_supported, pusch_SPS_SubframeRepPSCell_r15_supported, pusch_SPS_SubframeRepSCell_r15_supported, pusch_SPS_SubslotRepPCell_r15_supported, pusch_SPS_SubslotRepPSCell_r15_supported, pusch_SPS_SubslotRepSCell_r15_supported, semiStaticCFI_r15_supported, semiStaticCFI_Pattern_r15_supported);

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_v1530 phyLayerParameters_v1530(stti_SPT_Capabilities_r15, ce_Capabilities_r15, shortCQI_ForSCellActivation_r15_supported, mimo_CBSR_AdvancedCSI_r15_supported, crs_IntfMitig_r15_supported, ul_PowerControlEnhancements_r15_supported, urllc_Capabilities_r15, altMCS_Table_r15_supported);

    /* Creating 'rf_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedBandCombination_v1530' field of 'rf_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombination_v1530 supportedBandCombination_v1530;
    fill_SupportedBandCombination_v1530(supportedBandCombination_v1530);

    /* Creating 'supportedBandCombinationAdd_v1530' field of 'rf_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationAdd_v1530 supportedBandCombinationAdd_v1530;
    fill_SupportedBandCombination_v1530(supportedBandCombinationAdd_v1530);

    /* Creating 'supportedBandCombinationReduced_v1530' field of 'rf_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SupportedBandCombinationReduced_v1530 supportedBandCombinationReduced_v1530;
    fill_SupportedBandCombination_v1530(supportedBandCombinationReduced_v1530);

    /* Calling a fully-initializing constructor */
    RF_Parameters_v1530 rf_Parameters_v1530(sTTI_SPT_Supported_r15_supported, supportedBandCombination_v1530, supportedBandCombinationAdd_v1530, supportedBandCombinationReduced_v1530, powerClass_14dBm_r15_supported);

    /* Creating 'pdcp_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedUDC_r15' field of 'pdcp_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'supportedOperatorDic_r15' field of 'supportedUDC_r15' field of 'pdcp_Parameters_v1530' field of 'nonCriticalExtension' field... */
    /* Creating 'associatedPLMN_ID_r15' field of 'supportedOperatorDic_r15' field of 'supportedUDC_r15' field of 'pdcp_Parameters_v1530' field... */
    PLMN_Identity associatedPLMN_ID_r15;
    fill_PLMN_Identity(associatedPLMN_ID_r15);

    /* Calling a fully-initializing constructor */
    SupportedOperatorDic_r15 supportedOperatorDic_r15(0, associatedPLMN_ID_r15);

    /* Calling a fully-initializing constructor */
    SupportedUDC_r15 supportedUDC_r15(supportedStandardDic_r15_supported, supportedOperatorDic_r15);

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_v1530 pdcp_Parameters_v1530(supportedUDC_r15, pdcp_Duplication_r15_supported);

    /* Creating 'ue_BasedNetwPerfMeasParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    UE_BasedNetwPerfMeasParameters_v1530 ue_BasedNetwPerfMeasParameters_v1530(loggedMeasBT_r15_supported, loggedMeasWLAN_r15_supported, immMeasBT_r15_supported, immMeasWLAN_r15_supported);

    /* Creating 'rlc_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    RLC_Parameters_v1530 rlc_Parameters_v1530(flexibleUM_AM_Combinations_r15_supported, rlc_AM_Ooo_Delivery_r15_supported, rlc_UM_Ooo_Delivery_r15_supported);

    /* Creating 'sl_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'ue_CategorySL_r15' field of 'sl_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    UE_CategorySL_r15 ue_CategorySL_r15(1, 1);

    /* Creating 'v2x_SupportedBandCombinationList_v1530' field of 'sl_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    V2X_SupportedBandCombination_v1530 v2x_SupportedBandCombinationList_v1530;
    {
	/* Adding component #2 */
	V2X_BandCombinationParameters_v1530 comp2;
	fill_V2X_BandCombinationParameters_v1530(comp2);
	v2x_SupportedBandCombinationList_v1530.prepend(comp2);
    }
    {
	/* Adding component #1 */
	V2X_BandCombinationParameters_v1530 comp1;
	fill_V2X_BandCombinationParameters_v1530(comp1);
	v2x_SupportedBandCombinationList_v1530.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_Parameters_v1530 sl_Parameters_v1530(slss_SupportedTxFreq_r15_single, sl_64QAM_Tx_r15_supported, sl_TxDiversity_r15_supported, ue_CategorySL_r15, v2x_SupportedBandCombinationList_v1530);

    /* Creating 'laa_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    LAA_Parameters_v1530 laa_Parameters_v1530(aul_r15_supported, laa_PUSCH_Mode1_r15_supported, laa_PUSCH_Mode2_r15_supported, laa_PUSCH_Mode3_r15_supported);

    /* Creating 'fdd_Add_UE_EUTRA_Capabilities_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1530 fdd_Add_UE_EUTRA_Capabilities_v1530;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1530(fdd_Add_UE_EUTRA_Capabilities_v1530);

    /* Creating 'tdd_Add_UE_EUTRA_Capabilities_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_CapabilityAddXDD_Mode_v1530 tdd_Add_UE_EUTRA_Capabilities_v1530;
    fill_UE_EUTRA_CapabilityAddXDD_Mode_v1530(tdd_Add_UE_EUTRA_Capabilities_v1530);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_EUTRA_Capability_v1530_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1530_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(measParameters_v1530, otherParameters_v1530, neighCellSI_AcquisitionParameters_v1530, mac_Parameters_v1530, phyLayerParameters_v1530, rf_Parameters_v1530, pdcp_Parameters_v1530, 22, ue_BasedNetwPerfMeasParameters_v1530, rlc_Parameters_v1530, sl_Parameters_v1530, extendedNumberOfDRBs_r15_supported, UE_EUTRA_Capability_v1530_IEs_reducedCP_Latency_r15_supported, laa_Parameters_v1530, 22, fdd_Add_UE_EUTRA_Capabilities_v1530, tdd_Add_UE_EUTRA_Capabilities_v1530, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1520_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(measParameters_v1520, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1510_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(irat_ParametersNR_r15, featureSetsEUTRA_r15, pdcp_ParametersNR_r15, fdd_Add_UE_EUTRA_Capabilities_v1510, tdd_Add_UE_EUTRA_Capabilities_v1510, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1460_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(21, otherParameters_v1460, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1450_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(phyLayerParameters_v1450, rf_Parameters_v1450, otherParameters_v1450, 20, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1440_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(lwa_Parameters_v1440, mac_Parameters_v1440, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1430_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(phyLayerParameters_v1430, ue_CategoryDL_v1430_m2, ue_CategoryUL_v1430_n16, n21, mac_Parameters_v1430, measParameters_v1430, pdcp_Parameters_v1430, rlc_Parameters_v1430, rf_Parameters_v1430, laa_Parameters_v1430, lwa_Parameters_v1430, lwip_Parameters_v1430, otherParameters_v1430, mmtel_Parameters_r14, mobilityParameters_r14, ce_Parameters_v1430, fdd_Add_UE_EUTRA_Capabilities_v1430, tdd_Add_UE_EUTRA_Capabilities_v1430, mbms_Parameters_v1430, sl_Parameters_v1430, ue_BasedNetwPerfMeasParameters_v1430, highSpeedEnhParameters_r14, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1360_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(other_Parameters_v1360, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1350_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(ue_CategoryDL_v1350_oneBis, ue_CategoryUL_v1350_oneBis, ce_Parameters_v1350, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1340_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(15, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1330_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(18, phyLayerParameters_v1330, UE_EUTRA_Capability_v1330_IEs_ue_CE_NeedULGaps_r13_true, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1320_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(ce_Parameters_v1320, phyLayerParameters_v1320, rf_Parameters_v1320, fdd_Add_UE_EUTRA_Capabilities_v1320, tdd_Add_UE_EUTRA_Capabilities_v1320, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1310_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(ue_CategoryDL_v1310_n17, ue_CategoryUL_v1310_n14, pdcp_Parameters_v1310, rlc_Parameters_v1310, mac_Parameters_v1310, phyLayerParameters_v1310, rf_Parameters_v1310, measParameters_v1310, dc_Parameters_v1310, sl_Parameters_v1310, scptm_Parameters_r13, ce_Parameters_r13, interRAT_ParametersWLAN_r13, laa_Parameters_r13, lwa_Parameters_r13, wlan_IW_Parameters_v1310, lwip_Parameters_r13, fdd_Add_UE_EUTRA_Capabilities_v1310, tdd_Add_UE_EUTRA_Capabilities_v1310, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1280_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(phyLayerParameters_v1280, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1270_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v1270, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1260_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(15, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1250_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(phyLayerParameters_v1250, rf_Parameters_v1250, rlc_Parameters_r12, ue_BasedNetwPerfMeasParameters_v1250, 0, 0, wlan_IW_Parameters_r12, measParameters_v1250, dc_Parameters_r12, mbms_Parameters_v1250, mac_Parameters_r12, fdd_Add_UE_EUTRA_Capabilities_v1250, tdd_Add_UE_EUTRA_Capabilities_v1250, sl_Parameters_r12, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v11a0_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(11, measParameters_v11a0, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1180_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v1180, mbms_Parameters_r11, fdd_Add_UE_EUTRA_Capabilities_v1180, tdd_Add_UE_EUTRA_Capabilities_v1180, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1170_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(phyLayerParameters_v1170, 9, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1130_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(pdcp_Parameters_v1130, phyLayerParameters_v1130, rf_Parameters_v1130, measParameters_v1130, interRAT_ParametersCDMA2000_v1130, otherParameters_r11, fdd_Add_UE_EUTRA_Capabilities_v1130, tdd_Add_UE_EUTRA_Capabilities_v1130, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1090_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(rf_Parameters_v1090, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1060_IEs result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(fdd_Add_UE_EUTRA_Capabilities_v1060, tdd_Add_UE_EUTRA_Capabilities_v1060, rf_Parameters_v1060, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v1020_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(6, phyLayerParameters_v1020, rf_Parameters_v1020, measParameters_v1020, featureGroupIndRel10_r10, interRAT_ParametersCDMA2000_v1020, ue_BasedNetwPerfMeasParameters_r10, interRAT_ParametersUTRA_TDD_v1020, result_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v940_IEs nonCriticalExtension_nonCriticalExtension(lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_EUTRA_Capability_v920_IEs nonCriticalExtension(phyLayerParameters_v920, interRAT_ParametersGERAN_v920, interRAT_ParametersUTRA_v920, interRAT_ParametersCDMA2000_v920, noBenFromBatConsumpOpt, csg_ProximityIndicationParameters_r9, neighCellSI_AcquisitionParameters_r9, son_Parameters_r9, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    return new UE_EUTRA_Capability(rel8, 1, pdcp_Parameters, phyLayerParameters, rf_Parameters, measParameters, featureGroupIndicators, interRAT_Parameters, nonCriticalExtension);
}

static void fill_TDD_ConfigSL_r12(TDD_ConfigSL_r12 & value)
{
    value.set_subframeAssignmentSL_r12(none);
}

SBCCH_SL_BCH_Message *create_samplevalue_SBCCH_SL_BCH_Message()
{
    /* Creating 'message' field */
    /* Creating 'tdd_ConfigSL_r12' field of 'message' field */
    TDD_ConfigSL_r12 tdd_ConfigSL_r12;
    fill_TDD_ConfigSL_r12(tdd_ConfigSL_r12);

    /* Creating 'directFrameNumber_r12' field of 'message' field */
    static unsigned char directFrameNumber_r12_value[] = {
	0x00, 0x00
    };
    OssBitString directFrameNumber_r12(10, directFrameNumber_r12_value);

    /* Creating 'reserved_r12' field of 'message' field */
    static unsigned char reserved_r12_value[] = {
	0x00, 0x00, 0x00
    };
    OssBitString reserved_r12(19, reserved_r12_value);

    /* Calling a fully-initializing constructor */
    SBCCH_SL_BCH_MessageType message(sl_Bandwidth_r12_n6, tdd_ConfigSL_r12, directFrameNumber_r12, 0, TRUE, reserved_r12);

    /* Calling a fully-initializing constructor */
    return new SBCCH_SL_BCH_Message(message);
}

SBCCH_SL_BCH_Message_V2X_r14 *create_samplevalue_SBCCH_SL_BCH_Message_V2X_r14()
{
    /* Creating 'message' field */
    /* Creating 'tdd_ConfigSL_r14' field of 'message' field */
    TDD_ConfigSL_r12 tdd_ConfigSL_r14;
    fill_TDD_ConfigSL_r12(tdd_ConfigSL_r14);

    /* Creating 'directFrameNumber_r14' field of 'message' field */
    static unsigned char directFrameNumber_r14_value[] = {
	0x00, 0x00
    };
    OssBitString directFrameNumber_r14(10, directFrameNumber_r14_value);

    /* Creating 'reserved_r14' field of 'message' field */
    static unsigned char reserved_r14_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString reserved_r14(27, reserved_r14_value);

    /* Calling a fully-initializing constructor */
    SBCCH_SL_BCH_MessageType_V2X_r14 message(MasterInformationBlock_SL_V2X_r14_sl_Bandwidth_r14_n6, tdd_ConfigSL_r14, directFrameNumber_r14, 0, TRUE, reserved_r14);

    /* Calling a fully-initializing constructor */
    return new SBCCH_SL_BCH_Message_V2X_r14(message);
}

BCCH_BCH_Message_NB *create_samplevalue_BCCH_BCH_Message_NB()
{
    /* Creating 'message' field */
    /* Creating 'systemFrameNumber_MSB_r13' field of 'message' field */
    static unsigned char systemFrameNumber_MSB_r13_value[] = {
	0x00
    };
    OssBitString systemFrameNumber_MSB_r13(4, systemFrameNumber_MSB_r13_value);

    /* Creating 'hyperSFN_LSB_r13' field of 'message' field */
    static unsigned char hyperSFN_LSB_r13_value[] = {
	0x00
    };
    OssBitString hyperSFN_LSB_r13(2, hyperSFN_LSB_r13_value);

    /* Creating 'operationModeInfo_r13' field of 'message' field */
    BCCH_BCH_MessageType_NB::operationModeInfo_r13 operationModeInfo_r13;
    /* Setting 'inband_SamePCI_r13' alternative of 'operationModeInfo_r13' field of 'message' field */

    /* Calling a fully-initializing constructor */
    Inband_SamePCI_NB_r13 inband_SamePCI_r13(0);

    operationModeInfo_r13.set_inband_SamePCI_r13(inband_SamePCI_r13);

    /* Creating 'spare' field of 'message' field */
    static unsigned char spare_value[] = {
	0x00, 0x00
    };
    OssBitString spare(10, spare_value);

    /* Calling a fully-initializing constructor */
    BCCH_BCH_MessageType_NB message(systemFrameNumber_MSB_r13, hyperSFN_LSB_r13, 0, 0, TRUE, operationModeInfo_r13, TRUE, spare);

    /* Calling a fully-initializing constructor */
    return new BCCH_BCH_Message_NB(message);
}

BCCH_BCH_Message_TDD_NB *create_samplevalue_BCCH_BCH_Message_TDD_NB()
{
    /* Creating 'message' field */
    /* Creating 'systemFrameNumber_MSB_r15' field of 'message' field */
    static unsigned char systemFrameNumber_MSB_r15_value[] = {
	0x00
    };
    OssBitString systemFrameNumber_MSB_r15(4, systemFrameNumber_MSB_r15_value);

    /* Creating 'hyperSFN_LSB_r15' field of 'message' field */
    static unsigned char hyperSFN_LSB_r15_value[] = {
	0x00
    };
    OssBitString hyperSFN_LSB_r15(2, hyperSFN_LSB_r15_value);

    /* Creating 'operationModeInfo_r15' field of 'message' field */
    BCCH_BCH_MessageType_TDD_NB_r15::operationModeInfo_r15 operationModeInfo_r15;
    /* Setting 'inband_SamePCI_r15' alternative of 'operationModeInfo_r15' field of 'message' field */

    /* Calling a fully-initializing constructor */
    Inband_SamePCI_TDD_NB_r15 inband_SamePCI_r15(0, Inband_SamePCI_TDD_NB_r15_sib_InbandLocation_r15_lower);

    operationModeInfo_r15.set_inband_SamePCI_r15(inband_SamePCI_r15);

    /* Creating 'spare' field of 'message' field */
    static unsigned char spare_value[] = {
	0x00, 0x00
    };
    OssBitString spare(9, spare_value);

    /* Calling a fully-initializing constructor */
    BCCH_BCH_MessageType_TDD_NB_r15 message(systemFrameNumber_MSB_r15, hyperSFN_LSB_r15, 0, 0, TRUE, operationModeInfo_r15, sib1_CarrierInfo_r15_anchor, spare);

    /* Calling a fully-initializing constructor */
    return new BCCH_BCH_Message_TDD_NB(message);
}

static void fill_RACH_Info_NB_r13(RACH_Info_NB_r13 & value)
{
    value.set_ra_ResponseWindowSize_r13(ra_ResponseWindowSize_r13_pp2);
    value.set_mac_ContentionResolutionTimer_r13(mac_ContentionResolutionTimer_r13_pp1);
}

static void fill_RACH_Info_NB_v1530(RACH_Info_NB_v1530 & value)
{
    value.set_mac_ContentionResolutionTimer_r15(mac_ContentionResolutionTimer_r15_pp1);
}

static void fill_NPRACH_Parameters_NB_r13(NPRACH_Parameters_NB_r13 & value)
{
    value.set_nprach_Periodicity_r13(nprach_Periodicity_r13_ms40);
    value.set_nprach_StartTime_r13(nprach_StartTime_r13_ms8);
    value.set_nprach_SubcarrierOffset_r13(nprach_SubcarrierOffset_r13_n0);
    value.set_nprach_NumSubcarriers_r13(nprach_NumSubcarriers_r13_n12);
    value.set_nprach_SubcarrierMSG3_RangeStart_r13(nprach_SubcarrierMSG3_RangeStart_r13_zero);
    value.set_maxNumPreambleAttemptCE_r13(NPRACH_Parameters_NB_r13_maxNumPreambleAttemptCE_r13_n3);
    value.set_numRepetitionsPerPreambleAttempt_r13(numRepetitionsPerPreambleAttempt_r13_n1);
    value.set_npdcch_NumRepetitions_RA_r13(npdcch_NumRepetitions_RA_r13_r1);
    value.set_npdcch_StartSF_CSS_RA_r13(npdcch_StartSF_CSS_RA_r13_v1dot5);
    value.set_npdcch_Offset_RA_r13(npdcch_Offset_RA_r13_zero);
}

static void fill_NPRACH_Parameters_NB_v1330(NPRACH_Parameters_NB_v1330 & value)
{
    value.set_nprach_NumCBRA_StartSubcarriers_r13(nprach_NumCBRA_StartSubcarriers_r13_n8);
}

static void fill_NPRACH_ParametersTDD_NB_r15(NPRACH_ParametersTDD_NB_r15 & value)
{
    /* Setting 'nprach_Parameters_r15' field */

    /* Calling a fully-initializing constructor */
    NPRACH_ParametersTDD_NB_r15::nprach_Parameters_r15 nprach_Parameters_r15(NPRACH_ParametersTDD_NB_r15_nprach_Parameters_r15_nprach_Periodicity_r15_ms80, nprach_StartTime_r15_ms10, NPRACH_ParametersTDD_NB_r15_nprach_Parameters_r15_nprach_SubcarrierOffset_r15_n0, nprach_NumSubcarriers_r15_n12, NPRACH_ParametersTDD_NB_r15_nprach_Parameters_r15_nprach_SubcarrierMSG3_RangeStart_r15_zero, NPRACH_ParametersTDD_NB_r15_nprach_Parameters_r15_npdcch_NumRepetitions_RA_r15_r1, NPRACH_ParametersTDD_NB_r15_nprach_Parameters_r15_npdcch_StartSF_CSS_RA_r15_v4, NPRACH_ParametersTDD_NB_r15_nprach_Parameters_r15_npdcch_Offset_RA_r15_zero, nprach_NumCBRA_StartSubcarriers_r15_n8);

    value.set_nprach_Parameters_r15(nprach_Parameters_r15);
}

static void fill_NPRACH_ParametersFmt2_NB_r15(NPRACH_ParametersFmt2_NB_r15 & value)
{
    /* Setting 'nprach_Parameters_r15' field */

    /* Calling a fully-initializing constructor */
    NPRACH_ParametersFmt2_NB_r15::nprach_Parameters_r15 nprach_Parameters_r15(nprach_Periodicity_r15_ms40, nprach_StartTime_r15_ms8, NPRACH_ParametersFmt2_NB_r15_nprach_Parameters_r15_nprach_SubcarrierOffset_r15_n0, NPRACH_ParametersFmt2_NB_r15_nprach_Parameters_r15_nprach_NumSubcarriers_r15_n36, NPRACH_ParametersFmt2_NB_r15_nprach_Parameters_r15_nprach_SubcarrierMSG3_RangeStart_r15_zero, NPRACH_ParametersFmt2_NB_r15_nprach_Parameters_r15_npdcch_NumRepetitions_RA_r15_r1, npdcch_StartSF_CSS_RA_r15_v1dot5, NPRACH_ParametersFmt2_NB_r15_nprach_Parameters_r15_npdcch_Offset_RA_r15_zero, NPRACH_ParametersFmt2_NB_r15_nprach_Parameters_r15_nprach_NumCBRA_StartSubcarriers_r15_n24, 1);

    value.set_nprach_Parameters_r15(nprach_Parameters_r15);
}

static void fill_NPRACH_ParametersListFmt2_NB_r15(NPRACH_ParametersListFmt2_NB_r15 & value)
{
    {
	/* Adding component #2 */
	NPRACH_ParametersFmt2_NB_r15 comp2;
	fill_NPRACH_ParametersFmt2_NB_r15(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NPRACH_ParametersFmt2_NB_r15 comp1;
	fill_NPRACH_ParametersFmt2_NB_r15(comp1);
	value.prepend(comp1);
    }
}

static void fill_EDT_TBS_NB_r15(EDT_TBS_NB_r15 & value)
{
    value.set_edt_SmallTBS_Enabled_r15(TRUE);
    value.set_edt_TBS_r15(EDT_TBS_NB_r15_edt_TBS_r15_b328);
}

static void fill_NPRACH_Parameters_NB_r14(NPRACH_Parameters_NB_r14 & value)
{
    /* Setting 'nprach_Parameters_r14' field */

    /* Calling a fully-initializing constructor */
    NPRACH_Parameters_NB_r14::nprach_Parameters_r14 nprach_Parameters_r14(nprach_Periodicity_r14_ms40, nprach_StartTime_r14_ms8, nprach_SubcarrierOffset_r14_n0, nprach_NumSubcarriers_r14_n12, nprach_SubcarrierMSG3_RangeStart_r14_zero, npdcch_NumRepetitions_RA_r14_r1, npdcch_StartSF_CSS_RA_r14_v1dot5, npdcch_Offset_RA_r14_zero, nprach_NumCBRA_StartSubcarriers_r14_n8, 1);

    value.set_nprach_Parameters_r14(nprach_Parameters_r14);
}

static void fill_DL_GapConfig_NB_v1530(DL_GapConfig_NB_v1530 & value)
{
    value.set_dl_GapPeriodicity_v1530(dl_GapPeriodicity_v1530_sf1024);
}

static void fill_CarrierFreq_NB_r13(CarrierFreq_NB_r13 & value)
{
    value.set_carrierFreq_r13(0);
    value.set_carrierFreqOffset_r13(v_10);
}

static void fill_data_3(SystemInformation_NB_r13_IEs::sib_TypeAndInfo_r13::component & value)
{
    /* Setting 'sib2_r13' alternative */
    /* Creating 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */
    /* Creating 'rach_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */
    /* Creating 'powerRampingParameters_r13' field of 'rach_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    PowerRampingParameters powerRampingParameters_r13;
    fill_PowerRampingParameters(powerRampingParameters_r13);

    /* Creating 'rach_InfoList_r13' field of 'rach_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    RACH_InfoList_NB_r13 rach_InfoList_r13;
    {
	/* Adding component #2 */
	RACH_Info_NB_r13 comp2;
	fill_RACH_Info_NB_r13(comp2);
	rach_InfoList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	RACH_Info_NB_r13 comp1;
	fill_RACH_Info_NB_r13(comp1);
	rach_InfoList_r13.prepend(comp1);
    }

    /* Creating 'powerRampingParameters_v1450' field of 'rach_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    /* Creating 'powerRampingParametersCE1_r14' field of 'powerRampingParameters_v1450' field of 'rach_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field... */

    /* Calling a fully-initializing constructor */
    PowerRampingParameters_NB_v1450::powerRampingParametersCE1_r14 powerRampingParametersCE1_r14(powerRampingStepCE1_r14_dB0, preambleInitialReceivedTargetPowerCE1_r14_dBm_130);

    /* Calling a fully-initializing constructor */
    PowerRampingParameters_NB_v1450 powerRampingParameters_v1450(preambleInitialReceivedTargetPower_v1450_dBm_130, powerRampingParametersCE1_r14);

    /* Creating 'rach_InfoList_v1530' field of 'rach_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    RACH_InfoList_NB_v1530 rach_InfoList_v1530;
    {
	/* Adding component #2 */
	RACH_Info_NB_v1530 comp2;
	fill_RACH_Info_NB_v1530(comp2);
	rach_InfoList_v1530.prepend(comp2);
    }
    {
	/* Adding component #1 */
	RACH_Info_NB_v1530 comp1;
	fill_RACH_Info_NB_v1530(comp1);
	rach_InfoList_v1530.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RACH_ConfigCommon_NB_r13 rach_ConfigCommon_r13(PreambleTransMax_n3, powerRampingParameters_r13, rach_InfoList_r13, 0, powerRampingParameters_v1450, rach_InfoList_v1530);

    /* Creating 'bcch_Config_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    BCCH_Config_NB_r13 bcch_Config_r13(modificationPeriodCoeff_r13_n16);

    /* Creating 'pcch_Config_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    PCCH_Config_NB_r13 pcch_Config_r13(defaultPagingCycle_r13_rf128, nB_r13_fourT, npdcch_NumRepetitionPaging_r13_r1);

    /* Creating 'nprach_Config_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */
    /* Creating 'rsrp_ThresholdsPrachInfoList_r13' field of 'nprach_Config_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    RSRP_ThresholdsNPRACH_InfoList_NB_r13 rsrp_ThresholdsPrachInfoList_r13;
    rsrp_ThresholdsPrachInfoList_r13.prepend((OSS_UINT32)0);
    rsrp_ThresholdsPrachInfoList_r13.prepend((OSS_UINT32)0);

    /* Creating 'nprach_ParametersList_r13' field of 'nprach_Config_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    NPRACH_ParametersList_NB_r13 nprach_ParametersList_r13;
    {
	/* Adding component #2 */
	NPRACH_Parameters_NB_r13 comp2;
	fill_NPRACH_Parameters_NB_r13(comp2);
	nprach_ParametersList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NPRACH_Parameters_NB_r13 comp1;
	fill_NPRACH_Parameters_NB_r13(comp1);
	nprach_ParametersList_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    NPRACH_ConfigSIB_NB_r13 nprach_Config_r13(us66dot7, rsrp_ThresholdsPrachInfoList_r13, nprach_ParametersList_r13);

    /* Creating 'npdsch_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    NPDSCH_ConfigCommon_NB_r13 npdsch_ConfigCommon_r13(50);

    /* Creating 'npusch_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */
    /* Creating 'ack_NACK_NumRepetitions_Msg4_r13' field of 'npusch_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    NPUSCH_ConfigCommon_NB_r13::ack_NACK_NumRepetitions_Msg4_r13 ack_NACK_NumRepetitions_Msg4_r13;
    ack_NACK_NumRepetitions_Msg4_r13.prepend(ACK_NACK_NumRepetitions_NB_r13_r1);
    ack_NACK_NumRepetitions_Msg4_r13.prepend(ACK_NACK_NumRepetitions_NB_r13_r1);

    /* Creating 'dmrs_Config_r13' field of 'npusch_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */

    /* Calling a fully-initializing constructor */
    NPUSCH_ConfigCommon_NB_r13::dmrs_Config_r13 dmrs_Config_r13(0, 0, 0, 0, 0);

    /* Creating 'ul_ReferenceSignalsNPUSCH_r13' field of 'npusch_ConfigCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */

    /* Calling a fully-initializing constructor */
    UL_ReferenceSignalsNPUSCH_NB_r13 ul_ReferenceSignalsNPUSCH_r13(TRUE, 0);

    /* Calling a fully-initializing constructor */
    NPUSCH_ConfigCommon_NB_r13 npusch_ConfigCommon_r13(ack_NACK_NumRepetitions_Msg4_r13, srs_SubframeConfig_r13_sc0, dmrs_Config_r13, ul_ReferenceSignalsNPUSCH_r13);

    /* Creating 'dl_Gap_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    DL_GapConfig_NB_r13 dl_Gap_r13(dl_GapThreshold_r13_n32, dl_GapPeriodicity_r13_sf64, dl_GapDurationCoeff_r13_oneEighth);

    /* Creating 'uplinkPowerControlCommon_r13' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommon_NB_r13 uplinkPowerControlCommon_r13(24, alpha_r13_al0, -1);

    /* Creating 'nprach_Config_v1330' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */
    /* Creating 'nprach_ParametersList_v1330' field of 'nprach_Config_v1330' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    NPRACH_ParametersList_NB_v1330 nprach_ParametersList_v1330;
    {
	/* Adding component #2 */
	NPRACH_Parameters_NB_v1330 comp2;
	fill_NPRACH_Parameters_NB_v1330(comp2);
	nprach_ParametersList_v1330.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NPRACH_Parameters_NB_v1330 comp1;
	fill_NPRACH_Parameters_NB_v1330(comp1);
	nprach_ParametersList_v1330.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    NPRACH_ConfigSIB_NB_v1330 nprach_Config_v1330(nprach_ParametersList_v1330);

    /* Creating 'nprach_Config_v1450' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    NPRACH_ConfigSIB_NB_v1450 nprach_Config_v1450(maxNumPreambleAttemptCE_r14_n3);

    /* Creating 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */
    /* Creating 'tdd_Parameters_r15' field of 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    /* Creating 'nprach_ParametersListTDD_r15' field of 'tdd_Parameters_r15' field of 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field... */
    NPRACH_ParametersListTDD_NB_r15 nprach_ParametersListTDD_r15;
    {
	/* Adding component #2 */
	NPRACH_ParametersTDD_NB_r15 comp2;
	fill_NPRACH_ParametersTDD_NB_r15(comp2);
	nprach_ParametersListTDD_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NPRACH_ParametersTDD_NB_r15 comp1;
	fill_NPRACH_ParametersTDD_NB_r15(comp1);
	nprach_ParametersListTDD_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    NPRACH_ConfigSIB_NB_v1530::tdd_Parameters_r15 tdd_Parameters_r15(fmt0, numRepetitionsPerPreambleAttempt_r15_n1, nprach_ParametersListTDD_r15);

    /* Creating 'fmt2_Parameters_r15' field of 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    /* Creating 'nprach_ParametersListFmt2_r15' field of 'fmt2_Parameters_r15' field of 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field... */
    NPRACH_ParametersListFmt2_NB_r15 nprach_ParametersListFmt2_r15;
    fill_NPRACH_ParametersListFmt2_NB_r15(nprach_ParametersListFmt2_r15);

    /* Creating 'nprach_ParametersListFmt2EDT_r15' field of 'fmt2_Parameters_r15' field of 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field... */
    NPRACH_ParametersListFmt2_NB_r15 nprach_ParametersListFmt2EDT_r15;
    fill_NPRACH_ParametersListFmt2_NB_r15(nprach_ParametersListFmt2EDT_r15);

    /* Calling a fully-initializing constructor */
    NPRACH_ConfigSIB_NB_v1530::fmt2_Parameters_r15 fmt2_Parameters_r15(nprach_ParametersListFmt2_r15, nprach_ParametersListFmt2EDT_r15);

    /* Creating 'edt_Parameters_r15' field of 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative... */
    /* Creating 'edt_TBS_InfoList_r15' field of 'edt_Parameters_r15' field of 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field... */
    EDT_TBS_InfoList_NB_r15 edt_TBS_InfoList_r15;
    {
	/* Adding component #2 */
	EDT_TBS_NB_r15 comp2;
	fill_EDT_TBS_NB_r15(comp2);
	edt_TBS_InfoList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	EDT_TBS_NB_r15 comp1;
	fill_EDT_TBS_NB_r15(comp1);
	edt_TBS_InfoList_r15.prepend(comp1);
    }

    /* Creating 'nprach_ParametersListEDT_r15' field of 'edt_Parameters_r15' field of 'nprach_Config_v1530' field of 'radioResourceConfigCommon_r13' field... */
    NPRACH_ParametersList_NB_r14 nprach_ParametersListEDT_r15;
    {
	/* Adding component #2 */
	NPRACH_Parameters_NB_r14 comp2;
	fill_NPRACH_Parameters_NB_r14(comp2);
	nprach_ParametersListEDT_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NPRACH_Parameters_NB_r14 comp1;
	fill_NPRACH_Parameters_NB_r14(comp1);
	nprach_ParametersListEDT_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    NPRACH_ConfigSIB_NB_v1530::edt_Parameters_r15 edt_Parameters_r15(edt_Parameters_r15_edt_SmallTBS_Subset_r15_true, edt_TBS_InfoList_r15, nprach_ParametersListEDT_r15);

    /* Calling a fully-initializing constructor */
    NPRACH_ConfigSIB_NB_v1530 nprach_Config_v1530(tdd_Parameters_r15, fmt2_Parameters_r15, edt_Parameters_r15);

    /* Creating 'dl_Gap_v1530' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */
    DL_GapConfig_NB_v1530 dl_Gap_v1530;
    fill_DL_GapConfig_NB_v1530(dl_Gap_v1530);

    /* Creating 'wus_Config_r15' field of 'radioResourceConfigCommon_r13' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    WUS_Config_NB_r15 wus_Config_r15(one128th, WUS_Config_NB_r15_numPOs_r15_n1, numDRX_CyclesRelaxed_r15_n1, WUS_Config_NB_r15_timeOffsetDRX_r15_ms40, WUS_Config_NB_r15_timeOffset_eDRX_Short_r15_ms40, WUS_Config_NB_r15_timeOffset_eDRX_Long_r15_ms1000);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSIB_NB_r13 radioResourceConfigCommon_r13(rach_ConfigCommon_r13, bcch_Config_r13, pcch_Config_r13, nprach_Config_r13, npdsch_ConfigCommon_r13, npusch_ConfigCommon_r13, dl_Gap_r13, uplinkPowerControlCommon_r13, nprach_Config_v1330, nprach_Config_v1450, nprach_Config_v1530, dl_Gap_v1530, wus_Config_r15);

    /* Creating 'ue_TimersAndConstants_r13' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    UE_TimersAndConstants_NB_r13 ue_TimersAndConstants_r13(t300_r13_ms2500, UE_TimersAndConstants_NB_r13_t301_r13_ms2500, UE_TimersAndConstants_NB_r13_t310_r13_ms0, UE_TimersAndConstants_NB_r13_n310_r13_n1, UE_TimersAndConstants_NB_r13_t311_r13_ms1000, UE_TimersAndConstants_NB_r13_n311_r13_n1, UE_TimersAndConstants_NB_r13_t311_v1350_ms40000, t300_v1530_ms80000, UE_TimersAndConstants_NB_r13_t301_v1530_ms80000, UE_TimersAndConstants_NB_r13_t311_v1530_ms160000, UE_TimersAndConstants_NB_r13_t300_r15_ms6000);

    /* Creating 'freqInfo_r13' field of 'sib2_r13' alternative */
    /* Creating 'ul_CarrierFreq_r13' field of 'freqInfo_r13' field of 'sib2_r13' alternative */
    CarrierFreq_NB_r13 ul_CarrierFreq_r13;
    fill_CarrierFreq_NB_r13(ul_CarrierFreq_r13);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2_NB_r13::freqInfo_r13 freqInfo_r13(ul_CarrierFreq_r13, 1);

    /* Creating 'multiBandInfoList_r13' field of 'sib2_r13' alternative */
    SystemInformationBlockType2_NB_r13::multiBandInfoList_r13 multiBandInfoList_r13;
    multiBandInfoList_r13.prepend(1);
    multiBandInfoList_r13.prepend(1);

    /* Creating 'lateNonCriticalExtension' field of 'sib2_r13' alternative */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'freqInfo_v1530' field of 'sib2_r13' alternative */

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2_NB_r13::freqInfo_v1530 freqInfo_v1530(TDD_UL_DL_AlignmentOffset_NB_r15_khz_7dot5);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2_NB_r13 sib2_r13(radioResourceConfigCommon_r13, ue_TimersAndConstants_r13, freqInfo_r13, TimeAlignmentTimer_sf500, multiBandInfoList_r13, lateNonCriticalExtension, cp_Reestablishment_r14_true, servingCellMeasInfo_r14_true, cqi_Reporting_r14_true, enhancedPHR_r15_true, freqInfo_v1530, SystemInformationBlockType2_NB_r13_cp_EDT_r15_true, SystemInformationBlockType2_NB_r13_up_EDT_r15_true);

    value.set_sib2_r13(sib2_r13);
}

BCCH_DL_SCH_Message_NB *create_samplevalue_BCCH_DL_SCH_Message_NB()
{
    /* Creating 'message' field */
    BCCH_DL_SCH_MessageType_NB message;
    /* Setting 'c1' alternative of 'message' field */
    BCCH_DL_SCH_MessageType_NB::c1 c1;
    /* Setting 'systemInformation_r13' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'systemInformation_r13' alternative of 'c1' alternative of 'message' field... */
    SystemInformation_NB::criticalExtensions criticalExtensions;
    /* Setting 'systemInformation_r13' alternative of 'criticalExtensions' field of 'systemInformation_r13' alternative of 'c1' alternative... */
    /* Creating 'sib_TypeAndInfo_r13' field of 'systemInformation_r13' alternative of 'criticalExtensions' field of 'systemInformation_r13' alternative... */
    SystemInformation_NB_r13_IEs::sib_TypeAndInfo_r13 sib_TypeAndInfo_r13;
    {
	/* Adding component #2 */
	SystemInformation_NB_r13_IEs::sib_TypeAndInfo_r13::component comp2;
	fill_data_3(comp2);
	sib_TypeAndInfo_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SystemInformation_NB_r13_IEs::sib_TypeAndInfo_r13::component comp1;
	fill_data_3(comp1);
	sib_TypeAndInfo_r13.prepend(comp1);
    }

    /* Creating 'lateNonCriticalExtension' field of 'systemInformation_r13' alternative of 'criticalExtensions' field of 'systemInformation_r13' alternative... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'systemInformation_r13' alternative of 'criticalExtensions' field of 'systemInformation_r13' alternative... */
    SystemInformation_NB_r13_IEs::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SystemInformation_NB_r13_IEs criticalExtensions_systemInformation_r13(sib_TypeAndInfo_r13, lateNonCriticalExtension, nonCriticalExtension);

    criticalExtensions.set_systemInformation_r13(criticalExtensions_systemInformation_r13);

    /* Calling a fully-initializing constructor */
    SystemInformation_NB systemInformation_r13(criticalExtensions);

    c1.set_systemInformation_r13(systemInformation_r13);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new BCCH_DL_SCH_Message_NB(message);
}

static void fill_PagingRecord_NB_r13(PagingRecord_NB_r13 & value)
{
    /* Setting 'ue_Identity_r13' field */
    PagingUE_Identity ue_Identity_r13;
    fill_PagingUE_Identity(ue_Identity_r13);
    value.set_ue_Identity_r13(ue_Identity_r13);
}

PCCH_Message_NB *create_samplevalue_PCCH_Message_NB()
{
    /* Creating 'message' field */
    PCCH_MessageType_NB message;
    /* Setting 'c1' alternative of 'message' field */
    PCCH_MessageType_NB::c1 c1;
    /* Setting 'paging_r13' alternative of 'c1' alternative of 'message' field */
    /* Creating 'pagingRecordList_r13' field of 'paging_r13' alternative of 'c1' alternative of 'message' field... */
    PagingRecordList_NB_r13 pagingRecordList_r13;
    {
	/* Adding component #2 */
	PagingRecord_NB_r13 comp2;
	fill_PagingRecord_NB_r13(comp2);
	pagingRecordList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PagingRecord_NB_r13 comp1;
	fill_PagingRecord_NB_r13(comp1);
	pagingRecordList_r13.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'paging_r13' alternative of 'c1' alternative of 'message' field... */
    Paging_NB::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    Paging_NB paging_r13(pagingRecordList_r13, systemInfoModification_r13_true, Paging_NB_systemInfoModification_eDRX_r13_true, nonCriticalExtension);

    c1.set_paging_r13(paging_r13);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new PCCH_Message_NB(message);
}

static void fill_data_2(RLC_Config_NB_r13::am & value)
{
    /* Setting 'ul_AM_RLC_r13' field */

    /* Calling a fully-initializing constructor */
    UL_AM_RLC_NB_r13 ul_AM_RLC_r13(T_PollRetransmit_NB_r13_ms250, maxRetxThreshold_r13_t1);

    value.set_ul_AM_RLC_r13(ul_AM_RLC_r13);

    /* Setting 'dl_AM_RLC_r13' field */

    /* Calling a fully-initializing constructor */
    DL_AM_RLC_NB_r13 dl_AM_RLC_r13(enableStatusReportSN_Gap_r13_true);

    value.set_dl_AM_RLC_r13(dl_AM_RLC_r13);
}

static void fill_RLC_Config_NB_v1430(RLC_Config_NB_v1430 & value)
{
    value.set_t_Reordering_r14(T_Reordering_ms0);
}

static void fill_DRB_ToAddMod_NB_r13(DRB_ToAddMod_NB_r13 & value)
{
    value.set_eps_BearerIdentity_r13(0);
    value.set_drb_Identity_r13(1);
    /* Setting 'pdcp_Config_r13' field */
    /* Creating 'headerCompression_r13' field of 'pdcp_Config_r13' field */
    PDCP_Config_NB_r13::headerCompression_r13 headerCompression_r13;
    headerCompression_r13.set_notUsed(0);

    /* Calling a fully-initializing constructor */
    PDCP_Config_NB_r13 pdcp_Config_r13(discardTimer_r13_ms5120, headerCompression_r13);

    value.set_pdcp_Config_r13(pdcp_Config_r13);

    /* Setting 'rlc_Config_r13' field */
    RLC_Config_NB_r13 rlc_Config_r13;
    /* Setting 'am' alternative of 'rlc_Config_r13' field */
    RLC_Config_NB_r13::am am;
    fill_data_2(am);
    rlc_Config_r13.set_am(am);

    value.set_rlc_Config_r13(rlc_Config_r13);

    value.set_logicalChannelIdentity_r13(3);
    /* Setting 'logicalChannelConfig_r13' field */

    /* Calling a fully-initializing constructor */
    LogicalChannelConfig_NB_r13 logicalChannelConfig_r13(1, TRUE);

    value.set_logicalChannelConfig_r13(logicalChannelConfig_r13);

    /* Setting 'rlc_Config_v1430' field */
    RLC_Config_NB_v1430 rlc_Config_v1430;
    fill_RLC_Config_NB_v1430(rlc_Config_v1430);
    value.set_rlc_Config_v1430(rlc_Config_v1430);
}

static void fill_RadioResourceConfigDedicated_NB_r13(RadioResourceConfigDedicated_NB_r13 & value)
{
    /* Setting 'srb_ToAddModList_r13' field */
    SRB_ToAddModList_NB_r13 srb_ToAddModList_r13;
    {
	/* Adding component #1 */
	/* Creating 'rlc_Config_r13' field */
	SRB_ToAddMod_NB_r13::rlc_Config_r13 rlc_Config_r13;
	/* Setting 'explicitValue' alternative of 'rlc_Config_r13' field */
	RLC_Config_NB_r13 explicitValue;
	/* Setting 'am' alternative of 'explicitValue' alternative of 'rlc_Config_r13' field */
	RLC_Config_NB_r13::am am;
	fill_data_2(am);
	explicitValue.set_am(am);

	rlc_Config_r13.set_explicitValue(explicitValue);

	/* Creating 'logicalChannelConfig_r13' field */
	SRB_ToAddMod_NB_r13::logicalChannelConfig_r13 logicalChannelConfig_r13;
	/* Setting 'explicitValue' alternative of 'logicalChannelConfig_r13' field */

	/* Calling a fully-initializing constructor */
	LogicalChannelConfig_NB_r13 logicalChannelConfig_r13_explicitValue(1, TRUE);

	logicalChannelConfig_r13.set_explicitValue(logicalChannelConfig_r13_explicitValue);

	/* Creating 'rlc_Config_v1430' field */
	RLC_Config_NB_v1430 rlc_Config_v1430;
	fill_RLC_Config_NB_v1430(rlc_Config_v1430);

	/* Calling a fully-initializing constructor */
	SRB_ToAddMod_NB_r13 comp1(rlc_Config_r13, logicalChannelConfig_r13, rlc_Config_v1430);

	srb_ToAddModList_r13.prepend(comp1);
    }
    value.set_srb_ToAddModList_r13(srb_ToAddModList_r13);

    /* Setting 'drb_ToAddModList_r13' field */
    DRB_ToAddModList_NB_r13 drb_ToAddModList_r13;
    {
	/* Adding component #2 */
	DRB_ToAddMod_NB_r13 comp2;
	fill_DRB_ToAddMod_NB_r13(comp2);
	drb_ToAddModList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DRB_ToAddMod_NB_r13 comp1;
	fill_DRB_ToAddMod_NB_r13(comp1);
	drb_ToAddModList_r13.prepend(comp1);
    }
    value.set_drb_ToAddModList_r13(drb_ToAddModList_r13);

    /* Setting 'drb_ToReleaseList_r13' field */
    DRB_ToReleaseList_NB_r13 drb_ToReleaseList_r13;
    drb_ToReleaseList_r13.prepend(1);
    drb_ToReleaseList_r13.prepend(1);
    value.set_drb_ToReleaseList_r13(drb_ToReleaseList_r13);

    /* Setting 'mac_MainConfig_r13' field */
    RadioResourceConfigDedicated_NB_r13::mac_MainConfig_r13 mac_MainConfig_r13;
    /* Setting 'explicitValue_r13' alternative of 'mac_MainConfig_r13' field */
    /* Creating 'ul_SCH_Config_r13' field of 'explicitValue_r13' alternative of 'mac_MainConfig_r13' field */

    /* Calling a fully-initializing constructor */
    MAC_MainConfig_NB_r13::ul_SCH_Config_r13 ul_SCH_Config_r13(PeriodicBSR_Timer_NB_r13_pp2, RetxBSR_Timer_NB_r13_pp4);

    /* Creating 'drx_Config_r13' field of 'explicitValue_r13' alternative of 'mac_MainConfig_r13' field */
    DRX_Config_NB_r13 drx_Config_r13;
    drx_Config_r13.set_release(0);

    /* Creating 'logicalChannelSR_Config_r13' field of 'explicitValue_r13' alternative of 'mac_MainConfig_r13' field */
    MAC_MainConfig_NB_r13::logicalChannelSR_Config_r13 logicalChannelSR_Config_r13;
    logicalChannelSR_Config_r13.set_release(0);

    /* Creating 'dataInactivityTimerConfig_r14' field of 'explicitValue_r13' alternative of 'mac_MainConfig_r13' field */
    MAC_MainConfig_NB_r13::dataInactivityTimerConfig_r14 dataInactivityTimerConfig_r14;
    dataInactivityTimerConfig_r14.set_release(0);

    /* Calling a fully-initializing constructor */
    MAC_MainConfig_NB_r13 explicitValue_r13(ul_SCH_Config_r13, drx_Config_r13, TimeAlignmentTimer_sf500, logicalChannelSR_Config_r13, MAC_MainConfig_NB_r13_rai_Activation_r14_true, dataInactivityTimerConfig_r14, drx_Cycle_v1430_sf1280, ra_CFRA_Config_r14_true);

    mac_MainConfig_r13.set_explicitValue_r13(explicitValue_r13);

    value.set_mac_MainConfig_r13(mac_MainConfig_r13);

    /* Setting 'physicalConfigDedicated_r13' field */
    /* Creating 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field */
    /* Creating 'dl_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field */
    /* Creating 'dl_CarrierFreq_r13' field of 'dl_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field... */
    CarrierFreq_NB_r13 dl_CarrierFreq_r13;
    fill_CarrierFreq_NB_r13(dl_CarrierFreq_r13);

    /* Creating 'downlinkBitmapNonAnchor_r13' field of 'dl_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field... */
    DL_CarrierConfigDedicated_NB_r13::downlinkBitmapNonAnchor_r13 downlinkBitmapNonAnchor_r13;
    downlinkBitmapNonAnchor_r13.set_useNoBitmap_r13(0);

    /* Creating 'dl_GapNonAnchor_r13' field of 'dl_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field... */
    DL_CarrierConfigDedicated_NB_r13::dl_GapNonAnchor_r13 dl_GapNonAnchor_r13;
    dl_GapNonAnchor_r13.set_useNoGap_r13(0);

    /* Creating 'inbandCarrierInfo_r13' field of 'dl_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field... */
    /* Creating 'samePCI_Indicator_r13' field of 'inbandCarrierInfo_r13' field of 'dl_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field... */
    DL_CarrierConfigDedicated_NB_r13::inbandCarrierInfo_r13::samePCI_Indicator_r13 samePCI_Indicator_r13;
    /* Setting 'samePCI_r13' alternative of 'samePCI_Indicator_r13' field of 'inbandCarrierInfo_r13' field of 'dl_CarrierConfig_r13' field... */

    /* Calling a fully-initializing constructor */
    DL_CarrierConfigDedicated_NB_r13::inbandCarrierInfo_r13::samePCI_Indicator_r13::samePCI_r13 samePCI_r13(54);

    samePCI_Indicator_r13.set_samePCI_r13(samePCI_r13);

    /* Calling a fully-initializing constructor */
    DL_CarrierConfigDedicated_NB_r13::inbandCarrierInfo_r13 inbandCarrierInfo_r13(samePCI_Indicator_r13, inbandCarrierInfo_r13_eutraControlRegionSize_r13_n1);

    /* Creating 'dl_GapNonAnchor_v1530' field of 'dl_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field... */
    DL_GapConfig_NB_v1530 dl_GapNonAnchor_v1530;
    fill_DL_GapConfig_NB_v1530(dl_GapNonAnchor_v1530);

    /* Calling a fully-initializing constructor */
    DL_CarrierConfigDedicated_NB_r13 dl_CarrierConfig_r13(dl_CarrierFreq_r13, downlinkBitmapNonAnchor_r13, dl_GapNonAnchor_r13, inbandCarrierInfo_r13, nrs_PowerOffsetNonAnchor_v1330_dB_12, dl_GapNonAnchor_v1530);

    /* Creating 'ul_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field */
    /* Creating 'ul_CarrierFreq_r13' field of 'ul_CarrierConfig_r13' field of 'carrierConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field... */
    CarrierFreq_NB_r13 ul_CarrierFreq_r13;
    fill_CarrierFreq_NB_r13(ul_CarrierFreq_r13);

    /* Calling a fully-initializing constructor */
    UL_CarrierConfigDedicated_NB_r13 ul_CarrierConfig_r13(ul_CarrierFreq_r13, TDD_UL_DL_AlignmentOffset_NB_r15_khz_7dot5);

    /* Calling a fully-initializing constructor */
    CarrierConfigDedicated_NB_r13 carrierConfigDedicated_r13(dl_CarrierConfig_r13, ul_CarrierConfig_r13);

    /* Creating 'npdcch_ConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field */

    /* Calling a fully-initializing constructor */
    NPDCCH_ConfigDedicated_NB_r13 npdcch_ConfigDedicated_r13(npdcch_NumRepetitions_r13_r1, npdcch_StartSF_USS_r13_v1dot5, npdcch_Offset_USS_r13_zero);

    /* Creating 'npusch_ConfigDedicated_r13' field of 'physicalConfigDedicated_r13' field */

    /* Calling a fully-initializing constructor */
    NPUSCH_ConfigDedicated_NB_r13 npusch_ConfigDedicated_r13(ACK_NACK_NumRepetitions_NB_r13_r1, TRUE, NPUSCH_ConfigDedicated_NB_r13_groupHoppingDisabled_r13_true);

    /* Creating 'uplinkPowerControlDedicated_r13' field of 'physicalConfigDedicated_r13' field */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlDedicated_NB_r13 uplinkPowerControlDedicated_r13(7);

    /* Creating 'npdcch_ConfigDedicated_v1530' field of 'physicalConfigDedicated_r13' field */

    /* Calling a fully-initializing constructor */
    NPDCCH_ConfigDedicated_NB_v1530 npdcch_ConfigDedicated_v1530(npdcch_StartSF_USS_v1530_v96);

    /* Calling a fully-initializing constructor */
    PhysicalConfigDedicated_NB_r13 physicalConfigDedicated_r13(carrierConfigDedicated_r13, npdcch_ConfigDedicated_r13, npusch_ConfigDedicated_r13, uplinkPowerControlDedicated_r13, twoHARQ_ProcessesConfig_r14_true, interferenceRandomisationConfig_r14_true, npdcch_ConfigDedicated_v1530);

    value.set_physicalConfigDedicated_r13(physicalConfigDedicated_r13);

    /* Setting 'rlf_TimersAndConstants_r13' field */
    RLF_TimersAndConstants_NB_r13 rlf_TimersAndConstants_r13;
    rlf_TimersAndConstants_r13.set_release(0);
    value.set_rlf_TimersAndConstants_r13(rlf_TimersAndConstants_r13);

    /* Setting 'schedulingRequestConfig_r15' field */
    /* Creating 'sr_WithoutHARQ_ACK_Config_r15' field of 'schedulingRequestConfig_r15' field */
    SR_WithoutHARQ_ACK_Config_NB_r15 sr_WithoutHARQ_ACK_Config_r15;
    sr_WithoutHARQ_ACK_Config_r15.set_release(0);

    /* Creating 'sr_SPS_BSR_Config_r15' field of 'schedulingRequestConfig_r15' field */
    SR_SPS_BSR_Config_NB_r15 sr_SPS_BSR_Config_r15;
    sr_SPS_BSR_Config_r15.set_release(0);

    /* Calling a fully-initializing constructor */
    SchedulingRequestConfig_NB_r15 schedulingRequestConfig_r15(sr_WithHARQ_ACK_Config_r15_true, sr_WithoutHARQ_ACK_Config_r15, sr_SPS_BSR_Config_r15);

    value.set_schedulingRequestConfig_r15(schedulingRequestConfig_r15);
}

DL_CCCH_Message_NB *create_samplevalue_DL_CCCH_Message_NB()
{
    /* Creating 'message' field */
    DL_CCCH_MessageType_NB message;
    /* Setting 'c1' alternative of 'message' field */
    DL_CCCH_MessageType_NB::c1 c1;
    /* Setting 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative of 'message' field... */
    RRCConnectionReestablishment_NB::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative... */
    RRCConnectionReestablishment_NB::criticalExtensions::c1 criticalExtensions_c1;
    /* Setting 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishment_r13' alternative... */
    /* Creating 'radioResourceConfigDedicated_r13' field of 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    RadioResourceConfigDedicated_NB_r13 radioResourceConfigDedicated_r13;
    fill_RadioResourceConfigDedicated_NB_r13(radioResourceConfigDedicated_r13);

    /* Creating 'lateNonCriticalExtension' field of 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'dl_NAS_MAC' field of 'nonCriticalExtension' field of 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative... */
    static unsigned char dl_NAS_MAC_value[] = {
	0x00, 0x00
    };
    OssBitString dl_NAS_MAC(16, dl_NAS_MAC_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'rrcConnectionReestablishment_r13' alternative of 'c1' alternative... */
    RRCConnectionReestablishment_NB_v1430_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishment_NB_v1430_IEs nonCriticalExtension(dl_NAS_MAC, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishment_NB_r13_IEs c1_rrcConnectionReestablishment_r13(radioResourceConfigDedicated_r13, 0, lateNonCriticalExtension, nonCriticalExtension);

    criticalExtensions_c1.set_rrcConnectionReestablishment_r13(c1_rrcConnectionReestablishment_r13);

    criticalExtensions.set_c1(criticalExtensions_c1);

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishment_NB rrcConnectionReestablishment_r13(0, criticalExtensions);

    c1.set_rrcConnectionReestablishment_r13(rrcConnectionReestablishment_r13);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new DL_CCCH_Message_NB(message);
}

DL_DCCH_Message_NB *create_samplevalue_DL_DCCH_Message_NB()
{
    /* Creating 'message' field */
    DL_DCCH_MessageType_NB message;
    /* Setting 'c1' alternative of 'message' field */
    DL_DCCH_MessageType_NB::c1 c1;
    /* Setting 'dlInformationTransfer_r13' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'dlInformationTransfer_r13' alternative of 'c1' alternative of 'message' field... */
    DLInformationTransfer_NB::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field of 'dlInformationTransfer_r13' alternative of 'c1' alternative... */
    DLInformationTransfer_NB::criticalExtensions::c1 criticalExtensions_c1;
    /* Setting 'dlInformationTransfer_r13' alternative of 'c1' alternative of 'criticalExtensions' field of 'dlInformationTransfer_r13' alternative... */
    /* Creating 'dedicatedInfoNAS_r13' field of 'dlInformationTransfer_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    static unsigned char dedicatedInfoNAS_r13_value[] = {
	0x00
    };
    OssString dedicatedInfoNAS_r13(sizeof(dedicatedInfoNAS_r13_value), (char *)dedicatedInfoNAS_r13_value);

    /* Creating 'lateNonCriticalExtension' field of 'dlInformationTransfer_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'dlInformationTransfer_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    DLInformationTransfer_NB_r13_IEs::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    DLInformationTransfer_NB_r13_IEs c1_dlInformationTransfer_r13(dedicatedInfoNAS_r13, lateNonCriticalExtension, nonCriticalExtension);

    criticalExtensions_c1.set_dlInformationTransfer_r13(c1_dlInformationTransfer_r13);

    criticalExtensions.set_c1(criticalExtensions_c1);

    /* Calling a fully-initializing constructor */
    DLInformationTransfer_NB dlInformationTransfer_r13(0, criticalExtensions);

    c1.set_dlInformationTransfer_r13(dlInformationTransfer_r13);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new DL_DCCH_Message_NB(message);
}

UL_CCCH_Message_NB *create_samplevalue_UL_CCCH_Message_NB()
{
    /* Creating 'message' field */
    UL_CCCH_MessageType_NB message;
    /* Setting 'c1' alternative of 'message' field */
    UL_CCCH_MessageType_NB::c1 c1;
    /* Setting 'rrcConnectionReestablishmentRequest_r13' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'rrcConnectionReestablishmentRequest_r13' alternative of 'c1' alternative of 'message' field... */
    RRCConnectionReestablishmentRequest_NB::criticalExtensions criticalExtensions;
    /* Setting 'rrcConnectionReestablishmentRequest_r13' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishmentRequest_r13' alternative of 'c1' alternative... */
    /* Creating 'ue_Identity_r13' field of 'rrcConnectionReestablishmentRequest_r13' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishmentRequest_r13' alternative... */
    ReestabUE_Identity ue_Identity_r13;
    fill_ReestabUE_Identity(ue_Identity_r13);

    /* Creating 'spare' field of 'rrcConnectionReestablishmentRequest_r13' alternative of 'criticalExtensions' field of 'rrcConnectionReestablishmentRequest_r13' alternative... */
    static unsigned char spare_value[] = {
	0x00, 0x00, 0x00
    };
    OssBitString spare(20, spare_value);

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishmentRequest_NB_r13_IEs criticalExtensions_rrcConnectionReestablishmentRequest_r13(ue_Identity_r13, ReestablishmentCause_NB_r13_reconfigurationFailure, CQI_NPDCCH_NB_r14_noMeasurements, TRUE, spare);

    criticalExtensions.set_rrcConnectionReestablishmentRequest_r13(criticalExtensions_rrcConnectionReestablishmentRequest_r13);

    /* Calling a fully-initializing constructor */
    RRCConnectionReestablishmentRequest_NB rrcConnectionReestablishmentRequest_r13(criticalExtensions);

    c1.set_rrcConnectionReestablishmentRequest_r13(rrcConnectionReestablishmentRequest_r13);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UL_CCCH_Message_NB(message);
}

static void fill_SC_MTCH_Info_NB_r14(SC_MTCH_Info_NB_r14 & value)
{
    /* Setting 'sc_mtch_CarrierConfig_r14' field */
    SC_MTCH_Info_NB_r14::sc_mtch_CarrierConfig_r14 sc_mtch_CarrierConfig_r14;
    /* Setting 'dl_CarrierConfig_r14' alternative of 'sc_mtch_CarrierConfig_r14' field */
    /* Creating 'dl_CarrierFreq_r14' field of 'dl_CarrierConfig_r14' alternative of 'sc_mtch_CarrierConfig_r14' field */
    CarrierFreq_NB_r13 dl_CarrierFreq_r14;
    fill_CarrierFreq_NB_r13(dl_CarrierFreq_r14);

    /* Creating 'downlinkBitmapNonAnchor_r14' field of 'dl_CarrierConfig_r14' alternative of 'sc_mtch_CarrierConfig_r14' field */
    DL_CarrierConfigCommon_NB_r14::downlinkBitmapNonAnchor_r14 downlinkBitmapNonAnchor_r14;
    downlinkBitmapNonAnchor_r14.set_useNoBitmap_r14(0);

    /* Creating 'dl_GapNonAnchor_r14' field of 'dl_CarrierConfig_r14' alternative of 'sc_mtch_CarrierConfig_r14' field */
    DL_CarrierConfigCommon_NB_r14::dl_GapNonAnchor_r14 dl_GapNonAnchor_r14;
    dl_GapNonAnchor_r14.set_useNoGap_r14(0);

    /* Creating 'inbandCarrierInfo_r14' field of 'dl_CarrierConfig_r14' alternative of 'sc_mtch_CarrierConfig_r14' field */
    /* Creating 'samePCI_Indicator_r14' field of 'inbandCarrierInfo_r14' field of 'dl_CarrierConfig_r14' alternative of 'sc_mtch_CarrierConfig_r14' field... */
    DL_CarrierConfigCommon_NB_r14::inbandCarrierInfo_r14::samePCI_Indicator_r14 samePCI_Indicator_r14;
    /* Setting 'samePCI_r14' alternative of 'samePCI_Indicator_r14' field of 'inbandCarrierInfo_r14' field of 'dl_CarrierConfig_r14' alternative... */

    /* Calling a fully-initializing constructor */
    DL_CarrierConfigCommon_NB_r14::inbandCarrierInfo_r14::samePCI_Indicator_r14::samePCI_r14 samePCI_r14(54);

    samePCI_Indicator_r14.set_samePCI_r14(samePCI_r14);

    /* Calling a fully-initializing constructor */
    DL_CarrierConfigCommon_NB_r14::inbandCarrierInfo_r14 inbandCarrierInfo_r14(samePCI_Indicator_r14, eutraControlRegionSize_r14_n1);

    /* Creating 'dl_GapNonAnchor_v1530' field of 'dl_CarrierConfig_r14' alternative of 'sc_mtch_CarrierConfig_r14' field */
    DL_GapConfig_NB_v1530 dl_GapNonAnchor_v1530;
    fill_DL_GapConfig_NB_v1530(dl_GapNonAnchor_v1530);

    /* Calling a fully-initializing constructor */
    DL_CarrierConfigCommon_NB_r14 dl_CarrierConfig_r14(dl_CarrierFreq_r14, downlinkBitmapNonAnchor_r14, dl_GapNonAnchor_r14, inbandCarrierInfo_r14, nrs_PowerOffsetNonAnchor_r14_dB_12, dl_GapNonAnchor_v1530);

    sc_mtch_CarrierConfig_r14.set_dl_CarrierConfig_r14(dl_CarrierConfig_r14);

    value.set_sc_mtch_CarrierConfig_r14(sc_mtch_CarrierConfig_r14);

    /* Setting 'mbmsSessionInfo_r14' field */
    MBMSSessionInfo_r13 mbmsSessionInfo_r14;
    fill_MBMSSessionInfo_r13(mbmsSessionInfo_r14);
    value.set_mbmsSessionInfo_r14(mbmsSessionInfo_r14);

    /* Setting 'g_RNTI_r14' field */
    static unsigned char g_RNTI_r14_value[] = {
	0x00, 0x00
    };
    OssBitString g_RNTI_r14(16, g_RNTI_r14_value);
    value.set_g_RNTI_r14(g_RNTI_r14);

    /* Setting 'sc_mtch_SchedulingInfo_r14' field */
    /* Creating 'schedulingPeriodStartOffsetSCPTM_r14' field of 'sc_mtch_SchedulingInfo_r14' field */
    SC_MTCH_SchedulingInfo_NB_r14::schedulingPeriodStartOffsetSCPTM_r14 schedulingPeriodStartOffsetSCPTM_r14;
    schedulingPeriodStartOffsetSCPTM_r14.set_sf10(0);

    /* Calling a fully-initializing constructor */
    SC_MTCH_SchedulingInfo_NB_r14 sc_mtch_SchedulingInfo_r14(SC_MTCH_SchedulingInfo_NB_r14_onDurationTimerSCPTM_r14_pp1, SC_MTCH_SchedulingInfo_NB_r14_drx_InactivityTimerSCPTM_r14_pp0, schedulingPeriodStartOffsetSCPTM_r14);

    value.set_sc_mtch_SchedulingInfo_r14(sc_mtch_SchedulingInfo_r14);

    /* Setting 'sc_mtch_NeighbourCell_r14' field */
    static unsigned char sc_mtch_NeighbourCell_r14_value[] = {
	0x00
    };
    OssBitString sc_mtch_NeighbourCell_r14(8, sc_mtch_NeighbourCell_r14_value);
    value.set_sc_mtch_NeighbourCell_r14(sc_mtch_NeighbourCell_r14);

    value.set_npdcch_NPDSCH_MaxTBS_SC_MTCH_r14(n680);
    value.set_npdcch_NumRepetitions_SC_MTCH_r14(npdcch_NumRepetitions_SC_MTCH_r14_r1);
    value.set_npdcch_StartSF_SC_MTCH_r14(npdcch_StartSF_SC_MTCH_r14_v1dot5);
    value.set_npdcch_Offset_SC_MTCH_r14(npdcch_Offset_SC_MTCH_r14_zero);
}

static void fill_PCI_ARFCN_NB_r14(PCI_ARFCN_NB_r14 & value)
{
    value.set_physCellId_r14(0);
    /* Setting 'carrierFreq_r14' field */
    CarrierFreq_NB_r13 carrierFreq_r14;
    fill_CarrierFreq_NB_r13(carrierFreq_r14);
    value.set_carrierFreq_r14(carrierFreq_r14);
}

SC_MCCH_Message_NB *create_samplevalue_SC_MCCH_Message_NB()
{
    /* Creating 'message' field */
    SC_MCCH_MessageType_NB message;
    /* Setting 'c1' alternative of 'message' field */
    SC_MCCH_MessageType_NB::c1 c1;
    /* Setting 'scptmConfiguration_r14' alternative of 'c1' alternative of 'message' field */
    /* Creating 'sc_mtch_InfoList_r14' field of 'scptmConfiguration_r14' alternative of 'c1' alternative of 'message' field... */
    SC_MTCH_InfoList_NB_r14 sc_mtch_InfoList_r14;
    {
	/* Adding component #2 */
	SC_MTCH_Info_NB_r14 comp2;
	fill_SC_MTCH_Info_NB_r14(comp2);
	sc_mtch_InfoList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SC_MTCH_Info_NB_r14 comp1;
	fill_SC_MTCH_Info_NB_r14(comp1);
	sc_mtch_InfoList_r14.prepend(comp1);
    }

    /* Creating 'scptm_NeighbourCellList_r14' field of 'scptmConfiguration_r14' alternative of 'c1' alternative of 'message' field... */
    SCPTM_NeighbourCellList_NB_r14 scptm_NeighbourCellList_r14;
    {
	/* Adding component #2 */
	PCI_ARFCN_NB_r14 comp2;
	fill_PCI_ARFCN_NB_r14(comp2);
	scptm_NeighbourCellList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PCI_ARFCN_NB_r14 comp1;
	fill_PCI_ARFCN_NB_r14(comp1);
	scptm_NeighbourCellList_r14.prepend(comp1);
    }

    /* Creating 'lateNonCriticalExtension' field of 'scptmConfiguration_r14' alternative of 'c1' alternative of 'message' field... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'scptmConfiguration_r14' alternative of 'c1' alternative of 'message' field... */
    SCPTMConfiguration_NB_r14::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SCPTMConfiguration_NB_r14 scptmConfiguration_r14(sc_mtch_InfoList_r14, scptm_NeighbourCellList_r14, lateNonCriticalExtension, nonCriticalExtension);

    c1.set_scptmConfiguration_r14(scptmConfiguration_r14);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new SC_MCCH_Message_NB(message);
}

UL_DCCH_Message_NB *create_samplevalue_UL_DCCH_Message_NB()
{
    /* Creating 'message' field */
    UL_DCCH_MessageType_NB message;
    /* Setting 'c1' alternative of 'message' field */
    UL_DCCH_MessageType_NB::c1 c1;
    /* Setting 'rrcConnectionReconfigurationComplete_r13' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'rrcConnectionReconfigurationComplete_r13' alternative of 'c1' alternative of 'message' field... */
    RRCConnectionReconfigurationComplete_NB::criticalExtensions criticalExtensions;
    /* Setting 'rrcConnectionReconfigurationComplete_r13' alternative of 'criticalExtensions' field of 'rrcConnectionReconfigurationComplete_r13' alternative of 'c1' alternative... */
    /* Creating 'lateNonCriticalExtension' field of 'rrcConnectionReconfigurationComplete_r13' alternative of 'criticalExtensions' field of 'rrcConnectionReconfigurationComplete_r13' alternative... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'rrcConnectionReconfigurationComplete_r13' alternative of 'criticalExtensions' field of 'rrcConnectionReconfigurationComplete_r13' alternative... */
    RRCConnectionReconfigurationComplete_NB_r13_IEs::nonCriticalExtension nonCriticalExtension;
    fill_data_21(nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    RRCConnectionReconfigurationComplete_NB_r13_IEs criticalExtensions_rrcConnectionReconfigurationComplete_r13(lateNonCriticalExtension, nonCriticalExtension);

    criticalExtensions.set_rrcConnectionReconfigurationComplete_r13(criticalExtensions_rrcConnectionReconfigurationComplete_r13);

    /* Calling a fully-initializing constructor */
    RRCConnectionReconfigurationComplete_NB rrcConnectionReconfigurationComplete_r13(0, criticalExtensions);

    c1.set_rrcConnectionReconfigurationComplete_r13(rrcConnectionReconfigurationComplete_r13);

    message.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UL_DCCH_Message_NB(message);
}

static void fill_CellGlobalIdEUTRA_1(CellGlobalIdEUTRA & value)
{
    /* Setting 'plmn_Identity' field */
    PLMN_Identity plmn_Identity;
    fill_PLMN_Identity(plmn_Identity);
    value.set_plmn_Identity(plmn_Identity);

    /* Setting 'cellIdentity' field */
    static unsigned char cellIdentity_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity(28, cellIdentity_value);
    value.set_cellIdentity(cellIdentity);
}

static void fill_LocationInfo_r10(LocationInfo_r10 & value)
{
    /* Setting 'locationCoordinates_r10' field */
    LocationInfo_r10::locationCoordinates_r10 locationCoordinates_r10;
    /* Setting 'ellipsoid_Point_r10' alternative of 'locationCoordinates_r10' field */
    static unsigned char ellipsoid_Point_r10_value[] = {
	0x00
    };
    OssString ellipsoid_Point_r10(sizeof(ellipsoid_Point_r10_value), (char *)ellipsoid_Point_r10_value);
    locationCoordinates_r10.set_ellipsoid_Point_r10(ellipsoid_Point_r10);

    value.set_locationCoordinates_r10(locationCoordinates_r10);

    /* Setting 'horizontalVelocity_r10' field */
    static unsigned char horizontalVelocity_r10_value[] = {
	0x00
    };
    OssString horizontalVelocity_r10(sizeof(horizontalVelocity_r10_value), (char *)horizontalVelocity_r10_value);
    value.set_horizontalVelocity_r10(horizontalVelocity_r10);

    /* Setting 'gnss_TOD_msec_r10' field */
    static unsigned char gnss_TOD_msec_r10_value[] = {
	0x00
    };
    OssString gnss_TOD_msec_r10(sizeof(gnss_TOD_msec_r10_value), (char *)gnss_TOD_msec_r10_value);
    value.set_gnss_TOD_msec_r10(gnss_TOD_msec_r10);

    /* Setting 'verticalVelocityInfo_r15' field */
    LocationInfo_r10::verticalVelocityInfo_r15 verticalVelocityInfo_r15;
    /* Setting 'verticalVelocity_r15' alternative of 'verticalVelocityInfo_r15' field */
    static unsigned char verticalVelocity_r15_value[] = {
	0x00
    };
    OssString verticalVelocity_r15(sizeof(verticalVelocity_r15_value), (char *)verticalVelocity_r15_value);
    verticalVelocityInfo_r15.set_verticalVelocity_r15(verticalVelocity_r15);

    value.set_verticalVelocityInfo_r15(verticalVelocityInfo_r15);
}

static void fill_PLMN_IdentityList2(PLMN_IdentityList2 & value)
{
    {
	/* Adding component #2 */
	PLMN_Identity comp2;
	fill_PLMN_Identity(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_Identity comp1;
	fill_PLMN_Identity(comp1);
	value.prepend(comp1);
    }
}

static void fill_AdditionalSI_Info_r9(AdditionalSI_Info_r9 & value)
{
    value.set_csg_MemberStatus_r9(member);
    /* Setting 'csg_Identity_r9' field */
    static unsigned char csg_Identity_r9_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString csg_Identity_r9(27, csg_Identity_r9_value);
    value.set_csg_Identity_r9(csg_Identity_r9);
}

static void fill_PLMN_IdentityInfo_r15(PLMN_IdentityInfo_r15 & value)
{
    /* Setting 'plmn_Identity_5GC_r15' field */
    PLMN_IdentityInfo_r15::plmn_Identity_5GC_r15 plmn_Identity_5GC_r15;
    /* Setting 'plmn_Identity_r15' alternative of 'plmn_Identity_5GC_r15' field */
    /* Creating 'mcc' field of 'plmn_Identity_r15' alternative of 'plmn_Identity_5GC_r15' field */
    MCC mcc;
    fill_MCC(mcc);

    /* Creating 'mnc' field of 'plmn_Identity_r15' alternative of 'plmn_Identity_5GC_r15' field */
    MNC mnc;
    fill_MNC(mnc);

    /* Calling a fully-initializing constructor */
    PLMN_Identity plmn_Identity_r15(mcc, mnc);

    plmn_Identity_5GC_r15.set_plmn_Identity_r15(plmn_Identity_r15);

    value.set_plmn_Identity_5GC_r15(plmn_Identity_5GC_r15);

    value.set_cellReservedForOperatorUse_r15(cellReservedForOperatorUse_r15_reserved);
    value.set_cellReservedForOperatorUse_CRS_r15(PLMN_IdentityInfo_r15_cellReservedForOperatorUse_CRS_r15_reserved);
}

static void fill_CellAccessRelatedInfo_5GC_r15(CellAccessRelatedInfo_5GC_r15 & value)
{
    /* Setting 'plmn_IdentityList_r15' field */
    PLMN_IdentityList_r15 plmn_IdentityList_r15;
    {
	/* Adding component #2 */
	PLMN_IdentityInfo_r15 comp2;
	fill_PLMN_IdentityInfo_r15(comp2);
	plmn_IdentityList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_IdentityInfo_r15 comp1;
	fill_PLMN_IdentityInfo_r15(comp1);
	plmn_IdentityList_r15.prepend(comp1);
    }
    value.set_plmn_IdentityList_r15(plmn_IdentityList_r15);

    value.set_ran_AreaCode_r15(0);
    /* Setting 'trackingAreaCode_5GC_r15' field */
    static unsigned char trackingAreaCode_5GC_r15_value[] = {
	0x00, 0x00, 0x00
    };
    OssBitString trackingAreaCode_5GC_r15(24, trackingAreaCode_5GC_r15_value);
    value.set_trackingAreaCode_5GC_r15(trackingAreaCode_5GC_r15);

    /* Setting 'cellIdentity_5GC_r15' field */
    CellIdentity_5GC_r15 cellIdentity_5GC_r15;
    /* Setting 'cellIdentity_r15' alternative of 'cellIdentity_5GC_r15' field */
    static unsigned char cellIdentity_r15_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity_r15(28, cellIdentity_r15_value);
    cellIdentity_5GC_r15.set_cellIdentity_r15(cellIdentity_r15);

    value.set_cellIdentity_5GC_r15(cellIdentity_5GC_r15);
}

static void fill_MeasResultEUTRA(MeasResultEUTRA & value)
{
    value.set_physCellId(0);
    /* Setting 'cgi_Info' field */
    /* Creating 'cellGlobalId' field of 'cgi_Info' field */
    CellGlobalIdEUTRA cellGlobalId;
    fill_CellGlobalIdEUTRA_1(cellGlobalId);

    /* Creating 'trackingAreaCode' field of 'cgi_Info' field */
    static unsigned char trackingAreaCode_value[] = {
	0x00, 0x00
    };
    OssBitString trackingAreaCode(16, trackingAreaCode_value);

    /* Creating 'plmn_IdentityList' field of 'cgi_Info' field */
    PLMN_IdentityList2 plmn_IdentityList;
    fill_PLMN_IdentityList2(plmn_IdentityList);

    /* Calling a fully-initializing constructor */
    MeasResultEUTRA::cgi_Info cgi_Info(cellGlobalId, trackingAreaCode, plmn_IdentityList);

    value.set_cgi_Info(cgi_Info);

    /* Setting 'measResult' field */
    /* Creating 'additionalSI_Info_r9' field of 'measResult' field */
    AdditionalSI_Info_r9 additionalSI_Info_r9;
    fill_AdditionalSI_Info_r9(additionalSI_Info_r9);

    /* Creating 'cgi_Info_v1310' field of 'measResult' field */
    /* Creating 'multiBandInfoList_r13' field of 'cgi_Info_v1310' field of 'measResult' field */
    MultiBandInfoList_r11 multiBandInfoList_r13;
    multiBandInfoList_r13.prepend(1);
    multiBandInfoList_r13.prepend(1);

    /* Calling a fully-initializing constructor */
    MeasResultEUTRA::measResult::cgi_Info_v1310 cgi_Info_v1310(1, multiBandInfoList_r13, freqBandIndicatorPriority_r13_true);

    /* Creating 'cgi_Info_5GC_r15' field of 'measResult' field */
    MeasResultEUTRA::measResult::cgi_Info_5GC_r15 cgi_Info_5GC_r15;
    {
	/* Adding component #2 */
	CellAccessRelatedInfo_5GC_r15 comp2;
	fill_CellAccessRelatedInfo_5GC_r15(comp2);
	cgi_Info_5GC_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CellAccessRelatedInfo_5GC_r15 comp1;
	fill_CellAccessRelatedInfo_5GC_r15(comp1);
	cgi_Info_5GC_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    MeasResultEUTRA::measResult measResult(0, 0, additionalSI_Info_r9, MeasResultEUTRA_measResult_primaryPLMN_Suitable_r12_true, -30, 0, cgi_Info_v1310, -1, cgi_Info_5GC_r15);

    value.set_measResult(measResult);
}

static void fill_MeasResult2EUTRA_r9(MeasResult2EUTRA_r9 & value)
{
    value.set_carrierFreq_r9(0);
    /* Setting 'measResultList_r9' field */
    MeasResultListEUTRA measResultList_r9;
    {
	/* Adding component #2 */
	MeasResultEUTRA comp2;
	fill_MeasResultEUTRA(comp2);
	measResultList_r9.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultEUTRA comp1;
	fill_MeasResultEUTRA(comp1);
	measResultList_r9.prepend(comp1);
    }
    value.set_measResultList_r9(measResultList_r9);
}

static void fill_MeasResultList2EUTRA_r9(MeasResultList2EUTRA_r9 & value)
{
    {
	/* Adding component #2 */
	MeasResult2EUTRA_r9 comp2;
	fill_MeasResult2EUTRA_r9(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResult2EUTRA_r9 comp1;
	fill_MeasResult2EUTRA_r9(comp1);
	value.prepend(comp1);
    }
}

static void fill_CellGlobalIdUTRA(CellGlobalIdUTRA & value)
{
    /* Setting 'plmn_Identity' field */
    PLMN_Identity plmn_Identity;
    fill_PLMN_Identity(plmn_Identity);
    value.set_plmn_Identity(plmn_Identity);

    /* Setting 'cellIdentity' field */
    static unsigned char cellIdentity_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity(28, cellIdentity_value);
    value.set_cellIdentity(cellIdentity);
}

static void fill_MeasResultUTRA(MeasResultUTRA & value)
{
    /* Setting 'physCellId' field */
    MeasResultUTRA::physCellId physCellId;
    physCellId.set_fdd(0);
    value.set_physCellId(physCellId);

    /* Setting 'cgi_Info' field */
    /* Creating 'cellGlobalId' field of 'cgi_Info' field */
    CellGlobalIdUTRA cellGlobalId;
    fill_CellGlobalIdUTRA(cellGlobalId);

    /* Creating 'locationAreaCode' field of 'cgi_Info' field */
    static unsigned char locationAreaCode_value[] = {
	0x00, 0x00
    };
    OssBitString locationAreaCode(16, locationAreaCode_value);

    /* Creating 'routingAreaCode' field of 'cgi_Info' field */
    static unsigned char routingAreaCode_value[] = {
	0x00
    };
    OssBitString routingAreaCode(8, routingAreaCode_value);

    /* Creating 'plmn_IdentityList' field of 'cgi_Info' field */
    PLMN_IdentityList2 plmn_IdentityList;
    fill_PLMN_IdentityList2(plmn_IdentityList);

    /* Calling a fully-initializing constructor */
    MeasResultUTRA::cgi_Info cgi_Info(cellGlobalId, locationAreaCode, routingAreaCode, plmn_IdentityList);

    value.set_cgi_Info(cgi_Info);

    /* Setting 'measResult' field */
    /* Creating 'additionalSI_Info_r9' field of 'measResult' field */
    AdditionalSI_Info_r9 additionalSI_Info_r9;
    fill_AdditionalSI_Info_r9(additionalSI_Info_r9);

    /* Calling a fully-initializing constructor */
    MeasResultUTRA::measResult measResult(-5, 0, additionalSI_Info_r9, MeasResultUTRA_measResult_primaryPLMN_Suitable_r12_true);

    value.set_measResult(measResult);
}

static void fill_MeasResult2UTRA_r9(MeasResult2UTRA_r9 & value)
{
    value.set_carrierFreq_r9(0);
    /* Setting 'measResultList_r9' field */
    MeasResultListUTRA measResultList_r9;
    {
	/* Adding component #2 */
	MeasResultUTRA comp2;
	fill_MeasResultUTRA(comp2);
	measResultList_r9.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultUTRA comp1;
	fill_MeasResultUTRA(comp1);
	measResultList_r9.prepend(comp1);
    }
    value.set_measResultList_r9(measResultList_r9);
}

static void fill_MeasResultList2UTRA_r9(MeasResultList2UTRA_r9 & value)
{
    {
	/* Adding component #2 */
	MeasResult2UTRA_r9 comp2;
	fill_MeasResult2UTRA_r9(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResult2UTRA_r9 comp1;
	fill_MeasResult2UTRA_r9(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasResultGERAN(MeasResultGERAN & value)
{
    /* Setting 'carrierFreq' field */

    /* Calling a fully-initializing constructor */
    CarrierFreqGERAN carrierFreq(0, dcs1800);

    value.set_carrierFreq(carrierFreq);

    /* Setting 'physCellId' field */
    /* Creating 'networkColourCode' field of 'physCellId' field */
    static unsigned char networkColourCode_value[] = {
	0x00
    };
    OssBitString networkColourCode(3, networkColourCode_value);

    /* Creating 'baseStationColourCode' field of 'physCellId' field */
    static unsigned char baseStationColourCode_value[] = {
	0x00
    };
    OssBitString baseStationColourCode(3, baseStationColourCode_value);

    /* Calling a fully-initializing constructor */
    PhysCellIdGERAN physCellId(networkColourCode, baseStationColourCode);

    value.set_physCellId(physCellId);

    /* Setting 'cgi_Info' field */
    /* Creating 'cellGlobalId' field of 'cgi_Info' field */
    /* Creating 'plmn_Identity' field of 'cellGlobalId' field of 'cgi_Info' field */
    PLMN_Identity plmn_Identity;
    fill_PLMN_Identity(plmn_Identity);

    /* Creating 'locationAreaCode' field of 'cellGlobalId' field of 'cgi_Info' field */
    static unsigned char locationAreaCode_value[] = {
	0x00, 0x00
    };
    OssBitString locationAreaCode(16, locationAreaCode_value);

    /* Creating 'cellIdentity' field of 'cellGlobalId' field of 'cgi_Info' field */
    static unsigned char cellIdentity_value[] = {
	0x00, 0x00
    };
    OssBitString cellIdentity(16, cellIdentity_value);

    /* Calling a fully-initializing constructor */
    CellGlobalIdGERAN cellGlobalId(plmn_Identity, locationAreaCode, cellIdentity);

    /* Creating 'routingAreaCode' field of 'cgi_Info' field */
    static unsigned char routingAreaCode_value[] = {
	0x00
    };
    OssBitString routingAreaCode(8, routingAreaCode_value);

    /* Calling a fully-initializing constructor */
    MeasResultGERAN::cgi_Info cgi_Info(cellGlobalId, routingAreaCode);

    value.set_cgi_Info(cgi_Info);

    /* Setting 'measResult' field */

    /* Calling a fully-initializing constructor */
    MeasResultGERAN::measResult measResult(0);

    value.set_measResult(measResult);
}

static void fill_MeasResultListGERAN(MeasResultListGERAN & value)
{
    {
	/* Adding component #2 */
	MeasResultGERAN comp2;
	fill_MeasResultGERAN(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultGERAN comp1;
	fill_MeasResultGERAN(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasResultCDMA2000(MeasResultCDMA2000 & value)
{
    value.set_physCellId(0);
    /* Setting 'cgi_Info' field */
    CellGlobalIdCDMA2000 cgi_Info;
    /* Setting 'cellGlobalId1XRTT' alternative of 'cgi_Info' field */
    static unsigned char cellGlobalId1XRTT_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellGlobalId1XRTT(47, cellGlobalId1XRTT_value);
    cgi_Info.set_cellGlobalId1XRTT(cellGlobalId1XRTT);

    value.set_cgi_Info(cgi_Info);

    /* Setting 'measResult' field */

    /* Calling a fully-initializing constructor */
    MeasResultCDMA2000::measResult measResult(0, 0);

    value.set_measResult(measResult);
}

static void fill_MeasResult2CDMA2000_r9(MeasResult2CDMA2000_r9 & value)
{
    /* Setting 'carrierFreq_r9' field */

    /* Calling a fully-initializing constructor */
    CarrierFreqCDMA2000 carrierFreq_r9(bc0, 0);

    value.set_carrierFreq_r9(carrierFreq_r9);

    /* Setting 'measResultList_r9' field */
    /* Creating 'measResultListCDMA2000' field of 'measResultList_r9' field */
    MeasResultListCDMA2000 measResultListCDMA2000;
    {
	/* Adding component #2 */
	MeasResultCDMA2000 comp2;
	fill_MeasResultCDMA2000(comp2);
	measResultListCDMA2000.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultCDMA2000 comp1;
	fill_MeasResultCDMA2000(comp1);
	measResultListCDMA2000.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    MeasResultsCDMA2000 measResultList_r9(TRUE, measResultListCDMA2000);

    value.set_measResultList_r9(measResultList_r9);
}

static void fill_MeasResultList2CDMA2000_r9(MeasResultList2CDMA2000_r9 & value)
{
    {
	/* Adding component #2 */
	MeasResult2CDMA2000_r9 comp2;
	fill_MeasResult2CDMA2000_r9(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResult2CDMA2000_r9 comp1;
	fill_MeasResult2CDMA2000_r9(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasResult2EUTRA_v9e0(MeasResult2EUTRA_v9e0 & value)
{
    value.set_carrierFreq_v9e0(65536);
}

static void fill_MeasResultList2EUTRA_v9e0(MeasResultList2EUTRA_v9e0 & value)
{
    {
	/* Adding component #2 */
	MeasResult2EUTRA_v9e0 comp2;
	fill_MeasResult2EUTRA_v9e0(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResult2EUTRA_v9e0 comp1;
	fill_MeasResult2EUTRA_v9e0(comp1);
	value.prepend(comp1);
    }
}

static void fill_RSRQ_Type_r12(RSRQ_Type_r12 & value)
{
    value.set_allSymbols_r12(TRUE);
    value.set_wideBand_r12(TRUE);
}

static void fill_MeasResult2EUTRA_v1250(MeasResult2EUTRA_v1250 & value)
{
    /* Setting 'rsrq_Type_r12' field */
    RSRQ_Type_r12 rsrq_Type_r12;
    fill_RSRQ_Type_r12(rsrq_Type_r12);
    value.set_rsrq_Type_r12(rsrq_Type_r12);
}

static void fill_MeasResultList2EUTRA_v1250(MeasResultList2EUTRA_v1250 & value)
{
    {
	/* Adding component #2 */
	MeasResult2EUTRA_v1250 comp2;
	fill_MeasResult2EUTRA_v1250(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResult2EUTRA_v1250 comp1;
	fill_MeasResult2EUTRA_v1250(comp1);
	value.prepend(comp1);
    }
}

static void fill_LogMeasResultBT_r15(LogMeasResultBT_r15 & value)
{
    /* Setting 'bt_Addr_r15' field */
    static unsigned char bt_Addr_r15_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssBitString bt_Addr_r15(48, bt_Addr_r15_value);
    value.set_bt_Addr_r15(bt_Addr_r15);

    value.set_rssi_BT_r15(127);
}

static void fill_LogMeasResultListBT_r15(LogMeasResultListBT_r15 & value)
{
    {
	/* Adding component #2 */
	LogMeasResultBT_r15 comp2;
	fill_LogMeasResultBT_r15(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	LogMeasResultBT_r15 comp1;
	fill_LogMeasResultBT_r15(comp1);
	value.prepend(comp1);
    }
}

static void fill_WLAN_Identifiers_r12(WLAN_Identifiers_r12 & value)
{
    /* Setting 'ssid_r12' field */
    static unsigned char ssid_r12_value[] = {
	0x00
    };
    OssString ssid_r12(sizeof(ssid_r12_value), (char *)ssid_r12_value);
    value.set_ssid_r12(ssid_r12);

    /* Setting 'bssid_r12' field */
    static unsigned char bssid_r12_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssString bssid_r12(sizeof(bssid_r12_value), (char *)bssid_r12_value);
    value.set_bssid_r12(bssid_r12);

    /* Setting 'hessid_r12' field */
    static unsigned char hessid_r12_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssString hessid_r12(sizeof(hessid_r12_value), (char *)hessid_r12_value);
    value.set_hessid_r12(hessid_r12);
}

static void fill_LogMeasResultWLAN_r15(LogMeasResultWLAN_r15 & value)
{
    /* Setting 'wlan_Identifiers_r15' field */
    WLAN_Identifiers_r12 wlan_Identifiers_r15;
    fill_WLAN_Identifiers_r12(wlan_Identifiers_r15);
    value.set_wlan_Identifiers_r15(wlan_Identifiers_r15);

    value.set_rssiWLAN_r15(0);
    /* Setting 'rtt_WLAN_r15' field */

    /* Calling a fully-initializing constructor */
    WLAN_RTT_r15 rtt_WLAN_r15(0, microseconds, 0);

    value.set_rtt_WLAN_r15(rtt_WLAN_r15);
}

static void fill_LogMeasResultListWLAN_r15(LogMeasResultListWLAN_r15 & value)
{
    {
	/* Adding component #2 */
	LogMeasResultWLAN_r15 comp2;
	fill_LogMeasResultWLAN_r15(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	LogMeasResultWLAN_r15 comp1;
	fill_LogMeasResultWLAN_r15(comp1);
	value.prepend(comp1);
    }
}

VarConnEstFailReport_r11 *create_samplevalue_VarConnEstFailReport_r11()
{
    /* Creating 'connEstFailReport_r11' field */
    /* Creating 'failedCellId_r11' field of 'connEstFailReport_r11' field */
    CellGlobalIdEUTRA failedCellId_r11;
    fill_CellGlobalIdEUTRA_1(failedCellId_r11);

    /* Creating 'locationInfo_r11' field of 'connEstFailReport_r11' field */
    LocationInfo_r10 locationInfo_r11;
    fill_LocationInfo_r10(locationInfo_r11);

    /* Creating 'measResultFailedCell_r11' field of 'connEstFailReport_r11' field */

    /* Calling a fully-initializing constructor */
    ConnEstFailReport_r11::measResultFailedCell_r11 measResultFailedCell_r11(0, 0);

    /* Creating 'measResultNeighCells_r11' field of 'connEstFailReport_r11' field */
    /* Creating 'measResultListEUTRA_r11' field of 'measResultNeighCells_r11' field of 'connEstFailReport_r11' field */
    MeasResultList2EUTRA_r9 measResultListEUTRA_r11;
    fill_MeasResultList2EUTRA_r9(measResultListEUTRA_r11);

    /* Creating 'measResultListUTRA_r11' field of 'measResultNeighCells_r11' field of 'connEstFailReport_r11' field */
    MeasResultList2UTRA_r9 measResultListUTRA_r11;
    fill_MeasResultList2UTRA_r9(measResultListUTRA_r11);

    /* Creating 'measResultListGERAN_r11' field of 'measResultNeighCells_r11' field of 'connEstFailReport_r11' field */
    MeasResultListGERAN measResultListGERAN_r11;
    fill_MeasResultListGERAN(measResultListGERAN_r11);

    /* Creating 'measResultsCDMA2000_r11' field of 'measResultNeighCells_r11' field of 'connEstFailReport_r11' field */
    MeasResultList2CDMA2000_r9 measResultsCDMA2000_r11;
    fill_MeasResultList2CDMA2000_r9(measResultsCDMA2000_r11);

    /* Calling a fully-initializing constructor */
    ConnEstFailReport_r11::measResultNeighCells_r11 measResultNeighCells_r11(measResultListEUTRA_r11, measResultListUTRA_r11, measResultListGERAN_r11, measResultsCDMA2000_r11);

    /* Creating 'measResultListEUTRA_v1130' field of 'connEstFailReport_r11' field */
    MeasResultList2EUTRA_v9e0 measResultListEUTRA_v1130;
    fill_MeasResultList2EUTRA_v9e0(measResultListEUTRA_v1130);

    /* Creating 'failedCellRSRQ_Type_r12' field of 'connEstFailReport_r11' field */
    RSRQ_Type_r12 failedCellRSRQ_Type_r12;
    fill_RSRQ_Type_r12(failedCellRSRQ_Type_r12);

    /* Creating 'measResultListEUTRA_v1250' field of 'connEstFailReport_r11' field */
    MeasResultList2EUTRA_v1250 measResultListEUTRA_v1250;
    fill_MeasResultList2EUTRA_v1250(measResultListEUTRA_v1250);

    /* Creating 'logMeasResultListBT_r15' field of 'connEstFailReport_r11' field */
    LogMeasResultListBT_r15 logMeasResultListBT_r15;
    fill_LogMeasResultListBT_r15(logMeasResultListBT_r15);

    /* Creating 'logMeasResultListWLAN_r15' field of 'connEstFailReport_r11' field */
    LogMeasResultListWLAN_r15 logMeasResultListWLAN_r15;
    fill_LogMeasResultListWLAN_r15(logMeasResultListWLAN_r15);

    /* Calling a fully-initializing constructor */
    ConnEstFailReport_r11 connEstFailReport_r11(failedCellId_r11, locationInfo_r11, measResultFailedCell_r11, measResultNeighCells_r11, 1, TRUE, TRUE, 0, measResultListEUTRA_v1130, -30, failedCellRSRQ_Type_r12, measResultListEUTRA_v1250, -1, logMeasResultListBT_r15, logMeasResultListWLAN_r15);

    /* Creating 'plmn_Identity_r11' field */
    PLMN_Identity plmn_Identity_r11;
    fill_PLMN_Identity(plmn_Identity_r11);

    /* Calling a fully-initializing constructor */
    return new VarConnEstFailReport_r11(connEstFailReport_r11, plmn_Identity_r11);
}

static void fill_AreaConfiguration_r10(AreaConfiguration_r10 & value)
{
    /* Setting 'cellGlobalIdList_r10' alternative */
    CellGlobalIdList_r10 cellGlobalIdList_r10;
    {
	/* Adding component #2 */
	CellGlobalIdEUTRA comp2;
	fill_CellGlobalIdEUTRA_1(comp2);
	cellGlobalIdList_r10.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CellGlobalIdEUTRA comp1;
	fill_CellGlobalIdEUTRA_1(comp1);
	cellGlobalIdList_r10.prepend(comp1);
    }
    value.set_cellGlobalIdList_r10(cellGlobalIdList_r10);
}

VarLogMeasConfig_r10 *create_samplevalue_VarLogMeasConfig_r10()
{
    /* Creating 'areaConfiguration_r10' field */
    AreaConfiguration_r10 areaConfiguration_r10;
    fill_AreaConfiguration_r10(areaConfiguration_r10);

    /* Calling a fully-initializing constructor */
    return new VarLogMeasConfig_r10(areaConfiguration_r10, LoggingDuration_r10_min10, LoggingInterval_r10_ms1280);
}

static void fill_AreaConfiguration_v1130(AreaConfiguration_v1130 & value)
{
    /* Setting 'trackingAreaCodeList_v1130' field */
    /* Creating 'plmn_Identity_perTAC_List_r11' field of 'trackingAreaCodeList_v1130' field */
    TrackingAreaCodeList_v1130::plmn_Identity_perTAC_List_r11 plmn_Identity_perTAC_List_r11;
    {
	/* Adding component #2 */
	PLMN_Identity comp2;
	fill_PLMN_Identity(comp2);
	plmn_Identity_perTAC_List_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_Identity comp1;
	fill_PLMN_Identity(comp1);
	plmn_Identity_perTAC_List_r11.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    TrackingAreaCodeList_v1130 trackingAreaCodeList_v1130(plmn_Identity_perTAC_List_r11);

    value.set_trackingAreaCodeList_v1130(trackingAreaCodeList_v1130);
}

VarLogMeasConfig_r11 *create_samplevalue_VarLogMeasConfig_r11()
{
    /* Creating 'areaConfiguration_r10' field */
    AreaConfiguration_r10 areaConfiguration_r10;
    fill_AreaConfiguration_r10(areaConfiguration_r10);

    /* Creating 'areaConfiguration_v1130' field */
    AreaConfiguration_v1130 areaConfiguration_v1130;
    fill_AreaConfiguration_v1130(areaConfiguration_v1130);

    /* Calling a fully-initializing constructor */
    return new VarLogMeasConfig_r11(areaConfiguration_r10, areaConfiguration_v1130, LoggingDuration_r10_min10, LoggingInterval_r10_ms1280);
}

static void fill_TargetMBSFN_Area_r12(TargetMBSFN_Area_r12 & value)
{
    value.set_mbsfn_AreaId_r12(0);
    value.set_carrierFreq_r12(0);
}

static void fill_TargetMBSFN_AreaList_r12(TargetMBSFN_AreaList_r12 & value)
{
    {
	/* Adding component #2 */
	TargetMBSFN_Area_r12 comp2;
	fill_TargetMBSFN_Area_r12(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	TargetMBSFN_Area_r12 comp1;
	fill_TargetMBSFN_Area_r12(comp1);
	value.prepend(comp1);
    }
}

VarLogMeasConfig_r12 *create_samplevalue_VarLogMeasConfig_r12()
{
    /* Creating 'areaConfiguration_r10' field */
    AreaConfiguration_r10 areaConfiguration_r10;
    fill_AreaConfiguration_r10(areaConfiguration_r10);

    /* Creating 'areaConfiguration_v1130' field */
    AreaConfiguration_v1130 areaConfiguration_v1130;
    fill_AreaConfiguration_v1130(areaConfiguration_v1130);

    /* Creating 'targetMBSFN_AreaList_r12' field */
    TargetMBSFN_AreaList_r12 targetMBSFN_AreaList_r12;
    fill_TargetMBSFN_AreaList_r12(targetMBSFN_AreaList_r12);

    /* Calling a fully-initializing constructor */
    return new VarLogMeasConfig_r12(areaConfiguration_r10, areaConfiguration_v1130, LoggingDuration_r10_min10, LoggingInterval_r10_ms1280, targetMBSFN_AreaList_r12);
}

VarLogMeasConfig_r15 *create_samplevalue_VarLogMeasConfig_r15()
{
    /* Creating 'areaConfiguration_r10' field */
    AreaConfiguration_r10 areaConfiguration_r10;
    fill_AreaConfiguration_r10(areaConfiguration_r10);

    /* Creating 'areaConfiguration_v1130' field */
    AreaConfiguration_v1130 areaConfiguration_v1130;
    fill_AreaConfiguration_v1130(areaConfiguration_v1130);

    /* Creating 'targetMBSFN_AreaList_r12' field */
    TargetMBSFN_AreaList_r12 targetMBSFN_AreaList_r12;
    fill_TargetMBSFN_AreaList_r12(targetMBSFN_AreaList_r12);

    /* Creating 'bt_NameList_r15' field */
    BT_NameList_r15 bt_NameList_r15;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00
	};
	OssString comp2(sizeof(comp2_value), (char *)comp2_value);
	bt_NameList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00
	};
	OssString comp1(sizeof(comp1_value), (char *)comp1_value);
	bt_NameList_r15.prepend(comp1);
    }

    /* Creating 'wlan_NameList_r15' field */
    WLAN_NameList_r15 wlan_NameList_r15;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00
	};
	OssString comp2(sizeof(comp2_value), (char *)comp2_value);
	wlan_NameList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00
	};
	OssString comp1(sizeof(comp1_value), (char *)comp1_value);
	wlan_NameList_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    return new VarLogMeasConfig_r15(areaConfiguration_r10, areaConfiguration_v1130, LoggingDuration_r10_min10, LoggingInterval_r10_ms1280, targetMBSFN_AreaList_r12, bt_NameList_r15, wlan_NameList_r15);
}

static void fill_TraceReference_r10(TraceReference_r10 & value)
{
    /* Setting 'plmn_Identity_r10' field */
    PLMN_Identity plmn_Identity_r10;
    fill_PLMN_Identity(plmn_Identity_r10);
    value.set_plmn_Identity_r10(plmn_Identity_r10);

    /* Setting 'traceId_r10' field */
    static unsigned char traceId_r10_value[] = {
	0x00, 0x00, 0x00
    };
    OssString traceId_r10(sizeof(traceId_r10_value), (char *)traceId_r10_value);
    value.set_traceId_r10(traceId_r10);
}

static void fill_BLER_Result_r12(BLER_Result_r12 & value)
{
    value.set_bler_r12(0);
    /* Setting 'blocksReceived_r12' field */
    /* Creating 'n_r12' field of 'blocksReceived_r12' field */
    static unsigned char n_r12_value[] = {
	0x00
    };
    OssBitString n_r12(3, n_r12_value);

    /* Creating 'm_r12' field of 'blocksReceived_r12' field */
    static unsigned char m_r12_value[] = {
	0x00
    };
    OssBitString m_r12(8, m_r12_value);

    /* Calling a fully-initializing constructor */
    BLER_Result_r12::blocksReceived_r12 blocksReceived_r12(n_r12, m_r12);

    value.set_blocksReceived_r12(blocksReceived_r12);
}

static void fill_DataBLER_MCH_Result_r12(DataBLER_MCH_Result_r12 & value)
{
    value.set_mch_Index_r12(1);
    /* Setting 'dataBLER_Result_r12' field */
    BLER_Result_r12 dataBLER_Result_r12;
    fill_BLER_Result_r12(dataBLER_Result_r12);
    value.set_dataBLER_Result_r12(dataBLER_Result_r12);
}

static void fill_MeasResultMBSFN_r12(MeasResultMBSFN_r12 & value)
{
    /* Setting 'mbsfn_Area_r12' field */

    /* Calling a fully-initializing constructor */
    MeasResultMBSFN_r12::mbsfn_Area_r12 mbsfn_Area_r12(0, 0);

    value.set_mbsfn_Area_r12(mbsfn_Area_r12);

    value.set_rsrpResultMBSFN_r12(0);
    value.set_rsrqResultMBSFN_r12(0);
    /* Setting 'signallingBLER_Result_r12' field */
    BLER_Result_r12 signallingBLER_Result_r12;
    fill_BLER_Result_r12(signallingBLER_Result_r12);
    value.set_signallingBLER_Result_r12(signallingBLER_Result_r12);

    /* Setting 'dataBLER_MCH_ResultList_r12' field */
    DataBLER_MCH_ResultList_r12 dataBLER_MCH_ResultList_r12;
    {
	/* Adding component #2 */
	DataBLER_MCH_Result_r12 comp2;
	fill_DataBLER_MCH_Result_r12(comp2);
	dataBLER_MCH_ResultList_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DataBLER_MCH_Result_r12 comp1;
	fill_DataBLER_MCH_Result_r12(comp1);
	dataBLER_MCH_ResultList_r12.prepend(comp1);
    }
    value.set_dataBLER_MCH_ResultList_r12(dataBLER_MCH_ResultList_r12);
}

static void fill_LogMeasInfo_r10(LogMeasInfo_r10 & value)
{
    /* Setting 'locationInfo_r10' field */
    LocationInfo_r10 locationInfo_r10;
    fill_LocationInfo_r10(locationInfo_r10);
    value.set_locationInfo_r10(locationInfo_r10);

    value.set_relativeTimeStamp_r10(0);
    /* Setting 'servCellIdentity_r10' field */
    CellGlobalIdEUTRA servCellIdentity_r10;
    fill_CellGlobalIdEUTRA_1(servCellIdentity_r10);
    value.set_servCellIdentity_r10(servCellIdentity_r10);

    /* Setting 'measResultServCell_r10' field */

    /* Calling a fully-initializing constructor */
    LogMeasInfo_r10::measResultServCell_r10 measResultServCell_r10(0, 0);

    value.set_measResultServCell_r10(measResultServCell_r10);

    /* Setting 'measResultNeighCells_r10' field */
    /* Creating 'measResultListEUTRA_r10' field of 'measResultNeighCells_r10' field */
    MeasResultList2EUTRA_r9 measResultListEUTRA_r10;
    fill_MeasResultList2EUTRA_r9(measResultListEUTRA_r10);

    /* Creating 'measResultListUTRA_r10' field of 'measResultNeighCells_r10' field */
    MeasResultList2UTRA_r9 measResultListUTRA_r10;
    fill_MeasResultList2UTRA_r9(measResultListUTRA_r10);

    /* Creating 'measResultListGERAN_r10' field of 'measResultNeighCells_r10' field */
    MeasResultList2GERAN_r10 measResultListGERAN_r10;
    {
	/* Adding component #2 */
	MeasResultListGERAN comp2;
	fill_MeasResultListGERAN(comp2);
	measResultListGERAN_r10.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultListGERAN comp1;
	fill_MeasResultListGERAN(comp1);
	measResultListGERAN_r10.prepend(comp1);
    }

    /* Creating 'measResultListCDMA2000_r10' field of 'measResultNeighCells_r10' field */
    MeasResultList2CDMA2000_r9 measResultListCDMA2000_r10;
    fill_MeasResultList2CDMA2000_r9(measResultListCDMA2000_r10);

    /* Calling a fully-initializing constructor */
    LogMeasInfo_r10::measResultNeighCells_r10 measResultNeighCells_r10(measResultListEUTRA_r10, measResultListUTRA_r10, measResultListGERAN_r10, measResultListCDMA2000_r10);

    value.set_measResultNeighCells_r10(measResultNeighCells_r10);

    /* Setting 'measResultListEUTRA_v1090' field */
    MeasResultList2EUTRA_v9e0 measResultListEUTRA_v1090;
    fill_MeasResultList2EUTRA_v9e0(measResultListEUTRA_v1090);
    value.set_measResultListEUTRA_v1090(measResultListEUTRA_v1090);

    /* Setting 'measResultListMBSFN_r12' field */
    MeasResultListMBSFN_r12 measResultListMBSFN_r12;
    {
	/* Adding component #2 */
	MeasResultMBSFN_r12 comp2;
	fill_MeasResultMBSFN_r12(comp2);
	measResultListMBSFN_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultMBSFN_r12 comp1;
	fill_MeasResultMBSFN_r12(comp1);
	measResultListMBSFN_r12.prepend(comp1);
    }
    value.set_measResultListMBSFN_r12(measResultListMBSFN_r12);

    value.set_measResultServCell_v1250(-30);
    /* Setting 'servCellRSRQ_Type_r12' field */
    RSRQ_Type_r12 servCellRSRQ_Type_r12;
    fill_RSRQ_Type_r12(servCellRSRQ_Type_r12);
    value.set_servCellRSRQ_Type_r12(servCellRSRQ_Type_r12);

    /* Setting 'measResultListEUTRA_v1250' field */
    MeasResultList2EUTRA_v1250 measResultListEUTRA_v1250;
    fill_MeasResultList2EUTRA_v1250(measResultListEUTRA_v1250);
    value.set_measResultListEUTRA_v1250(measResultListEUTRA_v1250);

    value.set_inDeviceCoexDetected_r13(inDeviceCoexDetected_r13_true);
    value.set_measResultServCell_v1360(-1);
    /* Setting 'logMeasResultListBT_r15' field */
    LogMeasResultListBT_r15 logMeasResultListBT_r15;
    fill_LogMeasResultListBT_r15(logMeasResultListBT_r15);
    value.set_logMeasResultListBT_r15(logMeasResultListBT_r15);

    /* Setting 'logMeasResultListWLAN_r15' field */
    LogMeasResultListWLAN_r15 logMeasResultListWLAN_r15;
    fill_LogMeasResultListWLAN_r15(logMeasResultListWLAN_r15);
    value.set_logMeasResultListWLAN_r15(logMeasResultListWLAN_r15);
}

static void fill_LogMeasInfoList2_r10(LogMeasInfoList2_r10 & value)
{
    {
	/* Adding component #2 */
	LogMeasInfo_r10 comp2;
	fill_LogMeasInfo_r10(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	LogMeasInfo_r10 comp1;
	fill_LogMeasInfo_r10(comp1);
	value.prepend(comp1);
    }
}

VarLogMeasReport_r10 *create_samplevalue_VarLogMeasReport_r10()
{
    /* Creating 'traceReference_r10' field */
    TraceReference_r10 traceReference_r10;
    fill_TraceReference_r10(traceReference_r10);

    /* Creating 'traceRecordingSessionRef_r10' field */
    static unsigned char traceRecordingSessionRef_r10_value[] = {
	0x00, 0x00
    };
    OssString traceRecordingSessionRef_r10(sizeof(traceRecordingSessionRef_r10_value), (char *)traceRecordingSessionRef_r10_value);

    /* Creating 'tce_Id_r10' field */
    static unsigned char tce_Id_r10_value[] = {
	0x00
    };
    OssString tce_Id_r10(sizeof(tce_Id_r10_value), (char *)tce_Id_r10_value);

    /* Creating 'plmn_Identity_r10' field */
    PLMN_Identity plmn_Identity_r10;
    fill_PLMN_Identity(plmn_Identity_r10);

    /* Creating 'absoluteTimeInfo_r10' field */
    static unsigned char absoluteTimeInfo_r10_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssBitString absoluteTimeInfo_r10(48, absoluteTimeInfo_r10_value);

    /* Creating 'logMeasInfoList_r10' field */
    LogMeasInfoList2_r10 logMeasInfoList_r10;
    fill_LogMeasInfoList2_r10(logMeasInfoList_r10);

    /* Calling a fully-initializing constructor */
    return new VarLogMeasReport_r10(traceReference_r10, traceRecordingSessionRef_r10, tce_Id_r10, plmn_Identity_r10, absoluteTimeInfo_r10, logMeasInfoList_r10);
}

static void fill_PLMN_IdentityList3_r11(PLMN_IdentityList3_r11 & value)
{
    {
	/* Adding component #2 */
	PLMN_Identity comp2;
	fill_PLMN_Identity(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_Identity comp1;
	fill_PLMN_Identity(comp1);
	value.prepend(comp1);
    }
}

VarLogMeasReport_r11 *create_samplevalue_VarLogMeasReport_r11()
{
    /* Creating 'traceReference_r10' field */
    TraceReference_r10 traceReference_r10;
    fill_TraceReference_r10(traceReference_r10);

    /* Creating 'traceRecordingSessionRef_r10' field */
    static unsigned char traceRecordingSessionRef_r10_value[] = {
	0x00, 0x00
    };
    OssString traceRecordingSessionRef_r10(sizeof(traceRecordingSessionRef_r10_value), (char *)traceRecordingSessionRef_r10_value);

    /* Creating 'tce_Id_r10' field */
    static unsigned char tce_Id_r10_value[] = {
	0x00
    };
    OssString tce_Id_r10(sizeof(tce_Id_r10_value), (char *)tce_Id_r10_value);

    /* Creating 'plmn_IdentityList_r11' field */
    PLMN_IdentityList3_r11 plmn_IdentityList_r11;
    fill_PLMN_IdentityList3_r11(plmn_IdentityList_r11);

    /* Creating 'absoluteTimeInfo_r10' field */
    static unsigned char absoluteTimeInfo_r10_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssBitString absoluteTimeInfo_r10(48, absoluteTimeInfo_r10_value);

    /* Creating 'logMeasInfoList_r10' field */
    LogMeasInfoList2_r10 logMeasInfoList_r10;
    fill_LogMeasInfoList2_r10(logMeasInfoList_r10);

    /* Calling a fully-initializing constructor */
    return new VarLogMeasReport_r11(traceReference_r10, traceRecordingSessionRef_r10, tce_Id_r10, plmn_IdentityList_r11, absoluteTimeInfo_r10, logMeasInfoList_r10);
}

static void fill_MeasIdToAddMod(MeasIdToAddMod & value)
{
    value.set_measId(1);
    value.set_measObjectId(1);
    value.set_reportConfigId(1);
}

static void fill_MeasIdToAddModList(MeasIdToAddModList & value)
{
    {
	/* Adding component #2 */
	MeasIdToAddMod comp2;
	fill_MeasIdToAddMod(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasIdToAddMod comp1;
	fill_MeasIdToAddMod(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasIdToAddModExt_r12(MeasIdToAddModExt_r12 & value)
{
    value.set_measId_v1250(33);
    value.set_measObjectId_r12(1);
    value.set_reportConfigId_r12(1);
}

static void fill_MeasIdToAddModListExt_r12(MeasIdToAddModListExt_r12 & value)
{
    {
	/* Adding component #2 */
	MeasIdToAddModExt_r12 comp2;
	fill_MeasIdToAddModExt_r12(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasIdToAddModExt_r12 comp1;
	fill_MeasIdToAddModExt_r12(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasIdToAddMod_v1310(MeasIdToAddMod_v1310 & value)
{
    value.set_measObjectId_v1310(33);
}

static void fill_MeasIdToAddModList_v1310(MeasIdToAddModList_v1310 & value)
{
    {
	/* Adding component #2 */
	MeasIdToAddMod_v1310 comp2;
	fill_MeasIdToAddMod_v1310(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasIdToAddMod_v1310 comp1;
	fill_MeasIdToAddMod_v1310(comp1);
	value.prepend(comp1);
    }
}

static void fill_CellIndexList(CellIndexList & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_CellsToAddMod(CellsToAddMod & value)
{
    value.set_cellIndex(1);
    value.set_physCellId(0);
    value.set_cellIndividualOffset(dB_24);
}

static void fill_PhysCellIdRange(PhysCellIdRange & value)
{
    value.set_start(0);
    value.set_range(range_n4);
}

static void fill_BlackCellsToAddMod(BlackCellsToAddMod & value)
{
    value.set_cellIndex(1);
    /* Setting 'physCellIdRange' field */
    PhysCellIdRange physCellIdRange;
    fill_PhysCellIdRange(physCellIdRange);
    value.set_physCellIdRange(physCellIdRange);
}

static void fill_AltTTT_CellsToAddMod_r12(AltTTT_CellsToAddMod_r12 & value)
{
    value.set_cellIndex_r12(1);
    /* Setting 'physCellIdRange_r12' field */
    PhysCellIdRange physCellIdRange_r12;
    fill_PhysCellIdRange(physCellIdRange_r12);
    value.set_physCellIdRange_r12(physCellIdRange_r12);
}

static void fill_WhiteCellsToAddMod_r13(WhiteCellsToAddMod_r13 & value)
{
    value.set_cellIndex_r13(1);
    /* Setting 'physCellIdRange_r13' field */
    PhysCellIdRange physCellIdRange_r13;
    fill_PhysCellIdRange(physCellIdRange_r13);
    value.set_physCellIdRange_r13(physCellIdRange_r13);
}

static void fill_Tx_ResourcePoolMeasList_r14(Tx_ResourcePoolMeasList_r14 & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_MeasObjectEUTRA(MeasObjectEUTRA & value)
{
    value.set_carrierFreq(0);
    value.set_allowedMeasBandwidth(mbw6);
    value.set_presenceAntennaPort1(TRUE);
    /* Setting 'neighCellConfig' field */
    static unsigned char neighCellConfig_value[] = {
	0x00
    };
    OssBitString neighCellConfig(2, neighCellConfig_value);
    value.set_neighCellConfig(neighCellConfig);

    value.set_offsetFreq(dB_24);
    /* Setting 'cellsToRemoveList' field */
    CellIndexList cellsToRemoveList;
    fill_CellIndexList(cellsToRemoveList);
    value.set_cellsToRemoveList(cellsToRemoveList);

    /* Setting 'cellsToAddModList' field */
    CellsToAddModList cellsToAddModList;
    {
	/* Adding component #2 */
	CellsToAddMod comp2;
	fill_CellsToAddMod(comp2);
	cellsToAddModList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CellsToAddMod comp1;
	fill_CellsToAddMod(comp1);
	cellsToAddModList.prepend(comp1);
    }
    value.set_cellsToAddModList(cellsToAddModList);

    /* Setting 'blackCellsToRemoveList' field */
    CellIndexList blackCellsToRemoveList;
    fill_CellIndexList(blackCellsToRemoveList);
    value.set_blackCellsToRemoveList(blackCellsToRemoveList);

    /* Setting 'blackCellsToAddModList' field */
    BlackCellsToAddModList blackCellsToAddModList;
    {
	/* Adding component #2 */
	BlackCellsToAddMod comp2;
	fill_BlackCellsToAddMod(comp2);
	blackCellsToAddModList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	BlackCellsToAddMod comp1;
	fill_BlackCellsToAddMod(comp1);
	blackCellsToAddModList.prepend(comp1);
    }
    value.set_blackCellsToAddModList(blackCellsToAddModList);

    value.set_cellForWhichToReportCGI(0);
    value.set_measCycleSCell_r10(MeasCycleSCell_r10_sf160);
    /* Setting 'measSubframePatternConfigNeigh_r10' field */
    MeasSubframePatternConfigNeigh_r10 measSubframePatternConfigNeigh_r10;
    measSubframePatternConfigNeigh_r10.set_release(0);
    value.set_measSubframePatternConfigNeigh_r10(measSubframePatternConfigNeigh_r10);

    value.set_widebandRSRQ_Meas_r11(TRUE);
    /* Setting 'altTTT_CellsToRemoveList_r12' field */
    CellIndexList altTTT_CellsToRemoveList_r12;
    fill_CellIndexList(altTTT_CellsToRemoveList_r12);
    value.set_altTTT_CellsToRemoveList_r12(altTTT_CellsToRemoveList_r12);

    /* Setting 'altTTT_CellsToAddModList_r12' field */
    AltTTT_CellsToAddModList_r12 altTTT_CellsToAddModList_r12;
    {
	/* Adding component #2 */
	AltTTT_CellsToAddMod_r12 comp2;
	fill_AltTTT_CellsToAddMod_r12(comp2);
	altTTT_CellsToAddModList_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	AltTTT_CellsToAddMod_r12 comp1;
	fill_AltTTT_CellsToAddMod_r12(comp1);
	altTTT_CellsToAddModList_r12.prepend(comp1);
    }
    value.set_altTTT_CellsToAddModList_r12(altTTT_CellsToAddModList_r12);

    /* Setting 't312_r12' field */
    MeasObjectEUTRA::t312_r12 t312_r12;
    t312_r12.set_release(0);
    value.set_t312_r12(t312_r12);

    value.set_reducedMeasPerformance_r12(TRUE);
    /* Setting 'measDS_Config_r12' field */
    MeasDS_Config_r12 measDS_Config_r12;
    measDS_Config_r12.set_release(0);
    value.set_measDS_Config_r12(measDS_Config_r12);

    /* Setting 'whiteCellsToRemoveList_r13' field */
    CellIndexList whiteCellsToRemoveList_r13;
    fill_CellIndexList(whiteCellsToRemoveList_r13);
    value.set_whiteCellsToRemoveList_r13(whiteCellsToRemoveList_r13);

    /* Setting 'whiteCellsToAddModList_r13' field */
    WhiteCellsToAddModList_r13 whiteCellsToAddModList_r13;
    {
	/* Adding component #2 */
	WhiteCellsToAddMod_r13 comp2;
	fill_WhiteCellsToAddMod_r13(comp2);
	whiteCellsToAddModList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	WhiteCellsToAddMod_r13 comp1;
	fill_WhiteCellsToAddMod_r13(comp1);
	whiteCellsToAddModList_r13.prepend(comp1);
    }
    value.set_whiteCellsToAddModList_r13(whiteCellsToAddModList_r13);

    /* Setting 'rmtc_Config_r13' field */
    RMTC_Config_r13 rmtc_Config_r13;
    rmtc_Config_r13.set_release(0);
    value.set_rmtc_Config_r13(rmtc_Config_r13);

    value.set_carrierFreq_r13(65536);
    /* Setting 'tx_ResourcePoolToRemoveList_r14' field */
    Tx_ResourcePoolMeasList_r14 tx_ResourcePoolToRemoveList_r14;
    fill_Tx_ResourcePoolMeasList_r14(tx_ResourcePoolToRemoveList_r14);
    value.set_tx_ResourcePoolToRemoveList_r14(tx_ResourcePoolToRemoveList_r14);

    /* Setting 'tx_ResourcePoolToAddList_r14' field */
    Tx_ResourcePoolMeasList_r14 tx_ResourcePoolToAddList_r14;
    fill_Tx_ResourcePoolMeasList_r14(tx_ResourcePoolToAddList_r14);
    value.set_tx_ResourcePoolToAddList_r14(tx_ResourcePoolToAddList_r14);

    value.set_fembms_MixedCarrier_r14(TRUE);
    /* Setting 'measSensing_Config_r15' field */

    /* Calling a fully-initializing constructor */
    MeasSensing_Config_r15 measSensing_Config_r15(1, sensingPeriodicity_r15_ms20, 5, 1);

    value.set_measSensing_Config_r15(measSensing_Config_r15);
}

static void fill_MeasObjectToAddMod(MeasObjectToAddMod & value)
{
    value.set_measObjectId(1);
    /* Setting 'measObject' field */
    MeasObjectToAddMod::measObject measObject;
    /* Setting 'measObjectEUTRA' alternative of 'measObject' field */
    MeasObjectEUTRA measObjectEUTRA;
    fill_MeasObjectEUTRA(measObjectEUTRA);
    measObject.set_measObjectEUTRA(measObjectEUTRA);

    value.set_measObject(measObject);
}

static void fill_MeasObjectToAddModList(MeasObjectToAddModList & value)
{
    {
	/* Adding component #2 */
	MeasObjectToAddMod comp2;
	fill_MeasObjectToAddMod(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasObjectToAddMod comp1;
	fill_MeasObjectToAddMod(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasObjectToAddModExt_r13(MeasObjectToAddModExt_r13 & value)
{
    value.set_measObjectId_r13(33);
    /* Setting 'measObject_r13' field */
    MeasObjectToAddModExt_r13::measObject_r13 measObject_r13;
    /* Setting 'measObjectEUTRA_r13' alternative of 'measObject_r13' field */
    MeasObjectEUTRA measObjectEUTRA_r13;
    fill_MeasObjectEUTRA(measObjectEUTRA_r13);
    measObject_r13.set_measObjectEUTRA_r13(measObjectEUTRA_r13);

    value.set_measObject_r13(measObject_r13);
}

static void fill_MeasObjectToAddModListExt_r13(MeasObjectToAddModListExt_r13 & value)
{
    {
	/* Adding component #2 */
	MeasObjectToAddModExt_r13 comp2;
	fill_MeasObjectToAddModExt_r13(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasObjectToAddModExt_r13 comp1;
	fill_MeasObjectToAddModExt_r13(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasObjectToAddMod_v9e0(MeasObjectToAddMod_v9e0 & value)
{
    /* Setting 'measObjectEUTRA_v9e0' field */

    /* Calling a fully-initializing constructor */
    MeasObjectEUTRA_v9e0 measObjectEUTRA_v9e0(65536);

    value.set_measObjectEUTRA_v9e0(measObjectEUTRA_v9e0);
}

static void fill_MeasObjectToAddModList_v9e0(MeasObjectToAddModList_v9e0 & value)
{
    {
	/* Adding component #2 */
	MeasObjectToAddMod_v9e0 comp2;
	fill_MeasObjectToAddMod_v9e0(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasObjectToAddMod_v9e0 comp1;
	fill_MeasObjectToAddMod_v9e0(comp1);
	value.prepend(comp1);
    }
}

static void fill_RSRQ_RangeConfig_r12(RSRQ_RangeConfig_r12 & value)
{
    value.set_release(0);
}

static void fill_BT_NameListConfig_r15(BT_NameListConfig_r15 & value)
{
    value.set_release(0);
}

static void fill_WLAN_NameListConfig_r15(WLAN_NameListConfig_r15 & value)
{
    value.set_release(0);
}

static void fill_ReportConfigToAddMod(ReportConfigToAddMod & value)
{
    value.set_reportConfigId(1);
    /* Setting 'reportConfig' field */
    ReportConfigToAddMod::reportConfig reportConfig;
    /* Setting 'reportConfigEUTRA' alternative of 'reportConfig' field */
    /* Creating 'triggerType' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */
    ReportConfigEUTRA::triggerType triggerType;
    /* Setting 'event' alternative of 'triggerType' field of 'reportConfigEUTRA' alternative of 'reportConfig' field... */
    /* Creating 'eventId' field of 'event' alternative of 'triggerType' field of 'reportConfigEUTRA' alternative... */
    ReportConfigEUTRA::triggerType::event::eventId eventId;
    /* Setting 'eventA1' alternative of 'eventId' field of 'event' alternative of 'triggerType' field... */
    /* Creating 'a1_Threshold' field of 'eventA1' alternative of 'eventId' field of 'event' alternative... */
    ThresholdEUTRA a1_Threshold;
    a1_Threshold.set_threshold_RSRP(0);

    /* Calling a fully-initializing constructor */
    ReportConfigEUTRA::triggerType::event::eventId::eventA1 eventA1(a1_Threshold);

    eventId.set_eventA1(eventA1);

    /* Calling a fully-initializing constructor */
    ReportConfigEUTRA::triggerType::event event(eventId, 0, TimeToTrigger_ms0);

    triggerType.set_event(event);

    /* Creating 'alternativeTimeToTrigger_r12' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */
    ReportConfigEUTRA::alternativeTimeToTrigger_r12 alternativeTimeToTrigger_r12;
    alternativeTimeToTrigger_r12.set_release(0);

    /* Creating 'aN_Threshold1_v1250' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */
    RSRQ_RangeConfig_r12 aN_Threshold1_v1250;
    fill_RSRQ_RangeConfig_r12(aN_Threshold1_v1250);

    /* Creating 'a5_Threshold2_v1250' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */
    RSRQ_RangeConfig_r12 a5_Threshold2_v1250;
    fill_RSRQ_RangeConfig_r12(a5_Threshold2_v1250);

    /* Creating 'rs_sinr_Config_r13' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */
    ReportConfigEUTRA::rs_sinr_Config_r13 rs_sinr_Config_r13;
    rs_sinr_Config_r13.set_release(0);

    /* Creating 'measRSSI_ReportConfig_r13' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */

    /* Calling a fully-initializing constructor */
    MeasRSSI_ReportConfig_r13 measRSSI_ReportConfig_r13(0);

    /* Creating 'ul_DelayConfig_r13' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */
    UL_DelayConfig_r13 ul_DelayConfig_r13;
    ul_DelayConfig_r13.set_release(0);

    /* Creating 'includeBT_Meas_r15' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */
    BT_NameListConfig_r15 includeBT_Meas_r15;
    fill_BT_NameListConfig_r15(includeBT_Meas_r15);

    /* Creating 'includeWLAN_Meas_r15' field of 'reportConfigEUTRA' alternative of 'reportConfig' field */
    WLAN_NameListConfig_r15 includeWLAN_Meas_r15;
    fill_WLAN_NameListConfig_r15(includeWLAN_Meas_r15);

    /* Calling a fully-initializing constructor */
    ReportConfigEUTRA reportConfigEUTRA(triggerType, triggerQuantity_rsrp, sameAsTriggerQuantity, 1, ReportInterval_ms120, ReportConfigEUTRA_reportAmount_r1, ReportConfigEUTRA_si_RequestForHO_r9_setup, ue_RxTxTimeDiffPeriodical_r9_setup, includeLocationInfo_r10_true, reportAddNeighMeas_r10_setup, alternativeTimeToTrigger_r12, TRUE, TRUE, aN_Threshold1_v1250, a5_Threshold2_v1250, TRUE, TRUE, TRUE, TRUE, rs_sinr_Config_r13, TRUE, measRSSI_ReportConfig_r13, includeMultiBandInfo_r13_true, ul_DelayConfig_r13, TRUE, reportLocation, 0, includeBT_Meas_r15, includeWLAN_Meas_r15, sensing, 2, TRUE);

    reportConfig.set_reportConfigEUTRA(reportConfigEUTRA);

    value.set_reportConfig(reportConfig);
}

static void fill_ReportConfigToAddModList(ReportConfigToAddModList & value)
{
    {
	/* Adding component #2 */
	ReportConfigToAddMod comp2;
	fill_ReportConfigToAddMod(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	ReportConfigToAddMod comp1;
	fill_ReportConfigToAddMod(comp1);
	value.prepend(comp1);
    }
}

static void fill_QuantityConfigRS_NR_r15(QuantityConfigRS_NR_r15 & value)
{
    value.set_filterCoeff_RSRP_r15(fc0);
    value.set_filterCoeff_RSRQ_r15(fc0);
    value.set_filterCoefficient_SINR_r13(fc0);
}

static void fill_QuantityConfigNR_r15(QuantityConfigNR_r15 & value)
{
    /* Setting 'measQuantityCellNR_r15' field */
    QuantityConfigRS_NR_r15 measQuantityCellNR_r15;
    fill_QuantityConfigRS_NR_r15(measQuantityCellNR_r15);
    value.set_measQuantityCellNR_r15(measQuantityCellNR_r15);

    /* Setting 'measQuantityRS_IndexNR_r15' field */
    QuantityConfigRS_NR_r15 measQuantityRS_IndexNR_r15;
    fill_QuantityConfigRS_NR_r15(measQuantityRS_IndexNR_r15);
    value.set_measQuantityRS_IndexNR_r15(measQuantityRS_IndexNR_r15);
}

static void fill_QuantityConfig(QuantityConfig & value)
{
    /* Setting 'quantityConfigEUTRA' field */

    /* Calling a fully-initializing constructor */
    QuantityConfigEUTRA quantityConfigEUTRA(fc0, fc0);

    value.set_quantityConfigEUTRA(quantityConfigEUTRA);

    /* Setting 'quantityConfigUTRA' field */

    /* Calling a fully-initializing constructor */
    QuantityConfigUTRA quantityConfigUTRA(cpich_RSCP, pccpch_RSCP, fc0);

    value.set_quantityConfigUTRA(quantityConfigUTRA);

    /* Setting 'quantityConfigGERAN' field */

    /* Calling a fully-initializing constructor */
    QuantityConfigGERAN quantityConfigGERAN(rssi, fc0);

    value.set_quantityConfigGERAN(quantityConfigGERAN);

    /* Setting 'quantityConfigCDMA2000' field */

    /* Calling a fully-initializing constructor */
    QuantityConfigCDMA2000 quantityConfigCDMA2000(pilotStrength);

    value.set_quantityConfigCDMA2000(quantityConfigCDMA2000);

    /* Setting 'quantityConfigUTRA_v1020' field */

    /* Calling a fully-initializing constructor */
    QuantityConfigUTRA_v1020 quantityConfigUTRA_v1020(fc0);

    value.set_quantityConfigUTRA_v1020(quantityConfigUTRA_v1020);

    /* Setting 'quantityConfigEUTRA_v1250' field */

    /* Calling a fully-initializing constructor */
    QuantityConfigEUTRA_v1250 quantityConfigEUTRA_v1250(fc0);

    value.set_quantityConfigEUTRA_v1250(quantityConfigEUTRA_v1250);

    /* Setting 'quantityConfigEUTRA_v1310' field */

    /* Calling a fully-initializing constructor */
    QuantityConfigEUTRA_v1310 quantityConfigEUTRA_v1310(fc0);

    value.set_quantityConfigEUTRA_v1310(quantityConfigEUTRA_v1310);

    /* Setting 'quantityConfigWLAN_r13' field */

    /* Calling a fully-initializing constructor */
    QuantityConfigWLAN_r13 quantityConfigWLAN_r13(rssiWLAN, fc0);

    value.set_quantityConfigWLAN_r13(quantityConfigWLAN_r13);

    /* Setting 'quantityConfigNRList_r15' field */
    QuantityConfigNRList_r15 quantityConfigNRList_r15;
    {
	/* Adding component #2 */
	QuantityConfigNR_r15 comp2;
	fill_QuantityConfigNR_r15(comp2);
	quantityConfigNRList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	QuantityConfigNR_r15 comp1;
	fill_QuantityConfigNR_r15(comp1);
	quantityConfigNRList_r15.prepend(comp1);
    }
    value.set_quantityConfigNRList_r15(quantityConfigNRList_r15);
}

VarMeasConfig *create_samplevalue_VarMeasConfig()
{
    /* Creating 'measIdList' field */
    MeasIdToAddModList measIdList;
    fill_MeasIdToAddModList(measIdList);

    /* Creating 'measIdListExt_r12' field */
    MeasIdToAddModListExt_r12 measIdListExt_r12;
    fill_MeasIdToAddModListExt_r12(measIdListExt_r12);

    /* Creating 'measIdList_v1310' field */
    MeasIdToAddModList_v1310 measIdList_v1310;
    fill_MeasIdToAddModList_v1310(measIdList_v1310);

    /* Creating 'measIdListExt_v1310' field */
    MeasIdToAddModListExt_v1310 measIdListExt_v1310;
    fill_MeasIdToAddModList_v1310(measIdListExt_v1310);

    /* Creating 'measObjectList' field */
    MeasObjectToAddModList measObjectList;
    fill_MeasObjectToAddModList(measObjectList);

    /* Creating 'measObjectListExt_r13' field */
    MeasObjectToAddModListExt_r13 measObjectListExt_r13;
    fill_MeasObjectToAddModListExt_r13(measObjectListExt_r13);

    /* Creating 'measObjectList_v9i0' field */
    MeasObjectToAddModList_v9e0 measObjectList_v9i0;
    fill_MeasObjectToAddModList_v9e0(measObjectList_v9i0);

    /* Creating 'reportConfigList' field */
    ReportConfigToAddModList reportConfigList;
    fill_ReportConfigToAddModList(reportConfigList);

    /* Creating 'quantityConfig' field */
    QuantityConfig quantityConfig;
    fill_QuantityConfig(quantityConfig);

    /* Creating 'speedStatePars' field */
    VarMeasConfig::speedStatePars speedStatePars;
    speedStatePars.set_release(0);

    /* Calling a fully-initializing constructor */
    return new VarMeasConfig(measIdList, measIdListExt_r12, measIdList_v1310, measIdListExt_v1310, measObjectList, measObjectListExt_r13, measObjectList_v9i0, reportConfigList, quantityConfig, sf_EUTRA_cf1, -44, speedStatePars, TRUE);
}

static void fill_CellList_r15(CellList_r15 & value)
{
    {
	/* Adding component #2 */
	PhysCellIdRange comp2;
	fill_PhysCellIdRange(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PhysCellIdRange comp1;
	fill_PhysCellIdRange(comp1);
	value.prepend(comp1);
    }
}

static void fill_MeasIdleCarrierEUTRA_r15(MeasIdleCarrierEUTRA_r15 & value)
{
    value.set_carrierFreq_r15(0);
    value.set_allowedMeasBandwidth_r15(mbw6);
    /* Setting 'validityArea_r15' field */
    CellList_r15 validityArea_r15;
    fill_CellList_r15(validityArea_r15);
    value.set_validityArea_r15(validityArea_r15);

    /* Setting 'measCellList_r15' field */
    CellList_r15 measCellList_r15;
    fill_CellList_r15(measCellList_r15);
    value.set_measCellList_r15(measCellList_r15);

    value.set_reportQuantities(reportQuantities_rsrp);
    /* Setting 'qualityThreshold_r15' field */

    /* Calling a fully-initializing constructor */
    MeasIdleCarrierEUTRA_r15::qualityThreshold_r15 qualityThreshold_r15(0, -30);

    value.set_qualityThreshold_r15(qualityThreshold_r15);
}

VarMeasIdleConfig_r15 *create_samplevalue_VarMeasIdleConfig_r15()
{
    /* Creating 'measIdleCarrierListEUTRA_r15' field */
    EUTRA_CarrierList_r15 measIdleCarrierListEUTRA_r15;
    {
	/* Adding component #2 */
	MeasIdleCarrierEUTRA_r15 comp2;
	fill_MeasIdleCarrierEUTRA_r15(comp2);
	measIdleCarrierListEUTRA_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasIdleCarrierEUTRA_r15 comp1;
	fill_MeasIdleCarrierEUTRA_r15(comp1);
	measIdleCarrierListEUTRA_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    return new VarMeasIdleConfig_r15(measIdleCarrierListEUTRA_r15, VarMeasIdleConfig_r15_measIdleDuration_r15_sec10);
}

static void fill_MeasResultIdleEUTRA_r15(MeasResultIdleEUTRA_r15 & value)
{
    value.set_carrierFreq_r15(0);
    value.set_physCellId_r15(0);
    /* Setting 'measResult_r15' field */

    /* Calling a fully-initializing constructor */
    MeasResultIdleEUTRA_r15::measResult_r15 measResult_r15(0, -30);

    value.set_measResult_r15(measResult_r15);
}

static void fill_MeasResultIdle_r15(MeasResultIdle_r15 & value)
{
    /* Setting 'measResultServingCell_r15' field */

    /* Calling a fully-initializing constructor */
    MeasResultIdle_r15::measResultServingCell_r15 measResultServingCell_r15(0, -30);

    value.set_measResultServingCell_r15(measResultServingCell_r15);

    /* Setting 'measResultNeighCells_r15' field */
    MeasResultIdle_r15::measResultNeighCells_r15 measResultNeighCells_r15;
    /* Setting 'measResultIdleListEUTRA_r15' alternative of 'measResultNeighCells_r15' field */
    MeasResultIdleListEUTRA_r15 measResultIdleListEUTRA_r15;
    {
	/* Adding component #2 */
	MeasResultIdleEUTRA_r15 comp2;
	fill_MeasResultIdleEUTRA_r15(comp2);
	measResultIdleListEUTRA_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultIdleEUTRA_r15 comp1;
	fill_MeasResultIdleEUTRA_r15(comp1);
	measResultIdleListEUTRA_r15.prepend(comp1);
    }
    measResultNeighCells_r15.set_measResultIdleListEUTRA_r15(measResultIdleListEUTRA_r15);

    value.set_measResultNeighCells_r15(measResultNeighCells_r15);
}

VarMeasIdleReport_r15 *create_samplevalue_VarMeasIdleReport_r15()
{
    /* Creating 'measReportIdle_r15' field */
    MeasResultListIdle_r15 measReportIdle_r15;
    {
	/* Adding component #2 */
	MeasResultIdle_r15 comp2;
	fill_MeasResultIdle_r15(comp2);
	measReportIdle_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultIdle_r15 comp1;
	fill_MeasResultIdle_r15(comp1);
	measReportIdle_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    return new VarMeasIdleReport_r15(measReportIdle_r15);
}

static void fill_data_1(CellsTriggeredList::component & value)
{
    value.set_physCellIdEUTRA(0);
}

static void fill_VarMeasReport(VarMeasReport & value)
{
    value.set_measId(1);
    value.set_measId_v1250(33);
    /* Setting 'cellsTriggeredList' field */
    CellsTriggeredList cellsTriggeredList;
    {
	/* Adding component #2 */
	CellsTriggeredList::component comp2;
	fill_data_1(comp2);
	cellsTriggeredList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CellsTriggeredList::component comp1;
	fill_data_1(comp1);
	cellsTriggeredList.prepend(comp1);
    }
    value.set_cellsTriggeredList(cellsTriggeredList);

    /* Setting 'csi_RS_TriggeredList_r12' field */
    CSI_RS_TriggeredList_r12 csi_RS_TriggeredList_r12;
    csi_RS_TriggeredList_r12.prepend(1);
    csi_RS_TriggeredList_r12.prepend(1);
    value.set_csi_RS_TriggeredList_r12(csi_RS_TriggeredList_r12);

    /* Setting 'poolsTriggeredList_r14' field */
    Tx_ResourcePoolMeasList_r14 poolsTriggeredList_r14;
    fill_Tx_ResourcePoolMeasList_r14(poolsTriggeredList_r14);
    value.set_poolsTriggeredList_r14(poolsTriggeredList_r14);

    value.set_numberOfReportsSent(0);
}

VarMeasReportList *create_samplevalue_VarMeasReportList()
{
    VarMeasReportList *result = new VarMeasReportList;

    {
	/* Adding component #2 */
	VarMeasReport comp2;
	fill_VarMeasReport(comp2);
	result->prepend(comp2);
    }
    {
	/* Adding component #1 */
	VarMeasReport comp1;
	fill_VarMeasReport(comp1);
	result->prepend(comp1);
    }

    return result;
}

VarMeasReportList_r12 *create_samplevalue_VarMeasReportList_r12()
{
    VarMeasReportList_r12 *result = new VarMeasReportList_r12;

    {
	/* Adding component #2 */
	VarMeasReport comp2;
	fill_VarMeasReport(comp2);
	result->prepend(comp2);
    }
    {
	/* Adding component #1 */
	VarMeasReport comp1;
	fill_VarMeasReport(comp1);
	result->prepend(comp1);
    }

    return result;
}

static void fill_CellGlobalIdEUTRA(CellGlobalIdEUTRA & value)
{
    /* Setting 'plmn_Identity' field */
    PLMN_Identity plmn_Identity;
    fill_PLMN_Identity(plmn_Identity);
    value.set_plmn_Identity(plmn_Identity);

    /* Setting 'cellIdentity' field */
    static unsigned char cellIdentity_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity(28, cellIdentity_value);
    value.set_cellIdentity(cellIdentity);
}

static void fill_VisitedCellInfo_r12(VisitedCellInfo_r12 & value)
{
    /* Setting 'visitedCellId_r12' field */
    VisitedCellInfo_r12::visitedCellId_r12 visitedCellId_r12;
    /* Setting 'cellGlobalId_r12' alternative of 'visitedCellId_r12' field */
    CellGlobalIdEUTRA cellGlobalId_r12;
    fill_CellGlobalIdEUTRA(cellGlobalId_r12);
    visitedCellId_r12.set_cellGlobalId_r12(cellGlobalId_r12);

    value.set_visitedCellId_r12(visitedCellId_r12);

    value.set_timeSpent_r12(0);
}

VarMobilityHistoryReport_r12 *create_samplevalue_VarMobilityHistoryReport_r12()
{
    VarMobilityHistoryReport_r12 *result = new VarMobilityHistoryReport_r12;

    {
	/* Adding component #2 */
	VisitedCellInfo_r12 comp2;
	fill_VisitedCellInfo_r12(comp2);
	result->prepend(comp2);
    }
    {
	/* Adding component #1 */
	VisitedCellInfo_r12 comp1;
	fill_VisitedCellInfo_r12(comp1);
	result->prepend(comp1);
    }

    return result;
}

VarPendingRnaProcedure_r15 *create_samplevalue_VarPendingRnaProcedure_r15()
{
    /* Calling a fully-initializing constructor */
    return new VarPendingRnaProcedure_r15(TRUE);
}

static void fill_RLF_Report_r9(RLF_Report_r9 & value)
{
    /* Setting 'measResultLastServCell_r9' field */

    /* Calling a fully-initializing constructor */
    RLF_Report_r9::measResultLastServCell_r9 measResultLastServCell_r9(0, 0);

    value.set_measResultLastServCell_r9(measResultLastServCell_r9);

    /* Setting 'measResultNeighCells_r9' field */
    /* Creating 'measResultListEUTRA_r9' field of 'measResultNeighCells_r9' field */
    MeasResultList2EUTRA_r9 measResultListEUTRA_r9;
    fill_MeasResultList2EUTRA_r9(measResultListEUTRA_r9);

    /* Creating 'measResultListUTRA_r9' field of 'measResultNeighCells_r9' field */
    MeasResultList2UTRA_r9 measResultListUTRA_r9;
    fill_MeasResultList2UTRA_r9(measResultListUTRA_r9);

    /* Creating 'measResultListGERAN_r9' field of 'measResultNeighCells_r9' field */
    MeasResultListGERAN measResultListGERAN_r9;
    fill_MeasResultListGERAN(measResultListGERAN_r9);

    /* Creating 'measResultsCDMA2000_r9' field of 'measResultNeighCells_r9' field */
    MeasResultList2CDMA2000_r9 measResultsCDMA2000_r9;
    fill_MeasResultList2CDMA2000_r9(measResultsCDMA2000_r9);

    /* Calling a fully-initializing constructor */
    RLF_Report_r9::measResultNeighCells_r9 measResultNeighCells_r9(measResultListEUTRA_r9, measResultListUTRA_r9, measResultListGERAN_r9, measResultsCDMA2000_r9);

    value.set_measResultNeighCells_r9(measResultNeighCells_r9);

    /* Setting 'locationInfo_r10' field */
    LocationInfo_r10 locationInfo_r10;
    fill_LocationInfo_r10(locationInfo_r10);
    value.set_locationInfo_r10(locationInfo_r10);

    /* Setting 'failedPCellId_r10' field */
    RLF_Report_r9::failedPCellId_r10 failedPCellId_r10;
    /* Setting 'cellGlobalId_r10' alternative of 'failedPCellId_r10' field */
    CellGlobalIdEUTRA cellGlobalId_r10;
    fill_CellGlobalIdEUTRA(cellGlobalId_r10);
    failedPCellId_r10.set_cellGlobalId_r10(cellGlobalId_r10);

    value.set_failedPCellId_r10(failedPCellId_r10);

    /* Setting 'reestablishmentCellId_r10' field */
    CellGlobalIdEUTRA reestablishmentCellId_r10;
    fill_CellGlobalIdEUTRA_1(reestablishmentCellId_r10);
    value.set_reestablishmentCellId_r10(reestablishmentCellId_r10);

    value.set_timeConnFailure_r10(0);
    value.set_connectionFailureType_r10(rlf);
    /* Setting 'previousPCellId_r10' field */
    CellGlobalIdEUTRA previousPCellId_r10;
    fill_CellGlobalIdEUTRA_1(previousPCellId_r10);
    value.set_previousPCellId_r10(previousPCellId_r10);

    /* Setting 'failedPCellId_v1090' field */

    /* Calling a fully-initializing constructor */
    RLF_Report_r9::failedPCellId_v1090 failedPCellId_v1090(65536);

    value.set_failedPCellId_v1090(failedPCellId_v1090);

    /* Setting 'basicFields_r11' field */
    /* Creating 'c_RNTI_r11' field of 'basicFields_r11' field */
    static unsigned char c_RNTI_r11_value[] = {
	0x00, 0x00
    };
    OssBitString c_RNTI_r11(16, c_RNTI_r11_value);

    /* Calling a fully-initializing constructor */
    RLF_Report_r9::basicFields_r11 basicFields_r11(c_RNTI_r11, rlf_Cause_r11_t310_Expiry, 0);

    value.set_basicFields_r11(basicFields_r11);

    /* Setting 'previousUTRA_CellId_r11' field */
    /* Creating 'physCellId_r11' field of 'previousUTRA_CellId_r11' field */
    RLF_Report_r9::previousUTRA_CellId_r11::physCellId_r11 physCellId_r11;
    physCellId_r11.set_fdd_r11(0);

    /* Creating 'cellGlobalId_r11' field of 'previousUTRA_CellId_r11' field */
    CellGlobalIdUTRA cellGlobalId_r11;
    fill_CellGlobalIdUTRA(cellGlobalId_r11);

    /* Calling a fully-initializing constructor */
    RLF_Report_r9::previousUTRA_CellId_r11 previousUTRA_CellId_r11(0, physCellId_r11, cellGlobalId_r11);

    value.set_previousUTRA_CellId_r11(previousUTRA_CellId_r11);

    /* Setting 'selectedUTRA_CellId_r11' field */
    /* Creating 'physCellId_r11' field of 'selectedUTRA_CellId_r11' field */
    RLF_Report_r9::selectedUTRA_CellId_r11::physCellId_r11 selectedUTRA_CellId_r11_physCellId_r11;
    selectedUTRA_CellId_r11_physCellId_r11.set_fdd_r11(0);

    /* Calling a fully-initializing constructor */
    RLF_Report_r9::selectedUTRA_CellId_r11 selectedUTRA_CellId_r11(0, selectedUTRA_CellId_r11_physCellId_r11);

    value.set_selectedUTRA_CellId_r11(selectedUTRA_CellId_r11);

    /* Setting 'failedPCellId_v1250' field */
    /* Creating 'tac_FailedPCell_r12' field of 'failedPCellId_v1250' field */
    static unsigned char tac_FailedPCell_r12_value[] = {
	0x00, 0x00
    };
    OssBitString tac_FailedPCell_r12(16, tac_FailedPCell_r12_value);

    /* Calling a fully-initializing constructor */
    RLF_Report_r9::failedPCellId_v1250 failedPCellId_v1250(tac_FailedPCell_r12);

    value.set_failedPCellId_v1250(failedPCellId_v1250);

    value.set_measResultLastServCell_v1250(-30);
    /* Setting 'lastServCellRSRQ_Type_r12' field */
    RSRQ_Type_r12 lastServCellRSRQ_Type_r12;
    fill_RSRQ_Type_r12(lastServCellRSRQ_Type_r12);
    value.set_lastServCellRSRQ_Type_r12(lastServCellRSRQ_Type_r12);

    /* Setting 'measResultListEUTRA_v1250' field */
    MeasResultList2EUTRA_v1250 measResultListEUTRA_v1250;
    fill_MeasResultList2EUTRA_v1250(measResultListEUTRA_v1250);
    value.set_measResultListEUTRA_v1250(measResultListEUTRA_v1250);

    value.set_drb_EstablishedWithQCI_1_r13(drb_EstablishedWithQCI_1_r13_qci1);
    value.set_measResultLastServCell_v1360(-1);
    /* Setting 'logMeasResultListBT_r15' field */
    LogMeasResultListBT_r15 logMeasResultListBT_r15;
    fill_LogMeasResultListBT_r15(logMeasResultListBT_r15);
    value.set_logMeasResultListBT_r15(logMeasResultListBT_r15);

    /* Setting 'logMeasResultListWLAN_r15' field */
    LogMeasResultListWLAN_r15 logMeasResultListWLAN_r15;
    fill_LogMeasResultListWLAN_r15(logMeasResultListWLAN_r15);
    value.set_logMeasResultListWLAN_r15(logMeasResultListWLAN_r15);
}

VarRLF_Report_r10 *create_samplevalue_VarRLF_Report_r10()
{
    /* Creating 'rlf_Report_r10' field */
    RLF_Report_r9 rlf_Report_r10;
    fill_RLF_Report_r9(rlf_Report_r10);

    /* Creating 'plmn_Identity_r10' field */
    PLMN_Identity plmn_Identity_r10;
    fill_PLMN_Identity(plmn_Identity_r10);

    /* Calling a fully-initializing constructor */
    return new VarRLF_Report_r10(rlf_Report_r10, plmn_Identity_r10);
}

VarRLF_Report_r11 *create_samplevalue_VarRLF_Report_r11()
{
    /* Creating 'rlf_Report_r10' field */
    RLF_Report_r9 rlf_Report_r10;
    fill_RLF_Report_r9(rlf_Report_r10);

    /* Creating 'plmn_IdentityList_r11' field */
    PLMN_IdentityList3_r11 plmn_IdentityList_r11;
    fill_PLMN_IdentityList3_r11(plmn_IdentityList_r11);

    /* Calling a fully-initializing constructor */
    return new VarRLF_Report_r11(rlf_Report_r10, plmn_IdentityList_r11);
}

VarShortINACTIVE_MAC_Input_r15 *create_samplevalue_VarShortINACTIVE_MAC_Input_r15()
{
    /* Creating 'cellIdentity_r15' field */
    static unsigned char cellIdentity_r15_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity_r15(28, cellIdentity_r15_value);

    /* Creating 'c_RNTI_r15' field */
    static unsigned char c_RNTI_r15_value[] = {
	0x00, 0x00
    };
    OssBitString c_RNTI_r15(16, c_RNTI_r15_value);

    /* Calling a fully-initializing constructor */
    return new VarShortINACTIVE_MAC_Input_r15(cellIdentity_r15, 0, c_RNTI_r15);
}

static void fill_WLAN_Id_List_r13(WLAN_Id_List_r13 & value)
{
    {
	/* Adding component #2 */
	WLAN_Identifiers_r12 comp2;
	fill_WLAN_Identifiers_r12(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	WLAN_Identifiers_r12 comp1;
	fill_WLAN_Identifiers_r12(comp1);
	value.prepend(comp1);
    }
}

static void fill_WLAN_SuspendConfig_r14(WLAN_SuspendConfig_r14 & value)
{
    value.set_wlan_SuspendResumeAllowed_r14(TRUE);
    value.set_wlan_SuspendTriggersStatusReport_r14(TRUE);
}

VarWLAN_MobilityConfig *create_samplevalue_VarWLAN_MobilityConfig()
{
    /* Creating 'wlan_MobilitySet_r13' field */
    WLAN_Id_List_r13 wlan_MobilitySet_r13;
    fill_WLAN_Id_List_r13(wlan_MobilitySet_r13);

    /* Creating 'wlan_SuspendConfig_r14' field */
    WLAN_SuspendConfig_r14 wlan_SuspendConfig_r14;
    fill_WLAN_SuspendConfig_r14(wlan_SuspendConfig_r14);

    /* Calling a fully-initializing constructor */
    return new VarWLAN_MobilityConfig(wlan_MobilitySet_r13, successReportRequested_true, wlan_SuspendConfig_r14);
}

VarWLAN_Status_r13 *create_samplevalue_VarWLAN_Status_r13()
{
    /* Calling a fully-initializing constructor */
    return new VarWLAN_Status_r13(successfulAssociation, suspended);
}

VarShortMAC_Input_NB_r13 *create_samplevalue_VarShortMAC_Input_NB_r13()
{
    /* Creating 'cellIdentity' field */
    static unsigned char cellIdentity_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity(28, cellIdentity_value);

    /* Creating 'c_RNTI' field */
    static unsigned char c_RNTI_value[] = {
	0x00, 0x00
    };
    OssBitString c_RNTI(16, c_RNTI_value);

    /* Calling a fully-initializing constructor */
    return new VarShortMAC_Input_NB_r13(cellIdentity, 0, c_RNTI);
}

VarShortResumeMAC_Input_NB_r13 *create_samplevalue_VarShortResumeMAC_Input_NB_r13()
{
    /* Creating 'cellIdentity_r13' field */
    static unsigned char cellIdentity_r13_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity_r13(28, cellIdentity_r13_value);

    /* Creating 'c_RNTI_r13' field */
    static unsigned char c_RNTI_r13_value[] = {
	0x00, 0x00
    };
    OssBitString c_RNTI_r13(16, c_RNTI_r13_value);

    /* Creating 'resumeDiscriminator_r13' field */
    static unsigned char resumeDiscriminator_r13_value[] = {
	0x00
    };
    OssBitString resumeDiscriminator_r13(1, resumeDiscriminator_r13_value);

    /* Calling a fully-initializing constructor */
    return new VarShortResumeMAC_Input_NB_r13(cellIdentity_r13, 0, c_RNTI_r13, resumeDiscriminator_r13);
}

static void fill_SL_PreconfigGeneral_r12(SL_PreconfigGeneral_r12 & value)
{
    /* Setting 'rohc_Profiles_r12' field */

    /* Calling a fully-initializing constructor */
    SL_PreconfigGeneral_r12::rohc_Profiles_r12 rohc_Profiles_r12(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

    value.set_rohc_Profiles_r12(rohc_Profiles_r12);

    value.set_carrierFreq_r12(0);
    value.set_maxTxPower_r12(-30);
    value.set_additionalSpectrumEmission_r12(1);
    value.set_sl_bandwidth_r12(sl_bandwidth_r12_n6);
    /* Setting 'tdd_ConfigSL_r12' field */
    TDD_ConfigSL_r12 tdd_ConfigSL_r12;
    fill_TDD_ConfigSL_r12(tdd_ConfigSL_r12);
    value.set_tdd_ConfigSL_r12(tdd_ConfigSL_r12);

    /* Setting 'reserved_r12' field */
    static unsigned char reserved_r12_value[] = {
	0x00, 0x00, 0x00
    };
    OssBitString reserved_r12(19, reserved_r12_value);
    value.set_reserved_r12(reserved_r12);

    value.set_additionalSpectrumEmission_v1440(33);
}

static void fill_SL_OffsetIndicator_r12(SL_OffsetIndicator_r12 & value)
{
    value.set_small_r12(0);
}

static void fill_SL_TF_ResourceConfig_r12(SL_TF_ResourceConfig_r12 & value)
{
    value.set_prb_Num_r12(1);
    value.set_prb_Start_r12(0);
    value.set_prb_End_r12(0);
    /* Setting 'offsetIndicator_r12' field */
    SL_OffsetIndicator_r12 offsetIndicator_r12;
    fill_SL_OffsetIndicator_r12(offsetIndicator_r12);
    value.set_offsetIndicator_r12(offsetIndicator_r12);

    /* Setting 'subframeBitmap_r12' field */
    SubframeBitmapSL_r12 subframeBitmap_r12;
    /* Setting 'bs4_r12' alternative of 'subframeBitmap_r12' field */
    static unsigned char bs4_r12_value[] = {
	0x00
    };
    OssBitString bs4_r12(4, bs4_r12_value);
    subframeBitmap_r12.set_bs4_r12(bs4_r12);

    value.set_subframeBitmap_r12(subframeBitmap_r12);
}

static void fill_SL_PriorityList_r13(SL_PriorityList_r13 & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_SL_PreconfigCommPool_r12(SL_PreconfigCommPool_r12 & value)
{
    value.set_sc_CP_Len_r12(SL_CP_Len_r12_normal);
    value.set_sc_Period_r12(SL_PeriodComm_r12_sf40);
    /* Setting 'sc_TF_ResourceConfig_r12' field */
    SL_TF_ResourceConfig_r12 sc_TF_ResourceConfig_r12;
    fill_SL_TF_ResourceConfig_r12(sc_TF_ResourceConfig_r12);
    value.set_sc_TF_ResourceConfig_r12(sc_TF_ResourceConfig_r12);

    value.set_sc_TxParameters_r12(31);
    value.set_data_CP_Len_r12(SL_CP_Len_r12_normal);
    /* Setting 'data_TF_ResourceConfig_r12' field */
    SL_TF_ResourceConfig_r12 data_TF_ResourceConfig_r12;
    fill_SL_TF_ResourceConfig_r12(data_TF_ResourceConfig_r12);
    value.set_data_TF_ResourceConfig_r12(data_TF_ResourceConfig_r12);

    /* Setting 'dataHoppingConfig_r12' field */

    /* Calling a fully-initializing constructor */
    SL_HoppingConfigComm_r12 dataHoppingConfig_r12(0, ns1, 0);

    value.set_dataHoppingConfig_r12(dataHoppingConfig_r12);

    value.set_dataTxParameters_r12(31);
    /* Setting 'trpt_Subset_r12' field */
    static unsigned char trpt_Subset_r12_value[] = {
	0x00
    };
    OssBitString trpt_Subset_r12(3, trpt_Subset_r12_value);
    value.set_trpt_Subset_r12(trpt_Subset_r12);

    /* Setting 'priorityList_r13' field */
    SL_PriorityList_r13 priorityList_r13;
    fill_SL_PriorityList_r13(priorityList_r13);
    value.set_priorityList_r13(priorityList_r13);
}

static void fill_SL_PreconfigCommRxPoolList_r13(SL_PreconfigCommRxPoolList_r13 & value)
{
    {
	/* Adding component #2 */
	SL_PreconfigCommPool_r12 comp2;
	fill_SL_PreconfigCommPool_r12(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PreconfigCommPool_r12 comp1;
	fill_SL_PreconfigCommPool_r12(comp1);
	value.prepend(comp1);
    }
}

static void fill_SL_PreconfigDiscPool_r13(SL_PreconfigDiscPool_r13 & value)
{
    value.set_cp_Len_r13(SL_CP_Len_r12_normal);
    value.set_discPeriod_r13(discPeriod_r13_rf4);
    value.set_numRetx_r13(0);
    value.set_numRepetition_r13(1);
    /* Setting 'tf_ResourceConfig_r13' field */
    SL_TF_ResourceConfig_r12 tf_ResourceConfig_r13;
    fill_SL_TF_ResourceConfig_r12(tf_ResourceConfig_r13);
    value.set_tf_ResourceConfig_r13(tf_ResourceConfig_r13);

    /* Setting 'txParameters_r13' field */

    /* Calling a fully-initializing constructor */
    SL_PreconfigDiscPool_r13::txParameters_r13 txParameters_r13(31, txProbability_r13_p25);

    value.set_txParameters_r13(txParameters_r13);
}

static void fill_SL_PreconfigDiscRxPoolList_r13(SL_PreconfigDiscRxPoolList_r13 & value)
{
    {
	/* Adding component #2 */
	SL_PreconfigDiscPool_r13 comp2;
	fill_SL_PreconfigDiscPool_r13(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PreconfigDiscPool_r13 comp1;
	fill_SL_PreconfigDiscPool_r13(comp1);
	value.prepend(comp1);
    }
}

SL_Preconfiguration_r12 *create_samplevalue_SL_Preconfiguration_r12()
{
    /* Creating 'preconfigGeneral_r12' field */
    SL_PreconfigGeneral_r12 preconfigGeneral_r12;
    fill_SL_PreconfigGeneral_r12(preconfigGeneral_r12);

    /* Creating 'preconfigSync_r12' field */

    /* Calling a fully-initializing constructor */
    SL_PreconfigSync_r12 preconfigSync_r12(SL_CP_Len_r12_normal, 0, 0, 31, 0, fc0, syncRefMinHyst_r12_dB0, syncRefDiffHyst_r12_dB0, SL_PreconfigSync_r12_syncTxPeriodic_r13_true);

    /* Creating 'preconfigComm_r12' field */
    SL_PreconfigCommPoolList4_r12 preconfigComm_r12;
    {
	/* Adding component #2 */
	SL_PreconfigCommPool_r12 comp2;
	fill_SL_PreconfigCommPool_r12(comp2);
	preconfigComm_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PreconfigCommPool_r12 comp1;
	fill_SL_PreconfigCommPool_r12(comp1);
	preconfigComm_r12.prepend(comp1);
    }

    /* Creating 'preconfigComm_v1310' field */
    /* Creating 'commRxPoolList_r13' field of 'preconfigComm_v1310' field */
    SL_PreconfigCommRxPoolList_r13 commRxPoolList_r13;
    fill_SL_PreconfigCommRxPoolList_r13(commRxPoolList_r13);

    /* Creating 'commTxPoolList_r13' field of 'preconfigComm_v1310' field */
    SL_PreconfigCommTxPoolList_r13 commTxPoolList_r13;
    fill_SL_PreconfigCommRxPoolList_r13(commTxPoolList_r13);

    /* Calling a fully-initializing constructor */
    SL_Preconfiguration_r12::preconfigComm_v1310 preconfigComm_v1310(commRxPoolList_r13, commTxPoolList_r13);

    /* Creating 'preconfigDisc_r13' field */
    /* Creating 'discRxPoolList_r13' field of 'preconfigDisc_r13' field */
    SL_PreconfigDiscRxPoolList_r13 discRxPoolList_r13;
    fill_SL_PreconfigDiscRxPoolList_r13(discRxPoolList_r13);

    /* Creating 'discTxPoolList_r13' field of 'preconfigDisc_r13' field */
    SL_PreconfigDiscTxPoolList_r13 discTxPoolList_r13;
    fill_SL_PreconfigDiscRxPoolList_r13(discTxPoolList_r13);

    /* Calling a fully-initializing constructor */
    SL_Preconfiguration_r12::preconfigDisc_r13 preconfigDisc_r13(discRxPoolList_r13, discTxPoolList_r13);

    /* Creating 'preconfigRelay_r13' field */
    /* Creating 'reselectionInfoOoC_r13' field of 'preconfigRelay_r13' field */

    /* Calling a fully-initializing constructor */
    ReselectionInfoRelay_r13 reselectionInfoOoC_r13(-22, fc0, minHyst_r13_dB0);

    /* Calling a fully-initializing constructor */
    SL_PreconfigRelay_r13 preconfigRelay_r13(reselectionInfoOoC_r13);

    /* Calling a fully-initializing constructor */
    return new SL_Preconfiguration_r12(preconfigGeneral_r12, preconfigSync_r12, preconfigComm_r12, preconfigComm_v1310, preconfigDisc_r13, preconfigRelay_r13);
}

static void fill_SubframeBitmapSL_r14(SubframeBitmapSL_r14 & value)
{
    /* Setting 'bs10_r14' alternative */
    static unsigned char bs10_r14_value[] = {
	0x00, 0x00
    };
    OssBitString bs10_r14(10, bs10_r14_value);
    value.set_bs10_r14(bs10_r14);
}

static void fill_SL_PPPP_TxPreconfigIndex_r14(SL_PPPP_TxPreconfigIndex_r14 & value)
{
    value.set_priorityThreshold_r14(1);
    value.set_defaultTxConfigIndex_r14(0);
    value.set_cbr_ConfigIndex_r14(0);
    /* Setting 'tx_ConfigIndexList_r14' field */
    SL_PPPP_TxPreconfigIndex_r14::tx_ConfigIndexList_r14 tx_ConfigIndexList_r14;
    tx_ConfigIndexList_r14.prepend((OSS_UINT32)0);
    tx_ConfigIndexList_r14.prepend((OSS_UINT32)0);
    value.set_tx_ConfigIndexList_r14(tx_ConfigIndexList_r14);
}

static void fill_SL_P2X_ResourceSelectionConfig_r14(SL_P2X_ResourceSelectionConfig_r14 & value)
{
    value.set_partialSensing_r14(partialSensing_r14_true);
    value.set_randomSelection_r14(randomSelection_r14_true);
}

static void fill_SL_SyncAllowed_r14(SL_SyncAllowed_r14 & value)
{
    value.set_gnss_Sync_r14(SL_SyncAllowed_r14_gnss_Sync_r14_true);
    value.set_enb_Sync_r14(enb_Sync_r14_true);
    value.set_ue_Sync_r14(ue_Sync_r14_true);
}

static void fill_SL_RestrictResourceReservationPeriodList_r14(SL_RestrictResourceReservationPeriodList_r14 & value)
{
    value.prepend(SL_RestrictResourceReservationPeriod_r14_v0dot2);
    value.prepend(SL_RestrictResourceReservationPeriod_r14_v0dot2);
}

static void fill_SL_MinT2Value_r15(SL_MinT2Value_r15 & value)
{
    /* Setting 'priorityList_r15' field */
    SL_PriorityList_r13 priorityList_r15;
    fill_SL_PriorityList_r13(priorityList_r15);
    value.set_priorityList_r15(priorityList_r15);

    value.set_minT2Value_r15(10);
}

static void fill_SL_MinT2ValueList_r15(SL_MinT2ValueList_r15 & value)
{
    {
	/* Adding component #2 */
	SL_MinT2Value_r15 comp2;
	fill_SL_MinT2Value_r15(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_MinT2Value_r15 comp1;
	fill_SL_MinT2Value_r15(comp1);
	value.prepend(comp1);
    }
}

static void fill_EUTRA_Sidelink_Preconf_MCS_PSSCH_Range_r15(EUTRA_Sidelink_Preconf_MCS_PSSCH_Range_r15 & value)
{
    value.set_minMCS_PSSCH_r15(0);
    value.set_maxMCS_PSSCH_r15(0);
}

static void fill_SL_PPPP_TxPreconfigIndex_v1530(SL_PPPP_TxPreconfigIndex_v1530 & value)
{
    /* Setting 'mcs_PSSCH_Range_r15' field */
    SL_PPPP_TxPreconfigIndex_v1530::mcs_PSSCH_Range_r15 mcs_PSSCH_Range_r15;
    {
	/* Adding component #2 */
	EUTRA_Sidelink_Preconf_MCS_PSSCH_Range_r15 comp2;
	fill_EUTRA_Sidelink_Preconf_MCS_PSSCH_Range_r15(comp2);
	mcs_PSSCH_Range_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	EUTRA_Sidelink_Preconf_MCS_PSSCH_Range_r15 comp1;
	fill_EUTRA_Sidelink_Preconf_MCS_PSSCH_Range_r15(comp1);
	mcs_PSSCH_Range_r15.prepend(comp1);
    }
    value.set_mcs_PSSCH_Range_r15(mcs_PSSCH_Range_r15);
}

static void fill_SL_V2X_PreconfigCommPool_r14(SL_V2X_PreconfigCommPool_r14 & value)
{
    /* Setting 'sl_OffsetIndicator_r14' field */
    SL_OffsetIndicator_r12 sl_OffsetIndicator_r14;
    fill_SL_OffsetIndicator_r12(sl_OffsetIndicator_r14);
    value.set_sl_OffsetIndicator_r14(sl_OffsetIndicator_r14);

    /* Setting 'sl_Subframe_r14' field */
    SubframeBitmapSL_r14 sl_Subframe_r14;
    fill_SubframeBitmapSL_r14(sl_Subframe_r14);
    value.set_sl_Subframe_r14(sl_Subframe_r14);

    value.set_adjacencyPSCCH_PSSCH_r14(TRUE);
    value.set_sizeSubchannel_r14(SL_V2X_PreconfigCommPool_r14_sizeSubchannel_r14_n4);
    value.set_numSubchannel_r14(SL_V2X_PreconfigCommPool_r14_numSubchannel_r14_n1);
    value.set_startRB_Subchannel_r14(0);
    value.set_startRB_PSCCH_Pool_r14(0);
    value.set_dataTxParameters_r14(31);
    value.set_zoneID_r14(0);
    value.set_threshS_RSSI_CBR_r14(0);
    /* Setting 'cbr_pssch_TxConfigList_r14' field */
    SL_CBR_PPPP_TxPreconfigList_r14 cbr_pssch_TxConfigList_r14;
    {
	/* Adding component #2 */
	SL_PPPP_TxPreconfigIndex_r14 comp2;
	fill_SL_PPPP_TxPreconfigIndex_r14(comp2);
	cbr_pssch_TxConfigList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PPPP_TxPreconfigIndex_r14 comp1;
	fill_SL_PPPP_TxPreconfigIndex_r14(comp1);
	cbr_pssch_TxConfigList_r14.prepend(comp1);
    }
    value.set_cbr_pssch_TxConfigList_r14(cbr_pssch_TxConfigList_r14);

    /* Setting 'resourceSelectionConfigP2X_r14' field */
    SL_P2X_ResourceSelectionConfig_r14 resourceSelectionConfigP2X_r14;
    fill_SL_P2X_ResourceSelectionConfig_r14(resourceSelectionConfigP2X_r14);
    value.set_resourceSelectionConfigP2X_r14(resourceSelectionConfigP2X_r14);

    /* Setting 'syncAllowed_r14' field */
    SL_SyncAllowed_r14 syncAllowed_r14;
    fill_SL_SyncAllowed_r14(syncAllowed_r14);
    value.set_syncAllowed_r14(syncAllowed_r14);

    /* Setting 'restrictResourceReservationPeriod_r14' field */
    SL_RestrictResourceReservationPeriodList_r14 restrictResourceReservationPeriod_r14;
    fill_SL_RestrictResourceReservationPeriodList_r14(restrictResourceReservationPeriod_r14);
    value.set_restrictResourceReservationPeriod_r14(restrictResourceReservationPeriod_r14);

    /* Setting 'sl_MinT2ValueList_r15' field */
    SL_MinT2ValueList_r15 sl_MinT2ValueList_r15;
    fill_SL_MinT2ValueList_r15(sl_MinT2ValueList_r15);
    value.set_sl_MinT2ValueList_r15(sl_MinT2ValueList_r15);

    /* Setting 'cbr_pssch_TxConfigList_v1530' field */
    SL_CBR_PPPP_TxPreconfigList_v1530 cbr_pssch_TxConfigList_v1530;
    {
	/* Adding component #2 */
	SL_PPPP_TxPreconfigIndex_v1530 comp2;
	fill_SL_PPPP_TxPreconfigIndex_v1530(comp2);
	cbr_pssch_TxConfigList_v1530.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PPPP_TxPreconfigIndex_v1530 comp1;
	fill_SL_PPPP_TxPreconfigIndex_v1530(comp1);
	cbr_pssch_TxConfigList_v1530.prepend(comp1);
    }
    value.set_cbr_pssch_TxConfigList_v1530(cbr_pssch_TxConfigList_v1530);
}

static void fill_SL_PreconfigV2X_RxPoolList_r14(SL_PreconfigV2X_RxPoolList_r14 & value)
{
    {
	/* Adding component #2 */
	SL_V2X_PreconfigCommPool_r14 comp2;
	fill_SL_V2X_PreconfigCommPool_r14(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_V2X_PreconfigCommPool_r14 comp1;
	fill_SL_V2X_PreconfigCommPool_r14(comp1);
	value.prepend(comp1);
    }
}

static void fill_SL_PSSCH_TxParameters_r14(SL_PSSCH_TxParameters_r14 & value)
{
    value.set_minMCS_PSSCH_r14(0);
    value.set_maxMCS_PSSCH_r14(0);
    value.set_minSubChannel_NumberPSSCH_r14(1);
    value.set_maxSubchannel_NumberPSSCH_r14(1);
    value.set_allowedRetxNumberPSSCH_r14(allowedRetxNumberPSSCH_r14_n0);
    /* Setting 'maxTxPower_r14' field */
    SL_TxPower_r14 maxTxPower_r14;
    maxTxPower_r14.set_minusinfinity_r14(0);
    value.set_maxTxPower_r14(maxTxPower_r14);
}

static void fill_SL_PSSCH_TxParameters_v1530(SL_PSSCH_TxParameters_v1530 & value)
{
    value.set_minMCS_PSSCH_r15(0);
    value.set_maxMCS_PSSCH_r15(0);
}

static void fill_SL_PSSCH_TxConfig_r14(SL_PSSCH_TxConfig_r14 & value)
{
    value.set_typeTxSync_r14(SL_TypeTxSync_r14_gnss);
    value.set_thresUE_Speed_r14(kmph60);
    /* Setting 'parametersAboveThres_r14' field */
    SL_PSSCH_TxParameters_r14 parametersAboveThres_r14;
    fill_SL_PSSCH_TxParameters_r14(parametersAboveThres_r14);
    value.set_parametersAboveThres_r14(parametersAboveThres_r14);

    /* Setting 'parametersBelowThres_r14' field */
    SL_PSSCH_TxParameters_r14 parametersBelowThres_r14;
    fill_SL_PSSCH_TxParameters_r14(parametersBelowThres_r14);
    value.set_parametersBelowThres_r14(parametersBelowThres_r14);

    /* Setting 'parametersAboveThres_v1530' field */
    SL_PSSCH_TxParameters_v1530 parametersAboveThres_v1530;
    fill_SL_PSSCH_TxParameters_v1530(parametersAboveThres_v1530);
    value.set_parametersAboveThres_v1530(parametersAboveThres_v1530);

    /* Setting 'parametersBelowThres_v1530' field */
    SL_PSSCH_TxParameters_v1530 parametersBelowThres_v1530;
    fill_SL_PSSCH_TxParameters_v1530(parametersBelowThres_v1530);
    value.set_parametersBelowThres_v1530(parametersBelowThres_v1530);
}

static void fill_SL_CommTxPoolSensingConfig_r14(SL_CommTxPoolSensingConfig_r14 & value)
{
    /* Setting 'pssch_TxConfigList_r14' field of 'syncOffsetIndicators_r14' field of 'v2x_ResourceSelectionConfig_r14' field */
    SL_PSSCH_TxConfigList_r14 pssch_TxConfigList_r14;
    {
	/* Adding component #2 */
	SL_PSSCH_TxConfig_r14 comp2;
	fill_SL_PSSCH_TxConfig_r14(comp2);
	pssch_TxConfigList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PSSCH_TxConfig_r14 comp1;
	fill_SL_PSSCH_TxConfig_r14(comp1);
	pssch_TxConfigList_r14.prepend(comp1);
    }
    value.set_pssch_TxConfigList_r14(pssch_TxConfigList_r14);

    /* Setting 'thresPSSCH_RSRP_List_r14' field of 'syncOffsetIndicators_r14' field of 'v2x_ResourceSelectionConfig_r14' field */
    SL_ThresPSSCH_RSRP_List_r14 thresPSSCH_RSRP_List_r14;
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    thresPSSCH_RSRP_List_r14.prepend((OSS_UINT32)0);
    value.set_thresPSSCH_RSRP_List_r14(thresPSSCH_RSRP_List_r14);

    /* Setting 'restrictResourceReservationPeriod_r14' field of 'syncOffsetIndicators_r14' field of 'v2x_ResourceSelectionConfig_r14' field */
    SL_RestrictResourceReservationPeriodList_r14 restrictResourceReservationPeriod_r14;
    fill_SL_RestrictResourceReservationPeriodList_r14(restrictResourceReservationPeriod_r14);
    value.set_restrictResourceReservationPeriod_r14(restrictResourceReservationPeriod_r14);

    value.set_probResourceKeep_r14(probResourceKeep_r14_v0);
    /* Setting 'p2x_SensingConfig_r14' field of 'syncOffsetIndicators_r14' field of 'v2x_ResourceSelectionConfig_r14' field */
    /* Creating 'gapCandidateSensing_r14' field of 'p2x_SensingConfig_r14' field of 'syncOffsetIndicators_r14' field of 'v2x_ResourceSelectionConfig_r14' field... */
    static unsigned char gapCandidateSensing_r14_value[] = {
	0x00, 0x00
    };
    OssBitString gapCandidateSensing_r14(10, gapCandidateSensing_r14_value);

    /* Calling a fully-initializing constructor */
    SL_CommTxPoolSensingConfig_r14::p2x_SensingConfig_r14 p2x_SensingConfig_r14(1, gapCandidateSensing_r14);

    value.set_p2x_SensingConfig_r14(p2x_SensingConfig_r14);

    value.set_sl_ReselectAfter_r14(sl_ReselectAfter_r14_n1);
}

static void fill_SL_ZoneConfig_r14(SL_ZoneConfig_r14 & value)
{
    value.set_zoneLength_r14(zoneLength_r14_m5);
    value.set_zoneWidth_r14(zoneWidth_r14_m5);
    value.set_zoneIdLongiMod_r14(1);
    value.set_zoneIdLatiMod_r14(1);
}

static void fill_SL_V2X_FreqSelectionConfig_r15(SL_V2X_FreqSelectionConfig_r15 & value)
{
    /* Setting 'priorityList_r15' field */
    SL_PriorityList_r13 priorityList_r15;
    fill_SL_PriorityList_r13(priorityList_r15);
    value.set_priorityList_r15(priorityList_r15);

    value.set_threshCBR_FreqReselection_r15(0);
    value.set_threshCBR_FreqKeeping_r15(0);
}

static void fill_SL_V2X_FreqSelectionConfigList_r15(SL_V2X_FreqSelectionConfigList_r15 & value)
{
    {
	/* Adding component #2 */
	SL_V2X_FreqSelectionConfig_r15 comp2;
	fill_SL_V2X_FreqSelectionConfig_r15(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_V2X_FreqSelectionConfig_r15 comp1;
	fill_SL_V2X_FreqSelectionConfig_r15(comp1);
	value.prepend(comp1);
    }
}

static void fill_SL_V2X_PreconfigFreqInfo_r14(SL_V2X_PreconfigFreqInfo_r14 & value)
{
    /* Setting 'v2x_CommPreconfigGeneral_r14' field */
    SL_PreconfigGeneral_r12 v2x_CommPreconfigGeneral_r14;
    fill_SL_PreconfigGeneral_r12(v2x_CommPreconfigGeneral_r14);
    value.set_v2x_CommPreconfigGeneral_r14(v2x_CommPreconfigGeneral_r14);

    /* Setting 'v2x_CommPreconfigSync_r14' field */
    /* Creating 'syncOffsetIndicators_r14' field of 'v2x_CommPreconfigSync_r14' field */

    /* Calling a fully-initializing constructor */
    SL_V2X_SyncOffsetIndicators_r14 syncOffsetIndicators_r14(0, 0, 0);

    /* Calling a fully-initializing constructor */
    SL_PreconfigV2X_Sync_r14 v2x_CommPreconfigSync_r14(syncOffsetIndicators_r14, 31, 0, fc0, syncRefMinHyst_r14_dB0, syncRefDiffHyst_r14_dB0, SL_PreconfigV2X_Sync_r14_slss_TxDisabled_r15_true);

    value.set_v2x_CommPreconfigSync_r14(v2x_CommPreconfigSync_r14);

    /* Setting 'v2x_CommRxPoolList_r14' field */
    SL_PreconfigV2X_RxPoolList_r14 v2x_CommRxPoolList_r14;
    fill_SL_PreconfigV2X_RxPoolList_r14(v2x_CommRxPoolList_r14);
    value.set_v2x_CommRxPoolList_r14(v2x_CommRxPoolList_r14);

    /* Setting 'v2x_CommTxPoolList_r14' field */
    SL_PreconfigV2X_TxPoolList_r14 v2x_CommTxPoolList_r14;
    fill_SL_PreconfigV2X_RxPoolList_r14(v2x_CommTxPoolList_r14);
    value.set_v2x_CommTxPoolList_r14(v2x_CommTxPoolList_r14);

    /* Setting 'p2x_CommTxPoolList_r14' field */
    SL_PreconfigV2X_TxPoolList_r14 p2x_CommTxPoolList_r14;
    fill_SL_PreconfigV2X_RxPoolList_r14(p2x_CommTxPoolList_r14);
    value.set_p2x_CommTxPoolList_r14(p2x_CommTxPoolList_r14);

    /* Setting 'v2x_ResourceSelectionConfig_r14' field */
    SL_CommTxPoolSensingConfig_r14 v2x_ResourceSelectionConfig_r14;
    fill_SL_CommTxPoolSensingConfig_r14(v2x_ResourceSelectionConfig_r14);
    value.set_v2x_ResourceSelectionConfig_r14(v2x_ResourceSelectionConfig_r14);

    /* Setting 'zoneConfig_r14' field */
    SL_ZoneConfig_r14 zoneConfig_r14;
    fill_SL_ZoneConfig_r14(zoneConfig_r14);
    value.set_zoneConfig_r14(zoneConfig_r14);

    value.set_syncPriority_r14(syncPriority_r14_gnss);
    value.set_thresSL_TxPrioritization_r14(1);
    value.set_offsetDFN_r14(0);
    /* Setting 'v2x_FreqSelectionConfigList_r15' field */
    SL_V2X_FreqSelectionConfigList_r15 v2x_FreqSelectionConfigList_r15;
    fill_SL_V2X_FreqSelectionConfigList_r15(v2x_FreqSelectionConfigList_r15);
    value.set_v2x_FreqSelectionConfigList_r15(v2x_FreqSelectionConfigList_r15);
}

static void fill_SL_CBR_Levels_Config_r14(SL_CBR_Levels_Config_r14 & value)
{
    value.prepend((OSS_UINT32)0);
    value.prepend((OSS_UINT32)0);
}

static void fill_SL_CBR_PSSCH_TxConfig_r14(SL_CBR_PSSCH_TxConfig_r14 & value)
{
    value.set_cr_Limit_r14(0);
    /* Setting 'tx_Parameters_r14' field */
    SL_PSSCH_TxParameters_r14 tx_Parameters_r14;
    fill_SL_PSSCH_TxParameters_r14(tx_Parameters_r14);
    value.set_tx_Parameters_r14(tx_Parameters_r14);
}

static void fill_SL_PPPR_Dest_CarrierFreq(SL_PPPR_Dest_CarrierFreq & value)
{
    /* Setting 'destinationInfoList_r15' field */
    SL_DestinationInfoList_r12 destinationInfoList_r15;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp2(24, comp2_value);
	destinationInfoList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp1(24, comp1_value);
	destinationInfoList_r15.prepend(comp1);
    }
    value.set_destinationInfoList_r15(destinationInfoList_r15);

    /* Setting 'allowedCarrierFreqList_r15' field */
    /* Creating 'allowedCarrierFreqSet1' field of 'allowedCarrierFreqList_r15' field */
    SL_AllowedCarrierFreqList_r15::allowedCarrierFreqSet1 allowedCarrierFreqSet1;
    allowedCarrierFreqSet1.prepend((OSS_UINT32)0);
    allowedCarrierFreqSet1.prepend((OSS_UINT32)0);

    /* Creating 'allowedCarrierFreqSet2' field of 'allowedCarrierFreqList_r15' field */
    SL_AllowedCarrierFreqList_r15::allowedCarrierFreqSet2 allowedCarrierFreqSet2;
    allowedCarrierFreqSet2.prepend((OSS_UINT32)0);
    allowedCarrierFreqSet2.prepend((OSS_UINT32)0);

    /* Calling a fully-initializing constructor */
    SL_AllowedCarrierFreqList_r15 allowedCarrierFreqList_r15(allowedCarrierFreqSet1, allowedCarrierFreqSet2);

    value.set_allowedCarrierFreqList_r15(allowedCarrierFreqList_r15);
}

static void fill_SL_V2X_PacketDuplicationConfig_r15(SL_V2X_PacketDuplicationConfig_r15 & value)
{
    value.set_threshSL_Reliability_r15(1);
    /* Setting 'allowedCarrierFreqConfig_r15' field of 'sl_CBR_PSSCH_TxConfigList_r14' field of 'v2x_PacketDuplicationConfig_r15' field */
    SL_PPPR_Dest_CarrierFreqList_r15 allowedCarrierFreqConfig_r15;
    {
	/* Adding component #2 */
	SL_PPPR_Dest_CarrierFreq comp2;
	fill_SL_PPPR_Dest_CarrierFreq(comp2);
	allowedCarrierFreqConfig_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PPPR_Dest_CarrierFreq comp1;
	fill_SL_PPPR_Dest_CarrierFreq(comp1);
	allowedCarrierFreqConfig_r15.prepend(comp1);
    }
    value.set_allowedCarrierFreqConfig_r15(allowedCarrierFreqConfig_r15);
}

SL_V2X_Preconfiguration_r14 *create_samplevalue_SL_V2X_Preconfiguration_r14()
{
    /* Creating 'v2x_PreconfigFreqList_r14' field */
    SL_V2X_PreconfigFreqList_r14 v2x_PreconfigFreqList_r14;
    {
	/* Adding component #2 */
	SL_V2X_PreconfigFreqInfo_r14 comp2;
	fill_SL_V2X_PreconfigFreqInfo_r14(comp2);
	v2x_PreconfigFreqList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_V2X_PreconfigFreqInfo_r14 comp1;
	fill_SL_V2X_PreconfigFreqInfo_r14(comp1);
	v2x_PreconfigFreqList_r14.prepend(comp1);
    }

    /* Creating 'anchorCarrierFreqList_r14' field */
    SL_AnchorCarrierFreqList_V2X_r14 anchorCarrierFreqList_r14;
    anchorCarrierFreqList_r14.prepend((OSS_UINT32)0);
    anchorCarrierFreqList_r14.prepend((OSS_UINT32)0);

    /* Creating 'cbr_PreconfigList_r14' field */
    /* Creating 'cbr_RangeCommonConfigList_r14' field of 'cbr_PreconfigList_r14' field */
    SL_CBR_PreconfigTxConfigList_r14::cbr_RangeCommonConfigList_r14 cbr_RangeCommonConfigList_r14;
    {
	/* Adding component #2 */
	SL_CBR_Levels_Config_r14 comp2;
	fill_SL_CBR_Levels_Config_r14(comp2);
	cbr_RangeCommonConfigList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_CBR_Levels_Config_r14 comp1;
	fill_SL_CBR_Levels_Config_r14(comp1);
	cbr_RangeCommonConfigList_r14.prepend(comp1);
    }

    /* Creating 'sl_CBR_PSSCH_TxConfigList_r14' field of 'cbr_PreconfigList_r14' field */
    SL_CBR_PreconfigTxConfigList_r14::sl_CBR_PSSCH_TxConfigList_r14 sl_CBR_PSSCH_TxConfigList_r14;
    {
	/* Adding component #2 */
	SL_CBR_PSSCH_TxConfig_r14 comp2;
	fill_SL_CBR_PSSCH_TxConfig_r14(comp2);
	sl_CBR_PSSCH_TxConfigList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_CBR_PSSCH_TxConfig_r14 comp1;
	fill_SL_CBR_PSSCH_TxConfig_r14(comp1);
	sl_CBR_PSSCH_TxConfigList_r14.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_CBR_PreconfigTxConfigList_r14 cbr_PreconfigList_r14(cbr_RangeCommonConfigList_r14, sl_CBR_PSSCH_TxConfigList_r14);

    /* Creating 'v2x_PacketDuplicationConfig_r15' field */
    SL_V2X_PacketDuplicationConfig_r15 v2x_PacketDuplicationConfig_r15;
    fill_SL_V2X_PacketDuplicationConfig_r15(v2x_PacketDuplicationConfig_r15);

    /* Creating 'syncFreqList_r15' field */
    SL_V2X_SyncFreqList_r15 syncFreqList_r15;
    syncFreqList_r15.prepend((OSS_UINT32)0);
    syncFreqList_r15.prepend((OSS_UINT32)0);

    /* Creating 'v2x_TxProfileList_r15' field */
    SL_V2X_TxProfileList_r15 v2x_TxProfileList_r15;
    v2x_TxProfileList_r15.prepend(SL_V2X_TxProfile_r15_rel14);
    v2x_TxProfileList_r15.prepend(SL_V2X_TxProfile_r15_rel14);

    /* Calling a fully-initializing constructor */
    return new SL_V2X_Preconfiguration_r14(v2x_PreconfigFreqList_r14, anchorCarrierFreqList_r14, cbr_PreconfigList_r14, v2x_PacketDuplicationConfig_r15, syncFreqList_r15, SL_V2X_Preconfiguration_r14_slss_TxMultiFreq_r15_true, v2x_TxProfileList_r15);
}

HandoverCommand *create_samplevalue_HandoverCommand()
{
    /* Creating 'criticalExtensions' field */
    HandoverCommand::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    HandoverCommand::criticalExtensions::c1 c1;
    /* Setting 'handoverCommand_r8' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'handoverCommandMessage' field of 'handoverCommand_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    HandoverCommand_r8_IEs::handoverCommandMessage handoverCommandMessage;
    /* Creating 'message' field */
    DL_DCCH_MessageType message;
    /* Setting 'c1' alternative of 'message' field */
    DL_DCCH_MessageType::c1 message_c1;
    /* Setting 'csfbParametersResponseCDMA2000' alternative of 'c1' alternative of 'message' field */
    /* Creating 'criticalExtensions' field of 'csfbParametersResponseCDMA2000' alternative of 'c1' alternative of 'message' field... */
    CSFBParametersResponseCDMA2000::criticalExtensions csfbParametersResponseCDMA2000_criticalExtensions;
    /* Setting 'csfbParametersResponseCDMA2000_r8' alternative of 'criticalExtensions' field of 'csfbParametersResponseCDMA2000' alternative of 'c1' alternative... */
    /* Creating 'rand' field of 'csfbParametersResponseCDMA2000_r8' alternative of 'criticalExtensions' field of 'csfbParametersResponseCDMA2000' alternative... */
    static unsigned char rand_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString rand(32, rand_value);

    /* Creating 'mobilityParameters' field of 'csfbParametersResponseCDMA2000_r8' alternative of 'criticalExtensions' field of 'csfbParametersResponseCDMA2000' alternative... */
    static unsigned char mobilityParameters_value[] = {
	0x00
    };
    OssString mobilityParameters(sizeof(mobilityParameters_value), (char *)mobilityParameters_value);

    /* Creating 'nonCriticalExtension' field of 'csfbParametersResponseCDMA2000_r8' alternative of 'criticalExtensions' field of 'csfbParametersResponseCDMA2000' alternative... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'csfbParametersResponseCDMA2000_r8' alternative of 'criticalExtensions' field... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'csfbParametersResponseCDMA2000_r8' alternative of 'criticalExtensions' field... */
    CSFBParametersResponseCDMA2000_v8a0_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    CSFBParametersResponseCDMA2000_v8a0_IEs csfbParametersResponseCDMA2000_r8_nonCriticalExtension(lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    CSFBParametersResponseCDMA2000_r8_IEs csfbParametersResponseCDMA2000_r8(rand, mobilityParameters, csfbParametersResponseCDMA2000_r8_nonCriticalExtension);

    csfbParametersResponseCDMA2000_criticalExtensions.set_csfbParametersResponseCDMA2000_r8(csfbParametersResponseCDMA2000_r8);

    /* Calling a fully-initializing constructor */
    CSFBParametersResponseCDMA2000 csfbParametersResponseCDMA2000(0, csfbParametersResponseCDMA2000_criticalExtensions);

    message_c1.set_csfbParametersResponseCDMA2000(csfbParametersResponseCDMA2000);

    message.set_c1(message_c1);

    /* Calling a fully-initializing constructor */
    DL_DCCH_Message decoded(message);

    handoverCommandMessage.set_decoded(decoded);

    /* Creating 'nonCriticalExtension' field of 'handoverCommand_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    HandoverCommand_r8_IEs::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    HandoverCommand_r8_IEs handoverCommand_r8(handoverCommandMessage, nonCriticalExtension);

    c1.set_handoverCommand_r8(handoverCommand_r8);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new HandoverCommand(criticalExtensions);
}

static void fill_UE_CapabilityRAT_Container(UE_CapabilityRAT_Container & value)
{
    value.set_rat_Type(RAT_Type_eutra);
    /* Setting 'ueCapabilityRAT_Container' field */
    static unsigned char ueCapabilityRAT_Container_value[] = {
	0x00
    };
    OssString ueCapabilityRAT_Container(sizeof(ueCapabilityRAT_Container_value), (char *)ueCapabilityRAT_Container_value);
    value.set_ueCapabilityRAT_Container(ueCapabilityRAT_Container);
}

static void fill_MeasGapConfig(MeasGapConfig & value)
{
    value.set_release(0);
}

static void fill_MeasGapConfigPerCC_List_r14(MeasGapConfigPerCC_List_r14 & value)
{
    value.set_release(0);
}

static void fill_SecurityAlgorithmConfig(SecurityAlgorithmConfig & value)
{
    value.set_cipheringAlgorithm(eea0);
    value.set_integrityProtAlgorithm(eia0_v920);
}

static void fill_PLMN_IdentityInfo(PLMN_IdentityInfo & value)
{
    /* Setting 'plmn_Identity' field */
    PLMN_Identity plmn_Identity;
    fill_PLMN_Identity(plmn_Identity);
    value.set_plmn_Identity(plmn_Identity);

    value.set_cellReservedForOperatorUse(cellReservedForOperatorUse_reserved);
}

static void fill_PLMN_IdentityList(PLMN_IdentityList & value)
{
    {
	/* Adding component #2 */
	PLMN_IdentityInfo comp2;
	fill_PLMN_IdentityInfo(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_IdentityInfo comp1;
	fill_PLMN_IdentityInfo(comp1);
	value.prepend(comp1);
    }
}

static void fill_SchedulingInfo(SchedulingInfo & value)
{
    value.set_si_Periodicity(si_Periodicity_rf8);
    /* Setting 'sib_MappingInfo' field */
    SIB_MappingInfo sib_MappingInfo;
    sib_MappingInfo.prepend(sibType3);
    sib_MappingInfo.prepend(sibType3);
    value.set_sib_MappingInfo(sib_MappingInfo);
}

static void fill_TDD_Config(TDD_Config & value)
{
    value.set_subframeAssignment(subframeAssignment_sa0);
    value.set_specialSubframePatterns(specialSubframePatterns_ssp0);
}

static void fill_AntennaInfoCommon(AntennaInfoCommon & value)
{
    value.set_antennaPortsCount(antennaPortsCount_an1);
}

static void fill_MultiBandInfo_v9e0(MultiBandInfo_v9e0 & value)
{
    value.set_freqBandIndicator_v9e0(65);
}

static void fill_NS_PmaxValue_r10(NS_PmaxValue_r10 & value)
{
    value.set_additionalPmax_r10(-30);
    value.set_additionalSpectrumEmission(1);
}

static void fill_NS_PmaxList_r10(NS_PmaxList_r10 & value)
{
    {
	/* Adding component #2 */
	NS_PmaxValue_r10 comp2;
	fill_NS_PmaxValue_r10(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NS_PmaxValue_r10 comp1;
	fill_NS_PmaxValue_r10(comp1);
	value.prepend(comp1);
    }
}

static void fill_NS_PmaxValue_v10l0(NS_PmaxValue_v10l0 & value)
{
    value.set_additionalSpectrumEmission_v10l0(33);
}

static void fill_NS_PmaxList_v10l0(NS_PmaxList_v10l0 & value)
{
    {
	/* Adding component #2 */
	NS_PmaxValue_v10l0 comp2;
	fill_NS_PmaxValue_v10l0(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NS_PmaxValue_v10l0 comp1;
	fill_NS_PmaxValue_v10l0(comp1);
	value.prepend(comp1);
    }
}

static void fill_SchedulingInfo_BR_r13(SchedulingInfo_BR_r13 & value)
{
    value.set_si_Narrowband_r13(1);
    value.set_si_TBS_r13(b152);
}

static void fill_CellAccessRelatedInfo_r14(CellAccessRelatedInfo_r14 & value)
{
    /* Setting 'plmn_IdentityList_r14' field */
    PLMN_IdentityList plmn_IdentityList_r14;
    {
	/* Adding component #2 */
	PLMN_IdentityInfo comp2;
	fill_PLMN_IdentityInfo(comp2);
	plmn_IdentityList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_IdentityInfo comp1;
	fill_PLMN_IdentityInfo(comp1);
	plmn_IdentityList_r14.prepend(comp1);
    }
    value.set_plmn_IdentityList_r14(plmn_IdentityList_r14);

    /* Setting 'trackingAreaCode_r14' field */
    static unsigned char trackingAreaCode_r14_value[] = {
	0x00, 0x00
    };
    OssBitString trackingAreaCode_r14(16, trackingAreaCode_r14_value);
    value.set_trackingAreaCode_r14(trackingAreaCode_r14);

    /* Setting 'cellIdentity_r14' field */
    static unsigned char cellIdentity_r14_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity_r14(28, cellIdentity_r14_value);
    value.set_cellIdentity_r14(cellIdentity_r14);
}

static void fill_PLMN_IdentityInfo_v1530(PLMN_IdentityInfo_v1530 & value)
{
    value.set_cellReservedForOperatorUse_CRS_r15(PLMN_IdentityInfo_v1530_cellReservedForOperatorUse_CRS_r15_reserved);
}

static void fill_PosSIB_Type_r15(PosSIB_Type_r15 & value)
{
    value.set_encrypted_r15(encrypted_r15_true);
    /* Setting 'gnss_id_r15' field */

    /* Calling a fully-initializing constructor */
    GNSS_ID_r15 gnss_id_r15(gps);

    value.set_gnss_id_r15(gnss_id_r15);

    /* Setting 'sbas_id_r15' field */

    /* Calling a fully-initializing constructor */
    SBAS_ID_r15 sbas_id_r15(waas);

    value.set_sbas_id_r15(sbas_id_r15);

    value.set_posSibType_r15(posSibType1_1);
}

static void fill_PosSchedulingInfo_r15(PosSchedulingInfo_r15 & value)
{
    value.set_posSI_Periodicity_r15(posSI_Periodicity_r15_rf8);
    /* Setting 'posSIB_MappingInfo_r15' field */
    PosSIB_MappingInfo_r15 posSIB_MappingInfo_r15;
    {
	/* Adding component #2 */
	PosSIB_Type_r15 comp2;
	fill_PosSIB_Type_r15(comp2);
	posSIB_MappingInfo_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PosSIB_Type_r15 comp1;
	fill_PosSIB_Type_r15(comp1);
	posSIB_MappingInfo_r15.prepend(comp1);
    }
    value.set_posSIB_MappingInfo_r15(posSIB_MappingInfo_r15);
}

static void fill_PRACH_ConfigSCell_r10(PRACH_ConfigSCell_r10 & value)
{
    value.set_prach_ConfigIndex_r10(0);
}

static void fill_UplinkPowerControlCommon_v1530(UplinkPowerControlCommon_v1530 & value)
{
    /* Setting 'deltaFList_SPUCCH_r15' field of 'uplinkPowerControlCommonPUSCH_LessCell_v1430' field of 'uplinkPowerControlCommonSCell_v1530' field */
    DeltaFList_SPUCCH_r15 deltaFList_SPUCCH_r15;
    deltaFList_SPUCCH_r15.set_release(0);
    value.set_deltaFList_SPUCCH_r15(deltaFList_SPUCCH_r15);
}

static void fill_RadioResourceConfigCommonSCell_r10(RadioResourceConfigCommonSCell_r10 & value)
{
    /* Setting 'nonUL_Configuration_r10' field */
    /* Creating 'antennaInfoCommon_r10' field of 'nonUL_Configuration_r10' field */
    AntennaInfoCommon antennaInfoCommon_r10;
    fill_AntennaInfoCommon(antennaInfoCommon_r10);

    /* Creating 'mbsfn_SubframeConfigList_r10' field of 'nonUL_Configuration_r10' field */
    MBSFN_SubframeConfigList mbsfn_SubframeConfigList_r10;
    fill_MBSFN_SubframeConfigList(mbsfn_SubframeConfigList_r10);

    /* Creating 'phich_Config_r10' field of 'nonUL_Configuration_r10' field */
    PHICH_Config phich_Config_r10;
    fill_PHICH_Config(phich_Config_r10);

    /* Creating 'pdsch_ConfigCommon_r10' field of 'nonUL_Configuration_r10' field */
    PDSCH_ConfigCommon pdsch_ConfigCommon_r10;
    fill_PDSCH_ConfigCommon(pdsch_ConfigCommon_r10);

    /* Creating 'tdd_Config_r10' field of 'nonUL_Configuration_r10' field */
    TDD_Config tdd_Config_r10;
    fill_TDD_Config(tdd_Config_r10);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_r10::nonUL_Configuration_r10 nonUL_Configuration_r10(dl_Bandwidth_r10_n6, antennaInfoCommon_r10, mbsfn_SubframeConfigList_r10, phich_Config_r10, pdsch_ConfigCommon_r10, tdd_Config_r10);

    value.set_nonUL_Configuration_r10(nonUL_Configuration_r10);

    /* Setting 'ul_Configuration_r10' field */
    /* Creating 'ul_FreqInfo_r10' field of 'ul_Configuration_r10' field */

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_r10::ul_Configuration_r10::ul_FreqInfo_r10 ul_FreqInfo_r10(0, ul_Bandwidth_r10_n6, 1);

    /* Creating 'uplinkPowerControlCommonSCell_r10' field of 'ul_Configuration_r10' field */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommonSCell_r10 uplinkPowerControlCommonSCell_r10(24, Alpha_r12_al0);

    /* Creating 'soundingRS_UL_ConfigCommon_r10' field of 'ul_Configuration_r10' field */
    SoundingRS_UL_ConfigCommon soundingRS_UL_ConfigCommon_r10;
    fill_SoundingRS_UL_ConfigCommon(soundingRS_UL_ConfigCommon_r10);

    /* Creating 'prach_ConfigSCell_r10' field of 'ul_Configuration_r10' field */
    PRACH_ConfigSCell_r10 prach_ConfigSCell_r10;
    fill_PRACH_ConfigSCell_r10(prach_ConfigSCell_r10);

    /* Creating 'pusch_ConfigCommon_r10' field of 'ul_Configuration_r10' field */
    PUSCH_ConfigCommon pusch_ConfigCommon_r10;
    fill_PUSCH_ConfigCommon(pusch_ConfigCommon_r10);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_r10::ul_Configuration_r10 ul_Configuration_r10(ul_FreqInfo_r10, -30, uplinkPowerControlCommonSCell_r10, soundingRS_UL_ConfigCommon_r10, len1, prach_ConfigSCell_r10, pusch_ConfigCommon_r10);

    value.set_ul_Configuration_r10(ul_Configuration_r10);

    value.set_ul_CarrierFreq_v1090(65536);
    /* Setting 'rach_ConfigCommonSCell_r11' field */
    /* Creating 'powerRampingParameters_r11' field of 'rach_ConfigCommonSCell_r11' field */
    PowerRampingParameters powerRampingParameters_r11;
    fill_PowerRampingParameters(powerRampingParameters_r11);

    /* Creating 'ra_SupervisionInfo_r11' field of 'rach_ConfigCommonSCell_r11' field */

    /* Calling a fully-initializing constructor */
    RACH_ConfigCommonSCell_r11::ra_SupervisionInfo_r11 ra_SupervisionInfo_r11(PreambleTransMax_n3);

    /* Calling a fully-initializing constructor */
    RACH_ConfigCommonSCell_r11 rach_ConfigCommonSCell_r11(powerRampingParameters_r11, ra_SupervisionInfo_r11);

    value.set_rach_ConfigCommonSCell_r11(rach_ConfigCommonSCell_r11);

    /* Setting 'prach_ConfigSCell_r11' field */
    /* Creating 'prach_ConfigInfo' field of 'prach_ConfigSCell_r11' field */
    PRACH_ConfigInfo prach_ConfigInfo;
    fill_PRACH_ConfigInfo(prach_ConfigInfo);

    /* Calling a fully-initializing constructor */
    PRACH_Config prach_ConfigSCell_r11(0, prach_ConfigInfo);

    value.set_prach_ConfigSCell_r11(prach_ConfigSCell_r11);

    /* Setting 'tdd_Config_v1130' field */

    /* Calling a fully-initializing constructor */
    TDD_Config_v1130 tdd_Config_v1130(specialSubframePatterns_v1130_ssp7);

    value.set_tdd_Config_v1130(tdd_Config_v1130);

    /* Setting 'uplinkPowerControlCommonSCell_v1130' field */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommonSCell_v1130 uplinkPowerControlCommonSCell_v1130(-1);

    value.set_uplinkPowerControlCommonSCell_v1130(uplinkPowerControlCommonSCell_v1130);

    /* Setting 'pusch_ConfigCommon_v1270' field */
    PUSCH_ConfigCommon_v1270 pusch_ConfigCommon_v1270;
    fill_PUSCH_ConfigCommon_v1270(pusch_ConfigCommon_v1270);
    value.set_pusch_ConfigCommon_v1270(pusch_ConfigCommon_v1270);

    /* Setting 'pucch_ConfigCommon_r13' field */
    PUCCH_ConfigCommon pucch_ConfigCommon_r13;
    fill_PUCCH_ConfigCommon(pucch_ConfigCommon_r13);
    value.set_pucch_ConfigCommon_r13(pucch_ConfigCommon_r13);

    /* Setting 'uplinkPowerControlCommonSCell_v1310' field */
    /* Creating 'deltaFList_PUCCH' field of 'uplinkPowerControlCommonSCell_v1310' field */
    DeltaFList_PUCCH deltaFList_PUCCH;
    fill_DeltaFList_PUCCH(deltaFList_PUCCH);

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommonSCell_v1310 uplinkPowerControlCommonSCell_v1310(-96, deltaFList_PUCCH, UplinkPowerControlCommonSCell_v1310_deltaF_PUCCH_Format3_r12_deltaF_1, UplinkPowerControlCommonSCell_v1310_deltaF_PUCCH_Format1bCS_r12_deltaF1, UplinkPowerControlCommonSCell_v1310_deltaF_PUCCH_Format4_r13_deltaF16, UplinkPowerControlCommonSCell_v1310_deltaF_PUCCH_Format5_13_deltaF13);

    value.set_uplinkPowerControlCommonSCell_v1310(uplinkPowerControlCommonSCell_v1310);

    /* Setting 'highSpeedConfigSCell_r14' field */

    /* Calling a fully-initializing constructor */
    HighSpeedConfigSCell_r14 highSpeedConfigSCell_r14(HighSpeedConfigSCell_r14_highSpeedEnhancedDemodulationFlag_r14_true);

    value.set_highSpeedConfigSCell_r14(highSpeedConfigSCell_r14);

    /* Setting 'prach_Config_v1430' field */
    PRACH_Config_v1430 prach_Config_v1430;
    fill_PRACH_Config_v1430(prach_Config_v1430);
    value.set_prach_Config_v1430(prach_Config_v1430);

    /* Setting 'ul_Configuration_r14' field */
    /* Creating 'ul_FreqInfo_r14' field of 'ul_Configuration_r14' field */

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_r10::ul_Configuration_r14::ul_FreqInfo_r14 ul_FreqInfo_r14(0, ul_Bandwidth_r14_n6, 1);

    /* Creating 'soundingRS_UL_ConfigCommon_r14' field of 'ul_Configuration_r14' field */
    SoundingRS_UL_ConfigCommon soundingRS_UL_ConfigCommon_r14;
    fill_SoundingRS_UL_ConfigCommon(soundingRS_UL_ConfigCommon_r14);

    /* Creating 'prach_ConfigSCell_r14' field of 'ul_Configuration_r14' field */
    PRACH_ConfigSCell_r10 prach_ConfigSCell_r14;
    fill_PRACH_ConfigSCell_r10(prach_ConfigSCell_r14);

    /* Creating 'uplinkPowerControlCommonPUSCH_LessCell_v1430' field of 'ul_Configuration_r14' field */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommonPUSCH_LessCell_v1430 uplinkPowerControlCommonPUSCH_LessCell_v1430(24, 24, Alpha_r12_al0);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_r10::ul_Configuration_r14 ul_Configuration_r14(ul_FreqInfo_r14, -30, soundingRS_UL_ConfigCommon_r14, len1, prach_ConfigSCell_r14, uplinkPowerControlCommonPUSCH_LessCell_v1430);

    value.set_ul_Configuration_r14(ul_Configuration_r14);

    value.set_harq_ReferenceConfig_r14(harq_ReferenceConfig_r14_sa2);
    value.set_soundingRS_FlexibleTiming_r14(soundingRS_FlexibleTiming_r14_true);
    /* Setting 'mbsfn_SubframeConfigList_v1430' field */
    MBSFN_SubframeConfigList_v1430 mbsfn_SubframeConfigList_v1430;
    fill_MBSFN_SubframeConfigList_v1430(mbsfn_SubframeConfigList_v1430);
    value.set_mbsfn_SubframeConfigList_v1430(mbsfn_SubframeConfigList_v1430);

    /* Setting 'uplinkPowerControlCommonSCell_v1530' field */
    UplinkPowerControlCommon_v1530 uplinkPowerControlCommonSCell_v1530;
    fill_UplinkPowerControlCommon_v1530(uplinkPowerControlCommonSCell_v1530);
    value.set_uplinkPowerControlCommonSCell_v1530(uplinkPowerControlCommonSCell_v1530);
}

static void fill_PDCCH_CandidateReductionsLAA_UL_r14(PDCCH_CandidateReductionsLAA_UL_r14 & value)
{
    value.set_release(0);
}

static void fill_SRS_CC_SetIndex_r14(SRS_CC_SetIndex_r14 & value)
{
    value.set_cc_SetIndex_r14(0);
    value.set_cc_IndexInOneCC_Set_r14(0);
}

static void fill_SoundingRS_AperiodicSet_r14(SoundingRS_AperiodicSet_r14 & value)
{
    /* Setting 'srs_CC_SetIndexList_r14' field */
    SoundingRS_AperiodicSet_r14::srs_CC_SetIndexList_r14 srs_CC_SetIndexList_r14;
    {
	/* Adding component #2 */
	SRS_CC_SetIndex_r14 comp2;
	fill_SRS_CC_SetIndex_r14(comp2);
	srs_CC_SetIndexList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SRS_CC_SetIndex_r14 comp1;
	fill_SRS_CC_SetIndex_r14(comp1);
	srs_CC_SetIndexList_r14.prepend(comp1);
    }
    value.set_srs_CC_SetIndexList_r14(srs_CC_SetIndexList_r14);

    /* Setting 'soundingRS_UL_ConfigDedicatedAperiodic_r14' field */
    SoundingRS_UL_ConfigDedicatedAperiodic_r10 soundingRS_UL_ConfigDedicatedAperiodic_r14;
    fill_SoundingRS_UL_ConfigDedicatedAperiodic_r10(soundingRS_UL_ConfigDedicatedAperiodic_r14);
    value.set_soundingRS_UL_ConfigDedicatedAperiodic_r14(soundingRS_UL_ConfigDedicatedAperiodic_r14);
}

static void fill_SoundingRS_AperiodicSetUpPTsExt_r14(SoundingRS_AperiodicSetUpPTsExt_r14 & value)
{
    /* Setting 'srs_CC_SetIndexList_r14' field */
    SoundingRS_AperiodicSetUpPTsExt_r14::srs_CC_SetIndexList_r14 srs_CC_SetIndexList_r14;
    {
	/* Adding component #2 */
	SRS_CC_SetIndex_r14 comp2;
	fill_SRS_CC_SetIndex_r14(comp2);
	srs_CC_SetIndexList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SRS_CC_SetIndex_r14 comp1;
	fill_SRS_CC_SetIndex_r14(comp1);
	srs_CC_SetIndexList_r14.prepend(comp1);
    }
    value.set_srs_CC_SetIndexList_r14(srs_CC_SetIndexList_r14);

    /* Setting 'soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r14' field */
    SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13 soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r14;
    fill_SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13(soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r14);
    value.set_soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r14(soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r14);
}

static void fill_RadioResourceConfigDedicatedSCell_r10(RadioResourceConfigDedicatedSCell_r10 & value)
{
    /* Setting 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'nonUL_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'antennaInfo_r10' field of 'nonUL_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'codebookSubsetRestriction_r10' field of 'antennaInfo_r10' field of 'nonUL_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field... */
    static unsigned char codebookSubsetRestriction_r10_value[] = {
	0x00
    };
    OssBitString codebookSubsetRestriction_r10(1, codebookSubsetRestriction_r10_value);

    /* Creating 'ue_TransmitAntennaSelection' field of 'antennaInfo_r10' field of 'nonUL_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field... */
    AntennaInfoDedicated_r10::ue_TransmitAntennaSelection ue_TransmitAntennaSelection;
    fill_data_4(ue_TransmitAntennaSelection);

    /* Calling a fully-initializing constructor */
    AntennaInfoDedicated_r10 antennaInfo_r10(transmissionMode_r10_tm1, codebookSubsetRestriction_r10, ue_TransmitAntennaSelection);

    /* Creating 'crossCarrierSchedulingConfig_r10' field of 'nonUL_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'schedulingCellInfo_r10' field of 'crossCarrierSchedulingConfig_r10' field of 'nonUL_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field... */
    CrossCarrierSchedulingConfig_r10::schedulingCellInfo_r10 schedulingCellInfo_r10;
    /* Setting 'own_r10' alternative of 'schedulingCellInfo_r10' field of 'crossCarrierSchedulingConfig_r10' field of 'nonUL_Configuration_r10' field... */

    /* Calling a fully-initializing constructor */
    CrossCarrierSchedulingConfig_r10::schedulingCellInfo_r10::own_r10 own_r10(TRUE);

    schedulingCellInfo_r10.set_own_r10(own_r10);

    /* Calling a fully-initializing constructor */
    CrossCarrierSchedulingConfig_r10 crossCarrierSchedulingConfig_r10(schedulingCellInfo_r10);

    /* Creating 'csi_RS_Config_r10' field of 'nonUL_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_Config_r10 csi_RS_Config_r10;
    fill_CSI_RS_Config_r10(csi_RS_Config_r10);

    /* Creating 'pdsch_ConfigDedicated_r10' field of 'nonUL_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    PDSCH_ConfigDedicated pdsch_ConfigDedicated_r10;
    fill_PDSCH_ConfigDedicated(pdsch_ConfigDedicated_r10);

    /* Calling a fully-initializing constructor */
    PhysicalConfigDedicatedSCell_r10::nonUL_Configuration_r10 nonUL_Configuration_r10(antennaInfo_r10, crossCarrierSchedulingConfig_r10, csi_RS_Config_r10, pdsch_ConfigDedicated_r10);

    /* Creating 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'antennaInfoUL_r10' field of 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    AntennaInfoUL_r10 antennaInfoUL_r10;
    fill_AntennaInfoUL_r10(antennaInfoUL_r10);

    /* Creating 'pusch_ConfigDedicatedSCell_r10' field of 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicatedSCell_r10 pusch_ConfigDedicatedSCell_r10(PUSCH_ConfigDedicatedSCell_r10_groupHoppingDisabled_r10_true, PUSCH_ConfigDedicatedSCell_r10_dmrs_WithOCC_Activated_r10_true);

    /* Creating 'uplinkPowerControlDedicatedSCell_r10' field of 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlDedicatedSCell_r10 uplinkPowerControlDedicatedSCell_r10(7, deltaMCS_Enabled_r10_en0, TRUE, 0, 0, fc0, pathlossReferenceLinking_r10_pCell);

    /* Creating 'cqi_ReportConfigSCell_r10' field of 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'cqi_ReportPeriodicSCell_r10' field of 'cqi_ReportConfigSCell_r10' field of 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field... */
    CQI_ReportPeriodic_r10 cqi_ReportPeriodicSCell_r10;
    fill_CQI_ReportPeriodic_r10(cqi_ReportPeriodicSCell_r10);

    /* Calling a fully-initializing constructor */
    CQI_ReportConfigSCell_r10 cqi_ReportConfigSCell_r10(rm12, -1, cqi_ReportPeriodicSCell_r10, pmi_RI_Report_r10_setup);

    /* Creating 'soundingRS_UL_ConfigDedicated_r10' field of 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    SoundingRS_UL_ConfigDedicated soundingRS_UL_ConfigDedicated_r10;
    fill_SoundingRS_UL_ConfigDedicated(soundingRS_UL_ConfigDedicated_r10);

    /* Creating 'soundingRS_UL_ConfigDedicated_v1020' field of 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    SoundingRS_UL_ConfigDedicated_v1020 soundingRS_UL_ConfigDedicated_v1020;
    fill_SoundingRS_UL_ConfigDedicated_v1020(soundingRS_UL_ConfigDedicated_v1020);

    /* Creating 'soundingRS_UL_ConfigDedicatedAperiodic_r10' field of 'ul_Configuration_r10' field of 'physicalConfigDedicatedSCell_r10' field */
    SoundingRS_UL_ConfigDedicatedAperiodic_r10 soundingRS_UL_ConfigDedicatedAperiodic_r10;
    fill_SoundingRS_UL_ConfigDedicatedAperiodic_r10(soundingRS_UL_ConfigDedicatedAperiodic_r10);

    /* Calling a fully-initializing constructor */
    PhysicalConfigDedicatedSCell_r10::ul_Configuration_r10 ul_Configuration_r10(antennaInfoUL_r10, pusch_ConfigDedicatedSCell_r10, uplinkPowerControlDedicatedSCell_r10, cqi_ReportConfigSCell_r10, soundingRS_UL_ConfigDedicated_r10, soundingRS_UL_ConfigDedicated_v1020, soundingRS_UL_ConfigDedicatedAperiodic_r10);

    /* Creating 'csi_RS_ConfigNZPToReleaseList_r11' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_ConfigNZPToReleaseList_r11 csi_RS_ConfigNZPToReleaseList_r11;
    csi_RS_ConfigNZPToReleaseList_r11.prepend(1);
    csi_RS_ConfigNZPToReleaseList_r11.prepend(1);

    /* Creating 'csi_RS_ConfigNZPToAddModList_r11' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_ConfigNZPToAddModList_r11 csi_RS_ConfigNZPToAddModList_r11;
    fill_CSI_RS_ConfigNZPToAddModList_r11(csi_RS_ConfigNZPToAddModList_r11);

    /* Creating 'csi_RS_ConfigZPToReleaseList_r11' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_ConfigZPToReleaseList_r11 csi_RS_ConfigZPToReleaseList_r11;
    csi_RS_ConfigZPToReleaseList_r11.prepend(1);
    csi_RS_ConfigZPToReleaseList_r11.prepend(1);

    /* Creating 'csi_RS_ConfigZPToAddModList_r11' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_ConfigZPToAddModList_r11 csi_RS_ConfigZPToAddModList_r11;
    fill_CSI_RS_ConfigZPToAddModList_r11(csi_RS_ConfigZPToAddModList_r11);

    /* Creating 'epdcch_Config_r11' field of 'physicalConfigDedicatedSCell_r10' field */
    EPDCCH_Config_r11 epdcch_Config_r11;
    fill_EPDCCH_Config_r11(epdcch_Config_r11);

    /* Creating 'pdsch_ConfigDedicated_v1130' field of 'physicalConfigDedicatedSCell_r10' field */
    PDSCH_ConfigDedicated_v1130 pdsch_ConfigDedicated_v1130;
    fill_PDSCH_ConfigDedicated_v1130(pdsch_ConfigDedicated_v1130);

    /* Creating 'cqi_ReportConfig_v1130' field of 'physicalConfigDedicatedSCell_r10' field */
    CQI_ReportConfig_v1130 cqi_ReportConfig_v1130;
    fill_CQI_ReportConfig_v1130(cqi_ReportConfig_v1130);

    /* Creating 'pusch_ConfigDedicated_v1130' field of 'physicalConfigDedicatedSCell_r10' field */
    PUSCH_ConfigDedicated_v1130 pusch_ConfigDedicated_v1130;
    fill_PUSCH_ConfigDedicated_v1130(pusch_ConfigDedicated_v1130);

    /* Creating 'uplinkPowerControlDedicatedSCell_v1130' field of 'physicalConfigDedicatedSCell_r10' field */
    UplinkPowerControlDedicated_v1130 uplinkPowerControlDedicatedSCell_v1130;
    fill_UplinkPowerControlDedicated_v1130(uplinkPowerControlDedicatedSCell_v1130);

    /* Creating 'antennaInfo_v1250' field of 'physicalConfigDedicatedSCell_r10' field */
    AntennaInfoDedicated_v1250 antennaInfo_v1250;
    fill_AntennaInfoDedicated_v1250(antennaInfo_v1250);

    /* Creating 'eimta_MainConfigSCell_r12' field of 'physicalConfigDedicatedSCell_r10' field */
    EIMTA_MainConfigServCell_r12 eimta_MainConfigSCell_r12;
    fill_EIMTA_MainConfigServCell_r12(eimta_MainConfigSCell_r12);

    /* Creating 'cqi_ReportConfigSCell_v1250' field of 'physicalConfigDedicatedSCell_r10' field */
    CQI_ReportConfig_v1250 cqi_ReportConfigSCell_v1250;
    fill_CQI_ReportConfig_v1250(cqi_ReportConfigSCell_v1250);

    /* Creating 'uplinkPowerControlDedicatedSCell_v1250' field of 'physicalConfigDedicatedSCell_r10' field */
    UplinkPowerControlDedicated_v1250 uplinkPowerControlDedicatedSCell_v1250;
    fill_UplinkPowerControlDedicated_v1250(uplinkPowerControlDedicatedSCell_v1250);

    /* Creating 'csi_RS_Config_v1250' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_Config_v1250 csi_RS_Config_v1250;
    fill_CSI_RS_Config_v1250(csi_RS_Config_v1250);

    /* Creating 'pdsch_ConfigDedicated_v1280' field of 'physicalConfigDedicatedSCell_r10' field */
    PDSCH_ConfigDedicated_v1280 pdsch_ConfigDedicated_v1280;
    fill_PDSCH_ConfigDedicated_v1280(pdsch_ConfigDedicated_v1280);

    /* Creating 'pucch_SCell' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSCell_r10::pucch_SCell pucch_SCell;
    pucch_SCell.set_release(0);

    /* Creating 'crossCarrierSchedulingConfig_r13' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'schedulingCellInfo_r13' field of 'crossCarrierSchedulingConfig_r13' field of 'physicalConfigDedicatedSCell_r10' field */
    CrossCarrierSchedulingConfig_r13::schedulingCellInfo_r13 schedulingCellInfo_r13;
    /* Setting 'own_r13' alternative of 'schedulingCellInfo_r13' field of 'crossCarrierSchedulingConfig_r13' field of 'physicalConfigDedicatedSCell_r10' field... */

    /* Calling a fully-initializing constructor */
    CrossCarrierSchedulingConfig_r13::schedulingCellInfo_r13::own_r13 own_r13(TRUE);

    schedulingCellInfo_r13.set_own_r13(own_r13);

    /* Calling a fully-initializing constructor */
    CrossCarrierSchedulingConfig_r13 crossCarrierSchedulingConfig_r13(schedulingCellInfo_r13);

    /* Creating 'pdcch_ConfigSCell_r13' field of 'physicalConfigDedicatedSCell_r10' field */

    /* Calling a fully-initializing constructor */
    PDCCH_ConfigSCell_r13 pdcch_ConfigSCell_r13(skipMonitoringDCI_format0_1A_r13_true);

    /* Creating 'cqi_ReportConfig_v1310' field of 'physicalConfigDedicatedSCell_r10' field */
    CQI_ReportConfig_v1310 cqi_ReportConfig_v1310;
    fill_CQI_ReportConfig_v1310(cqi_ReportConfig_v1310);

    /* Creating 'pdsch_ConfigDedicated_v1310' field of 'physicalConfigDedicatedSCell_r10' field */
    PDSCH_ConfigDedicated_v1310 pdsch_ConfigDedicated_v1310;
    fill_PDSCH_ConfigDedicated_v1310(pdsch_ConfigDedicated_v1310);

    /* Creating 'soundingRS_UL_ConfigDedicated_v1310' field of 'physicalConfigDedicatedSCell_r10' field */
    SoundingRS_UL_ConfigDedicated_v1310 soundingRS_UL_ConfigDedicated_v1310;
    fill_SoundingRS_UL_ConfigDedicated_v1310(soundingRS_UL_ConfigDedicated_v1310);

    /* Creating 'soundingRS_UL_ConfigDedicatedUpPTsExt_r13' field of 'physicalConfigDedicatedSCell_r10' field */
    SoundingRS_UL_ConfigDedicatedUpPTsExt_r13 soundingRS_UL_ConfigDedicatedUpPTsExt_r13;
    fill_SoundingRS_UL_ConfigDedicatedUpPTsExt_r13(soundingRS_UL_ConfigDedicatedUpPTsExt_r13);

    /* Creating 'soundingRS_UL_ConfigDedicatedAperiodic_v1310' field of 'physicalConfigDedicatedSCell_r10' field */
    SoundingRS_UL_ConfigDedicatedAperiodic_v1310 soundingRS_UL_ConfigDedicatedAperiodic_v1310;
    fill_SoundingRS_UL_ConfigDedicatedAperiodic_v1310(soundingRS_UL_ConfigDedicatedAperiodic_v1310);

    /* Creating 'soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13' field of 'physicalConfigDedicatedSCell_r10' field */
    SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13 soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13;
    fill_SoundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13(soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13);

    /* Creating 'csi_RS_Config_v1310' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_Config_v1310 csi_RS_Config_v1310;
    fill_CSI_RS_Config_v1310(csi_RS_Config_v1310);

    /* Creating 'laa_SCellConfiguration_r13' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'laa_SCellSubframeConfig_r13' field of 'laa_SCellConfiguration_r13' field of 'physicalConfigDedicatedSCell_r10' field */
    static unsigned char laa_SCellSubframeConfig_r13_value[] = {
	0x00
    };
    OssBitString laa_SCellSubframeConfig_r13(8, laa_SCellSubframeConfig_r13_value);

    /* Calling a fully-initializing constructor */
    LAA_SCellConfiguration_r13 laa_SCellConfiguration_r13(subframeStartPosition_r13_s0, laa_SCellSubframeConfig_r13);

    /* Creating 'csi_RS_ConfigNZPToAddModListExt_r13' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_ConfigNZPToAddModListExt_r13 csi_RS_ConfigNZPToAddModListExt_r13;
    fill_CSI_RS_ConfigNZPToAddModListExt_r13(csi_RS_ConfigNZPToAddModListExt_r13);

    /* Creating 'csi_RS_ConfigNZPToReleaseListExt_r13' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_ConfigNZPToReleaseListExt_r13 csi_RS_ConfigNZPToReleaseListExt_r13;
    fill_CSI_RS_ConfigNZPToReleaseListExt_r13(csi_RS_ConfigNZPToReleaseListExt_r13);

    /* Creating 'cqi_ReportConfig_v1320' field of 'physicalConfigDedicatedSCell_r10' field */
    CQI_ReportConfig_v1320 cqi_ReportConfig_v1320;
    fill_CQI_ReportConfig_v1320(cqi_ReportConfig_v1320);

    /* Creating 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'crossCarrierSchedulingConfig_UL_r14' field of 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    LAA_SCellConfiguration_v1430::crossCarrierSchedulingConfig_UL_r14 crossCarrierSchedulingConfig_UL_r14;
    crossCarrierSchedulingConfig_UL_r14.set_release(0);

    /* Creating 'lbt_Config_r14' field of 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    LBT_Config_r14 lbt_Config_r14;
    lbt_Config_r14.set_maxEnergyDetectionThreshold_r14(-52);

    /* Creating 'pdcch_ConfigLAA_r14' field of 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'pdcch_CandidateReductions_Format0A_r14' field of 'pdcch_ConfigLAA_r14' field of 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field... */
    PDCCH_CandidateReductions_r13 pdcch_CandidateReductions_Format0A_r14;
    fill_PDCCH_CandidateReductions_r13(pdcch_CandidateReductions_Format0A_r14);

    /* Creating 'pdcch_CandidateReductions_Format4A_r14' field of 'pdcch_ConfigLAA_r14' field of 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field... */
    PDCCH_CandidateReductionsLAA_UL_r14 pdcch_CandidateReductions_Format4A_r14;
    fill_PDCCH_CandidateReductionsLAA_UL_r14(pdcch_CandidateReductions_Format4A_r14);

    /* Creating 'pdcch_CandidateReductions_Format0B_r14' field of 'pdcch_ConfigLAA_r14' field of 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field... */
    PDCCH_CandidateReductionsLAA_UL_r14 pdcch_CandidateReductions_Format0B_r14;
    fill_PDCCH_CandidateReductionsLAA_UL_r14(pdcch_CandidateReductions_Format0B_r14);

    /* Creating 'pdcch_CandidateReductions_Format4B_r14' field of 'pdcch_ConfigLAA_r14' field of 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field... */
    PDCCH_CandidateReductionsLAA_UL_r14 pdcch_CandidateReductions_Format4B_r14;
    fill_PDCCH_CandidateReductionsLAA_UL_r14(pdcch_CandidateReductions_Format4B_r14);

    /* Calling a fully-initializing constructor */
    PDCCH_ConfigLAA_r14 pdcch_ConfigLAA_r14(maxNumberOfSchedSubframes_Format0B_r14_sf2, maxNumberOfSchedSubframes_Format4B_r14_sf2, skipMonitoringDCI_Format0A_r14_true, skipMonitoringDCI_Format4A_r14_true, pdcch_CandidateReductions_Format0A_r14, pdcch_CandidateReductions_Format4A_r14, pdcch_CandidateReductions_Format0B_r14, pdcch_CandidateReductions_Format4B_r14);

    /* Creating 'soundingRS_UL_ConfigDedicatedAperiodic_v1430' field of 'laa_SCellConfiguration_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    SoundingRS_UL_ConfigDedicatedAperiodic_v1430 soundingRS_UL_ConfigDedicatedAperiodic_v1430;
    soundingRS_UL_ConfigDedicatedAperiodic_v1430.set_release(0);

    /* Calling a fully-initializing constructor */
    LAA_SCellConfiguration_v1430 laa_SCellConfiguration_v1430(crossCarrierSchedulingConfig_UL_r14, lbt_Config_r14, pdcch_ConfigLAA_r14, absenceOfAnyOtherTechnology_r14_true, soundingRS_UL_ConfigDedicatedAperiodic_v1430);

    /* Creating 'typeB_SRS_TPC_PDCCH_Config_r14' field of 'physicalConfigDedicatedSCell_r10' field */
    SRS_TPC_PDCCH_Config_r14 typeB_SRS_TPC_PDCCH_Config_r14;
    typeB_SRS_TPC_PDCCH_Config_r14.set_release(0);

    /* Creating 'uplinkPUSCH_LessPowerControlDedicated_v1430' field of 'physicalConfigDedicatedSCell_r10' field */

    /* Calling a fully-initializing constructor */
    UplinkPUSCH_LessPowerControlDedicated_v1430 uplinkPUSCH_LessPowerControlDedicated_v1430(7, 7, TRUE);

    /* Creating 'soundingRS_UL_PeriodicConfigDedicatedList_r14' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSCell_r10::soundingRS_UL_PeriodicConfigDedicatedList_r14 soundingRS_UL_PeriodicConfigDedicatedList_r14;
    {
	/* Adding component #2 */
	SoundingRS_UL_ConfigDedicated comp2;
	fill_SoundingRS_UL_ConfigDedicated(comp2);
	soundingRS_UL_PeriodicConfigDedicatedList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SoundingRS_UL_ConfigDedicated comp1;
	fill_SoundingRS_UL_ConfigDedicated(comp1);
	soundingRS_UL_PeriodicConfigDedicatedList_r14.prepend(comp1);
    }

    /* Creating 'soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSCell_r10::soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14 soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14;
    {
	/* Adding component #2 */
	SoundingRS_UL_ConfigDedicatedUpPTsExt_r13 comp2;
	fill_SoundingRS_UL_ConfigDedicatedUpPTsExt_r13(comp2);
	soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SoundingRS_UL_ConfigDedicatedUpPTsExt_r13 comp1;
	fill_SoundingRS_UL_ConfigDedicatedUpPTsExt_r13(comp1);
	soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14.prepend(comp1);
    }

    /* Creating 'soundingRS_UL_AperiodicConfigDedicatedList_r14' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSCell_r10::soundingRS_UL_AperiodicConfigDedicatedList_r14 soundingRS_UL_AperiodicConfigDedicatedList_r14;
    {
	/* Adding component #2 */
	SoundingRS_AperiodicSet_r14 comp2;
	fill_SoundingRS_AperiodicSet_r14(comp2);
	soundingRS_UL_AperiodicConfigDedicatedList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SoundingRS_AperiodicSet_r14 comp1;
	fill_SoundingRS_AperiodicSet_r14(comp1);
	soundingRS_UL_AperiodicConfigDedicatedList_r14.prepend(comp1);
    }

    /* Creating 'soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSCell_r10::soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14 soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14;
    {
	/* Adding component #2 */
	SoundingRS_AperiodicSetUpPTsExt_r14 comp2;
	fill_SoundingRS_AperiodicSetUpPTsExt_r14(comp2);
	soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SoundingRS_AperiodicSetUpPTsExt_r14 comp1;
	fill_SoundingRS_AperiodicSetUpPTsExt_r14(comp1);
	soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14.prepend(comp1);
    }

    /* Creating 'must_Config_r14' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSCell_r10::must_Config_r14 must_Config_r14;
    must_Config_r14.set_release(0);

    /* Creating 'pusch_ConfigDedicated_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'enable256QAM_r14' field of 'pusch_ConfigDedicated_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    Enable256QAM_r14 enable256QAM_r14;
    fill_Enable256QAM_r14(enable256QAM_r14);

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicatedSCell_v1430 pusch_ConfigDedicated_v1430(enable256QAM_r14);

    /* Creating 'csi_RS_Config_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_Config_v1430 csi_RS_Config_v1430;
    fill_CSI_RS_Config_v1430(csi_RS_Config_v1430);

    /* Creating 'csi_RS_ConfigZP_ApList_r14' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_ConfigZP_ApList_r14 csi_RS_ConfigZP_ApList_r14;
    fill_CSI_RS_ConfigZP_ApList_r14(csi_RS_ConfigZP_ApList_r14);

    /* Creating 'cqi_ReportConfig_v1430' field of 'physicalConfigDedicatedSCell_r10' field */
    CQI_ReportConfig_v1430 cqi_ReportConfig_v1430;
    fill_CQI_ReportConfig_v1430(cqi_ReportConfig_v1430);

    /* Creating 'pdsch_ConfigDedicatedSCell_v1430' field of 'physicalConfigDedicatedSCell_r10' field */

    /* Calling a fully-initializing constructor */
    PDSCH_ConfigDedicatedSCell_v1430 pdsch_ConfigDedicatedSCell_v1430(PDSCH_ConfigDedicatedSCell_v1430_tbsIndexAlt2_r14_b33);

    /* Creating 'csi_RS_Config_v1480' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_Config_v1480 csi_RS_Config_v1480;
    fill_CSI_RS_Config_v1480(csi_RS_Config_v1480);

    /* Creating 'physicalConfigDedicatedSTTI_r15' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSTTI_r15 physicalConfigDedicatedSTTI_r15;
    fill_PhysicalConfigDedicatedSTTI_r15(physicalConfigDedicatedSTTI_r15);

    /* Creating 'pdsch_ConfigDedicated_v1530' field of 'physicalConfigDedicatedSCell_r10' field */
    PDSCH_ConfigDedicated_v1530 pdsch_ConfigDedicated_v1530;
    fill_PDSCH_ConfigDedicated_v1530(pdsch_ConfigDedicated_v1530);

    /* Creating 'cqi_ReportConfig_v1530' field of 'physicalConfigDedicatedSCell_r10' field */
    CQI_ReportConfig_v1530 cqi_ReportConfig_v1530;
    fill_CQI_ReportConfig_v1530(cqi_ReportConfig_v1530);

    /* Creating 'cqi_ReportConfigSCell_r15' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'cqi_ReportPeriodicSCell_r15' field of 'cqi_ReportConfigSCell_r15' field of 'physicalConfigDedicatedSCell_r10' field */
    CQI_ReportPeriodicSCell_r15 cqi_ReportPeriodicSCell_r15;
    cqi_ReportPeriodicSCell_r15.set_release(0);

    /* Calling a fully-initializing constructor */
    CQI_ReportConfigSCell_r15 cqi_ReportConfigSCell_r15(cqi_ReportPeriodicSCell_r15, CQI_ReportConfigSCell_r15_altCQI_Table_1024QAM_r15_allSubframes);

    /* Creating 'cqi_ShortConfigSCell_r15' field of 'physicalConfigDedicatedSCell_r10' field */
    CQI_ShortConfigSCell_r15 cqi_ShortConfigSCell_r15;
    cqi_ShortConfigSCell_r15.set_release(0);

    /* Creating 'csi_RS_Config_v1530' field of 'physicalConfigDedicatedSCell_r10' field */
    CSI_RS_Config_v1530 csi_RS_Config_v1530;
    fill_CSI_RS_Config_v1530(csi_RS_Config_v1530);

    /* Creating 'uplinkPowerControlDedicatedSCell_v1530' field of 'physicalConfigDedicatedSCell_r10' field */
    UplinkPowerControlDedicated_v1530 uplinkPowerControlDedicatedSCell_v1530;
    fill_UplinkPowerControlDedicated_v1530(uplinkPowerControlDedicatedSCell_v1530);

    /* Creating 'laa_SCellConfiguration_v1530' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'aul_Config_r15' field of 'laa_SCellConfiguration_v1530' field of 'physicalConfigDedicatedSCell_r10' field */
    AUL_Config_r15 aul_Config_r15;
    aul_Config_r15.set_release(0);

    /* Creating 'pusch_ModeConfigLAA_r15' field of 'laa_SCellConfiguration_v1530' field of 'physicalConfigDedicatedSCell_r10' field */

    /* Calling a fully-initializing constructor */
    PUSCH_ModeConfigLAA_r15 pusch_ModeConfigLAA_r15(TRUE, TRUE, TRUE);

    /* Calling a fully-initializing constructor */
    LAA_SCellConfiguration_v1530 laa_SCellConfiguration_v1530(aul_Config_r15, pusch_ModeConfigLAA_r15);

    /* Creating 'pusch_ConfigDedicated_v1530' field of 'physicalConfigDedicatedSCell_r10' field */
    /* Creating 'uci_OnPUSCH_r15' field of 'pusch_ConfigDedicated_v1530' field of 'physicalConfigDedicatedSCell_r10' field */
    PUSCH_ConfigDedicatedScell_v1530::uci_OnPUSCH_r15 uci_OnPUSCH_r15;
    uci_OnPUSCH_r15.set_release(0);

    /* Calling a fully-initializing constructor */
    PUSCH_ConfigDedicatedScell_v1530 pusch_ConfigDedicated_v1530(uci_OnPUSCH_r15);

    /* Creating 'semiStaticCFI_Config_r15' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSCell_r10::semiStaticCFI_Config_r15 semiStaticCFI_Config_r15;
    semiStaticCFI_Config_r15.set_release(0);

    /* Creating 'blindPDSCH_Repetition_Config_r15' field of 'physicalConfigDedicatedSCell_r10' field */
    PhysicalConfigDedicatedSCell_r10::blindPDSCH_Repetition_Config_r15 blindPDSCH_Repetition_Config_r15;
    blindPDSCH_Repetition_Config_r15.set_release(0);

    /* Calling a fully-initializing constructor */
    PhysicalConfigDedicatedSCell_r10 physicalConfigDedicatedSCell_r10(nonUL_Configuration_r10, ul_Configuration_r10, csi_RS_ConfigNZPToReleaseList_r11, csi_RS_ConfigNZPToAddModList_r11, csi_RS_ConfigZPToReleaseList_r11, csi_RS_ConfigZPToAddModList_r11, epdcch_Config_r11, pdsch_ConfigDedicated_v1130, cqi_ReportConfig_v1130, pusch_ConfigDedicated_v1130, uplinkPowerControlDedicatedSCell_v1130, antennaInfo_v1250, eimta_MainConfigSCell_r12, cqi_ReportConfigSCell_v1250, uplinkPowerControlDedicatedSCell_v1250, csi_RS_Config_v1250, pdsch_ConfigDedicated_v1280, pucch_Cell_r13_true, pucch_SCell, crossCarrierSchedulingConfig_r13, pdcch_ConfigSCell_r13, cqi_ReportConfig_v1310, pdsch_ConfigDedicated_v1310, soundingRS_UL_ConfigDedicated_v1310, soundingRS_UL_ConfigDedicatedUpPTsExt_r13, soundingRS_UL_ConfigDedicatedAperiodic_v1310, soundingRS_UL_ConfigDedicatedAperiodicUpPTsExt_r13, csi_RS_Config_v1310, laa_SCellConfiguration_r13, csi_RS_ConfigNZPToAddModListExt_r13, csi_RS_ConfigNZPToReleaseListExt_r13, cqi_ReportConfig_v1320, laa_SCellConfiguration_v1430, typeB_SRS_TPC_PDCCH_Config_r14, uplinkPUSCH_LessPowerControlDedicated_v1430, soundingRS_UL_PeriodicConfigDedicatedList_r14, soundingRS_UL_PeriodicConfigDedicatedUpPTsExtList_r14, soundingRS_UL_AperiodicConfigDedicatedList_r14, soundingRS_UL_ConfigDedicatedApUpPTsExtList_r14, must_Config_r14, pusch_ConfigDedicated_v1430, csi_RS_Config_v1430, csi_RS_ConfigZP_ApList_r14, cqi_ReportConfig_v1430, TRUE, pdsch_ConfigDedicatedSCell_v1430, csi_RS_Config_v1480, physicalConfigDedicatedSTTI_r15, pdsch_ConfigDedicated_v1530, cqi_ReportConfig_v1530, cqi_ReportConfigSCell_r15, cqi_ShortConfigSCell_r15, csi_RS_Config_v1530, uplinkPowerControlDedicatedSCell_v1530, laa_SCellConfiguration_v1530, pusch_ConfigDedicated_v1530, semiStaticCFI_Config_r15, blindPDSCH_Repetition_Config_r15);

    value.set_physicalConfigDedicatedSCell_r10(physicalConfigDedicatedSCell_r10);

    /* Setting 'mac_MainConfigSCell_r11' field */

    /* Calling a fully-initializing constructor */
    MAC_MainConfigSCell_r11 mac_MainConfigSCell_r11(1);

    value.set_mac_MainConfigSCell_r11(mac_MainConfigSCell_r11);

    /* Setting 'naics_Info_r12' field */
    NAICS_AssistanceInfo_r12 naics_Info_r12;
    fill_NAICS_AssistanceInfo_r12(naics_Info_r12);
    value.set_naics_Info_r12(naics_Info_r12);

    /* Setting 'neighCellsCRS_InfoSCell_r13' field */
    NeighCellsCRS_Info_r13 neighCellsCRS_InfoSCell_r13;
    fill_NeighCellsCRS_Info_r13(neighCellsCRS_InfoSCell_r13);
    value.set_neighCellsCRS_InfoSCell_r13(neighCellsCRS_InfoSCell_r13);

    /* Setting 'physicalConfigDedicatedSCell_v1370' field */
    /* Creating 'pucch_SCell_v1370' field of 'physicalConfigDedicatedSCell_v1370' field */
    PhysicalConfigDedicatedSCell_v1370::pucch_SCell_v1370 pucch_SCell_v1370;
    pucch_SCell_v1370.set_release(0);

    /* Calling a fully-initializing constructor */
    PhysicalConfigDedicatedSCell_v1370 physicalConfigDedicatedSCell_v1370(pucch_SCell_v1370);

    value.set_physicalConfigDedicatedSCell_v1370(physicalConfigDedicatedSCell_v1370);

    value.set_crs_IntfMitigEnabled_r15(TRUE);
    /* Setting 'neighCellsCRS_Info_r15' field */
    NeighCellsCRS_Info_r15 neighCellsCRS_Info_r15;
    fill_NeighCellsCRS_Info_r15(neighCellsCRS_Info_r15);
    value.set_neighCellsCRS_Info_r15(neighCellsCRS_Info_r15);

    /* Setting 'sps_Config_v1530' field */
    SPS_Config_v1530 sps_Config_v1530;
    fill_SPS_Config_v1530(sps_Config_v1530);
    value.set_sps_Config_v1530(sps_Config_v1530);
}

static void fill_AntennaInfoDedicated_v10i0(AntennaInfoDedicated_v10i0 & value)
{
    value.set_maxLayersMIMO_r10(maxLayersMIMO_r10_twoLayers);
}

static void fill_SCellToAddMod_r10(SCellToAddMod_r10 & value)
{
    value.set_sCellIndex_r10(1);
    /* Setting 'cellIdentification_r10' field */

    /* Calling a fully-initializing constructor */
    SCellToAddMod_r10::cellIdentification_r10 cellIdentification_r10(0, 0);

    value.set_cellIdentification_r10(cellIdentification_r10);

    /* Setting 'radioResourceConfigCommonSCell_r10' field */
    RadioResourceConfigCommonSCell_r10 radioResourceConfigCommonSCell_r10;
    fill_RadioResourceConfigCommonSCell_r10(radioResourceConfigCommonSCell_r10);
    value.set_radioResourceConfigCommonSCell_r10(radioResourceConfigCommonSCell_r10);

    /* Setting 'radioResourceConfigDedicatedSCell_r10' field */
    RadioResourceConfigDedicatedSCell_r10 radioResourceConfigDedicatedSCell_r10;
    fill_RadioResourceConfigDedicatedSCell_r10(radioResourceConfigDedicatedSCell_r10);
    value.set_radioResourceConfigDedicatedSCell_r10(radioResourceConfigDedicatedSCell_r10);

    value.set_dl_CarrierFreq_v1090(65536);
    /* Setting 'antennaInfoDedicatedSCell_v10i0' field */
    AntennaInfoDedicated_v10i0 antennaInfoDedicatedSCell_v10i0;
    fill_AntennaInfoDedicated_v10i0(antennaInfoDedicatedSCell_v10i0);
    value.set_antennaInfoDedicatedSCell_v10i0(antennaInfoDedicatedSCell_v10i0);

    value.set_srs_SwitchFromServCellIndex_r14(0);
    value.set_sCellState_r15(SCellToAddMod_r10_sCellState_r15_activated);
}

static void fill_SCellToAddModList_r10(SCellToAddModList_r10 & value)
{
    {
	/* Adding component #2 */
	SCellToAddMod_r10 comp2;
	fill_SCellToAddMod_r10(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SCellToAddMod_r10 comp1;
	fill_SCellToAddMod_r10(comp1);
	value.prepend(comp1);
    }
}

static void fill_DRB_ToAddModSCG_r12(DRB_ToAddModSCG_r12 & value)
{
    value.set_drb_Identity_r12(1);
    /* Setting 'drb_Type_r12' field */
    DRB_ToAddModSCG_r12::drb_Type_r12 drb_Type_r12;
    drb_Type_r12.set_split_r12(0);
    value.set_drb_Type_r12(drb_Type_r12);

    /* Setting 'rlc_ConfigSCG_r12' field */
    RLC_Config rlc_ConfigSCG_r12;
    fill_RLC_Config(rlc_ConfigSCG_r12);
    value.set_rlc_ConfigSCG_r12(rlc_ConfigSCG_r12);

    /* Setting 'rlc_Config_v1250' field */
    RLC_Config_v1250 rlc_Config_v1250;
    fill_RLC_Config_v1250(rlc_Config_v1250);
    value.set_rlc_Config_v1250(rlc_Config_v1250);

    value.set_logicalChannelIdentitySCG_r12(3);
    /* Setting 'logicalChannelConfigSCG_r12' field */
    LogicalChannelConfig logicalChannelConfigSCG_r12;
    fill_LogicalChannelConfig(logicalChannelConfigSCG_r12);
    value.set_logicalChannelConfigSCG_r12(logicalChannelConfigSCG_r12);

    /* Setting 'rlc_Config_v1430' field */
    RLC_Config_v1430 rlc_Config_v1430;
    fill_RLC_Config_v1430(rlc_Config_v1430);
    value.set_rlc_Config_v1430(rlc_Config_v1430);

    value.set_logicalChannelIdentitySCG_r15(32);
    /* Setting 'rlc_Config_v1530' field */
    RLC_Config_v1530 rlc_Config_v1530;
    rlc_Config_v1530.set_release(0);
    value.set_rlc_Config_v1530(rlc_Config_v1530);

    /* Setting 'rlc_BearerConfigDupl_r15' field */
    RLC_BearerConfig_r15 rlc_BearerConfigDupl_r15;
    fill_RLC_BearerConfig_r15(rlc_BearerConfigDupl_r15);
    value.set_rlc_BearerConfigDupl_r15(rlc_BearerConfigDupl_r15);
}

static void fill_SCellToAddModExt_r13(SCellToAddModExt_r13 & value)
{
    value.set_sCellIndex_r13(1);
    /* Setting 'cellIdentification_r13' field */

    /* Calling a fully-initializing constructor */
    SCellToAddModExt_r13::cellIdentification_r13 cellIdentification_r13(0, 0);

    value.set_cellIdentification_r13(cellIdentification_r13);

    /* Setting 'radioResourceConfigCommonSCell_r13' field */
    RadioResourceConfigCommonSCell_r10 radioResourceConfigCommonSCell_r13;
    fill_RadioResourceConfigCommonSCell_r10(radioResourceConfigCommonSCell_r13);
    value.set_radioResourceConfigCommonSCell_r13(radioResourceConfigCommonSCell_r13);

    /* Setting 'radioResourceConfigDedicatedSCell_r13' field */
    RadioResourceConfigDedicatedSCell_r10 radioResourceConfigDedicatedSCell_r13;
    fill_RadioResourceConfigDedicatedSCell_r10(radioResourceConfigDedicatedSCell_r13);
    value.set_radioResourceConfigDedicatedSCell_r13(radioResourceConfigDedicatedSCell_r13);

    /* Setting 'antennaInfoDedicatedSCell_r13' field */
    AntennaInfoDedicated_v10i0 antennaInfoDedicatedSCell_r13;
    fill_AntennaInfoDedicated_v10i0(antennaInfoDedicatedSCell_r13);
    value.set_antennaInfoDedicatedSCell_r13(antennaInfoDedicatedSCell_r13);
}

static void fill_SCellToAddModListExt_r13(SCellToAddModListExt_r13 & value)
{
    {
	/* Adding component #2 */
	SCellToAddModExt_r13 comp2;
	fill_SCellToAddModExt_r13(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SCellToAddModExt_r13 comp1;
	fill_SCellToAddModExt_r13(comp1);
	value.prepend(comp1);
    }
}

static void fill_SCellToAddModExt_v1370(SCellToAddModExt_v1370 & value)
{
    /* Setting 'radioResourceConfigCommonSCell_v1370' field */
    /* Creating 'ul_Configuration_v10l0' field of 'radioResourceConfigCommonSCell_v1370' field */

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_v10l0::ul_Configuration_v10l0 ul_Configuration_v10l0(33);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_v10l0 radioResourceConfigCommonSCell_v1370(ul_Configuration_v10l0);

    value.set_radioResourceConfigCommonSCell_v1370(radioResourceConfigCommonSCell_v1370);
}

static void fill_SCellToReleaseListExt_r13(SCellToReleaseListExt_r13 & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_SCellGroupToAddMod_r15(SCellGroupToAddMod_r15 & value)
{
    value.set_sCellGroupIndex_r15(1);
    /* Setting 'sCellConfigCommon_r15' field */
    /* Creating 'radioResourceConfigCommonSCell_r15' field of 'sCellConfigCommon_r15' field */
    RadioResourceConfigCommonSCell_r10 radioResourceConfigCommonSCell_r15;
    fill_RadioResourceConfigCommonSCell_r10(radioResourceConfigCommonSCell_r15);

    /* Creating 'radioResourceConfigDedicatedSCell_r15' field of 'sCellConfigCommon_r15' field */
    RadioResourceConfigDedicatedSCell_r10 radioResourceConfigDedicatedSCell_r15;
    fill_RadioResourceConfigDedicatedSCell_r10(radioResourceConfigDedicatedSCell_r15);

    /* Creating 'antennaInfoDedicatedSCell_r15' field of 'sCellConfigCommon_r15' field */
    AntennaInfoDedicated_v10i0 antennaInfoDedicatedSCell_r15;
    fill_AntennaInfoDedicated_v10i0(antennaInfoDedicatedSCell_r15);

    /* Calling a fully-initializing constructor */
    SCellConfigCommon_r15 sCellConfigCommon_r15(radioResourceConfigCommonSCell_r15, radioResourceConfigDedicatedSCell_r15, antennaInfoDedicatedSCell_r15);

    value.set_sCellConfigCommon_r15(sCellConfigCommon_r15);

    /* Setting 'sCellToReleaseList_r15' field */
    SCellToReleaseListExt_r13 sCellToReleaseList_r15;
    fill_SCellToReleaseListExt_r13(sCellToReleaseList_r15);
    value.set_sCellToReleaseList_r15(sCellToReleaseList_r15);

    /* Setting 'sCellToAddModList_r15' field */
    SCellToAddModListExt_r13 sCellToAddModList_r15;
    fill_SCellToAddModListExt_r13(sCellToAddModList_r15);
    value.set_sCellToAddModList_r15(sCellToAddModList_r15);
}

static void fill_SCG_ConfigPartSCG_r12(SCG_ConfigPartSCG_r12 & value)
{
    /* Setting 'radioResourceConfigDedicatedSCG_r12' field */
    /* Creating 'drb_ToAddModListSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    DRB_ToAddModListSCG_r12 drb_ToAddModListSCG_r12;
    {
	/* Adding component #2 */
	DRB_ToAddModSCG_r12 comp2;
	fill_DRB_ToAddModSCG_r12(comp2);
	drb_ToAddModListSCG_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DRB_ToAddModSCG_r12 comp1;
	fill_DRB_ToAddModSCG_r12(comp1);
	drb_ToAddModListSCG_r12.prepend(comp1);
    }

    /* Creating 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    /* Creating 'ul_SCH_Config' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::ul_SCH_Config ul_SCH_Config;
    fill_data_15(ul_SCH_Config);

    /* Creating 'drx_Config' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    DRX_Config drx_Config;
    fill_DRX_Config(drx_Config);

    /* Creating 'phr_Config' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::phr_Config phr_Config;
    fill_data_14(phr_Config);

    /* Creating 'mac_MainConfig_v1020' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::mac_MainConfig_v1020 mac_MainConfig_v1020;
    fill_data_13(mac_MainConfig_v1020);

    /* Creating 'stag_ToReleaseList_r11' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    STAG_ToReleaseList_r11 stag_ToReleaseList_r11;
    stag_ToReleaseList_r11.prepend(1);
    stag_ToReleaseList_r11.prepend(1);

    /* Creating 'stag_ToAddModList_r11' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    STAG_ToAddModList_r11 stag_ToAddModList_r11;
    fill_STAG_ToAddModList_r11(stag_ToAddModList_r11);

    /* Creating 'drx_Config_v1130' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    DRX_Config_v1130 drx_Config_v1130;
    fill_DRX_Config_v1130(drx_Config_v1130);

    /* Creating 'dualConnectivityPHR' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::dualConnectivityPHR dualConnectivityPHR;
    fill_data_12(dualConnectivityPHR);

    /* Creating 'logicalChannelSR_Config_r12' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::logicalChannelSR_Config_r12 logicalChannelSR_Config_r12;
    fill_data_11(logicalChannelSR_Config_r12);

    /* Creating 'drx_Config_v1310' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    DRX_Config_v1310 drx_Config_v1310;
    fill_DRX_Config_v1310(drx_Config_v1310);

    /* Creating 'eDRX_Config_CycleStartOffset_r13' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::eDRX_Config_CycleStartOffset_r13 eDRX_Config_CycleStartOffset_r13;
    fill_data_10(eDRX_Config_CycleStartOffset_r13);

    /* Creating 'drx_Config_r13' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::drx_Config_r13 drx_Config_r13;
    fill_data_9(drx_Config_r13);

    /* Creating 'skipUplinkTx_r14' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::skipUplinkTx_r14 skipUplinkTx_r14;
    fill_data_8(skipUplinkTx_r14);

    /* Creating 'dataInactivityTimerConfig_r14' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::dataInactivityTimerConfig_r14 dataInactivityTimerConfig_r14;
    fill_data_7(dataInactivityTimerConfig_r14);

    /* Creating 'shortTTI_AndSPT_r15' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::shortTTI_AndSPT_r15 shortTTI_AndSPT_r15;
    fill_data_6(shortTTI_AndSPT_r15);

    /* Creating 'dormantStateTimers_r15' field of 'mac_MainConfigSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    MAC_MainConfig::dormantStateTimers_r15 dormantStateTimers_r15;
    fill_data_5(dormantStateTimers_r15);

    /* Calling a fully-initializing constructor */
    MAC_MainConfig mac_MainConfigSCG_r12(ul_SCH_Config, drx_Config, TimeAlignmentTimer_sf500, phr_Config, 0, mac_MainConfig_v1020, stag_ToReleaseList_r11, stag_ToAddModList_r11, drx_Config_v1130, TRUE, dualConnectivityPHR, logicalChannelSR_Config_r12, drx_Config_v1310, TRUE, eDRX_Config_CycleStartOffset_r13, drx_Config_r13, skipUplinkTx_r14, dataInactivityTimerConfig_r14, MAC_MainConfig_rai_Activation_r14_true, shortTTI_AndSPT_r15, TRUE, dormantStateTimers_r15);

    /* Creating 'rlf_TimersAndConstantsSCG_r12' field of 'radioResourceConfigDedicatedSCG_r12' field */
    RLF_TimersAndConstantsSCG_r12 rlf_TimersAndConstantsSCG_r12;
    rlf_TimersAndConstantsSCG_r12.set_release(0);

    /* Creating 'drb_ToAddModListSCG_r15' field of 'radioResourceConfigDedicatedSCG_r12' field */
    DRB_ToAddModListSCG_r15 drb_ToAddModListSCG_r15;
    {
	/* Adding component #2 */
	DRB_ToAddModSCG_r12 comp2;
	fill_DRB_ToAddModSCG_r12(comp2);
	drb_ToAddModListSCG_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DRB_ToAddModSCG_r12 comp1;
	fill_DRB_ToAddModSCG_r12(comp1);
	drb_ToAddModListSCG_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RadioResourceConfigDedicatedSCG_r12 radioResourceConfigDedicatedSCG_r12(drb_ToAddModListSCG_r12, mac_MainConfigSCG_r12, rlf_TimersAndConstantsSCG_r12, drb_ToAddModListSCG_r15);

    value.set_radioResourceConfigDedicatedSCG_r12(radioResourceConfigDedicatedSCG_r12);

    /* Setting 'sCellToReleaseListSCG_r12' field */
    SCellToReleaseList_r10 sCellToReleaseListSCG_r12;
    sCellToReleaseListSCG_r12.prepend(1);
    sCellToReleaseListSCG_r12.prepend(1);
    value.set_sCellToReleaseListSCG_r12(sCellToReleaseListSCG_r12);

    /* Setting 'pSCellToAddMod_r12' field */
    /* Creating 'cellIdentification_r12' field of 'pSCellToAddMod_r12' field */

    /* Calling a fully-initializing constructor */
    PSCellToAddMod_r12::cellIdentification_r12 cellIdentification_r12(0, 0);

    /* Creating 'radioResourceConfigCommonPSCell_r12' field of 'pSCellToAddMod_r12' field */
    /* Creating 'basicFields_r12' field of 'radioResourceConfigCommonPSCell_r12' field of 'pSCellToAddMod_r12' field */
    RadioResourceConfigCommonSCell_r10 basicFields_r12;
    fill_RadioResourceConfigCommonSCell_r10(basicFields_r12);

    /* Creating 'pucch_ConfigCommon_r12' field of 'radioResourceConfigCommonPSCell_r12' field of 'pSCellToAddMod_r12' field */
    PUCCH_ConfigCommon pucch_ConfigCommon_r12;
    fill_PUCCH_ConfigCommon(pucch_ConfigCommon_r12);

    /* Creating 'rach_ConfigCommon_r12' field of 'radioResourceConfigCommonPSCell_r12' field of 'pSCellToAddMod_r12' field */
    RACH_ConfigCommon rach_ConfigCommon_r12;
    fill_RACH_ConfigCommon(rach_ConfigCommon_r12);

    /* Creating 'uplinkPowerControlCommonPSCell_r12' field of 'radioResourceConfigCommonPSCell_r12' field of 'pSCellToAddMod_r12' field */
    /* Creating 'deltaFList_PUCCH_r12' field of 'uplinkPowerControlCommonPSCell_r12' field of 'radioResourceConfigCommonPSCell_r12' field of 'pSCellToAddMod_r12' field... */
    DeltaFList_PUCCH deltaFList_PUCCH_r12;
    fill_DeltaFList_PUCCH(deltaFList_PUCCH_r12);

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommonPSCell_r12 uplinkPowerControlCommonPSCell_r12(UplinkPowerControlCommonPSCell_r12_deltaF_PUCCH_Format3_r12_deltaF_1, UplinkPowerControlCommonPSCell_r12_deltaF_PUCCH_Format1bCS_r12_deltaF1, -96, deltaFList_PUCCH_r12);

    /* Creating 'uplinkPowerControlCommonPSCell_v1310' field of 'radioResourceConfigCommonPSCell_r12' field of 'pSCellToAddMod_r12' field */

    /* Calling a fully-initializing constructor */
    UplinkPowerControlCommon_v1310 uplinkPowerControlCommonPSCell_v1310(UplinkPowerControlCommon_v1310_deltaF_PUCCH_Format4_r13_deltaF16, UplinkPowerControlCommon_v1310_deltaF_PUCCH_Format5_13_deltaF13);

    /* Creating 'uplinkPowerControlCommonPSCell_v1530' field of 'radioResourceConfigCommonPSCell_r12' field of 'pSCellToAddMod_r12' field */
    UplinkPowerControlCommon_v1530 uplinkPowerControlCommonPSCell_v1530;
    fill_UplinkPowerControlCommon_v1530(uplinkPowerControlCommonPSCell_v1530);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonPSCell_r12 radioResourceConfigCommonPSCell_r12(basicFields_r12, pucch_ConfigCommon_r12, rach_ConfigCommon_r12, uplinkPowerControlCommonPSCell_r12, uplinkPowerControlCommonPSCell_v1310, uplinkPowerControlCommonPSCell_v1530);

    /* Creating 'radioResourceConfigDedicatedPSCell_r12' field of 'pSCellToAddMod_r12' field */
    /* Creating 'physicalConfigDedicatedPSCell_r12' field of 'radioResourceConfigDedicatedPSCell_r12' field of 'pSCellToAddMod_r12' field */
    PhysicalConfigDedicated physicalConfigDedicatedPSCell_r12;
    fill_PhysicalConfigDedicated(physicalConfigDedicatedPSCell_r12);

    /* Creating 'sps_Config_r12' field of 'radioResourceConfigDedicatedPSCell_r12' field of 'pSCellToAddMod_r12' field */
    SPS_Config sps_Config_r12;
    fill_SPS_Config(sps_Config_r12);

    /* Creating 'naics_Info_r12' field of 'radioResourceConfigDedicatedPSCell_r12' field of 'pSCellToAddMod_r12' field */
    NAICS_AssistanceInfo_r12 naics_Info_r12;
    fill_NAICS_AssistanceInfo_r12(naics_Info_r12);

    /* Creating 'neighCellsCRS_InfoPSCell_r13' field of 'radioResourceConfigDedicatedPSCell_r12' field of 'pSCellToAddMod_r12' field */
    NeighCellsCRS_Info_r13 neighCellsCRS_InfoPSCell_r13;
    fill_NeighCellsCRS_Info_r13(neighCellsCRS_InfoPSCell_r13);

    /* Creating 'sps_Config_v1430' field of 'radioResourceConfigDedicatedPSCell_r12' field of 'pSCellToAddMod_r12' field */
    SPS_Config_v1430 sps_Config_v1430;
    fill_SPS_Config_v1430(sps_Config_v1430);

    /* Creating 'sps_Config_v1530' field of 'radioResourceConfigDedicatedPSCell_r12' field of 'pSCellToAddMod_r12' field */
    SPS_Config_v1530 sps_Config_v1530;
    fill_SPS_Config_v1530(sps_Config_v1530);

    /* Creating 'neighCellsCRS_Info_r15' field of 'radioResourceConfigDedicatedPSCell_r12' field of 'pSCellToAddMod_r12' field */
    NeighCellsCRS_Info_r15 neighCellsCRS_Info_r15;
    fill_NeighCellsCRS_Info_r15(neighCellsCRS_Info_r15);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigDedicatedPSCell_r12 radioResourceConfigDedicatedPSCell_r12(physicalConfigDedicatedPSCell_r12, sps_Config_r12, naics_Info_r12, neighCellsCRS_InfoPSCell_r13, sps_Config_v1430, sps_Config_v1530, TRUE, neighCellsCRS_Info_r15);

    /* Creating 'antennaInfoDedicatedPSCell_v1280' field of 'pSCellToAddMod_r12' field */
    AntennaInfoDedicated_v10i0 antennaInfoDedicatedPSCell_v1280;
    fill_AntennaInfoDedicated_v10i0(antennaInfoDedicatedPSCell_v1280);

    /* Creating 'radioResourceConfigDedicatedPSCell_v1370' field of 'pSCellToAddMod_r12' field */
    /* Creating 'physicalConfigDedicatedPSCell_v1370' field of 'radioResourceConfigDedicatedPSCell_v1370' field of 'pSCellToAddMod_r12' field */
    /* Creating 'pucch_ConfigDedicated_v1370' field of 'physicalConfigDedicatedPSCell_v1370' field of 'radioResourceConfigDedicatedPSCell_v1370' field of 'pSCellToAddMod_r12' field... */
    /* Creating 'pucch_Format_v1370' field of 'pucch_ConfigDedicated_v1370' field of 'physicalConfigDedicatedPSCell_v1370' field of 'radioResourceConfigDedicatedPSCell_v1370' field... */
    PUCCH_ConfigDedicated_v1370::pucch_Format_v1370 pucch_Format_v1370;
    pucch_Format_v1370.set_release(0);

    /* Calling a fully-initializing constructor */
    PUCCH_ConfigDedicated_v1370 pucch_ConfigDedicated_v1370(pucch_Format_v1370);

    /* Calling a fully-initializing constructor */
    PhysicalConfigDedicated_v1370 physicalConfigDedicatedPSCell_v1370(pucch_ConfigDedicated_v1370);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigDedicatedPSCell_v1370 radioResourceConfigDedicatedPSCell_v1370(physicalConfigDedicatedPSCell_v1370);

    /* Calling a fully-initializing constructor */
    PSCellToAddMod_r12 pSCellToAddMod_r12(1, cellIdentification_r12, radioResourceConfigCommonPSCell_r12, radioResourceConfigDedicatedPSCell_r12, antennaInfoDedicatedPSCell_v1280, 1, radioResourceConfigDedicatedPSCell_v1370);

    value.set_pSCellToAddMod_r12(pSCellToAddMod_r12);

    /* Setting 'sCellToAddModListSCG_r12' field */
    SCellToAddModList_r10 sCellToAddModListSCG_r12;
    fill_SCellToAddModList_r10(sCellToAddModListSCG_r12);
    value.set_sCellToAddModListSCG_r12(sCellToAddModListSCG_r12);

    /* Setting 'mobilityControlInfoSCG_r12' field */
    /* Creating 'ue_IdentitySCG_r12' field of 'mobilityControlInfoSCG_r12' field */
    static unsigned char ue_IdentitySCG_r12_value[] = {
	0x00, 0x00
    };
    OssBitString ue_IdentitySCG_r12(16, ue_IdentitySCG_r12_value);

    /* Creating 'rach_ConfigDedicated_r12' field of 'mobilityControlInfoSCG_r12' field */

    /* Calling a fully-initializing constructor */
    RACH_ConfigDedicated rach_ConfigDedicated_r12(0, 0);

    /* Creating 'rach_SkipSCG_r14' field of 'mobilityControlInfoSCG_r12' field */
    /* Creating 'targetTA_r14' field of 'rach_SkipSCG_r14' field of 'mobilityControlInfoSCG_r12' field */
    RACH_Skip_r14::targetTA_r14 targetTA_r14;
    targetTA_r14.set_ta0_r14(0);

    /* Creating 'ul_ConfigInfo_r14' field of 'rach_SkipSCG_r14' field of 'mobilityControlInfoSCG_r12' field */
    /* Creating 'ul_Grant_r14' field of 'ul_ConfigInfo_r14' field of 'rach_SkipSCG_r14' field of 'mobilityControlInfoSCG_r12' field... */
    static unsigned char ul_Grant_r14_value[] = {
	0x00, 0x00
    };
    OssBitString ul_Grant_r14(16, ul_Grant_r14_value);

    /* Calling a fully-initializing constructor */
    RACH_Skip_r14::ul_ConfigInfo_r14 ul_ConfigInfo_r14(1, ul_SchedInterval_r14_sf2, 0, ul_Grant_r14);

    /* Calling a fully-initializing constructor */
    RACH_Skip_r14 rach_SkipSCG_r14(targetTA_r14, ul_ConfigInfo_r14);

    /* Calling a fully-initializing constructor */
    MobilityControlInfoSCG_r12 mobilityControlInfoSCG_r12(t307_r12_ms50, ue_IdentitySCG_r12, rach_ConfigDedicated_r12, eea0, makeBeforeBreakSCG_r14_true, rach_SkipSCG_r14);

    value.set_mobilityControlInfoSCG_r12(mobilityControlInfoSCG_r12);

    /* Setting 'sCellToReleaseListSCG_Ext_r13' field */
    SCellToReleaseListExt_r13 sCellToReleaseListSCG_Ext_r13;
    sCellToReleaseListSCG_Ext_r13.prepend(1);
    sCellToReleaseListSCG_Ext_r13.prepend(1);
    value.set_sCellToReleaseListSCG_Ext_r13(sCellToReleaseListSCG_Ext_r13);

    /* Setting 'sCellToAddModListSCG_Ext_r13' field */
    SCellToAddModListExt_r13 sCellToAddModListSCG_Ext_r13;
    fill_SCellToAddModListExt_r13(sCellToAddModListSCG_Ext_r13);
    value.set_sCellToAddModListSCG_Ext_r13(sCellToAddModListSCG_Ext_r13);

    /* Setting 'sCellToAddModListSCG_Ext_v1370' field */
    SCellToAddModListExt_v1370 sCellToAddModListSCG_Ext_v1370;
    {
	/* Adding component #2 */
	SCellToAddModExt_v1370 comp2;
	fill_SCellToAddModExt_v1370(comp2);
	sCellToAddModListSCG_Ext_v1370.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SCellToAddModExt_v1370 comp1;
	fill_SCellToAddModExt_v1370(comp1);
	sCellToAddModListSCG_Ext_v1370.prepend(comp1);
    }
    value.set_sCellToAddModListSCG_Ext_v1370(sCellToAddModListSCG_Ext_v1370);

    /* Setting 'pSCellToAddMod_v1440' field */
    /* Creating 'radioResourceConfigCommonPSCell_r14' field of 'pSCellToAddMod_v1440' field */
    /* Creating 'basicFields_v1440' field of 'radioResourceConfigCommonPSCell_r14' field of 'pSCellToAddMod_v1440' field */
    /* Creating 'ul_Configuration_v1440' field of 'basicFields_v1440' field of 'radioResourceConfigCommonPSCell_r14' field of 'pSCellToAddMod_v1440' field... */
    /* Creating 'ul_FreqInfo_v1440' field of 'ul_Configuration_v1440' field of 'basicFields_v1440' field of 'radioResourceConfigCommonPSCell_r14' field... */

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_v1440::ul_Configuration_v1440::ul_FreqInfo_v1440 ul_FreqInfo_v1440(33);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_v1440::ul_Configuration_v1440 ul_Configuration_v1440(ul_FreqInfo_v1440);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonSCell_v1440 basicFields_v1440(ul_Configuration_v1440);

    /* Calling a fully-initializing constructor */
    RadioResourceConfigCommonPSCell_v1440 radioResourceConfigCommonPSCell_r14(basicFields_v1440);

    /* Calling a fully-initializing constructor */
    PSCellToAddMod_v1440 pSCellToAddMod_v1440(radioResourceConfigCommonPSCell_r14);

    value.set_pSCellToAddMod_v1440(pSCellToAddMod_v1440);

    /* Setting 'sCellGroupToReleaseListSCG_r15' field */
    SCellGroupToReleaseList_r15 sCellGroupToReleaseListSCG_r15;
    sCellGroupToReleaseListSCG_r15.prepend(1);
    sCellGroupToReleaseListSCG_r15.prepend(1);
    value.set_sCellGroupToReleaseListSCG_r15(sCellGroupToReleaseListSCG_r15);

    /* Setting 'sCellGroupToAddModListSCG_r15' field */
    SCellGroupToAddModList_r15 sCellGroupToAddModListSCG_r15;
    {
	/* Adding component #2 */
	SCellGroupToAddMod_r15 comp2;
	fill_SCellGroupToAddMod_r15(comp2);
	sCellGroupToAddModListSCG_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SCellGroupToAddMod_r15 comp1;
	fill_SCellGroupToAddMod_r15(comp1);
	sCellGroupToAddModListSCG_r15.prepend(comp1);
    }
    value.set_sCellGroupToAddModListSCG_r15(sCellGroupToAddModListSCG_r15);
}

static void fill_CandidateCellInfo_r10(CandidateCellInfo_r10 & value)
{
    value.set_physCellId_r10(0);
    value.set_dl_CarrierFreq_r10(0);
    value.set_rsrpResult_r10(0);
    value.set_rsrqResult_r10(0);
    value.set_dl_CarrierFreq_v1090(65536);
    value.set_rsrqResult_v1250(-30);
    value.set_rs_sinr_Result_r13(0);
}

static void fill_MeasResultNR_r15(MeasResultNR_r15 & value)
{
    value.set_rsrpResult_r15(0);
    value.set_rsrqResult_r15(0);
    value.set_rs_sinr_Result_r15(0);
}

static void fill_MeasResultSSB_Index_r15(MeasResultSSB_Index_r15 & value)
{
    value.set_ssb_Index_r15(0);
    /* Setting 'measResultSSB_Index_r15' field */
    MeasResultNR_r15 measResultSSB_Index_r15;
    fill_MeasResultNR_r15(measResultSSB_Index_r15);
    value.set_measResultSSB_Index_r15(measResultSSB_Index_r15);
}

static void fill_PLMN_IdentityInfoNR_r15(PLMN_IdentityInfoNR_r15 & value)
{
    /* Setting 'plmn_IdentityList_r15' field */
    PLMN_IdentityListNR_r15 plmn_IdentityList_r15;
    {
	/* Adding component #2 */
	PLMN_Identity comp2;
	fill_PLMN_Identity(comp2);
	plmn_IdentityList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_Identity comp1;
	fill_PLMN_Identity(comp1);
	plmn_IdentityList_r15.prepend(comp1);
    }
    value.set_plmn_IdentityList_r15(plmn_IdentityList_r15);

    /* Setting 'trackingAreaCode_r15' field */
    static unsigned char trackingAreaCode_r15_value[] = {
	0x00, 0x00, 0x00
    };
    OssBitString trackingAreaCode_r15(24, trackingAreaCode_r15_value);
    value.set_trackingAreaCode_r15(trackingAreaCode_r15);

    value.set_ran_AreaCode_r15(0);
    /* Setting 'cellIdentity_r15' field */
    static unsigned char cellIdentity_r15_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity_r15(36, cellIdentity_r15_value);
    value.set_cellIdentity_r15(cellIdentity_r15);
}

static void fill_MeasResultCellNR_r15(MeasResultCellNR_r15 & value)
{
    value.set_pci_r15(0);
    /* Setting 'measResultCell_r15' field */
    MeasResultNR_r15 measResultCell_r15;
    fill_MeasResultNR_r15(measResultCell_r15);
    value.set_measResultCell_r15(measResultCell_r15);

    /* Setting 'measResultRS_IndexList_r15' field */
    MeasResultSSB_IndexList_r15 measResultRS_IndexList_r15;
    {
	/* Adding component #2 */
	MeasResultSSB_Index_r15 comp2;
	fill_MeasResultSSB_Index_r15(comp2);
	measResultRS_IndexList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultSSB_Index_r15 comp1;
	fill_MeasResultSSB_Index_r15(comp1);
	measResultRS_IndexList_r15.prepend(comp1);
    }
    value.set_measResultRS_IndexList_r15(measResultRS_IndexList_r15);

    /* Setting 'cgi_Info_r15' field */
    /* Creating 'plmn_IdentityInfoList_r15' field of 'cgi_Info_r15' field */
    PLMN_IdentityInfoListNR_r15 plmn_IdentityInfoList_r15;
    {
	/* Adding component #2 */
	PLMN_IdentityInfoNR_r15 comp2;
	fill_PLMN_IdentityInfoNR_r15(comp2);
	plmn_IdentityInfoList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_IdentityInfoNR_r15 comp1;
	fill_PLMN_IdentityInfoNR_r15(comp1);
	plmn_IdentityInfoList_r15.prepend(comp1);
    }

    /* Creating 'frequencyBandList_15' field of 'cgi_Info_r15' field */
    MultiFrequencyBandListNR_r15 frequencyBandList_15;
    frequencyBandList_15.prepend(1);
    frequencyBandList_15.prepend(1);

    /* Creating 'noSIB1_r15' field of 'cgi_Info_r15' field */

    /* Calling a fully-initializing constructor */
    CGI_InfoNR_r15::noSIB1_r15 noSIB1_r15(0, 0);

    /* Calling a fully-initializing constructor */
    CGI_InfoNR_r15 cgi_Info_r15(plmn_IdentityInfoList_r15, frequencyBandList_15, noSIB1_r15);

    value.set_cgi_Info_r15(cgi_Info_r15);
}

static void fill_MeasResultServFreqNR_r15(MeasResultServFreqNR_r15 & value)
{
    value.set_carrierFreq_r15(0);
    /* Setting 'measResultSCell_r15' field */
    MeasResultCellNR_r15 measResultSCell_r15;
    fill_MeasResultCellNR_r15(measResultSCell_r15);
    value.set_measResultSCell_r15(measResultSCell_r15);

    /* Setting 'measResultBestNeighCell_r15' field */
    MeasResultCellNR_r15 measResultBestNeighCell_r15;
    fill_MeasResultCellNR_r15(measResultBestNeighCell_r15);
    value.set_measResultBestNeighCell_r15(measResultBestNeighCell_r15);
}

static void fill_AdditionalReestabInfo(AdditionalReestabInfo & value)
{
    /* Setting 'cellIdentity' field */
    static unsigned char cellIdentity_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity(28, cellIdentity_value);
    value.set_cellIdentity(cellIdentity);

    /* Setting 'key_eNodeB_Star' field */
    static unsigned char key_eNodeB_Star_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssBitString key_eNodeB_Star(256, key_eNodeB_Star_value);
    value.set_key_eNodeB_Star(key_eNodeB_Star);

    /* Setting 'shortMAC_I' field */
    static unsigned char shortMAC_I_value[] = {
	0x00, 0x00
    };
    OssBitString shortMAC_I(16, shortMAC_I_value);
    value.set_shortMAC_I(shortMAC_I);
}

static void fill_AdditionalReestabInfoList(AdditionalReestabInfoList & value)
{
    {
	/* Adding component #2 */
	AdditionalReestabInfo comp2;
	fill_AdditionalReestabInfo(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	AdditionalReestabInfo comp1;
	fill_AdditionalReestabInfo(comp1);
	value.prepend(comp1);
    }
}

static void fill_AffectedCarrierFreq_r11(AffectedCarrierFreq_r11 & value)
{
    value.set_carrierFreq_r11(1);
    value.set_interferenceDirection_r11(interferenceDirection_r11_eutra);
}

static void fill_AffectedCarrierFreqComb_r11(AffectedCarrierFreqComb_r11 & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_AffectedCarrierFreq_v1310(AffectedCarrierFreq_v1310 & value)
{
    value.set_carrierFreq_v1310(33);
}

static void fill_AffectedCarrierFreqComb_r13(AffectedCarrierFreqComb_r13 & value)
{
    value.prepend(1);
    value.prepend(1);
}

static void fill_AffectedCarrierFreqCombInfoMRDC_r15(AffectedCarrierFreqCombInfoMRDC_r15 & value)
{
    /* Setting 'victimSystemType_r15' field */

    /* Calling a fully-initializing constructor */
    VictimSystemType_r11 victimSystemType_r15(gps_r11_true, glonass_r11_true, bds_r11_true, galileo_r11_true, wlan_r11_true, bluetooth_r11_true);

    value.set_victimSystemType_r15(victimSystemType_r15);

    value.set_interferenceDirectionMRDC_r15(interferenceDirectionMRDC_r15_eutra_nr);
    /* Setting 'affectedCarrierFreqCombMRDC_r15' field */
    /* Creating 'affectedCarrierFreqCombEUTRA_r15' field of 'affectedCarrierFreqCombMRDC_r15' field */
    AffectedCarrierFreqComb_r15 affectedCarrierFreqCombEUTRA_r15;
    affectedCarrierFreqCombEUTRA_r15.prepend(1);
    affectedCarrierFreqCombEUTRA_r15.prepend(1);

    /* Creating 'affectedCarrierFreqCombNR_r15' field of 'affectedCarrierFreqCombMRDC_r15' field */
    AffectedCarrierFreqCombNR_r15 affectedCarrierFreqCombNR_r15;
    affectedCarrierFreqCombNR_r15.prepend((OSS_UINT32)0);
    affectedCarrierFreqCombNR_r15.prepend((OSS_UINT32)0);

    /* Calling a fully-initializing constructor */
    AffectedCarrierFreqCombInfoMRDC_r15::affectedCarrierFreqCombMRDC_r15 affectedCarrierFreqCombMRDC_r15(affectedCarrierFreqCombEUTRA_r15, affectedCarrierFreqCombNR_r15);

    value.set_affectedCarrierFreqCombMRDC_r15(affectedCarrierFreqCombMRDC_r15);
}

static void fill_MBMS_ServiceInfo_r13(MBMS_ServiceInfo_r13 & value)
{
    /* Setting 'tmgi_r13' field */
    /* Creating 'plmn_Id_r9' field of 'tmgi_r13' field */
    TMGI_r9::plmn_Id_r9 plmn_Id_r9;
    plmn_Id_r9.set_plmn_Index_r9(1);

    /* Creating 'serviceId_r9' field of 'tmgi_r13' field */
    static unsigned char serviceId_r9_value[] = {
	0x00, 0x00, 0x00
    };
    OssString serviceId_r9(sizeof(serviceId_r9_value), (char *)serviceId_r9_value);

    /* Calling a fully-initializing constructor */
    TMGI_r9 tmgi_r13(plmn_Id_r9, serviceId_r9);

    value.set_tmgi_r13(tmgi_r13);
}

static void fill_decoded_2(MBMSInterestIndication_r11 & value)
{
    /* Setting 'criticalExtensions' field */
    MBMSInterestIndication_r11::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    MBMSInterestIndication_r11::criticalExtensions::c1 c1;
    /* Setting 'interestIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'mbms_FreqList_r11' field of 'interestIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    CarrierFreqListMBMS_r11 mbms_FreqList_r11;
    mbms_FreqList_r11.prepend((OSS_UINT32)0);
    mbms_FreqList_r11.prepend((OSS_UINT32)0);

    /* Creating 'lateNonCriticalExtension' field of 'interestIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'interestIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'mbms_Services_r13' field of 'nonCriticalExtension' field of 'interestIndication_r11' alternative of 'c1' alternative... */
    MBMS_ServiceList_r13 mbms_Services_r13;
    {
	/* Adding component #2 */
	MBMS_ServiceInfo_r13 comp2;
	fill_MBMS_ServiceInfo_r13(comp2);
	mbms_Services_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MBMS_ServiceInfo_r13 comp1;
	fill_MBMS_ServiceInfo_r13(comp1);
	mbms_Services_r13.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'interestIndication_r11' alternative of 'c1' alternative... */
    MBMSInterestIndication_v1310_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    MBMSInterestIndication_v1310_IEs nonCriticalExtension(mbms_Services_r13, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    MBMSInterestIndication_r11_IEs interestIndication_r11(mbms_FreqList_r11, mbms_Priority_r11_true, lateNonCriticalExtension, nonCriticalExtension);

    c1.set_interestIndication_r11(interestIndication_r11);

    criticalExtensions.set_c1(c1);

    value.set_criticalExtensions(criticalExtensions);
}

static void fill_TrafficPatternInfo_r14(TrafficPatternInfo_r14 & value)
{
    value.set_trafficPeriodicity_r14(trafficPeriodicity_r14_sf20);
    value.set_timingOffset_r14(0);
    value.set_priorityInfoSL_r14(1);
    value.set_logicalChannelIdentityUL_r14(3);
    /* Setting 'messageSize_r14' field */
    static unsigned char messageSize_r14_value[] = {
	0x00
    };
    OssBitString messageSize_r14(6, messageSize_r14_value);
    value.set_messageSize_r14(messageSize_r14);
}

static void fill_TrafficPatternInfo_v1530(TrafficPatternInfo_v1530 & value)
{
    /* Setting 'trafficDestination_r15' field */
    static unsigned char trafficDestination_r15_value[] = {
	0x00, 0x00, 0x00
    };
    OssBitString trafficDestination_r15(24, trafficDestination_r15_value);
    value.set_trafficDestination_r15(trafficDestination_r15);

    value.set_reliabilityInfoSL_r15(1);
}

static void fill_SL_DiscTxResourceReq_r13(SL_DiscTxResourceReq_r13 & value)
{
    value.set_carrierFreqDiscTx_r13(1);
    value.set_discTxResourceReq_r13(1);
}

static void fill_SL_GapPattern_r13(SL_GapPattern_r13 & value)
{
    value.set_gapPeriod_r13(gapPeriod_r13_sf40);
    /* Setting 'gapOffset_r12' field */
    SL_OffsetIndicator_r12 gapOffset_r12;
    gapOffset_r12.set_small_r12(0);
    value.set_gapOffset_r12(gapOffset_r12);

    /* Setting 'gapSubframeBitmap_r13' field */
    static unsigned char gapSubframeBitmap_r13_value[] = {
	0x00
    };
    OssBitString gapSubframeBitmap_r13(1, gapSubframeBitmap_r13_value);
    value.set_gapSubframeBitmap_r13(gapSubframeBitmap_r13);
}

static void fill_SL_GapFreqInfo_r13(SL_GapFreqInfo_r13 & value)
{
    value.set_carrierFreq_r13(0);
    /* Setting 'gapPatternList_r13' field */
    SL_GapPatternList_r13 gapPatternList_r13;
    {
	/* Adding component #2 */
	SL_GapPattern_r13 comp2;
	fill_SL_GapPattern_r13(comp2);
	gapPatternList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_GapPattern_r13 comp1;
	fill_SL_GapPattern_r13(comp1);
	gapPatternList_r13.prepend(comp1);
    }
    value.set_gapPatternList_r13(gapPatternList_r13);
}

static void fill_SL_DiscResourcePool_r12(SL_DiscResourcePool_r12 & value)
{
    value.set_cp_Len_r12(SL_CP_Len_r12_normal);
    value.set_discPeriod_r12(discPeriod_r12_rf32);
    value.set_numRetx_r12(0);
    value.set_numRepetition_r12(1);
    /* Setting 'tf_ResourceConfig_r12' field */
    /* Creating 'offsetIndicator_r12' field of 'tf_ResourceConfig_r12' field */
    SL_OffsetIndicator_r12 offsetIndicator_r12;
    offsetIndicator_r12.set_small_r12(0);

    /* Creating 'subframeBitmap_r12' field of 'tf_ResourceConfig_r12' field */
    SubframeBitmapSL_r12 subframeBitmap_r12;
    /* Setting 'bs4_r12' alternative of 'subframeBitmap_r12' field of 'tf_ResourceConfig_r12' field */
    static unsigned char bs4_r12_value[] = {
	0x00
    };
    OssBitString bs4_r12(4, bs4_r12_value);
    subframeBitmap_r12.set_bs4_r12(bs4_r12);

    /* Calling a fully-initializing constructor */
    SL_TF_ResourceConfig_r12 tf_ResourceConfig_r12(1, 0, 0, offsetIndicator_r12, subframeBitmap_r12);

    value.set_tf_ResourceConfig_r12(tf_ResourceConfig_r12);

    /* Setting 'txParameters_r12' field */
    /* Creating 'txParametersGeneral_r12' field of 'txParameters_r12' field */

    /* Calling a fully-initializing constructor */
    SL_TxParameters_r12 txParametersGeneral_r12(Alpha_r12_al0, 31);

    /* Creating 'ue_SelectedResourceConfig_r12' field of 'txParameters_r12' field */
    /* Creating 'poolSelection_r12' field of 'ue_SelectedResourceConfig_r12' field of 'txParameters_r12' field */
    SL_DiscResourcePool_r12::txParameters_r12::ue_SelectedResourceConfig_r12::poolSelection_r12 poolSelection_r12;
    /* Setting 'rsrpBased_r12' alternative of 'poolSelection_r12' field of 'ue_SelectedResourceConfig_r12' field of 'txParameters_r12' field... */

    /* Calling a fully-initializing constructor */
    SL_PoolSelectionConfig_r12 rsrpBased_r12(0, 0);

    poolSelection_r12.set_rsrpBased_r12(rsrpBased_r12);

    /* Calling a fully-initializing constructor */
    SL_DiscResourcePool_r12::txParameters_r12::ue_SelectedResourceConfig_r12 ue_SelectedResourceConfig_r12(poolSelection_r12, txProbability_r12_p25);

    /* Calling a fully-initializing constructor */
    SL_DiscResourcePool_r12::txParameters_r12 txParameters_r12(txParametersGeneral_r12, ue_SelectedResourceConfig_r12);

    value.set_txParameters_r12(txParameters_r12);

    /* Setting 'rxParameters_r12' field */
    /* Creating 'tdd_Config_r12' field of 'rxParameters_r12' field */

    /* Calling a fully-initializing constructor */
    TDD_Config tdd_Config_r12(subframeAssignment_sa0, specialSubframePatterns_ssp0);

    /* Calling a fully-initializing constructor */
    SL_DiscResourcePool_r12::rxParameters_r12 rxParameters_r12(tdd_Config_r12, 0);

    value.set_rxParameters_r12(rxParameters_r12);

    /* Setting 'discPeriod_v1310' field */
    SL_DiscResourcePool_r12::discPeriod_v1310 discPeriod_v1310;
    discPeriod_v1310.set_release(0);
    value.set_discPeriod_v1310(discPeriod_v1310);

    /* Setting 'rxParamsAddNeighFreq_r13' field */
    SL_DiscResourcePool_r12::rxParamsAddNeighFreq_r13 rxParamsAddNeighFreq_r13;
    rxParamsAddNeighFreq_r13.set_release(0);
    value.set_rxParamsAddNeighFreq_r13(rxParamsAddNeighFreq_r13);

    /* Setting 'txParamsAddNeighFreq_r13' field */
    SL_DiscResourcePool_r12::txParamsAddNeighFreq_r13 txParamsAddNeighFreq_r13;
    txParamsAddNeighFreq_r13.set_release(0);
    value.set_txParamsAddNeighFreq_r13(txParamsAddNeighFreq_r13);

    /* Setting 'txParamsAddNeighFreq_v1370' field */
    SL_DiscResourcePool_r12::txParamsAddNeighFreq_v1370 txParamsAddNeighFreq_v1370;
    txParamsAddNeighFreq_v1370.set_release(0);
    value.set_txParamsAddNeighFreq_v1370(txParamsAddNeighFreq_v1370);
}

static void fill_SL_DiscTxPowerInfo_r12(SL_DiscTxPowerInfo_r12 & value)
{
    value.set_discMaxTxPower_r12(-30);
}

static void fill_SL_DiscSysInfoReport_r13(SL_DiscSysInfoReport_r13 & value)
{
    /* Setting 'plmn_IdentityList_r13' field */
    PLMN_IdentityList plmn_IdentityList_r13;
    {
	/* Adding component #2 */
	PLMN_IdentityInfo comp2;
	fill_PLMN_IdentityInfo(comp2);
	plmn_IdentityList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_IdentityInfo comp1;
	fill_PLMN_IdentityInfo(comp1);
	plmn_IdentityList_r13.prepend(comp1);
    }
    value.set_plmn_IdentityList_r13(plmn_IdentityList_r13);

    /* Setting 'cellIdentity_13' field */
    static unsigned char cellIdentity_13_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity_13(28, cellIdentity_13_value);
    value.set_cellIdentity_13(cellIdentity_13);

    value.set_carrierFreqInfo_13(0);
    /* Setting 'discRxResources_r13' field */
    SL_DiscRxPoolList_r12 discRxResources_r13;
    {
	/* Adding component #2 */
	SL_DiscResourcePool_r12 comp2;
	fill_SL_DiscResourcePool_r12(comp2);
	discRxResources_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_DiscResourcePool_r12 comp1;
	fill_SL_DiscResourcePool_r12(comp1);
	discRxResources_r13.prepend(comp1);
    }
    value.set_discRxResources_r13(discRxResources_r13);

    /* Setting 'discTxPoolCommon_r13' field */
    SL_DiscTxPoolList_r12 discTxPoolCommon_r13;
    {
	/* Adding component #2 */
	SL_DiscResourcePool_r12 comp2;
	fill_SL_DiscResourcePool_r12(comp2);
	discTxPoolCommon_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_DiscResourcePool_r12 comp1;
	fill_SL_DiscResourcePool_r12(comp1);
	discTxPoolCommon_r13.prepend(comp1);
    }
    value.set_discTxPoolCommon_r13(discTxPoolCommon_r13);

    /* Setting 'discTxPowerInfo_r13' field */
    SL_DiscTxPowerInfoList_r12 discTxPowerInfo_r13;
    {
	/* Adding component #3 */
	SL_DiscTxPowerInfo_r12 comp3;
	fill_SL_DiscTxPowerInfo_r12(comp3);
	discTxPowerInfo_r13.prepend(comp3);
    }
    {
	/* Adding component #2 */
	SL_DiscTxPowerInfo_r12 comp2;
	fill_SL_DiscTxPowerInfo_r12(comp2);
	discTxPowerInfo_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_DiscTxPowerInfo_r12 comp1;
	fill_SL_DiscTxPowerInfo_r12(comp1);
	discTxPowerInfo_r13.prepend(comp1);
    }
    value.set_discTxPowerInfo_r13(discTxPowerInfo_r13);

    /* Setting 'discSyncConfig_r13' field */
    /* Creating 'asyncParameters_r13' field of 'discSyncConfig_r13' field */

    /* Calling a fully-initializing constructor */
    SL_SyncConfigNFreq_r13::asyncParameters_r13 asyncParameters_r13(SL_CP_Len_r12_normal, 0, 0);

    /* Creating 'txParameters_r13' field of 'discSyncConfig_r13' field */
    /* Creating 'syncTxParameters_r13' field of 'txParameters_r13' field of 'discSyncConfig_r13' field */

    /* Calling a fully-initializing constructor */
    SL_TxParameters_r12 syncTxParameters_r13(Alpha_r12_al0, 31);

    /* Creating 'syncInfoReserved_r13' field of 'txParameters_r13' field of 'discSyncConfig_r13' field */
    static unsigned char syncInfoReserved_r13_value[] = {
	0x00, 0x00, 0x00
    };
    OssBitString syncInfoReserved_r13(19, syncInfoReserved_r13_value);

    /* Calling a fully-initializing constructor */
    SL_SyncConfigNFreq_r13::txParameters_r13 txParameters_r13(syncTxParameters_r13, 0, syncInfoReserved_r13, txParameters_r13_syncTxPeriodic_r13_true);

    /* Creating 'rxParameters_r13' field of 'discSyncConfig_r13' field */

    /* Calling a fully-initializing constructor */
    SL_SyncConfigNFreq_r13::rxParameters_r13 rxParameters_r13(discSyncWindow_r13_w1);

    /* Calling a fully-initializing constructor */
    SL_SyncConfigNFreq_r13 discSyncConfig_r13(asyncParameters_r13, txParameters_r13, rxParameters_r13, 40, SL_SyncConfigNFreq_r13_gnss_Sync_r14_true, 0, 0, SL_SyncConfigNFreq_r13_slss_TxDisabled_r15_true);

    value.set_discSyncConfig_r13(discSyncConfig_r13);

    /* Setting 'discCellSelectionInfo_r13' field */

    /* Calling a fully-initializing constructor */
    SL_DiscSysInfoReport_r13::discCellSelectionInfo_r13 discCellSelectionInfo_r13(-22, 1);

    value.set_discCellSelectionInfo_r13(discCellSelectionInfo_r13);

    /* Setting 'cellReselectionInfo_r13' field */

    /* Calling a fully-initializing constructor */
    SL_DiscSysInfoReport_r13::cellReselectionInfo_r13 cellReselectionInfo_r13(cellReselectionInfo_r13_q_Hyst_r13_dB0, -22, 0);

    value.set_cellReselectionInfo_r13(cellReselectionInfo_r13);

    /* Setting 'tdd_Config_r13' field */

    /* Calling a fully-initializing constructor */
    TDD_Config tdd_Config_r13(subframeAssignment_sa0, specialSubframePatterns_ssp0);

    value.set_tdd_Config_r13(tdd_Config_r13);

    /* Setting 'freqInfo_r13' field */

    /* Calling a fully-initializing constructor */
    SL_DiscSysInfoReport_r13::freqInfo_r13 freqInfo_r13(0, ul_Bandwidth_r13_n6, 1);

    value.set_freqInfo_r13(freqInfo_r13);

    value.set_p_Max_r13(-30);
    value.set_referenceSignalPower_r13(50);
    /* Setting 'freqInfo_v1370' field */

    /* Calling a fully-initializing constructor */
    SL_DiscSysInfoReport_r13::freqInfo_v1370 freqInfo_v1370(33);

    value.set_freqInfo_v1370(freqInfo_v1370);
}

static void fill_SL_V2X_CommTxResourceReq_r14(SL_V2X_CommTxResourceReq_r14 & value)
{
    value.set_carrierFreqCommTx_r14(0);
    value.set_v2x_TypeTxSync_r14(SL_TypeTxSync_r14_gnss);
    /* Setting 'v2x_DestinationInfoList_r14' field */
    SL_DestinationInfoList_r12 v2x_DestinationInfoList_r14;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp2(24, comp2_value);
	v2x_DestinationInfoList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp1(24, comp1_value);
	v2x_DestinationInfoList_r14.prepend(comp1);
    }
    value.set_v2x_DestinationInfoList_r14(v2x_DestinationInfoList_r14);
}

static void fill_SL_TxParameters_r12(SL_TxParameters_r12 & value)
{
    value.set_alpha_r12(Alpha_r12_al0);
    value.set_p0_r12(31);
}

static void fill_SL_PPPP_TxConfigIndex_r14(SL_PPPP_TxConfigIndex_r14 & value)
{
    value.set_priorityThreshold_r14(1);
    value.set_defaultTxConfigIndex_r14(0);
    value.set_cbr_ConfigIndex_r14(0);
    /* Setting 'tx_ConfigIndexList_r14' field */
    SL_PPPP_TxConfigIndex_r14::tx_ConfigIndexList_r14 tx_ConfigIndexList_r14;
    tx_ConfigIndexList_r14.prepend((OSS_UINT32)0);
    tx_ConfigIndexList_r14.prepend((OSS_UINT32)0);
    value.set_tx_ConfigIndexList_r14(tx_ConfigIndexList_r14);
}

static void fill_SL_PPPP_TxConfigIndex_v1530(SL_PPPP_TxConfigIndex_v1530 & value)
{
    /* Setting 'mcs_PSSCH_RangeList_r15' field */
    SL_PPPP_TxConfigIndex_v1530::mcs_PSSCH_RangeList_r15 mcs_PSSCH_RangeList_r15;
    {
	/* Adding component #2 */
	EUTRA_RRC_Definitions_MCS_PSSCH_Range_r15 comp2;
	fill_EUTRA_Sidelink_Preconf_MCS_PSSCH_Range_r15(comp2);
	mcs_PSSCH_RangeList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	EUTRA_RRC_Definitions_MCS_PSSCH_Range_r15 comp1;
	fill_EUTRA_Sidelink_Preconf_MCS_PSSCH_Range_r15(comp1);
	mcs_PSSCH_RangeList_r15.prepend(comp1);
    }
    value.set_mcs_PSSCH_RangeList_r15(mcs_PSSCH_RangeList_r15);
}

static void fill_SL_CommResourcePoolV2X_r14(SL_CommResourcePoolV2X_r14 & value)
{
    /* Setting 'sl_OffsetIndicator_r14' field */
    SL_OffsetIndicator_r12 sl_OffsetIndicator_r14;
    fill_SL_OffsetIndicator_r12(sl_OffsetIndicator_r14);
    value.set_sl_OffsetIndicator_r14(sl_OffsetIndicator_r14);

    /* Setting 'sl_Subframe_r14' field */
    SubframeBitmapSL_r14 sl_Subframe_r14;
    fill_SubframeBitmapSL_r14(sl_Subframe_r14);
    value.set_sl_Subframe_r14(sl_Subframe_r14);

    value.set_adjacencyPSCCH_PSSCH_r14(TRUE);
    value.set_sizeSubchannel_r14(SL_CommResourcePoolV2X_r14_sizeSubchannel_r14_n4);
    value.set_numSubchannel_r14(SL_CommResourcePoolV2X_r14_numSubchannel_r14_n1);
    value.set_startRB_Subchannel_r14(0);
    value.set_startRB_PSCCH_Pool_r14(0);
    /* Setting 'rxParametersNCell_r14' field */
    /* Creating 'tdd_Config_r14' field of 'rxParametersNCell_r14' field */
    TDD_Config tdd_Config_r14;
    fill_TDD_Config(tdd_Config_r14);

    /* Calling a fully-initializing constructor */
    SL_CommResourcePoolV2X_r14::rxParametersNCell_r14 rxParametersNCell_r14(tdd_Config_r14, 0);

    value.set_rxParametersNCell_r14(rxParametersNCell_r14);

    /* Setting 'dataTxParameters_r14' field */
    SL_TxParameters_r12 dataTxParameters_r14;
    fill_SL_TxParameters_r12(dataTxParameters_r14);
    value.set_dataTxParameters_r14(dataTxParameters_r14);

    value.set_zoneID_r14(0);
    value.set_threshS_RSSI_CBR_r14(0);
    value.set_poolReportId_r14(1);
    /* Setting 'cbr_pssch_TxConfigList_r14' field */
    SL_CBR_PPPP_TxConfigList_r14 cbr_pssch_TxConfigList_r14;
    {
	/* Adding component #2 */
	SL_PPPP_TxConfigIndex_r14 comp2;
	fill_SL_PPPP_TxConfigIndex_r14(comp2);
	cbr_pssch_TxConfigList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PPPP_TxConfigIndex_r14 comp1;
	fill_SL_PPPP_TxConfigIndex_r14(comp1);
	cbr_pssch_TxConfigList_r14.prepend(comp1);
    }
    value.set_cbr_pssch_TxConfigList_r14(cbr_pssch_TxConfigList_r14);

    /* Setting 'resourceSelectionConfigP2X_r14' field */
    SL_P2X_ResourceSelectionConfig_r14 resourceSelectionConfigP2X_r14;
    fill_SL_P2X_ResourceSelectionConfig_r14(resourceSelectionConfigP2X_r14);
    value.set_resourceSelectionConfigP2X_r14(resourceSelectionConfigP2X_r14);

    /* Setting 'syncAllowed_r14' field */
    SL_SyncAllowed_r14 syncAllowed_r14;
    fill_SL_SyncAllowed_r14(syncAllowed_r14);
    value.set_syncAllowed_r14(syncAllowed_r14);

    /* Setting 'restrictResourceReservationPeriod_r14' field */
    SL_RestrictResourceReservationPeriodList_r14 restrictResourceReservationPeriod_r14;
    fill_SL_RestrictResourceReservationPeriodList_r14(restrictResourceReservationPeriod_r14);
    value.set_restrictResourceReservationPeriod_r14(restrictResourceReservationPeriod_r14);

    /* Setting 'sl_MinT2ValueList_r15' field */
    SL_MinT2ValueList_r15 sl_MinT2ValueList_r15;
    fill_SL_MinT2ValueList_r15(sl_MinT2ValueList_r15);
    value.set_sl_MinT2ValueList_r15(sl_MinT2ValueList_r15);

    /* Setting 'cbr_pssch_TxConfigList_v1530' field */
    SL_CBR_PPPP_TxConfigList_v1530 cbr_pssch_TxConfigList_v1530;
    {
	/* Adding component #2 */
	SL_PPPP_TxConfigIndex_v1530 comp2;
	fill_SL_PPPP_TxConfigIndex_v1530(comp2);
	cbr_pssch_TxConfigList_v1530.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_PPPP_TxConfigIndex_v1530 comp1;
	fill_SL_PPPP_TxConfigIndex_v1530(comp1);
	cbr_pssch_TxConfigList_v1530.prepend(comp1);
    }
    value.set_cbr_pssch_TxConfigList_v1530(cbr_pssch_TxConfigList_v1530);
}

static void fill_SL_SyncConfigNFreq_r13(SL_SyncConfigNFreq_r13 & value)
{
    /* Setting 'asyncParameters_r13' field */

    /* Calling a fully-initializing constructor */
    SL_SyncConfigNFreq_r13::asyncParameters_r13 asyncParameters_r13(SL_CP_Len_r12_normal, 0, 0);

    value.set_asyncParameters_r13(asyncParameters_r13);

    /* Setting 'txParameters_r13' field */
    /* Creating 'syncTxParameters_r13' field of 'txParameters_r13' field */
    SL_TxParameters_r12 syncTxParameters_r13;
    fill_SL_TxParameters_r12(syncTxParameters_r13);

    /* Creating 'syncInfoReserved_r13' field of 'txParameters_r13' field */
    static unsigned char syncInfoReserved_r13_value[] = {
	0x00, 0x00, 0x00
    };
    OssBitString syncInfoReserved_r13(19, syncInfoReserved_r13_value);

    /* Calling a fully-initializing constructor */
    SL_SyncConfigNFreq_r13::txParameters_r13 txParameters_r13(syncTxParameters_r13, 0, syncInfoReserved_r13, txParameters_r13_syncTxPeriodic_r13_true);

    value.set_txParameters_r13(txParameters_r13);

    /* Setting 'rxParameters_r13' field */

    /* Calling a fully-initializing constructor */
    SL_SyncConfigNFreq_r13::rxParameters_r13 rxParameters_r13(discSyncWindow_r13_w1);

    value.set_rxParameters_r13(rxParameters_r13);

    value.set_syncOffsetIndicator_v1430(40);
    value.set_gnss_Sync_r14(SL_SyncConfigNFreq_r13_gnss_Sync_r14_true);
    value.set_syncOffsetIndicator2_r14(0);
    value.set_syncOffsetIndicator3_r14(0);
    value.set_slss_TxDisabled_r15(SL_SyncConfigNFreq_r13_slss_TxDisabled_r15_true);
}

static void fill_SL_CommRxPoolListV2X_r14(SL_CommRxPoolListV2X_r14 & value)
{
    {
	/* Adding component #2 */
	SL_CommResourcePoolV2X_r14 comp2;
	fill_SL_CommResourcePoolV2X_r14(comp2);
	value.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_CommResourcePoolV2X_r14 comp1;
	fill_SL_CommResourcePoolV2X_r14(comp1);
	value.prepend(comp1);
    }
}

static void fill_SL_V2X_InterFreqUE_Config_r14(SL_V2X_InterFreqUE_Config_r14 & value)
{
    /* Setting 'physCellIdList_r14' field */
    PhysCellIdList_r13 physCellIdList_r14;
    physCellIdList_r14.prepend((OSS_UINT32)0);
    physCellIdList_r14.prepend((OSS_UINT32)0);
    value.set_physCellIdList_r14(physCellIdList_r14);

    value.set_typeTxSync_r14(SL_TypeTxSync_r14_gnss);
    /* Setting 'v2x_SyncConfig_r14' field */
    SL_SyncConfigListNFreqV2X_r14 v2x_SyncConfig_r14;
    {
	/* Adding component #2 */
	SL_SyncConfigNFreq_r13 comp2;
	fill_SL_SyncConfigNFreq_r13(comp2);
	v2x_SyncConfig_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_SyncConfigNFreq_r13 comp1;
	fill_SL_SyncConfigNFreq_r13(comp1);
	v2x_SyncConfig_r14.prepend(comp1);
    }
    value.set_v2x_SyncConfig_r14(v2x_SyncConfig_r14);

    /* Setting 'v2x_CommRxPool_r14' field */
    SL_CommRxPoolListV2X_r14 v2x_CommRxPool_r14;
    fill_SL_CommRxPoolListV2X_r14(v2x_CommRxPool_r14);
    value.set_v2x_CommRxPool_r14(v2x_CommRxPool_r14);

    /* Setting 'v2x_CommTxPoolNormal_r14' field */
    SL_CommTxPoolListV2X_r14 v2x_CommTxPoolNormal_r14;
    fill_SL_CommRxPoolListV2X_r14(v2x_CommTxPoolNormal_r14);
    value.set_v2x_CommTxPoolNormal_r14(v2x_CommTxPoolNormal_r14);

    /* Setting 'p2x_CommTxPoolNormal_r14' field */
    SL_CommTxPoolListV2X_r14 p2x_CommTxPoolNormal_r14;
    fill_SL_CommRxPoolListV2X_r14(p2x_CommTxPoolNormal_r14);
    value.set_p2x_CommTxPoolNormal_r14(p2x_CommTxPoolNormal_r14);

    /* Setting 'v2x_CommTxPoolExceptional_r14' field */
    SL_CommResourcePoolV2X_r14 v2x_CommTxPoolExceptional_r14;
    fill_SL_CommResourcePoolV2X_r14(v2x_CommTxPoolExceptional_r14);
    value.set_v2x_CommTxPoolExceptional_r14(v2x_CommTxPoolExceptional_r14);

    /* Setting 'v2x_ResourceSelectionConfig_r14' field */
    SL_CommTxPoolSensingConfig_r14 v2x_ResourceSelectionConfig_r14;
    fill_SL_CommTxPoolSensingConfig_r14(v2x_ResourceSelectionConfig_r14);
    value.set_v2x_ResourceSelectionConfig_r14(v2x_ResourceSelectionConfig_r14);

    /* Setting 'zoneConfig_r14' field */
    SL_ZoneConfig_r14 zoneConfig_r14;
    fill_SL_ZoneConfig_r14(zoneConfig_r14);
    value.set_zoneConfig_r14(zoneConfig_r14);

    value.set_offsetDFN_r14(0);
}

static void fill_SL_InterFreqInfoV2X_r14(SL_InterFreqInfoV2X_r14 & value)
{
    /* Setting 'plmn_IdentityList_r14' field */
    PLMN_IdentityList plmn_IdentityList_r14;
    fill_PLMN_IdentityList(plmn_IdentityList_r14);
    value.set_plmn_IdentityList_r14(plmn_IdentityList_r14);

    value.set_v2x_CommCarrierFreq_r14(0);
    value.set_sl_MaxTxPower_r14(-30);
    value.set_sl_Bandwidth_r14(SL_InterFreqInfoV2X_r14_sl_Bandwidth_r14_n6);
    /* Setting 'v2x_SchedulingPool_r14' field */
    SL_CommResourcePoolV2X_r14 v2x_SchedulingPool_r14;
    fill_SL_CommResourcePoolV2X_r14(v2x_SchedulingPool_r14);
    value.set_v2x_SchedulingPool_r14(v2x_SchedulingPool_r14);

    /* Setting 'v2x_UE_ConfigList_r14' field */
    SL_V2X_UE_ConfigList_r14 v2x_UE_ConfigList_r14;
    {
	/* Adding component #2 */
	SL_V2X_InterFreqUE_Config_r14 comp2;
	fill_SL_V2X_InterFreqUE_Config_r14(comp2);
	v2x_UE_ConfigList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_V2X_InterFreqUE_Config_r14 comp1;
	fill_SL_V2X_InterFreqUE_Config_r14(comp1);
	v2x_UE_ConfigList_r14.prepend(comp1);
    }
    value.set_v2x_UE_ConfigList_r14(v2x_UE_ConfigList_r14);

    /* Setting 'additionalSpectrumEmissionV2X_r14' field */
    SL_InterFreqInfoV2X_r14::additionalSpectrumEmissionV2X_r14 additionalSpectrumEmissionV2X_r14;
    additionalSpectrumEmissionV2X_r14.set_additionalSpectrumEmission_r14(1);
    value.set_additionalSpectrumEmissionV2X_r14(additionalSpectrumEmissionV2X_r14);

    /* Setting 'v2x_FreqSelectionConfigList_r15' field */
    SL_V2X_FreqSelectionConfigList_r15 v2x_FreqSelectionConfigList_r15;
    fill_SL_V2X_FreqSelectionConfigList_r15(v2x_FreqSelectionConfigList_r15);
    value.set_v2x_FreqSelectionConfigList_r15(v2x_FreqSelectionConfigList_r15);
}

static void fill_MeasResultWLAN_r13(MeasResultWLAN_r13 & value)
{
    /* Setting 'wlan_Identifiers_r13' field */
    WLAN_Identifiers_r12 wlan_Identifiers_r13;
    fill_WLAN_Identifiers_r12(wlan_Identifiers_r13);
    value.set_wlan_Identifiers_r13(wlan_Identifiers_r13);

    /* Setting 'carrierInfoWLAN_r13' field */
    /* Creating 'channelNumbers_r13' field of 'carrierInfoWLAN_r13' field */
    WLAN_ChannelList_r13 channelNumbers_r13;
    channelNumbers_r13.prepend((OSS_UINT32)0);
    channelNumbers_r13.prepend((OSS_UINT32)0);

    /* Calling a fully-initializing constructor */
    WLAN_CarrierInfo_r13 carrierInfoWLAN_r13(0, unitedStates, channelNumbers_r13);

    value.set_carrierInfoWLAN_r13(carrierInfoWLAN_r13);

    value.set_bandWLAN_r13(band2dot4);
    value.set_rssiWLAN_r13(0);
    value.set_availableAdmissionCapacityWLAN_r13(0);
    value.set_backhaulDL_BandwidthWLAN_r13(r0);
    value.set_backhaulUL_BandwidthWLAN_r13(r0);
    value.set_channelUtilizationWLAN_r13(0);
    value.set_stationCountWLAN_r13(0);
    value.set_connectedWLAN_r13(connectedWLAN_r13_true);
}

HandoverPreparationInformation *create_samplevalue_HandoverPreparationInformation()
{
    /* Creating 'criticalExtensions' field */
    HandoverPreparationInformation::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    HandoverPreparationInformation::criticalExtensions::c1 c1;
    /* Setting 'handoverPreparationInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'ue_RadioAccessCapabilityInfo' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UE_CapabilityRAT_ContainerList ue_RadioAccessCapabilityInfo;
    {
	/* Adding component #2 */
	UE_CapabilityRAT_Container comp2;
	fill_UE_CapabilityRAT_Container(comp2);
	ue_RadioAccessCapabilityInfo.prepend(comp2);
    }
    {
	/* Adding component #1 */
	UE_CapabilityRAT_Container comp1;
	fill_UE_CapabilityRAT_Container(comp1);
	ue_RadioAccessCapabilityInfo.prepend(comp1);
    }

    /* Creating 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'measObjectToRemoveList' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasObjectToRemoveList measObjectToRemoveList;
    measObjectToRemoveList.prepend(1);
    measObjectToRemoveList.prepend(1);

    /* Creating 'measObjectToAddModList' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasObjectToAddModList measObjectToAddModList;
    fill_MeasObjectToAddModList(measObjectToAddModList);

    /* Creating 'reportConfigToRemoveList' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    ReportConfigToRemoveList reportConfigToRemoveList;
    reportConfigToRemoveList.prepend(1);
    reportConfigToRemoveList.prepend(1);

    /* Creating 'reportConfigToAddModList' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    ReportConfigToAddModList reportConfigToAddModList;
    fill_ReportConfigToAddModList(reportConfigToAddModList);

    /* Creating 'measIdToRemoveList' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasIdToRemoveList measIdToRemoveList;
    measIdToRemoveList.prepend(1);
    measIdToRemoveList.prepend(1);

    /* Creating 'measIdToAddModList' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasIdToAddModList measIdToAddModList;
    fill_MeasIdToAddModList(measIdToAddModList);

    /* Creating 'quantityConfig' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    QuantityConfig quantityConfig;
    fill_QuantityConfig(quantityConfig);

    /* Creating 'measGapConfig' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasGapConfig measGapConfig;
    fill_MeasGapConfig(measGapConfig);

    /* Creating 'preRegistrationInfoHRPD' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    /* Creating 'secondaryPreRegistrationZoneIdList' field of 'preRegistrationInfoHRPD' field of 'sourceMeasConfig' field of 'as_Config' field... */
    SecondaryPreRegistrationZoneIdListHRPD secondaryPreRegistrationZoneIdList;
    secondaryPreRegistrationZoneIdList.prepend((OSS_UINT32)0);
    secondaryPreRegistrationZoneIdList.prepend((OSS_UINT32)0);

    /* Calling a fully-initializing constructor */
    PreRegistrationInfoHRPD preRegistrationInfoHRPD(TRUE, 0, secondaryPreRegistrationZoneIdList);

    /* Creating 'speedStatePars' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasConfig::speedStatePars speedStatePars;
    speedStatePars.set_release(0);

    /* Creating 'measObjectToAddModList_v9e0' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasObjectToAddModList_v9e0 measObjectToAddModList_v9e0;
    fill_MeasObjectToAddModList_v9e0(measObjectToAddModList_v9e0);

    /* Creating 'measScaleFactor_r12' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasConfig::measScaleFactor_r12 measScaleFactor_r12;
    measScaleFactor_r12.set_release(0);

    /* Creating 'measIdToRemoveListExt_r12' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasIdToRemoveListExt_r12 measIdToRemoveListExt_r12;
    measIdToRemoveListExt_r12.prepend(33);
    measIdToRemoveListExt_r12.prepend(33);

    /* Creating 'measIdToAddModListExt_r12' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasIdToAddModListExt_r12 measIdToAddModListExt_r12;
    fill_MeasIdToAddModListExt_r12(measIdToAddModListExt_r12);

    /* Creating 'measObjectToRemoveListExt_r13' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasObjectToRemoveListExt_r13 measObjectToRemoveListExt_r13;
    measObjectToRemoveListExt_r13.prepend(33);
    measObjectToRemoveListExt_r13.prepend(33);

    /* Creating 'measObjectToAddModListExt_r13' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasObjectToAddModListExt_r13 measObjectToAddModListExt_r13;
    fill_MeasObjectToAddModListExt_r13(measObjectToAddModListExt_r13);

    /* Creating 'measIdToAddModList_v1310' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasIdToAddModList_v1310 measIdToAddModList_v1310;
    fill_MeasIdToAddModList_v1310(measIdToAddModList_v1310);

    /* Creating 'measIdToAddModListExt_v1310' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasIdToAddModListExt_v1310 measIdToAddModListExt_v1310;
    fill_MeasIdToAddModList_v1310(measIdToAddModListExt_v1310);

    /* Creating 'measGapConfigPerCC_List_r14' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasGapConfigPerCC_List_r14 measGapConfigPerCC_List_r14;
    fill_MeasGapConfigPerCC_List_r14(measGapConfigPerCC_List_r14);

    /* Creating 'measGapSharingConfig_r14' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasGapSharingConfig_r14 measGapSharingConfig_r14;
    measGapSharingConfig_r14.set_release(0);

    /* Creating 'measGapConfigDensePRS_r15' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasGapConfigDensePRS_r15 measGapConfigDensePRS_r15;
    measGapConfigDensePRS_r15.set_release(0);

    /* Creating 'heightThreshRef_r15' field of 'sourceMeasConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MeasConfig::heightThreshRef_r15 heightThreshRef_r15;
    heightThreshRef_r15.set_release(0);

    /* Calling a fully-initializing constructor */
    MeasConfig sourceMeasConfig(measObjectToRemoveList, measObjectToAddModList, reportConfigToRemoveList, reportConfigToAddModList, measIdToRemoveList, measIdToAddModList, quantityConfig, measGapConfig, 0, preRegistrationInfoHRPD, speedStatePars, measObjectToAddModList_v9e0, TRUE, measScaleFactor_r12, measIdToRemoveListExt_r12, measIdToAddModListExt_r12, TRUE, measObjectToRemoveListExt_r13, measObjectToAddModListExt_r13, measIdToAddModList_v1310, measIdToAddModListExt_v1310, measGapConfigPerCC_List_r14, measGapSharingConfig_r14, TRUE, TRUE, measGapConfigDensePRS_r15, heightThreshRef_r15);

    /* Creating 'sourceRadioResourceConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    RadioResourceConfigDedicated sourceRadioResourceConfig;
    fill_RadioResourceConfigDedicated(sourceRadioResourceConfig);

    /* Creating 'sourceSecurityAlgorithmConfig' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    SecurityAlgorithmConfig sourceSecurityAlgorithmConfig;
    fill_SecurityAlgorithmConfig(sourceSecurityAlgorithmConfig);

    /* Creating 'sourceUE_Identity' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    static unsigned char sourceUE_Identity_value[] = {
	0x00, 0x00
    };
    OssBitString sourceUE_Identity(16, sourceUE_Identity_value);

    /* Creating 'sourceMasterInformationBlock' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    MasterInformationBlock sourceMasterInformationBlock;
    fill_MasterInformationBlock(sourceMasterInformationBlock);

    /* Creating 'sourceSystemInformationBlockType1' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'cellAccessRelatedInfo' field of 'sourceSystemInformationBlockType1' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    /* Creating 'plmn_IdentityList' field of 'cellAccessRelatedInfo' field of 'sourceSystemInformationBlockType1' field of 'as_Config' field... */
    PLMN_IdentityList plmn_IdentityList;
    fill_PLMN_IdentityList(plmn_IdentityList);

    /* Creating 'trackingAreaCode' field of 'cellAccessRelatedInfo' field of 'sourceSystemInformationBlockType1' field of 'as_Config' field... */
    static unsigned char trackingAreaCode_value[] = {
	0x00, 0x00
    };
    OssBitString trackingAreaCode(16, trackingAreaCode_value);

    /* Creating 'cellIdentity' field of 'cellAccessRelatedInfo' field of 'sourceSystemInformationBlockType1' field of 'as_Config' field... */
    static unsigned char cellIdentity_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString cellIdentity(28, cellIdentity_value);

    /* Creating 'csg_Identity' field of 'cellAccessRelatedInfo' field of 'sourceSystemInformationBlockType1' field of 'as_Config' field... */
    static unsigned char csg_Identity_value[] = {
	0x00, 0x00, 0x00, 0x00
    };
    OssBitString csg_Identity(27, csg_Identity_value);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1::cellAccessRelatedInfo cellAccessRelatedInfo(plmn_IdentityList, trackingAreaCode, cellIdentity, cellBarred_barred, intraFreqReselection_allowed, TRUE, csg_Identity);

    /* Creating 'cellSelectionInfo' field of 'sourceSystemInformationBlockType1' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1::cellSelectionInfo cellSelectionInfo(-22, 1);

    /* Creating 'schedulingInfoList' field of 'sourceSystemInformationBlockType1' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    SchedulingInfoList schedulingInfoList;
    {
	/* Adding component #2 */
	SchedulingInfo comp2;
	fill_SchedulingInfo(comp2);
	schedulingInfoList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SchedulingInfo comp1;
	fill_SchedulingInfo(comp1);
	schedulingInfoList.prepend(comp1);
    }

    /* Calling a mandatory fields constructor */
    SystemInformationBlockType1 sourceSystemInformationBlockType1(cellAccessRelatedInfo, cellSelectionInfo, 1, schedulingInfoList, si_WindowLength_ms1, 0);

    /* Setting optional fields */
    sourceSystemInformationBlockType1.set_p_Max(-30);
    {
	/* Setting 'tdd_Config' field of 'sourceSystemInformationBlockType1' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
	TDD_Config tdd_Config;
	fill_TDD_Config(tdd_Config);
	sourceSystemInformationBlockType1.set_tdd_Config(tdd_Config);
    }

    /* Creating 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'ac_BarringInfo' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    SystemInformationBlockType2::ac_BarringInfo ac_BarringInfo;
    fill_data_23(ac_BarringInfo);

    /* Creating 'radioResourceConfigCommon' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    RadioResourceConfigCommonSIB radioResourceConfigCommon;
    fill_RadioResourceConfigCommonSIB(radioResourceConfigCommon);

    /* Creating 'ue_TimersAndConstants' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    UE_TimersAndConstants ue_TimersAndConstants;
    fill_UE_TimersAndConstants(ue_TimersAndConstants);

    /* Creating 'freqInfo' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    SystemInformationBlockType2::freqInfo freqInfo;
    fill_data_22(freqInfo);

    /* Creating 'mbsfn_SubframeConfigList' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MBSFN_SubframeConfigList mbsfn_SubframeConfigList;
    fill_MBSFN_SubframeConfigList(mbsfn_SubframeConfigList);

    /* Creating 'lateNonCriticalExtension' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    SystemInformationBlockType2::lateNonCriticalExtension lateNonCriticalExtension;
    SystemInformationBlockType2_v8h0_IEs decoded;
    fill_decoded_3(decoded);
    lateNonCriticalExtension.set_decoded(decoded);

    /* Creating 'ssac_BarringForMMTEL_Voice_r9' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    AC_BarringConfig ssac_BarringForMMTEL_Voice_r9;
    fill_AC_BarringConfig(ssac_BarringForMMTEL_Voice_r9);

    /* Creating 'ssac_BarringForMMTEL_Video_r9' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    AC_BarringConfig ssac_BarringForMMTEL_Video_r9;
    fill_AC_BarringConfig(ssac_BarringForMMTEL_Video_r9);

    /* Creating 'ac_BarringForCSFB_r10' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    AC_BarringConfig ac_BarringForCSFB_r10;
    fill_AC_BarringConfig(ac_BarringForCSFB_r10);

    /* Creating 'ac_BarringPerPLMN_List_r12' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    AC_BarringPerPLMN_List_r12 ac_BarringPerPLMN_List_r12;
    fill_AC_BarringPerPLMN_List_r12(ac_BarringPerPLMN_List_r12);

    /* Creating 'acdc_BarringForCommon_r13' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    ACDC_BarringForCommon_r13 acdc_BarringForCommon_r13;
    fill_ACDC_BarringForCommon_r13(acdc_BarringForCommon_r13);

    /* Creating 'acdc_BarringPerPLMN_List_r13' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    ACDC_BarringPerPLMN_List_r13 acdc_BarringPerPLMN_List_r13;
    fill_ACDC_BarringPerPLMN_List_r13(acdc_BarringPerPLMN_List_r13);

    /* Creating 'udt_RestrictingForCommon_r13' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    UDT_Restricting_r13 udt_RestrictingForCommon_r13;
    fill_UDT_Restricting_r13(udt_RestrictingForCommon_r13);

    /* Creating 'udt_RestrictingPerPLMN_List_r13' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    UDT_RestrictingPerPLMN_List_r13 udt_RestrictingPerPLMN_List_r13;
    fill_UDT_RestrictingPerPLMN_List_r13(udt_RestrictingPerPLMN_List_r13);

    /* Creating 'cIoT_EPS_OptimisationInfo_r13' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    CIOT_EPS_OptimisationInfo_r13 cIoT_EPS_OptimisationInfo_r13;
    fill_CIOT_EPS_OptimisationInfo_r13(cIoT_EPS_OptimisationInfo_r13);

    /* Creating 'mbsfn_SubframeConfigList_v1430' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    MBSFN_SubframeConfigList_v1430 mbsfn_SubframeConfigList_v1430;
    fill_MBSFN_SubframeConfigList_v1430(mbsfn_SubframeConfigList_v1430);

    /* Creating 'plmn_InfoList_r15' field of 'sourceSystemInformationBlockType2' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    PLMN_InfoList_r15 plmn_InfoList_r15;
    fill_PLMN_InfoList_r15(plmn_InfoList_r15);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType2 sourceSystemInformationBlockType2(ac_BarringInfo, radioResourceConfigCommon, ue_TimersAndConstants, freqInfo, mbsfn_SubframeConfigList, TimeAlignmentTimer_sf500, lateNonCriticalExtension, ssac_BarringForMMTEL_Voice_r9, ssac_BarringForMMTEL_Video_r9, ac_BarringForCSFB_r10, SystemInformationBlockType2_ac_BarringSkipForMMTELVoice_r12_true, SystemInformationBlockType2_ac_BarringSkipForMMTELVideo_r12_true, SystemInformationBlockType2_ac_BarringSkipForSMS_r12_true, ac_BarringPerPLMN_List_r12, voiceServiceCauseIndication_r12_true, acdc_BarringForCommon_r13, acdc_BarringPerPLMN_List_r13, udt_RestrictingForCommon_r13, udt_RestrictingPerPLMN_List_r13, cIoT_EPS_OptimisationInfo_r13, useFullResumeID_r13_true, unicastFreqHoppingInd_r13_true, mbsfn_SubframeConfigList_v1430, videoServiceCauseIndication_r14_true, plmn_InfoList_r15, SystemInformationBlockType2_cp_EDT_r15_true, SystemInformationBlockType2_up_EDT_r15_true, idleModeMeasurements_r15_true, reducedCP_LatencyEnabled_r15_true);

    /* Creating 'antennaInfoCommon' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    AntennaInfoCommon antennaInfoCommon;
    fill_AntennaInfoCommon(antennaInfoCommon);

    /* Creating 'sourceSystemInformationBlockType1Ext' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    AS_Config::sourceSystemInformationBlockType1Ext sourceSystemInformationBlockType1Ext;
    /* Creating 'lateNonCriticalExtension' field of 'plmn_InfoList_r15' field of 'sourceSystemInformationBlockType1Ext' field of 'as_Config' field... */
    SystemInformationBlockType1_v890_IEs::lateNonCriticalExtension decoded_lateNonCriticalExtension;
    /* Creating 'multiBandInfoList' field */
    MultiBandInfoList multiBandInfoList;
    multiBandInfoList.prepend(1);
    multiBandInfoList.prepend(1);

    /* Creating 'nonCriticalExtension' field */
    /* Creating 'multiBandInfoList_v9e0' field of 'nonCriticalExtension' field */
    MultiBandInfoList_v9e0 multiBandInfoList_v9e0;
    {
	/* Adding component #2 */
	MultiBandInfo_v9e0 comp2;
	fill_MultiBandInfo_v9e0(comp2);
	multiBandInfoList_v9e0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MultiBandInfo_v9e0 comp1;
	fill_MultiBandInfo_v9e0(comp1);
	multiBandInfoList_v9e0.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'freqBandInfo_r10' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    NS_PmaxList_r10 freqBandInfo_r10;
    {
	/* Adding component #2 */
	NS_PmaxValue_r10 comp2;
	fill_NS_PmaxValue_r10(comp2);
	freqBandInfo_r10.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NS_PmaxValue_r10 comp1;
	fill_NS_PmaxValue_r10(comp1);
	freqBandInfo_r10.prepend(comp1);
    }

    /* Creating 'multiBandInfoList_v10j0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    MultiBandInfoList_v10j0 multiBandInfoList_v10j0;
    {
	/* Adding component #2 */
	NS_PmaxList_r10 comp2;
	fill_NS_PmaxList_r10(comp2);
	multiBandInfoList_v10j0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NS_PmaxList_r10 comp1;
	fill_NS_PmaxList_r10(comp1);
	multiBandInfoList_v10j0.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'freqBandInfo_v10l0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    NS_PmaxList_v10l0 freqBandInfo_v10l0;
    {
	/* Adding component #2 */
	NS_PmaxValue_v10l0 comp2;
	fill_NS_PmaxValue_v10l0(comp2);
	freqBandInfo_v10l0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NS_PmaxValue_v10l0 comp1;
	fill_NS_PmaxValue_v10l0(comp1);
	freqBandInfo_v10l0.prepend(comp1);
    }

    /* Creating 'multiBandInfoList_v10l0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MultiBandInfoList_v10l0 multiBandInfoList_v10l0;
    {
	/* Adding component #2 */
	NS_PmaxList_v10l0 comp2;
	fill_NS_PmaxList_v10l0(comp2);
	multiBandInfoList_v10l0.prepend(comp2);
    }
    {
	/* Adding component #1 */
	NS_PmaxList_v10l0 comp1;
	fill_NS_PmaxList_v10l0(comp1);
	multiBandInfoList_v10l0.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInformationBlockType1_v10l0_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v10l0_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(freqBandInfo_v10l0, multiBandInfoList_v10l0, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v10j0_IEs nonCriticalExtension_nonCriticalExtension(freqBandInfo_r10, multiBandInfoList_v10j0, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v9e0_IEs lateNonCriticalExtension_decoded_nonCriticalExtension(65, multiBandInfoList_v9e0, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v8h0_IEs lateNonCriticalExtension_decoded(multiBandInfoList, lateNonCriticalExtension_decoded_nonCriticalExtension);

    decoded_lateNonCriticalExtension.set_decoded(lateNonCriticalExtension_decoded);

    /* Creating 'nonCriticalExtension' field of 'plmn_InfoList_r15' field of 'sourceSystemInformationBlockType1Ext' field of 'as_Config' field... */
    /* Creating 'cellSelectionInfo_v920' field of 'nonCriticalExtension' field of 'plmn_InfoList_r15' field of 'sourceSystemInformationBlockType1Ext' field... */

    /* Calling a fully-initializing constructor */
    CellSelectionInfo_v920 cellSelectionInfo_v920(-3, 1);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'plmn_InfoList_r15' field of 'sourceSystemInformationBlockType1Ext' field... */
    /* Creating 'tdd_Config_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'plmn_InfoList_r15' field... */

    /* Calling a fully-initializing constructor */
    TDD_Config_v1130 tdd_Config_v1130(specialSubframePatterns_v1130_ssp7);

    /* Creating 'cellSelectionInfo_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'plmn_InfoList_r15' field... */

    /* Calling a fully-initializing constructor */
    CellSelectionInfo_v1130 cellSelectionInfo_v1130(-3);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'plmn_InfoList_r15' field... */
    /* Creating 'cellAccessRelatedInfo_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1250_IEs::cellAccessRelatedInfo_v1250 cellAccessRelatedInfo_v1250(category0Allowed_r12_true);

    /* Creating 'cellSelectionInfo_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CellSelectionInfo_v1250 cellSelectionInfo_v1250(-3);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'hyperSFN_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char hyperSFN_r13_value[] = {
	0x00, 0x00
    };
    OssBitString hyperSFN_r13(10, hyperSFN_r13_value);

    /* Creating 'cellSelectionInfoCE_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CellSelectionInfoCE_r13 cellSelectionInfoCE_r13(-22, -3);

    /* Creating 'bandwidthReducedAccessRelatedInfo_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'schedulingInfoList_BR_r13' field of 'bandwidthReducedAccessRelatedInfo_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SchedulingInfoList_BR_r13 schedulingInfoList_BR_r13;
    {
	/* Adding component #2 */
	SchedulingInfo_BR_r13 comp2;
	fill_SchedulingInfo_BR_r13(comp2);
	schedulingInfoList_BR_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SchedulingInfo_BR_r13 comp1;
	fill_SchedulingInfo_BR_r13(comp1);
	schedulingInfoList_BR_r13.prepend(comp1);
    }

    /* Creating 'fdd_DownlinkOrTddSubframeBitmapBR_r13' field of 'bandwidthReducedAccessRelatedInfo_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInformationBlockType1_v1310_IEs::bandwidthReducedAccessRelatedInfo_r13::fdd_DownlinkOrTddSubframeBitmapBR_r13 fdd_DownlinkOrTddSubframeBitmapBR_r13;
    /* Setting 'subframePattern10_r13' alternative of 'fdd_DownlinkOrTddSubframeBitmapBR_r13' field of 'bandwidthReducedAccessRelatedInfo_r13' field of 'nonCriticalExtension' field... */
    static unsigned char subframePattern10_r13_value[] = {
	0x00, 0x00
    };
    OssBitString subframePattern10_r13(10, subframePattern10_r13_value);
    fdd_DownlinkOrTddSubframeBitmapBR_r13.set_subframePattern10_r13(subframePattern10_r13);

    /* Creating 'fdd_UplinkSubframeBitmapBR_r13' field of 'bandwidthReducedAccessRelatedInfo_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char fdd_UplinkSubframeBitmapBR_r13_value[] = {
	0x00, 0x00
    };
    OssBitString fdd_UplinkSubframeBitmapBR_r13(10, fdd_UplinkSubframeBitmapBR_r13_value);

    /* Creating 'systemInfoValueTagList_r13' field of 'bandwidthReducedAccessRelatedInfo_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInfoValueTagList_r13 systemInfoValueTagList_r13;
    systemInfoValueTagList_r13.prepend((OSS_UINT32)0);
    systemInfoValueTagList_r13.prepend((OSS_UINT32)0);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1310_IEs::bandwidthReducedAccessRelatedInfo_r13 bandwidthReducedAccessRelatedInfo_r13(si_WindowLength_BR_r13_ms20, everyRF, schedulingInfoList_BR_r13, fdd_DownlinkOrTddSubframeBitmapBR_r13, fdd_UplinkSubframeBitmapBR_r13, 1, si_HoppingConfigCommon_r13_on, si_ValidityTime_r13_true, systemInfoValueTagList_r13);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'freqHoppingParametersDL_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'interval_DLHoppingConfigCommonModeA_r13' field of 'freqHoppingParametersDL_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInformationBlockType1_v1320_IEs::freqHoppingParametersDL_r13::interval_DLHoppingConfigCommonModeA_r13 interval_DLHoppingConfigCommonModeA_r13;
    interval_DLHoppingConfigCommonModeA_r13.set_interval_FDD_r13(interval_DLHoppingConfigCommonModeA_r13_interval_FDD_r13_int1);

    /* Creating 'interval_DLHoppingConfigCommonModeB_r13' field of 'freqHoppingParametersDL_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInformationBlockType1_v1320_IEs::freqHoppingParametersDL_r13::interval_DLHoppingConfigCommonModeB_r13 interval_DLHoppingConfigCommonModeB_r13;
    interval_DLHoppingConfigCommonModeB_r13.set_interval_FDD_r13(interval_DLHoppingConfigCommonModeB_r13_interval_FDD_r13_int2);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1320_IEs::freqHoppingParametersDL_r13 freqHoppingParametersDL_r13(mpdcch_pdsch_HoppingNB_r13_nb2, interval_DLHoppingConfigCommonModeA_r13, interval_DLHoppingConfigCommonModeB_r13, 1);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'cellSelectionInfoCE1_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CellSelectionInfoCE1_r13 cellSelectionInfoCE1_r13(-22, -3);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'cellSelectionInfoCE1_v1360' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CellSelectionInfoCE1_v1360 cellSelectionInfoCE1_v1360(-1);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'tdd_Config_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    TDD_Config_v1430 tdd_Config_v1430(specialSubframePatterns_v1430_ssp10);

    /* Creating 'cellAccessRelatedInfoList_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInformationBlockType1_v1430_IEs::cellAccessRelatedInfoList_r14 cellAccessRelatedInfoList_r14;
    {
	/* Adding component #2 */
	CellAccessRelatedInfo_r14 comp2;
	fill_CellAccessRelatedInfo_r14(comp2);
	cellAccessRelatedInfoList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CellAccessRelatedInfo_r14 comp1;
	fill_CellAccessRelatedInfo_r14(comp1);
	cellAccessRelatedInfoList_r14.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'tdd_Config_v1450' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    TDD_Config_v1450 tdd_Config_v1450(specialSubframePatterns_v1450_ssp10_CRS_LessDwPTS);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'cellSelectionInfoCE_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    CellSelectionInfoCE_v1530 cellSelectionInfoCE_v1530(powerClass14dBm_Offset_r15_dB_6);

    /* Creating 'crs_IntfMitigConfig_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInformationBlockType1_v1530_IEs::crs_IntfMitigConfig_r15 crs_IntfMitigConfig_r15;
    crs_IntfMitigConfig_r15.set_crs_IntfMitigEnabled_15(0);

    /* Creating 'plmn_IdentityList_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PLMN_IdentityList_v1530 plmn_IdentityList_v1530;
    {
	/* Adding component #2 */
	PLMN_IdentityInfo_v1530 comp2;
	fill_PLMN_IdentityInfo_v1530(comp2);
	plmn_IdentityList_v1530.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_IdentityInfo_v1530 comp1;
	fill_PLMN_IdentityInfo_v1530(comp1);
	plmn_IdentityList_v1530.prepend(comp1);
    }

    /* Creating 'posSchedulingInfoList_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    PosSchedulingInfoList_r15 posSchedulingInfoList_r15;
    {
	/* Adding component #2 */
	PosSchedulingInfo_r15 comp2;
	fill_PosSchedulingInfo_r15(comp2);
	posSchedulingInfoList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PosSchedulingInfo_r15 comp1;
	fill_PosSchedulingInfo_r15(comp1);
	posSchedulingInfoList_r15.prepend(comp1);
    }

    /* Creating 'cellAccessRelatedInfo_5GC_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'cellAccessRelatedInfoList_5GC_r15' field of 'cellAccessRelatedInfo_5GC_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInformationBlockType1_v1530_IEs::cellAccessRelatedInfo_5GC_r15::cellAccessRelatedInfoList_5GC_r15 cellAccessRelatedInfoList_5GC_r15;
    {
	/* Adding component #2 */
	CellAccessRelatedInfo_5GC_r15 comp2;
	fill_CellAccessRelatedInfo_5GC_r15(comp2);
	cellAccessRelatedInfoList_5GC_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CellAccessRelatedInfo_5GC_r15 comp1;
	fill_CellAccessRelatedInfo_5GC_r15(comp1);
	cellAccessRelatedInfoList_5GC_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1530_IEs::cellAccessRelatedInfo_5GC_r15 cellAccessRelatedInfo_5GC_r15(cellBarred_5GC_r15_barred, cellBarred_5GC_CRS_r15_barred, cellAccessRelatedInfoList_5GC_r15);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SystemInformationBlockType1_v1530_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1530_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(hsdn_Cell_r15_true, cellSelectionInfoCE_v1530, crs_IntfMitigConfig_r15, cellBarred_CRS_r15_barred, plmn_IdentityList_v1530, posSchedulingInfoList_r15, cellAccessRelatedInfo_5GC_r15, ims_EmergencySupport5GC_r15_true, eCallOverIMS_Support5GC_r15_true, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1450_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(tdd_Config_v1450, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1430_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(eCallOverIMS_Support_r14_true, tdd_Config_v1430, cellAccessRelatedInfoList_r14, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1360_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(cellSelectionInfoCE1_v1360, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1350_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(cellSelectionInfoCE1_r13, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1320_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(freqHoppingParametersDL_r13, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1310_IEs decoded_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(hyperSFN_r13, eDRX_Allowed_r13_true, cellSelectionInfoCE_r13, bandwidthReducedAccessRelatedInfo_r13, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1250_IEs decoded_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(cellAccessRelatedInfo_v1250, cellSelectionInfo_v1250, freqBandIndicatorPriority_r12_true, decoded_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v1130_IEs decoded_nonCriticalExtension_nonCriticalExtension(tdd_Config_v1130, cellSelectionInfo_v1130, decoded_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v920_IEs decoded_nonCriticalExtension(ims_EmergencySupport_r9_true, cellSelectionInfo_v920, decoded_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SystemInformationBlockType1_v890_IEs sourceSystemInformationBlockType1Ext_decoded(decoded_lateNonCriticalExtension, decoded_nonCriticalExtension);

    sourceSystemInformationBlockType1Ext.set_decoded(sourceSystemInformationBlockType1Ext_decoded);

    /* Creating 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'reportProximityConfig_r9' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */

    /* Calling a fully-initializing constructor */
    ReportProximityConfig_r9 reportProximityConfig_r9(proximityIndicationEUTRA_r9_enabled, proximityIndicationUTRA_r9_enabled);

    /* Creating 'idc_Config_r11' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    /* Creating 'autonomousDenialParameters_r11' field of 'idc_Config_r11' field of 'sourceOtherConfig_r9' field of 'as_Config' field... */

    /* Calling a fully-initializing constructor */
    IDC_Config_r11::autonomousDenialParameters_r11 autonomousDenialParameters_r11(autonomousDenialSubframes_r11_n2, autonomousDenialValidity_r11_sf200);

    /* Creating 'idc_Indication_MRDC_r15' field of 'idc_Config_r11' field of 'sourceOtherConfig_r9' field of 'as_Config' field... */
    IDC_Config_r11::idc_Indication_MRDC_r15 idc_Indication_MRDC_r15;
    idc_Indication_MRDC_r15.set_release(0);

    /* Calling a fully-initializing constructor */
    IDC_Config_r11 idc_Config_r11(idc_Indication_r11_setup, autonomousDenialParameters_r11, idc_Indication_UL_CA_r11_setup, idc_HardwareSharingIndication_r13_setup, idc_Indication_MRDC_r15);

    /* Creating 'powerPrefIndicationConfig_r11' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    PowerPrefIndicationConfig_r11 powerPrefIndicationConfig_r11;
    powerPrefIndicationConfig_r11.set_release(0);

    /* Creating 'obtainLocationConfig_r11' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */

    /* Calling a fully-initializing constructor */
    ObtainLocationConfig_r11 obtainLocationConfig_r11(obtainLocation_r11_setup);

    /* Creating 'delayBudgetReportingConfig_r14' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    OtherConfig_r9::delayBudgetReportingConfig_r14 delayBudgetReportingConfig_r14;
    delayBudgetReportingConfig_r14.set_release(0);

    /* Creating 'rlm_ReportConfig_r14' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    OtherConfig_r9::rlm_ReportConfig_r14 rlm_ReportConfig_r14;
    rlm_ReportConfig_r14.set_release(0);

    /* Creating 'overheatingAssistanceConfig_r14' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    OtherConfig_r9::overheatingAssistanceConfig_r14 overheatingAssistanceConfig_r14;
    overheatingAssistanceConfig_r14.set_release(0);

    /* Creating 'measConfigAppLayer_r15' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    OtherConfig_r9::measConfigAppLayer_r15 measConfigAppLayer_r15;
    measConfigAppLayer_r15.set_release(0);

    /* Creating 'bt_NameListConfig_r15' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    BT_NameListConfig_r15 bt_NameListConfig_r15;
    fill_BT_NameListConfig_r15(bt_NameListConfig_r15);

    /* Creating 'wlan_NameListConfig_r15' field of 'sourceOtherConfig_r9' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    WLAN_NameListConfig_r15 wlan_NameListConfig_r15;
    fill_WLAN_NameListConfig_r15(wlan_NameListConfig_r15);

    /* Calling a fully-initializing constructor */
    OtherConfig_r9 sourceOtherConfig_r9(reportProximityConfig_r9, idc_Config_r11, powerPrefIndicationConfig_r11, obtainLocationConfig_r11, bw_PreferenceIndicationTimer_r14_s0, TRUE, delayBudgetReportingConfig_r14, rlm_ReportConfig_r14, overheatingAssistanceConfig_r14, measConfigAppLayer_r15, TRUE, bt_NameListConfig_r15, wlan_NameListConfig_r15);

    /* Creating 'sourceSCellConfigList_r10' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    SCellToAddModList_r10 sourceSCellConfigList_r10;
    fill_SCellToAddModList_r10(sourceSCellConfigList_r10);

    /* Creating 'sourceConfigSCG_r12' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'criticalExtensions' field of 'sourceConfigSCG_r12' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    SCG_Config_r12::criticalExtensions sourceConfigSCG_r12_criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field of 'sourceConfigSCG_r12' field of 'as_Config' field... */
    SCG_Config_r12::criticalExtensions::c1 criticalExtensions_c1;
    /* Setting 'scg_Config_r12' alternative of 'c1' alternative of 'criticalExtensions' field of 'sourceConfigSCG_r12' field... */
    /* Creating 'scg_RadioConfig_r12' field of 'scg_Config_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    SCG_ConfigPartSCG_r12 scg_RadioConfig_r12;
    fill_SCG_ConfigPartSCG_r12(scg_RadioConfig_r12);

    /* Creating 'nonCriticalExtension' field of 'scg_Config_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    SCG_Config_r12_IEs::nonCriticalExtension scg_Config_r12_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SCG_Config_r12_IEs scg_Config_r12(scg_RadioConfig_r12, scg_Config_r12_nonCriticalExtension);

    criticalExtensions_c1.set_scg_Config_r12(scg_Config_r12);

    sourceConfigSCG_r12_criticalExtensions.set_c1(criticalExtensions_c1);

    /* Calling a fully-initializing constructor */
    SCG_Config_r12 sourceConfigSCG_r12(sourceConfigSCG_r12_criticalExtensions);

    /* Creating 'as_ConfigNR_r15' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'sourceRB_ConfigNR_r15' field of 'as_ConfigNR_r15' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    static unsigned char sourceRB_ConfigNR_r15_value[] = {
	0x00
    };
    OssString sourceRB_ConfigNR_r15(sizeof(sourceRB_ConfigNR_r15_value), (char *)sourceRB_ConfigNR_r15_value);

    /* Creating 'sourceRB_ConfigSN_NR_r15' field of 'as_ConfigNR_r15' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    static unsigned char sourceRB_ConfigSN_NR_r15_value[] = {
	0x00
    };
    OssString sourceRB_ConfigSN_NR_r15(sizeof(sourceRB_ConfigSN_NR_r15_value), (char *)sourceRB_ConfigSN_NR_r15_value);

    /* Creating 'sourceOtherConfigSN_NR_r15' field of 'as_ConfigNR_r15' field of 'as_Config' field of 'handoverPreparationInformation_r8' alternative... */
    static unsigned char sourceOtherConfigSN_NR_r15_value[] = {
	0x00
    };
    OssString sourceOtherConfigSN_NR_r15(sizeof(sourceOtherConfigSN_NR_r15_value), (char *)sourceOtherConfigSN_NR_r15_value);

    /* Calling a fully-initializing constructor */
    AS_ConfigNR_r15 as_ConfigNR_r15(sourceRB_ConfigNR_r15, sourceRB_ConfigSN_NR_r15, sourceOtherConfigSN_NR_r15);

    /* Calling a fully-initializing constructor */
    AS_Config as_Config(sourceMeasConfig, sourceRadioResourceConfig, sourceSecurityAlgorithmConfig, sourceUE_Identity, sourceMasterInformationBlock, sourceSystemInformationBlockType1, sourceSystemInformationBlockType2, antennaInfoCommon, 0, sourceSystemInformationBlockType1Ext, sourceOtherConfig_r9, sourceSCellConfigList_r10, sourceConfigSCG_r12, as_ConfigNR_r15);

    /* Creating 'rrm_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'candidateCellInfoList_r10' field of 'rrm_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    CandidateCellInfoList_r10 candidateCellInfoList_r10;
    {
	/* Adding component #2 */
	CandidateCellInfo_r10 comp2;
	fill_CandidateCellInfo_r10(comp2);
	candidateCellInfoList_r10.prepend(comp2);
    }
    {
	/* Adding component #1 */
	CandidateCellInfo_r10 comp1;
	fill_CandidateCellInfo_r10(comp1);
	candidateCellInfoList_r10.prepend(comp1);
    }

    /* Creating 'candidateCellInfoListNR_r15' field of 'rrm_Config' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    MeasResultServFreqListNR_r15 candidateCellInfoListNR_r15;
    {
	/* Adding component #2 */
	MeasResultServFreqNR_r15 comp2;
	fill_MeasResultServFreqNR_r15(comp2);
	candidateCellInfoListNR_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultServFreqNR_r15 comp1;
	fill_MeasResultServFreqNR_r15(comp1);
	candidateCellInfoListNR_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RRM_Config rrm_Config(RRM_Config_ue_InactiveTime_s1, candidateCellInfoList_r10, candidateCellInfoListNR_r15);

    /* Creating 'as_Context' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'reestablishmentInfo' field of 'as_Context' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'targetCellShortMAC_I' field of 'reestablishmentInfo' field of 'as_Context' field of 'handoverPreparationInformation_r8' alternative... */
    static unsigned char targetCellShortMAC_I_value[] = {
	0x00, 0x00
    };
    OssBitString targetCellShortMAC_I(16, targetCellShortMAC_I_value);

    /* Creating 'additionalReestabInfoList' field of 'reestablishmentInfo' field of 'as_Context' field of 'handoverPreparationInformation_r8' alternative... */
    AdditionalReestabInfoList additionalReestabInfoList;
    fill_AdditionalReestabInfoList(additionalReestabInfoList);

    /* Calling a fully-initializing constructor */
    ReestablishmentInfo reestablishmentInfo(0, targetCellShortMAC_I, additionalReestabInfoList);

    /* Calling a fully-initializing constructor */
    AS_Context as_Context(reestablishmentInfo);

    /* Creating 'nonCriticalExtension' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'handoverPreparationInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'handoverPreparationInformation_r8' alternative... */
    HandoverPreparationInformation_v9d0_IEs::lateNonCriticalExtension nonCriticalExtension_lateNonCriticalExtension;
    /* Creating 'lateNonCriticalExtension' field */
    static unsigned char lateNonCriticalExtension_decoded_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension_decoded_lateNonCriticalExtension(sizeof(lateNonCriticalExtension_decoded_lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_decoded_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field */
    /* Creating 'as_Config_v10j0' field of 'nonCriticalExtension' field */
    /* Creating 'antennaInfoDedicatedPCell_v10i0' field of 'as_Config_v10j0' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    AntennaInfoDedicated_v10i0 antennaInfoDedicatedPCell_v10i0(maxLayersMIMO_r10_twoLayers);

    /* Calling a fully-initializing constructor */
    AS_Config_v10j0 as_Config_v10j0(antennaInfoDedicatedPCell_v10i0);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    HandoverPreparationInformation_v10j0_IEs::nonCriticalExtension lateNonCriticalExtension_decoded_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v10j0_IEs nonCriticalExtension_lateNonCriticalExtension_decoded_nonCriticalExtension(as_Config_v10j0, lateNonCriticalExtension_decoded_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v9j0_IEs nonCriticalExtension_lateNonCriticalExtension_decoded(lateNonCriticalExtension_decoded_lateNonCriticalExtension, nonCriticalExtension_lateNonCriticalExtension_decoded_nonCriticalExtension);

    nonCriticalExtension_lateNonCriticalExtension.set_decoded(nonCriticalExtension_lateNonCriticalExtension_decoded);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'handoverPreparationInformation_r8' alternative... */
    /* Creating 'as_Config_v9e0' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    AS_Config_v9e0 as_Config_v9e0(65536);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'as_Context_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'idc_Indication_r11' field of 'as_Context_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    AS_Context_v1130::idc_Indication_r11 idc_Indication_r11;
    /* Creating 'criticalExtensions' field */
    InDeviceCoexIndication_r11::criticalExtensions decoded_criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    InDeviceCoexIndication_r11::criticalExtensions::c1 decoded_criticalExtensions_c1;
    /* Setting 'inDeviceCoexIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'affectedCarrierFreqList_r11' field of 'inDeviceCoexIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    AffectedCarrierFreqList_r11 affectedCarrierFreqList_r11;
    {
	/* Adding component #2 */
	AffectedCarrierFreq_r11 comp2;
	fill_AffectedCarrierFreq_r11(comp2);
	affectedCarrierFreqList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	AffectedCarrierFreq_r11 comp1;
	fill_AffectedCarrierFreq_r11(comp1);
	affectedCarrierFreqList_r11.prepend(comp1);
    }

    /* Creating 'tdm_AssistanceInfo_r11' field of 'inDeviceCoexIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    TDM_AssistanceInfo_r11 tdm_AssistanceInfo_r11;
    /* Setting 'drx_AssistanceInfo_r11' alternative of 'tdm_AssistanceInfo_r11' field of 'inDeviceCoexIndication_r11' alternative of 'c1' alternative... */

    /* Calling a fully-initializing constructor */
    TDM_AssistanceInfo_r11::drx_AssistanceInfo_r11 drx_AssistanceInfo_r11(drx_CycleLength_r11_sf40, 0, drx_ActiveTime_r11_sf20);

    tdm_AssistanceInfo_r11.set_drx_AssistanceInfo_r11(drx_AssistanceInfo_r11);

    /* Creating 'lateNonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    static unsigned char inDeviceCoexIndication_r11_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString inDeviceCoexIndication_r11_lateNonCriticalExtension(sizeof(inDeviceCoexIndication_r11_lateNonCriticalExtension_value), (char *)inDeviceCoexIndication_r11_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'ul_CA_AssistanceInfo_r11' field of 'nonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative of 'c1' alternative... */
    /* Creating 'affectedCarrierFreqCombList_r11' field of 'ul_CA_AssistanceInfo_r11' field of 'nonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative... */
    AffectedCarrierFreqCombList_r11 affectedCarrierFreqCombList_r11;
    {
	/* Adding component #2 */
	AffectedCarrierFreqComb_r11 comp2;
	fill_AffectedCarrierFreqComb_r11(comp2);
	affectedCarrierFreqCombList_r11.prepend(comp2);
    }
    {
	/* Adding component #1 */
	AffectedCarrierFreqComb_r11 comp1;
	fill_AffectedCarrierFreqComb_r11(comp1);
	affectedCarrierFreqCombList_r11.prepend(comp1);
    }

    /* Creating 'victimSystemType_r11' field of 'ul_CA_AssistanceInfo_r11' field of 'nonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative... */

    /* Calling a fully-initializing constructor */
    VictimSystemType_r11 victimSystemType_r11(gps_r11_true, glonass_r11_true, bds_r11_true, galileo_r11_true, wlan_r11_true, bluetooth_r11_true);

    /* Calling a fully-initializing constructor */
    InDeviceCoexIndication_v11d0_IEs::ul_CA_AssistanceInfo_r11 ul_CA_AssistanceInfo_r11(affectedCarrierFreqCombList_r11, victimSystemType_r11);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative of 'c1' alternative... */
    /* Creating 'affectedCarrierFreqList_v1310' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative... */
    AffectedCarrierFreqList_v1310 affectedCarrierFreqList_v1310;
    {
	/* Adding component #2 */
	AffectedCarrierFreq_v1310 comp2;
	fill_AffectedCarrierFreq_v1310(comp2);
	affectedCarrierFreqList_v1310.prepend(comp2);
    }
    {
	/* Adding component #1 */
	AffectedCarrierFreq_v1310 comp1;
	fill_AffectedCarrierFreq_v1310(comp1);
	affectedCarrierFreqList_v1310.prepend(comp1);
    }

    /* Creating 'affectedCarrierFreqCombList_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative... */
    AffectedCarrierFreqCombList_r13 affectedCarrierFreqCombList_r13;
    {
	/* Adding component #2 */
	AffectedCarrierFreqComb_r13 comp2;
	fill_AffectedCarrierFreqComb_r13(comp2);
	affectedCarrierFreqCombList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	AffectedCarrierFreqComb_r13 comp1;
	fill_AffectedCarrierFreqComb_r13(comp1);
	affectedCarrierFreqCombList_r13.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'inDeviceCoexIndication_r11' alternative... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'mrdc_AssistanceInfo_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'affectedCarrierFreqCombInfoListMRDC_r15' field of 'mrdc_AssistanceInfo_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MRDC_AssistanceInfo_r15::affectedCarrierFreqCombInfoListMRDC_r15 affectedCarrierFreqCombInfoListMRDC_r15;
    {
	/* Adding component #2 */
	AffectedCarrierFreqCombInfoMRDC_r15 comp2;
	fill_AffectedCarrierFreqCombInfoMRDC_r15(comp2);
	affectedCarrierFreqCombInfoListMRDC_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	AffectedCarrierFreqCombInfoMRDC_r15 comp1;
	fill_AffectedCarrierFreqCombInfoMRDC_r15(comp1);
	affectedCarrierFreqCombInfoListMRDC_r15.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    MRDC_AssistanceInfo_r15 mrdc_AssistanceInfo_r15(affectedCarrierFreqCombInfoListMRDC_r15);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    InDeviceCoexIndication_v1530_IEs::nonCriticalExtension inDeviceCoexIndication_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    InDeviceCoexIndication_v1530_IEs inDeviceCoexIndication_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(mrdc_AssistanceInfo_r15, inDeviceCoexIndication_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    InDeviceCoexIndication_v1360_IEs inDeviceCoexIndication_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(hardwareSharingProblem_r13_true, inDeviceCoexIndication_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    InDeviceCoexIndication_v1310_IEs inDeviceCoexIndication_r11_nonCriticalExtension_nonCriticalExtension(affectedCarrierFreqList_v1310, affectedCarrierFreqCombList_r13, inDeviceCoexIndication_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    InDeviceCoexIndication_v11d0_IEs inDeviceCoexIndication_r11_nonCriticalExtension(ul_CA_AssistanceInfo_r11, inDeviceCoexIndication_r11_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    InDeviceCoexIndication_r11_IEs inDeviceCoexIndication_r11(affectedCarrierFreqList_r11, tdm_AssistanceInfo_r11, inDeviceCoexIndication_r11_lateNonCriticalExtension, inDeviceCoexIndication_r11_nonCriticalExtension);

    decoded_criticalExtensions_c1.set_inDeviceCoexIndication_r11(inDeviceCoexIndication_r11);

    decoded_criticalExtensions.set_c1(decoded_criticalExtensions_c1);

    /* Calling a fully-initializing constructor */
    InDeviceCoexIndication_r11 idc_Indication_r11_decoded(decoded_criticalExtensions);

    idc_Indication_r11.set_decoded(idc_Indication_r11_decoded);

    /* Creating 'mbmsInterestIndication_r11' field of 'as_Context_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    AS_Context_v1130::mbmsInterestIndication_r11 mbmsInterestIndication_r11;
    MBMSInterestIndication_r11 mbmsInterestIndication_r11_decoded;
    fill_decoded_2(mbmsInterestIndication_r11_decoded);
    mbmsInterestIndication_r11.set_decoded(mbmsInterestIndication_r11_decoded);

    /* Creating 'powerPrefIndication_r11' field of 'as_Context_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    AS_Context_v1130::powerPrefIndication_r11 powerPrefIndication_r11;
    /* Creating 'criticalExtensions' field */
    UEAssistanceInformation_r11::criticalExtensions powerPrefIndication_r11_decoded_criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    UEAssistanceInformation_r11::criticalExtensions::c1 powerPrefIndication_r11_decoded_criticalExtensions_c1;
    /* Setting 'ueAssistanceInformation_r11' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'lateNonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    static unsigned char ueAssistanceInformation_r11_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString ueAssistanceInformation_r11_lateNonCriticalExtension(sizeof(ueAssistanceInformation_r11_lateNonCriticalExtension_value), (char *)ueAssistanceInformation_r11_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'bw_Preference_r14' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative of 'c1' alternative... */

    /* Calling a fully-initializing constructor */
    BW_Preference_r14 bw_Preference_r14(dl_Preference_r14_mhz1dot4, ul_Preference_r14_mhz1dot4);

    /* Creating 'sps_AssistanceInformation_r14' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative of 'c1' alternative... */
    /* Creating 'trafficPatternInfoListSL_r14' field of 'sps_AssistanceInformation_r14' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative... */
    TrafficPatternInfoList_r14 trafficPatternInfoListSL_r14;
    {
	/* Adding component #2 */
	TrafficPatternInfo_r14 comp2;
	fill_TrafficPatternInfo_r14(comp2);
	trafficPatternInfoListSL_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	TrafficPatternInfo_r14 comp1;
	fill_TrafficPatternInfo_r14(comp1);
	trafficPatternInfoListSL_r14.prepend(comp1);
    }

    /* Creating 'trafficPatternInfoListUL_r14' field of 'sps_AssistanceInformation_r14' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative... */
    TrafficPatternInfoList_r14 trafficPatternInfoListUL_r14;
    {
	/* Adding component #2 */
	TrafficPatternInfo_r14 comp2;
	fill_TrafficPatternInfo_r14(comp2);
	trafficPatternInfoListUL_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	TrafficPatternInfo_r14 comp1;
	fill_TrafficPatternInfo_r14(comp1);
	trafficPatternInfoListUL_r14.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    UEAssistanceInformation_v1430_IEs::sps_AssistanceInformation_r14 sps_AssistanceInformation_r14(trafficPatternInfoListSL_r14, trafficPatternInfoListUL_r14);

    /* Creating 'rlm_Report_r14' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative of 'c1' alternative... */

    /* Calling a fully-initializing constructor */
    UEAssistanceInformation_v1430_IEs::rlm_Report_r14 rlm_Report_r14(earlyOutOfSync, excessRep1);

    /* Creating 'delayBudgetReport_r14' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative of 'c1' alternative... */
    DelayBudgetReport_r14 delayBudgetReport_r14;
    delayBudgetReport_r14.set_type1(msMinus1280);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative of 'c1' alternative... */
    /* Creating 'overheatingAssistance_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative... */
    /* Creating 'reducedUE_Category' field of 'overheatingAssistance_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    OverheatingAssistance_r14::reducedUE_Category reducedUE_Category(0, 0);

    /* Creating 'reducedMaxCCs' field of 'overheatingAssistance_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    OverheatingAssistance_r14::reducedMaxCCs reducedMaxCCs(0, 0);

    /* Calling a fully-initializing constructor */
    OverheatingAssistance_r14 overheatingAssistance_r14(reducedUE_Category, reducedMaxCCs);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueAssistanceInformation_r11' alternative... */
    /* Creating 'sps_AssistanceInformation_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'trafficPatternInfoListSL_v1530' field of 'sps_AssistanceInformation_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    TrafficPatternInfoList_v1530 trafficPatternInfoListSL_v1530;
    {
	/* Adding component #2 */
	TrafficPatternInfo_v1530 comp2;
	fill_TrafficPatternInfo_v1530(comp2);
	trafficPatternInfoListSL_v1530.prepend(comp2);
    }
    {
	/* Adding component #1 */
	TrafficPatternInfo_v1530 comp1;
	fill_TrafficPatternInfo_v1530(comp1);
	trafficPatternInfoListSL_v1530.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    UEAssistanceInformation_v1530_IEs::sps_AssistanceInformation_v1530 sps_AssistanceInformation_v1530(trafficPatternInfoListSL_v1530);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UEAssistanceInformation_v1530_IEs::nonCriticalExtension ueAssistanceInformation_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UEAssistanceInformation_v1530_IEs ueAssistanceInformation_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(sps_AssistanceInformation_v1530, ueAssistanceInformation_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UEAssistanceInformation_v1450_IEs ueAssistanceInformation_r11_nonCriticalExtension_nonCriticalExtension(overheatingAssistance_r14, ueAssistanceInformation_r11_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UEAssistanceInformation_v1430_IEs ueAssistanceInformation_r11_nonCriticalExtension(bw_Preference_r14, sps_AssistanceInformation_r14, rlm_Report_r14, delayBudgetReport_r14, ueAssistanceInformation_r11_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UEAssistanceInformation_r11_IEs ueAssistanceInformation_r11(powerPrefIndication_r11_normal, ueAssistanceInformation_r11_lateNonCriticalExtension, ueAssistanceInformation_r11_nonCriticalExtension);

    powerPrefIndication_r11_decoded_criticalExtensions_c1.set_ueAssistanceInformation_r11(ueAssistanceInformation_r11);

    powerPrefIndication_r11_decoded_criticalExtensions.set_c1(powerPrefIndication_r11_decoded_criticalExtensions_c1);

    /* Calling a fully-initializing constructor */
    UEAssistanceInformation_r11 powerPrefIndication_r11_decoded(powerPrefIndication_r11_decoded_criticalExtensions);

    powerPrefIndication_r11.set_decoded(powerPrefIndication_r11_decoded);

    /* Creating 'sidelinkUEInformation_r12' field of 'as_Context_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    AS_Context_v1130::sidelinkUEInformation_r12 sidelinkUEInformation_r12;
    /* Creating 'criticalExtensions' field */
    SidelinkUEInformation_r12::criticalExtensions sidelinkUEInformation_r12_decoded_criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    SidelinkUEInformation_r12::criticalExtensions::c1 sidelinkUEInformation_r12_decoded_criticalExtensions_c1;
    /* Setting 'sidelinkUEInformation_r12' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'commTxResourceReq_r12' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'destinationInfoList_r12' field of 'commTxResourceReq_r12' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */
    SL_DestinationInfoList_r12 destinationInfoList_r12;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp2(24, comp2_value);
	destinationInfoList_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp1(24, comp1_value);
	destinationInfoList_r12.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_CommTxResourceReq_r12 commTxResourceReq_r12(0, destinationInfoList_r12);

    /* Creating 'lateNonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    static unsigned char sidelinkUEInformation_r12_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString sidelinkUEInformation_r12_lateNonCriticalExtension(sizeof(sidelinkUEInformation_r12_lateNonCriticalExtension_value), (char *)sidelinkUEInformation_r12_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'commTxResourceReqUC_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */
    /* Creating 'destinationInfoList_r12' field of 'commTxResourceReqUC_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative... */
    SL_DestinationInfoList_r12 commTxResourceReqUC_r13_destinationInfoList_r12;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp2(24, comp2_value);
	commTxResourceReqUC_r13_destinationInfoList_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp1(24, comp1_value);
	commTxResourceReqUC_r13_destinationInfoList_r12.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_CommTxResourceReq_r12 commTxResourceReqUC_r13(0, commTxResourceReqUC_r13_destinationInfoList_r12);

    /* Creating 'commTxResourceInfoReqRelay_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */
    /* Creating 'commTxResourceReqRelay_r13' field of 'commTxResourceInfoReqRelay_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative... */
    /* Creating 'destinationInfoList_r12' field of 'commTxResourceReqRelay_r13' field of 'commTxResourceInfoReqRelay_r13' field of 'nonCriticalExtension' field... */
    SL_DestinationInfoList_r12 commTxResourceReqRelay_r13_destinationInfoList_r12;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp2(24, comp2_value);
	commTxResourceReqRelay_r13_destinationInfoList_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp1(24, comp1_value);
	commTxResourceReqRelay_r13_destinationInfoList_r12.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_CommTxResourceReq_r12 commTxResourceReqRelay_r13(0, commTxResourceReqRelay_r13_destinationInfoList_r12);

    /* Creating 'commTxResourceReqRelayUC_r13' field of 'commTxResourceInfoReqRelay_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative... */
    /* Creating 'destinationInfoList_r12' field of 'commTxResourceReqRelayUC_r13' field of 'commTxResourceInfoReqRelay_r13' field of 'nonCriticalExtension' field... */
    SL_DestinationInfoList_r12 commTxResourceReqRelayUC_r13_destinationInfoList_r12;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp2(24, comp2_value);
	commTxResourceReqRelayUC_r13_destinationInfoList_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00, 0x00, 0x00
	};
	OssBitString comp1(24, comp1_value);
	commTxResourceReqRelayUC_r13_destinationInfoList_r12.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_CommTxResourceReq_r12 commTxResourceReqRelayUC_r13(0, commTxResourceReqRelayUC_r13_destinationInfoList_r12);

    /* Calling a fully-initializing constructor */
    SidelinkUEInformation_v1310_IEs::commTxResourceInfoReqRelay_r13 commTxResourceInfoReqRelay_r13(commTxResourceReqRelay_r13, commTxResourceReqRelayUC_r13, relayUE);

    /* Creating 'discTxResourceReq_v1310' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */
    /* Creating 'discTxResourceReqAddFreq_r13' field of 'discTxResourceReq_v1310' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative... */
    SL_DiscTxResourceReqPerFreqList_r13 discTxResourceReqAddFreq_r13;
    {
	/* Adding component #2 */
	SL_DiscTxResourceReq_r13 comp2;
	fill_SL_DiscTxResourceReq_r13(comp2);
	discTxResourceReqAddFreq_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_DiscTxResourceReq_r13 comp1;
	fill_SL_DiscTxResourceReq_r13(comp1);
	discTxResourceReqAddFreq_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SidelinkUEInformation_v1310_IEs::discTxResourceReq_v1310 discTxResourceReq_v1310(1, discTxResourceReqAddFreq_r13);

    /* Creating 'discTxResourceReqPS_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */

    /* Calling a fully-initializing constructor */
    SL_DiscTxResourceReq_r13 discTxResourceReqPS_r13(1, 1);

    /* Creating 'discRxGapReq_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */
    SL_GapRequest_r13 discRxGapReq_r13;
    {
	/* Adding component #2 */
	SL_GapFreqInfo_r13 comp2;
	fill_SL_GapFreqInfo_r13(comp2);
	discRxGapReq_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_GapFreqInfo_r13 comp1;
	fill_SL_GapFreqInfo_r13(comp1);
	discRxGapReq_r13.prepend(comp1);
    }

    /* Creating 'discTxGapReq_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */
    SL_GapRequest_r13 discTxGapReq_r13;
    {
	/* Adding component #2 */
	SL_GapFreqInfo_r13 comp2;
	fill_SL_GapFreqInfo_r13(comp2);
	discTxGapReq_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_GapFreqInfo_r13 comp1;
	fill_SL_GapFreqInfo_r13(comp1);
	discTxGapReq_r13.prepend(comp1);
    }

    /* Creating 'discSysInfoReportFreqList_r13' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */
    SL_DiscSysInfoReportFreqList_r13 discSysInfoReportFreqList_r13;
    {
	/* Adding component #2 */
	SL_DiscSysInfoReport_r13 comp2;
	fill_SL_DiscSysInfoReport_r13(comp2);
	discSysInfoReportFreqList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_DiscSysInfoReport_r13 comp1;
	fill_SL_DiscSysInfoReport_r13(comp1);
	discSysInfoReportFreqList_r13.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative of 'c1' alternative... */
    /* Creating 'v2x_CommRxInterestedFreqList_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative... */
    SL_V2X_CommFreqList_r14 v2x_CommRxInterestedFreqList_r14;
    v2x_CommRxInterestedFreqList_r14.prepend((OSS_UINT32)0);
    v2x_CommRxInterestedFreqList_r14.prepend((OSS_UINT32)0);

    /* Creating 'v2x_CommTxResourceReq_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative... */
    SL_V2X_CommTxFreqList_r14 v2x_CommTxResourceReq_r14;
    {
	/* Adding component #2 */
	SL_V2X_CommTxResourceReq_r14 comp2;
	fill_SL_V2X_CommTxResourceReq_r14(comp2);
	v2x_CommTxResourceReq_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_V2X_CommTxResourceReq_r14 comp1;
	fill_SL_V2X_CommTxResourceReq_r14(comp1);
	v2x_CommTxResourceReq_r14.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'sidelinkUEInformation_r12' alternative... */
    /* Creating 'reliabilityInfoListSL_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SL_ReliabilityList_r15 reliabilityInfoListSL_r15;
    reliabilityInfoListSL_r15.prepend(1);
    reliabilityInfoListSL_r15.prepend(1);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SidelinkUEInformation_v1530_IEs::nonCriticalExtension sidelinkUEInformation_r12_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SidelinkUEInformation_v1530_IEs sidelinkUEInformation_r12_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(reliabilityInfoListSL_r15, sidelinkUEInformation_r12_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SidelinkUEInformation_v1430_IEs sidelinkUEInformation_r12_nonCriticalExtension_nonCriticalExtension(v2x_CommRxInterestedFreqList_r14, p2x_CommTxType_r14_true, v2x_CommTxResourceReq_r14, sidelinkUEInformation_r12_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SidelinkUEInformation_v1310_IEs sidelinkUEInformation_r12_nonCriticalExtension(commTxResourceReqUC_r13, commTxResourceInfoReqRelay_r13, discTxResourceReq_v1310, discTxResourceReqPS_r13, discRxGapReq_r13, discTxGapReq_r13, discSysInfoReportFreqList_r13, sidelinkUEInformation_r12_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SidelinkUEInformation_r12_IEs c1_sidelinkUEInformation_r12(0, commTxResourceReq_r12, discRxInterest_r12_true, 1, sidelinkUEInformation_r12_lateNonCriticalExtension, sidelinkUEInformation_r12_nonCriticalExtension);

    sidelinkUEInformation_r12_decoded_criticalExtensions_c1.set_sidelinkUEInformation_r12(c1_sidelinkUEInformation_r12);

    sidelinkUEInformation_r12_decoded_criticalExtensions.set_c1(sidelinkUEInformation_r12_decoded_criticalExtensions_c1);

    /* Calling a fully-initializing constructor */
    SidelinkUEInformation_r12 sidelinkUEInformation_r12_decoded(sidelinkUEInformation_r12_decoded_criticalExtensions);

    sidelinkUEInformation_r12.set_decoded(sidelinkUEInformation_r12_decoded);

    /* Creating 'sourceContextEN_DC_r15' field of 'as_Context_v1130' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    static unsigned char sourceContextEN_DC_r15_value[] = {
	0x00
    };
    OssString sourceContextEN_DC_r15(sizeof(sourceContextEN_DC_r15_value), (char *)sourceContextEN_DC_r15_value);

    /* Calling a fully-initializing constructor */
    AS_Context_v1130 as_Context_v1130(idc_Indication_r11, mbmsInterestIndication_r11, powerPrefIndication_r11, sidelinkUEInformation_r12, sourceContextEN_DC_r15);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'as_Config_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'thresholdRSRP_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12::thresholdRSRP_r12 thresholdRSRP_r12(0, 0);

    /* Creating 'thresholdRSRQ_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12::thresholdRSRQ_r12 thresholdRSRQ_r12(0, 0);

    /* Creating 'thresholdRSRQ_OnAllSymbolsWithWB_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12::thresholdRSRQ_OnAllSymbolsWithWB_r12 thresholdRSRQ_OnAllSymbolsWithWB_r12(0, 0);

    /* Creating 'thresholdRSRQ_OnAllSymbols_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12::thresholdRSRQ_OnAllSymbols_r12 thresholdRSRQ_OnAllSymbols_r12(0, 0);

    /* Creating 'thresholdRSRQ_WB_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12::thresholdRSRQ_WB_r12 thresholdRSRQ_WB_r12(0, 0);

    /* Creating 'thresholdChannelUtilization_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12::thresholdChannelUtilization_r12 thresholdChannelUtilization_r12(0, 0);

    /* Creating 'thresholdBackhaul_Bandwidth_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12::thresholdBackhaul_Bandwidth_r12 thresholdBackhaul_Bandwidth_r12(r0, r0, r0, r0);

    /* Creating 'thresholdWLAN_RSSI_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12::thresholdWLAN_RSSI_r12 thresholdWLAN_RSSI_r12(0, 0);

    /* Creating 'offloadPreferenceIndicator_r12' field of 'sourceWlan_OffloadConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    static unsigned char offloadPreferenceIndicator_r12_value[] = {
	0x00, 0x00
    };
    OssBitString offloadPreferenceIndicator_r12(16, offloadPreferenceIndicator_r12_value);

    /* Calling a fully-initializing constructor */
    WLAN_OffloadConfig_r12 sourceWlan_OffloadConfig_r12(thresholdRSRP_r12, thresholdRSRQ_r12, thresholdRSRQ_OnAllSymbolsWithWB_r12, thresholdRSRQ_OnAllSymbols_r12, thresholdRSRQ_WB_r12, thresholdChannelUtilization_r12, thresholdBackhaul_Bandwidth_r12, thresholdWLAN_RSSI_r12, offloadPreferenceIndicator_r12, 0);

    /* Creating 'sourceSL_CommConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'commTxResources_r12' field of 'sourceSL_CommConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_CommConfig_r12::commTxResources_r12 commTxResources_r12;
    commTxResources_r12.set_release(0);

    /* Creating 'commTxResources_v1310' field of 'sourceSL_CommConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_CommConfig_r12::commTxResources_v1310 commTxResources_v1310;
    commTxResources_v1310.set_release(0);

    /* Calling a fully-initializing constructor */
    SL_CommConfig_r12 sourceSL_CommConfig_r12(commTxResources_r12, commTxResources_v1310, TRUE);

    /* Creating 'sourceSL_DiscConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'discTxResources_r12' field of 'sourceSL_DiscConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_DiscConfig_r12::discTxResources_r12 discTxResources_r12;
    discTxResources_r12.set_release(0);

    /* Creating 'discTF_IndexList_v1260' field of 'sourceSL_DiscConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_DiscConfig_r12::discTF_IndexList_v1260 discTF_IndexList_v1260;
    discTF_IndexList_v1260.set_release(0);

    /* Creating 'discTxResourcesPS_r13' field of 'sourceSL_DiscConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_DiscConfig_r12::discTxResourcesPS_r13 discTxResourcesPS_r13;
    discTxResourcesPS_r13.set_release(0);

    /* Creating 'discTxInterFreqInfo_r13' field of 'sourceSL_DiscConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_DiscConfig_r12::discTxInterFreqInfo_r13 discTxInterFreqInfo_r13;
    discTxInterFreqInfo_r13.set_release(0);

    /* Creating 'discRxGapConfig_r13' field of 'sourceSL_DiscConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_DiscConfig_r12::discRxGapConfig_r13 discRxGapConfig_r13;
    discRxGapConfig_r13.set_release(0);

    /* Creating 'discTxGapConfig_r13' field of 'sourceSL_DiscConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_DiscConfig_r12::discTxGapConfig_r13 discTxGapConfig_r13;
    discTxGapConfig_r13.set_release(0);

    /* Creating 'discSysInfoToReportConfig_r13' field of 'sourceSL_DiscConfig_r12' field of 'as_Config_v1250' field of 'nonCriticalExtension' field... */
    SL_DiscConfig_r12::discSysInfoToReportConfig_r13 discSysInfoToReportConfig_r13;
    discSysInfoToReportConfig_r13.set_release(0);

    /* Calling a fully-initializing constructor */
    SL_DiscConfig_r12 sourceSL_DiscConfig_r12(discTxResources_r12, discTF_IndexList_v1260, discTxResourcesPS_r13, discTxInterFreqInfo_r13, TRUE, discRxGapConfig_r13, discTxGapConfig_r13, discSysInfoToReportConfig_r13);

    /* Calling a fully-initializing constructor */
    AS_Config_v1250 as_Config_v1250(sourceWlan_OffloadConfig_r12, sourceSL_CommConfig_r12, sourceSL_DiscConfig_r12);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'as_Config_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'sourceSCellConfigList_r13' field of 'as_Config_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SCellToAddModListExt_r13 sourceSCellConfigList_r13;
    fill_SCellToAddModListExt_r13(sourceSCellConfigList_r13);

    /* Creating 'sourceRCLWI_Configuration_r13' field of 'as_Config_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    RCLWI_Configuration_r13 sourceRCLWI_Configuration_r13;
    sourceRCLWI_Configuration_r13.set_release(0);

    /* Calling a fully-initializing constructor */
    AS_Config_v1320 as_Config_v1320(sourceSCellConfigList_r13, sourceRCLWI_Configuration_r13);

    /* Creating 'as_Context_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'wlanConnectionStatusReport_r13' field of 'as_Context_v1320' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    AS_Context_v1320::wlanConnectionStatusReport_r13 wlanConnectionStatusReport_r13;
    /* Creating 'criticalExtensions' field */
    WLANConnectionStatusReport_r13::criticalExtensions wlanConnectionStatusReport_r13_decoded_criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    WLANConnectionStatusReport_r13::criticalExtensions::c1 wlanConnectionStatusReport_r13_decoded_criticalExtensions_c1;
    /* Setting 'wlanConnectionStatusReport_r13' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'lateNonCriticalExtension' field of 'wlanConnectionStatusReport_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    static unsigned char wlanConnectionStatusReport_r13_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString wlanConnectionStatusReport_r13_lateNonCriticalExtension(sizeof(wlanConnectionStatusReport_r13_lateNonCriticalExtension_value), (char *)wlanConnectionStatusReport_r13_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'wlanConnectionStatusReport_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'wlanConnectionStatusReport_r13' alternative of 'c1' alternative... */
    WLANConnectionStatusReport_v1430_IEs::nonCriticalExtension wlanConnectionStatusReport_r13_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    WLANConnectionStatusReport_v1430_IEs wlanConnectionStatusReport_r13_nonCriticalExtension(suspended, wlanConnectionStatusReport_r13_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    WLANConnectionStatusReport_r13_IEs c1_wlanConnectionStatusReport_r13(successfulAssociation, wlanConnectionStatusReport_r13_lateNonCriticalExtension, wlanConnectionStatusReport_r13_nonCriticalExtension);

    wlanConnectionStatusReport_r13_decoded_criticalExtensions_c1.set_wlanConnectionStatusReport_r13(c1_wlanConnectionStatusReport_r13);

    wlanConnectionStatusReport_r13_decoded_criticalExtensions.set_c1(wlanConnectionStatusReport_r13_decoded_criticalExtensions_c1);

    /* Calling a fully-initializing constructor */
    WLANConnectionStatusReport_r13 wlanConnectionStatusReport_r13_decoded(wlanConnectionStatusReport_r13_decoded_criticalExtensions);

    wlanConnectionStatusReport_r13.set_decoded(wlanConnectionStatusReport_r13_decoded);

    /* Calling a fully-initializing constructor */
    AS_Context_v1320 as_Context_v1320(wlanConnectionStatusReport_r13);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'as_Config_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'commTxResources_r14' field of 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field... */
    SL_V2X_ConfigDedicated_r14::commTxResources_r14 commTxResources_r14;
    commTxResources_r14.set_release(0);

    /* Creating 'v2x_InterFreqInfoList_r14' field of 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field... */
    SL_InterFreqInfoListV2X_r14 v2x_InterFreqInfoList_r14;
    {
	/* Adding component #2 */
	SL_InterFreqInfoV2X_r14 comp2;
	fill_SL_InterFreqInfoV2X_r14(comp2);
	v2x_InterFreqInfoList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_InterFreqInfoV2X_r14 comp1;
	fill_SL_InterFreqInfoV2X_r14(comp1);
	v2x_InterFreqInfoList_r14.prepend(comp1);
    }

    /* Creating 'cbr_DedicatedTxConfigList_r14' field of 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field... */
    /* Creating 'cbr_RangeCommonConfigList_r14' field of 'cbr_DedicatedTxConfigList_r14' field of 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field... */
    SL_CBR_CommonTxConfigList_r14::cbr_RangeCommonConfigList_r14 cbr_RangeCommonConfigList_r14;
    {
	/* Adding component #2 */
	SL_CBR_Levels_Config_r14 comp2;
	fill_SL_CBR_Levels_Config_r14(comp2);
	cbr_RangeCommonConfigList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_CBR_Levels_Config_r14 comp1;
	fill_SL_CBR_Levels_Config_r14(comp1);
	cbr_RangeCommonConfigList_r14.prepend(comp1);
    }

    /* Creating 'sl_CBR_PSSCH_TxConfigList_r14' field of 'cbr_DedicatedTxConfigList_r14' field of 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field... */
    SL_CBR_CommonTxConfigList_r14::sl_CBR_PSSCH_TxConfigList_r14 sl_CBR_PSSCH_TxConfigList_r14;
    {
	/* Adding component #2 */
	SL_CBR_PSSCH_TxConfig_r14 comp2;
	fill_SL_CBR_PSSCH_TxConfig_r14(comp2);
	sl_CBR_PSSCH_TxConfigList_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SL_CBR_PSSCH_TxConfig_r14 comp1;
	fill_SL_CBR_PSSCH_TxConfig_r14(comp1);
	sl_CBR_PSSCH_TxConfigList_r14.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    SL_CBR_CommonTxConfigList_r14 cbr_DedicatedTxConfigList_r14(cbr_RangeCommonConfigList_r14, sl_CBR_PSSCH_TxConfigList_r14);

    /* Creating 'commTxResources_v1530' field of 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field... */
    SL_V2X_ConfigDedicated_r14::commTxResources_v1530 commTxResources_v1530;
    commTxResources_v1530.set_release(0);

    /* Creating 'v2x_PacketDuplicationConfig_r15' field of 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field... */
    SL_V2X_PacketDuplicationConfig_r15 v2x_PacketDuplicationConfig_r15;
    fill_SL_V2X_PacketDuplicationConfig_r15(v2x_PacketDuplicationConfig_r15);

    /* Creating 'syncFreqList_r15' field of 'sourceSL_V2X_CommConfig_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field... */
    SL_V2X_SyncFreqList_r15 syncFreqList_r15;
    syncFreqList_r15.prepend((OSS_UINT32)0);
    syncFreqList_r15.prepend((OSS_UINT32)0);

    /* Calling a fully-initializing constructor */
    SL_V2X_ConfigDedicated_r14 sourceSL_V2X_CommConfig_r14(commTxResources_r14, v2x_InterFreqInfoList_r14, 1, SL_TypeTxSync_r14_gnss, cbr_DedicatedTxConfigList_r14, commTxResources_v1530, v2x_PacketDuplicationConfig_r15, syncFreqList_r15, SL_V2X_ConfigDedicated_r14_slss_TxMultiFreq_r15_true);

    /* Creating 'sourceLWA_Config_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'lwa_MobilityConfig_r13' field of 'sourceLWA_Config_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field... */
    /* Creating 'wlan_ToReleaseList_r13' field of 'lwa_MobilityConfig_r13' field of 'sourceLWA_Config_r14' field of 'as_Config_v1430' field... */
    WLAN_Id_List_r13 wlan_ToReleaseList_r13;
    fill_WLAN_Id_List_r13(wlan_ToReleaseList_r13);

    /* Creating 'wlan_ToAddList_r13' field of 'lwa_MobilityConfig_r13' field of 'sourceLWA_Config_r14' field of 'as_Config_v1430' field... */
    WLAN_Id_List_r13 wlan_ToAddList_r13;
    fill_WLAN_Id_List_r13(wlan_ToAddList_r13);

    /* Creating 'wlan_SuspendConfig_r14' field of 'lwa_MobilityConfig_r13' field of 'sourceLWA_Config_r14' field of 'as_Config_v1430' field... */
    WLAN_SuspendConfig_r14 wlan_SuspendConfig_r14;
    fill_WLAN_SuspendConfig_r14(wlan_SuspendConfig_r14);

    /* Calling a fully-initializing constructor */
    WLAN_MobilityConfig_r13 lwa_MobilityConfig_r13(wlan_ToReleaseList_r13, wlan_ToAddList_r13, associationTimer_r13_s10, successReportRequested_r13_true, wlan_SuspendConfig_r14);

    /* Creating 'wt_MAC_Address_r14' field of 'sourceLWA_Config_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field... */
    static unsigned char wt_MAC_Address_r14_value[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };
    OssString wt_MAC_Address_r14(sizeof(wt_MAC_Address_r14_value), (char *)wt_MAC_Address_r14_value);

    /* Calling a fully-initializing constructor */
    LWA_Config_r13 sourceLWA_Config_r14(lwa_MobilityConfig_r13, 0, wt_MAC_Address_r14);

    /* Creating 'sourceWLAN_MeasResult_r14' field of 'as_Config_v1430' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MeasResultListWLAN_r13 sourceWLAN_MeasResult_r14;
    {
	/* Adding component #2 */
	MeasResultWLAN_r13 comp2;
	fill_MeasResultWLAN_r13(comp2);
	sourceWLAN_MeasResult_r14.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultWLAN_r13 comp1;
	fill_MeasResultWLAN_r13(comp1);
	sourceWLAN_MeasResult_r14.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    AS_Config_v1430 as_Config_v1430(sourceSL_V2X_CommConfig_r14, sourceLWA_Config_r14, sourceWLAN_MeasResult_r14);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    HandoverPreparationInformation_v1430_IEs::nonCriticalExtension handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v1430_IEs handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(as_Config_v1430, makeBeforeBreakReq_r14_true, handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v1320_IEs handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(as_Config_v1320, as_Context_v1320, handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v1250_IEs handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(0, as_Config_v1250, handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v1130_IEs handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(as_Context_v1130, handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v9e0_IEs handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(as_Config_v9e0, handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v9d0_IEs handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension(nonCriticalExtension_lateNonCriticalExtension, handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_v920_IEs nonCriticalExtension(ue_ConfigRelease_r9_rel9, handoverPreparationInformation_r8_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_r8_IEs handoverPreparationInformation_r8(ue_RadioAccessCapabilityInfo, as_Config, rrm_Config, as_Context, nonCriticalExtension);

    c1.set_handoverPreparationInformation_r8(handoverPreparationInformation_r8);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new HandoverPreparationInformation(criticalExtensions);
}

static void fill_PLMN_RAN_AreaCell_r15(PLMN_RAN_AreaCell_r15 & value)
{
    /* Setting 'plmn_Identity_r15' field */
    PLMN_Identity plmn_Identity_r15;
    fill_PLMN_Identity(plmn_Identity_r15);
    value.set_plmn_Identity_r15(plmn_Identity_r15);

    /* Setting 'ran_AreaCells_r15' field */
    PLMN_RAN_AreaCell_r15::ran_AreaCells_r15 ran_AreaCells_r15;
    {
	/* Adding component #2 */
	static unsigned char comp2_value[] = {
	    0x00, 0x00, 0x00, 0x00
	};
	OssBitString comp2(28, comp2_value);
	ran_AreaCells_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	static unsigned char comp1_value[] = {
	    0x00, 0x00, 0x00, 0x00
	};
	OssBitString comp1(28, comp1_value);
	ran_AreaCells_r15.prepend(comp1);
    }
    value.set_ran_AreaCells_r15(ran_AreaCells_r15);
}

HandoverPreparationInformation_v1530_IEs *create_samplevalue_HandoverPreparationInformation_v1530_IEs()
{
    /* Creating 'ran_NotificationAreaInfo_r15' field */
    RAN_NotificationAreaInfo_r15 ran_NotificationAreaInfo_r15;
    /* Setting 'cellList_r15' alternative of 'ran_NotificationAreaInfo_r15' field */
    PLMN_RAN_AreaCellList_r15 cellList_r15;
    {
	/* Adding component #2 */
	PLMN_RAN_AreaCell_r15 comp2;
	fill_PLMN_RAN_AreaCell_r15(comp2);
	cellList_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	PLMN_RAN_AreaCell_r15 comp1;
	fill_PLMN_RAN_AreaCell_r15(comp1);
	cellList_r15.prepend(comp1);
    }
    ran_NotificationAreaInfo_r15.set_cellList_r15(cellList_r15);

    /* Creating 'nonCriticalExtension' field */
    HandoverPreparationInformation_v1530_IEs::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    return new HandoverPreparationInformation_v1530_IEs(ran_NotificationAreaInfo_r15, nonCriticalExtension);
}

static void fill_decoded_1(UECapabilityInformation & value)
{
    value.set_rrc_TransactionIdentifier(0);
    /* Setting 'criticalExtensions' field */
    UECapabilityInformation::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    UECapabilityInformation::criticalExtensions::c1 c1;
    /* Setting 'ueCapabilityInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'ue_CapabilityRAT_ContainerList' field of 'ueCapabilityInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UE_CapabilityRAT_ContainerList ue_CapabilityRAT_ContainerList;
    {
	/* Adding component #2 */
	UE_CapabilityRAT_Container comp2;
	fill_UE_CapabilityRAT_Container(comp2);
	ue_CapabilityRAT_ContainerList.prepend(comp2);
    }
    {
	/* Adding component #1 */
	UE_CapabilityRAT_Container comp1;
	fill_UE_CapabilityRAT_Container(comp1);
	ue_CapabilityRAT_ContainerList.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'ueCapabilityInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'ueCapabilityInformation_r8' alternative of 'c1' alternative... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueCapabilityInformation_r8' alternative of 'c1' alternative... */
    /* Creating 'ue_RadioPagingInfo_r12' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueCapabilityInformation_r8' alternative... */

    /* Calling a fully-initializing constructor */
    UE_RadioPagingInfo_r12 ue_RadioPagingInfo_r12(0, UE_RadioPagingInfo_r12_ue_CategoryDL_v1310_m1, ce_ModeA_r13_true, ce_ModeB_r13_true, UE_RadioPagingInfo_r12_wakeUpSignal_r15_true, wakeUpSignal_TDD_r15_true, UE_RadioPagingInfo_r12_wakeUpSignalMinGap_eDRX_r15_ms40, wakeUpSignalMinGap_eDRX_TDD_r15_ms40);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueCapabilityInformation_r8' alternative... */
    UECapabilityInformation_v1250_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UECapabilityInformation_v1250_IEs nonCriticalExtension_nonCriticalExtension(ue_RadioPagingInfo_r12, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UECapabilityInformation_v8a0_IEs nonCriticalExtension(lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UECapabilityInformation_r8_IEs ueCapabilityInformation_r8(ue_CapabilityRAT_ContainerList, nonCriticalExtension);

    c1.set_ueCapabilityInformation_r8(ueCapabilityInformation_r8);

    criticalExtensions.set_c1(c1);

    value.set_criticalExtensions(criticalExtensions);
}

static void fill_MeasResultServCellSCG_r12(MeasResultServCellSCG_r12 & value)
{
    value.set_servCellId_r12(0);
    /* Setting 'measResultSCell_r12' field */

    /* Calling a fully-initializing constructor */
    MeasResultServCellSCG_r12::measResultSCell_r12 measResultSCell_r12(0, 0);

    value.set_measResultSCell_r12(measResultSCell_r12);

    value.set_servCellId_r13(0);
    /* Setting 'measResultSCell_v1310' field */

    /* Calling a fully-initializing constructor */
    MeasResultServCellSCG_r12::measResultSCell_v1310 measResultSCell_v1310(0);

    value.set_measResultSCell_v1310(measResultSCell_v1310);
}

static void fill_DRB_InfoSCG_r12(DRB_InfoSCG_r12 & value)
{
    value.set_eps_BearerIdentity_r12(0);
    value.set_drb_Identity_r12(1);
    value.set_drb_Type_r12(split);
}

static void fill_Cell_ToAddMod_r12(Cell_ToAddMod_r12 & value)
{
    value.set_sCellIndex_r12(1);
    /* Setting 'cellIdentification_r12' field */

    /* Calling a fully-initializing constructor */
    Cell_ToAddMod_r12::cellIdentification_r12 cellIdentification_r12(0, 0);

    value.set_cellIdentification_r12(cellIdentification_r12);

    /* Setting 'measResultCellToAdd_r12' field */

    /* Calling a fully-initializing constructor */
    Cell_ToAddMod_r12::measResultCellToAdd_r12 measResultCellToAdd_r12(0, 0);

    value.set_measResultCellToAdd_r12(measResultCellToAdd_r12);

    value.set_sCellIndex_r13(1);
    /* Setting 'measResultCellToAdd_v1310' field */

    /* Calling a fully-initializing constructor */
    Cell_ToAddMod_r12::measResultCellToAdd_v1310 measResultCellToAdd_v1310(0);

    value.set_measResultCellToAdd_v1310(measResultCellToAdd_v1310);
}

static void fill_MeasResultRSSI_SCG_r13(MeasResultRSSI_SCG_r13 & value)
{
    value.set_servCellId_r13(0);
    /* Setting 'measResultForRSSI_r13' field */

    /* Calling a fully-initializing constructor */
    MeasResultForRSSI_r13 measResultForRSSI_r13(0, 0);

    value.set_measResultForRSSI_r13(measResultForRSSI_r13);
}

SCG_ConfigInfo_r12 *create_samplevalue_SCG_ConfigInfo_r12()
{
    /* Creating 'criticalExtensions' field */
    SCG_ConfigInfo_r12::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    SCG_ConfigInfo_r12::criticalExtensions::c1 c1;
    /* Setting 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'radioResourceConfigDedMCG_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    RadioResourceConfigDedicated radioResourceConfigDedMCG_r12;
    fill_RadioResourceConfigDedicated(radioResourceConfigDedMCG_r12);

    /* Creating 'sCellToAddModListMCG_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    SCellToAddModList_r10 sCellToAddModListMCG_r12;
    fill_SCellToAddModList_r10(sCellToAddModListMCG_r12);

    /* Creating 'measGapConfig_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    MeasGapConfig measGapConfig_r12;
    fill_MeasGapConfig(measGapConfig_r12);

    /* Creating 'powerCoordinationInfo_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */

    /* Calling a fully-initializing constructor */
    PowerCoordinationInfo_r12 powerCoordinationInfo_r12(1, 1, 1);

    /* Creating 'scg_RadioConfig_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    SCG_ConfigPartSCG_r12 scg_RadioConfig_r12;
    fill_SCG_ConfigPartSCG_r12(scg_RadioConfig_r12);

    /* Creating 'eutra_CapabilityInfo_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    SCG_ConfigInfo_r12_IEs::eutra_CapabilityInfo_r12 eutra_CapabilityInfo_r12;
    UECapabilityInformation decoded;
    fill_decoded_1(decoded);
    eutra_CapabilityInfo_r12.set_decoded(decoded);

    /* Creating 'scg_ConfigRestrictInfo_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */

    /* Calling a fully-initializing constructor */
    SCG_ConfigRestrictInfo_r12 scg_ConfigRestrictInfo_r12(1, 1);

    /* Creating 'mbmsInterestIndication_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    SCG_ConfigInfo_r12_IEs::mbmsInterestIndication_r12 mbmsInterestIndication_r12;
    MBMSInterestIndication_r11 mbmsInterestIndication_r12_decoded;
    fill_decoded_2(mbmsInterestIndication_r12_decoded);
    mbmsInterestIndication_r12.set_decoded(mbmsInterestIndication_r12_decoded);

    /* Creating 'measResultServCellListSCG_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    MeasResultServCellListSCG_r12 measResultServCellListSCG_r12;
    {
	/* Adding component #2 */
	MeasResultServCellSCG_r12 comp2;
	fill_MeasResultServCellSCG_r12(comp2);
	measResultServCellListSCG_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultServCellSCG_r12 comp1;
	fill_MeasResultServCellSCG_r12(comp1);
	measResultServCellListSCG_r12.prepend(comp1);
    }

    /* Creating 'drb_ToAddModListSCG_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    DRB_InfoListSCG_r12 drb_ToAddModListSCG_r12;
    {
	/* Adding component #2 */
	DRB_InfoSCG_r12 comp2;
	fill_DRB_InfoSCG_r12(comp2);
	drb_ToAddModListSCG_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DRB_InfoSCG_r12 comp1;
	fill_DRB_InfoSCG_r12(comp1);
	drb_ToAddModListSCG_r12.prepend(comp1);
    }

    /* Creating 'drb_ToReleaseListSCG_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    DRB_ToReleaseList drb_ToReleaseListSCG_r12;
    fill_DRB_ToReleaseList(drb_ToReleaseListSCG_r12);

    /* Creating 'sCellToAddModListSCG_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    SCellToAddModListSCG_r12 sCellToAddModListSCG_r12;
    {
	/* Adding component #2 */
	Cell_ToAddMod_r12 comp2;
	fill_Cell_ToAddMod_r12(comp2);
	sCellToAddModListSCG_r12.prepend(comp2);
    }
    {
	/* Adding component #1 */
	Cell_ToAddMod_r12 comp1;
	fill_Cell_ToAddMod_r12(comp1);
	sCellToAddModListSCG_r12.prepend(comp1);
    }

    /* Creating 'sCellToReleaseListSCG_r12' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    SCellToReleaseList_r10 sCellToReleaseListSCG_r12;
    sCellToReleaseListSCG_r12.prepend(1);
    sCellToReleaseListSCG_r12.prepend(1);

    /* Creating 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'measResultSSTD_r13' field of 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative... */

    /* Calling a fully-initializing constructor */
    MeasResultSSTD_r13 measResultSSTD_r13(0, 4, 0);

    /* Creating 'sCellToAddModListMCG_Ext_r13' field of 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative... */
    SCellToAddModListExt_r13 sCellToAddModListMCG_Ext_r13;
    fill_SCellToAddModListExt_r13(sCellToAddModListMCG_Ext_r13);

    /* Creating 'measResultServCellListSCG_Ext_r13' field of 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative... */
    MeasResultServCellListSCG_Ext_r13 measResultServCellListSCG_Ext_r13;
    {
	/* Adding component #2 */
	MeasResultServCellSCG_r12 comp2;
	fill_MeasResultServCellSCG_r12(comp2);
	measResultServCellListSCG_Ext_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultServCellSCG_r12 comp1;
	fill_MeasResultServCellSCG_r12(comp1);
	measResultServCellListSCG_Ext_r13.prepend(comp1);
    }

    /* Creating 'sCellToAddModListSCG_Ext_r13' field of 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative... */
    SCellToAddModListSCG_Ext_r13 sCellToAddModListSCG_Ext_r13;
    {
	/* Adding component #2 */
	Cell_ToAddMod_r12 comp2;
	fill_Cell_ToAddMod_r12(comp2);
	sCellToAddModListSCG_Ext_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	Cell_ToAddMod_r12 comp1;
	fill_Cell_ToAddMod_r12(comp1);
	sCellToAddModListSCG_Ext_r13.prepend(comp1);
    }

    /* Creating 'sCellToReleaseListSCG_Ext_r13' field of 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative... */
    SCellToReleaseListExt_r13 sCellToReleaseListSCG_Ext_r13;
    fill_SCellToReleaseListExt_r13(sCellToReleaseListSCG_Ext_r13);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative of 'c1' alternative... */
    /* Creating 'measResultListRSSI_SCG_r13' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative... */
    MeasResultListRSSI_SCG_r13 measResultListRSSI_SCG_r13;
    {
	/* Adding component #2 */
	MeasResultRSSI_SCG_r13 comp2;
	fill_MeasResultRSSI_SCG_r13(comp2);
	measResultListRSSI_SCG_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	MeasResultRSSI_SCG_r13 comp1;
	fill_MeasResultRSSI_SCG_r13(comp1);
	measResultListRSSI_SCG_r13.prepend(comp1);
    }

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'scg_ConfigInfo_r12' alternative... */
    /* Creating 'measGapConfigPerCC_List' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    MeasGapConfigPerCC_List_r14 measGapConfigPerCC_List;
    fill_MeasGapConfigPerCC_List_r14(measGapConfigPerCC_List);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'drb_ToAddModListSCG_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    DRB_InfoListSCG_r15 drb_ToAddModListSCG_r15;
    {
	/* Adding component #2 */
	DRB_InfoSCG_r12 comp2;
	fill_DRB_InfoSCG_r12(comp2);
	drb_ToAddModListSCG_r15.prepend(comp2);
    }
    {
	/* Adding component #1 */
	DRB_InfoSCG_r12 comp1;
	fill_DRB_InfoSCG_r12(comp1);
	drb_ToAddModListSCG_r15.prepend(comp1);
    }

    /* Creating 'drb_ToReleaseListSCG_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    DRB_ToReleaseList_r15 drb_ToReleaseListSCG_r15;
    fill_DRB_ToReleaseList_r15(drb_ToReleaseListSCG_r15);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    SCG_ConfigInfo_v1530_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    SCG_ConfigInfo_v1530_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(drb_ToAddModListSCG_r15, drb_ToReleaseListSCG_r15, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SCG_ConfigInfo_v1430_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(makeBeforeBreakSCG_Req_r14_true, measGapConfigPerCC_List, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SCG_ConfigInfo_v1330_IEs nonCriticalExtension_nonCriticalExtension(measResultListRSSI_SCG_r13, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SCG_ConfigInfo_v1310_IEs nonCriticalExtension(measResultSSTD_r13, sCellToAddModListMCG_Ext_r13, measResultServCellListSCG_Ext_r13, sCellToAddModListSCG_Ext_r13, sCellToReleaseListSCG_Ext_r13, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    SCG_ConfigInfo_r12_IEs scg_ConfigInfo_r12(radioResourceConfigDedMCG_r12, sCellToAddModListMCG_r12, measGapConfig_r12, powerCoordinationInfo_r12, scg_RadioConfig_r12, eutra_CapabilityInfo_r12, scg_ConfigRestrictInfo_r12, mbmsInterestIndication_r12, measResultServCellListSCG_r12, drb_ToAddModListSCG_r12, drb_ToReleaseListSCG_r12, sCellToAddModListSCG_r12, sCellToReleaseListSCG_r12, -30, nonCriticalExtension);

    c1.set_scg_ConfigInfo_r12(scg_ConfigInfo_r12);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new SCG_ConfigInfo_r12(criticalExtensions);
}

UEPagingCoverageInformation *create_samplevalue_UEPagingCoverageInformation()
{
    /* Creating 'criticalExtensions' field */
    UEPagingCoverageInformation::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    UEPagingCoverageInformation::criticalExtensions::c1 c1;
    /* Setting 'uePagingCoverageInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'nonCriticalExtension' field of 'uePagingCoverageInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UEPagingCoverageInformation_r13_IEs::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UEPagingCoverageInformation_r13_IEs uePagingCoverageInformation_r13(1, nonCriticalExtension);

    c1.set_uePagingCoverageInformation_r13(uePagingCoverageInformation_r13);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UEPagingCoverageInformation(criticalExtensions);
}

UERadioAccessCapabilityInformation *create_samplevalue_UERadioAccessCapabilityInformation()
{
    /* Creating 'criticalExtensions' field */
    UERadioAccessCapabilityInformation::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    UERadioAccessCapabilityInformation::criticalExtensions::c1 c1;
    /* Setting 'ueRadioAccessCapabilityInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'ue_RadioAccessCapabilityInfo' field of 'ueRadioAccessCapabilityInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UERadioAccessCapabilityInformation_r8_IEs::ue_RadioAccessCapabilityInfo ue_RadioAccessCapabilityInfo;
    UECapabilityInformation decoded;
    fill_decoded_1(decoded);
    ue_RadioAccessCapabilityInfo.set_decoded(decoded);

    /* Creating 'nonCriticalExtension' field of 'ueRadioAccessCapabilityInformation_r8' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UERadioAccessCapabilityInformation_r8_IEs::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UERadioAccessCapabilityInformation_r8_IEs ueRadioAccessCapabilityInformation_r8(ue_RadioAccessCapabilityInfo, nonCriticalExtension);

    c1.set_ueRadioAccessCapabilityInformation_r8(ueRadioAccessCapabilityInformation_r8);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UERadioAccessCapabilityInformation(criticalExtensions);
}

UERadioPagingInformation *create_samplevalue_UERadioPagingInformation()
{
    /* Creating 'criticalExtensions' field */
    UERadioPagingInformation::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    UERadioPagingInformation::criticalExtensions::c1 c1;
    /* Setting 'ueRadioPagingInformation_r12' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'ue_RadioPagingInfo_r12' field of 'ueRadioPagingInformation_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UERadioPagingInformation_r12_IEs::ue_RadioPagingInfo_r12 ue_RadioPagingInfo_r12;

    /* Calling a fully-initializing constructor */
    UE_RadioPagingInfo_r12 decoded(0, UE_RadioPagingInfo_r12_ue_CategoryDL_v1310_m1, ce_ModeA_r13_true, ce_ModeB_r13_true, UE_RadioPagingInfo_r12_wakeUpSignal_r15_true, wakeUpSignal_TDD_r15_true, UE_RadioPagingInfo_r12_wakeUpSignalMinGap_eDRX_r15_ms40, wakeUpSignalMinGap_eDRX_TDD_r15_ms40);

    ue_RadioPagingInfo_r12.set_decoded(decoded);

    /* Creating 'nonCriticalExtension' field of 'ueRadioPagingInformation_r12' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'supportedBandListEUTRAForPaging_r13' field of 'nonCriticalExtension' field of 'ueRadioPagingInformation_r12' alternative of 'c1' alternative... */
    UERadioPagingInformation_v1310_IEs::supportedBandListEUTRAForPaging_r13 supportedBandListEUTRAForPaging_r13;
    supportedBandListEUTRAForPaging_r13.prepend(1);
    supportedBandListEUTRAForPaging_r13.prepend(1);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueRadioPagingInformation_r12' alternative of 'c1' alternative... */
    UERadioPagingInformation_v1310_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UERadioPagingInformation_v1310_IEs nonCriticalExtension(supportedBandListEUTRAForPaging_r13, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UERadioPagingInformation_r12_IEs ueRadioPagingInformation_r12(ue_RadioPagingInfo_r12, nonCriticalExtension);

    c1.set_ueRadioPagingInformation_r12(ueRadioPagingInformation_r12);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UERadioPagingInformation(criticalExtensions);
}

static void fill_SupportedBand_NB_r13(SupportedBand_NB_r13 & value)
{
    value.set_band_r13(1);
    value.set_powerClassNB_20dBm_r13(powerClassNB_20dBm_r13_supported);
}

static void fill_decoded(UE_Capability_NB_Ext_r14_IEs & value)
{
    value.set_ue_Category_NB_r14(ue_Category_NB_r14_nb2);
    /* Setting 'mac_Parameters_r14' field */

    /* Calling a fully-initializing constructor */
    MAC_Parameters_NB_r14 mac_Parameters_r14(MAC_Parameters_NB_r14_dataInactMon_r14_supported, MAC_Parameters_NB_r14_rai_Support_r14_supported);

    value.set_mac_Parameters_r14(mac_Parameters_r14);

    /* Setting 'phyLayerParameters_v1430' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_v1430 phyLayerParameters_v1430(multiCarrier_NPRACH_r14_supported, twoHARQ_Processes_r14_supported);

    value.set_phyLayerParameters_v1430(phyLayerParameters_v1430);

    /* Setting 'rf_Parameters_v1430' field */

    /* Calling a fully-initializing constructor */
    RF_Parameters_NB_v1430 rf_Parameters_v1430(powerClassNB_14dBm_r14_supported);

    value.set_rf_Parameters_v1430(rf_Parameters_v1430);

    /* Setting 'nonCriticalExtension' field */
    /* Creating 'phyLayerParameters_v1440' field of 'nonCriticalExtension' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_v1440 phyLayerParameters_v1440(interferenceRandomisation_r14_supported);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field */
    /* Creating 'rlc_Parameters_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    RLC_Parameters_NB_r15 rlc_Parameters_r15(rlc_UM_r15_supported);

    /* Creating 'mac_Parameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    MAC_Parameters_NB_v1530 mac_Parameters_v1530(sr_SPS_BSR_r15_supported);

    /* Creating 'phyLayerParameters_v1530' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_v1530 phyLayerParameters_v1530(PhyLayerParameters_NB_v1530_mixedOperationMode_r15_supported, sr_WithHARQ_ACK_r15_supported, sr_WithoutHARQ_ACK_r15_supported, nprach_Format2_r15_supported, additionalTransmissionSIB1_r15_supported, npusch_3dot75kHz_SCS_TDD_r15_supported);

    /* Creating 'tdd_UE_Capability_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    /* Creating 'phyLayerParametersRel13_r15' field of 'tdd_UE_Capability_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_r13 phyLayerParametersRel13_r15(multiTone_r13_supported, multiCarrier_r13_supported);

    /* Creating 'phyLayerParametersRel14_r15' field of 'tdd_UE_Capability_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_v1430 phyLayerParametersRel14_r15(multiCarrier_NPRACH_r14_supported, twoHARQ_Processes_r14_supported);

    /* Creating 'phyLayerParameters_v1530' field of 'tdd_UE_Capability_r15' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_v1530 tdd_UE_Capability_r15_phyLayerParameters_v1530(PhyLayerParameters_NB_v1530_mixedOperationMode_r15_supported, sr_WithHARQ_ACK_r15_supported, sr_WithoutHARQ_ACK_r15_supported, nprach_Format2_r15_supported, additionalTransmissionSIB1_r15_supported, npusch_3dot75kHz_SCS_TDD_r15_supported);

    /* Calling a fully-initializing constructor */
    TDD_UE_Capability_NB_r15 tdd_UE_Capability_r15(ue_Category_NB_r15_nb2, phyLayerParametersRel13_r15, phyLayerParametersRel14_r15, tdd_UE_Capability_r15_phyLayerParameters_v1530);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field... */
    UE_Capability_NB_v1530_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UE_Capability_NB_v1530_IEs nonCriticalExtension_nonCriticalExtension_nonCriticalExtension(UE_Capability_NB_v1530_IEs_earlyData_UP_r15_supported, rlc_Parameters_r15, mac_Parameters_v1530, phyLayerParameters_v1530, tdd_UE_Capability_r15, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_Capability_NB_v14x0_IEs nonCriticalExtension_nonCriticalExtension(lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UE_Capability_NB_v1440_IEs nonCriticalExtension(phyLayerParameters_v1440, nonCriticalExtension_nonCriticalExtension);

    value.set_nonCriticalExtension(nonCriticalExtension);
}

HandoverPreparationInformation_NB *create_samplevalue_HandoverPreparationInformation_NB()
{
    /* Creating 'criticalExtensions' field */
    HandoverPreparationInformation_NB::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    HandoverPreparationInformation_NB::criticalExtensions::c1 c1;
    /* Setting 'handoverPreparationInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'ue_RadioAccessCapabilityInfo_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'pdcp_Parameters_r13' field of 'ue_RadioAccessCapabilityInfo_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    /* Creating 'supportedROHC_Profiles_r13' field of 'pdcp_Parameters_r13' field of 'ue_RadioAccessCapabilityInfo_r13' field of 'handoverPreparationInformation_r13' alternative... */

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_NB_r13::supportedROHC_Profiles_r13 supportedROHC_Profiles_r13(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_NB_r13 pdcp_Parameters_r13(supportedROHC_Profiles_r13, maxNumberROHC_ContextSessions_r13_cs2);

    /* Creating 'phyLayerParameters_r13' field of 'ue_RadioAccessCapabilityInfo_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_r13 phyLayerParameters_r13(multiTone_r13_supported, multiCarrier_r13_supported);

    /* Creating 'rf_Parameters_r13' field of 'ue_RadioAccessCapabilityInfo_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    /* Creating 'supportedBandList_r13' field of 'rf_Parameters_r13' field of 'ue_RadioAccessCapabilityInfo_r13' field of 'handoverPreparationInformation_r13' alternative... */
    SupportedBandList_NB_r13 supportedBandList_r13;
    {
	/* Adding component #2 */
	SupportedBand_NB_r13 comp2;
	fill_SupportedBand_NB_r13(comp2);
	supportedBandList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBand_NB_r13 comp1;
	fill_SupportedBand_NB_r13(comp1);
	supportedBandList_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_NB_r13 rf_Parameters_r13(supportedBandList_r13, multiNS_Pmax_r13_supported);

    /* Creating 'dummy' field of 'ue_RadioAccessCapabilityInfo_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    UE_Capability_NB_r13::dummy dummy;

    /* Calling a fully-initializing constructor */
    UE_Capability_NB_r13 ue_RadioAccessCapabilityInfo_r13(AccessStratumRelease_NB_r13_rel13, UE_Capability_NB_r13_ue_Category_NB_r13_nb1, multipleDRB_r13_supported, pdcp_Parameters_r13, phyLayerParameters_r13, rf_Parameters_r13, dummy);

    /* Creating 'as_Config_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'sourceRadioResourceConfig_r13' field of 'as_Config_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    RadioResourceConfigDedicated_NB_r13 sourceRadioResourceConfig_r13;
    fill_RadioResourceConfigDedicated_NB_r13(sourceRadioResourceConfig_r13);

    /* Creating 'sourceSecurityAlgorithmConfig_r13' field of 'as_Config_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    SecurityAlgorithmConfig sourceSecurityAlgorithmConfig_r13;
    fill_SecurityAlgorithmConfig(sourceSecurityAlgorithmConfig_r13);

    /* Creating 'sourceUE_Identity_r13' field of 'as_Config_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    static unsigned char sourceUE_Identity_r13_value[] = {
	0x00, 0x00
    };
    OssBitString sourceUE_Identity_r13(16, sourceUE_Identity_r13_value);

    /* Creating 'sourceDl_CarrierFreq_r13' field of 'as_Config_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    CarrierFreq_NB_r13 sourceDl_CarrierFreq_r13;
    fill_CarrierFreq_NB_r13(sourceDl_CarrierFreq_r13);

    /* Calling a fully-initializing constructor */
    AS_Config_NB as_Config_r13(sourceRadioResourceConfig_r13, sourceSecurityAlgorithmConfig_r13, sourceUE_Identity_r13, sourceDl_CarrierFreq_r13);

    /* Creating 'rrm_Config_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */

    /* Calling a fully-initializing constructor */
    RRM_Config_NB rrm_Config_r13(RRM_Config_NB_ue_InactiveTime_s1);

    /* Creating 'as_Context_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'reestablishmentInfo_r13' field of 'as_Context_r13' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    /* Creating 'targetCellShortMAC_I_r13' field of 'reestablishmentInfo_r13' field of 'as_Context_r13' field of 'handoverPreparationInformation_r13' alternative... */
    static unsigned char targetCellShortMAC_I_r13_value[] = {
	0x00, 0x00
    };
    OssBitString targetCellShortMAC_I_r13(16, targetCellShortMAC_I_r13_value);

    /* Creating 'additionalReestabInfoList_r13' field of 'reestablishmentInfo_r13' field of 'as_Context_r13' field of 'handoverPreparationInformation_r13' alternative... */
    AdditionalReestabInfoList additionalReestabInfoList_r13;
    fill_AdditionalReestabInfoList(additionalReestabInfoList_r13);

    /* Calling a fully-initializing constructor */
    ReestablishmentInfo_NB reestablishmentInfo_r13(0, targetCellShortMAC_I_r13, additionalReestabInfoList_r13);

    /* Calling a fully-initializing constructor */
    AS_Context_NB as_Context_r13(reestablishmentInfo_r13);

    /* Creating 'nonCriticalExtension' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'handoverPreparationInformation_r13' alternative of 'c1' alternative... */
    /* Creating 'ue_RadioAccessCapabilityInfoExt_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'handoverPreparationInformation_r13' alternative... */
    HandoverPreparationInformation_NB_Ext_r14_IEs::ue_RadioAccessCapabilityInfoExt_r14 ue_RadioAccessCapabilityInfoExt_r14;
    UE_Capability_NB_Ext_r14_IEs decoded;
    fill_decoded(decoded);
    ue_RadioAccessCapabilityInfoExt_r14.set_decoded(decoded);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'handoverPreparationInformation_r13' alternative... */
    HandoverPreparationInformation_NB_Ext_r14_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_NB_Ext_r14_IEs nonCriticalExtension_nonCriticalExtension(ue_RadioAccessCapabilityInfoExt_r14, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_NB_v1380_IEs nonCriticalExtension(lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    HandoverPreparationInformation_NB_IEs handoverPreparationInformation_r13(ue_RadioAccessCapabilityInfo_r13, as_Config_r13, rrm_Config_r13, as_Context_r13, nonCriticalExtension);

    c1.set_handoverPreparationInformation_r13(handoverPreparationInformation_r13);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new HandoverPreparationInformation_NB(criticalExtensions);
}

UEPagingCoverageInformation_NB *create_samplevalue_UEPagingCoverageInformation_NB()
{
    /* Creating 'criticalExtensions' field */
    UEPagingCoverageInformation_NB::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    UEPagingCoverageInformation_NB::criticalExtensions::c1 c1;
    /* Setting 'uePagingCoverageInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'nonCriticalExtension' field of 'uePagingCoverageInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UEPagingCoverageInformation_NB_IEs::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UEPagingCoverageInformation_NB_IEs uePagingCoverageInformation_r13(1, nonCriticalExtension);

    c1.set_uePagingCoverageInformation_r13(uePagingCoverageInformation_r13);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UEPagingCoverageInformation_NB(criticalExtensions);
}

UERadioAccessCapabilityInformation_NB *create_samplevalue_UERadioAccessCapabilityInformation_NB()
{
    /* Creating 'criticalExtensions' field */
    UERadioAccessCapabilityInformation_NB::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    UERadioAccessCapabilityInformation_NB::criticalExtensions::c1 c1;
    /* Setting 'ueRadioAccessCapabilityInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'ue_RadioAccessCapabilityInfo_r13' field of 'ueRadioAccessCapabilityInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UERadioAccessCapabilityInformation_NB_IEs::ue_RadioAccessCapabilityInfo_r13 ue_RadioAccessCapabilityInfo_r13;
    /* Creating 'pdcp_Parameters_r13' field */
    /* Creating 'supportedROHC_Profiles_r13' field of 'pdcp_Parameters_r13' field */

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_NB_r13::supportedROHC_Profiles_r13 supportedROHC_Profiles_r13(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_NB_r13 pdcp_Parameters_r13(supportedROHC_Profiles_r13, maxNumberROHC_ContextSessions_r13_cs2);

    /* Creating 'phyLayerParameters_r13' field */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_r13 phyLayerParameters_r13(multiTone_r13_supported, multiCarrier_r13_supported);

    /* Creating 'rf_Parameters_r13' field */
    /* Creating 'supportedBandList_r13' field of 'rf_Parameters_r13' field */
    SupportedBandList_NB_r13 supportedBandList_r13;
    {
	/* Adding component #2 */
	SupportedBand_NB_r13 comp2;
	fill_SupportedBand_NB_r13(comp2);
	supportedBandList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBand_NB_r13 comp1;
	fill_SupportedBand_NB_r13(comp1);
	supportedBandList_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_NB_r13 rf_Parameters_r13(supportedBandList_r13, multiNS_Pmax_r13_supported);

    /* Creating 'dummy' field */
    UE_Capability_NB_r13::dummy dummy;

    /* Calling a fully-initializing constructor */
    UE_Capability_NB_r13 decoded(AccessStratumRelease_NB_r13_rel13, UE_Capability_NB_r13_ue_Category_NB_r13_nb1, multipleDRB_r13_supported, pdcp_Parameters_r13, phyLayerParameters_r13, rf_Parameters_r13, dummy);

    ue_RadioAccessCapabilityInfo_r13.set_decoded(decoded);

    /* Creating 'nonCriticalExtension' field of 'ueRadioAccessCapabilityInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    /* Creating 'lateNonCriticalExtension' field of 'nonCriticalExtension' field of 'ueRadioAccessCapabilityInformation_r13' alternative of 'c1' alternative... */
    static unsigned char lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString lateNonCriticalExtension(sizeof(lateNonCriticalExtension_value), (char *)lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueRadioAccessCapabilityInformation_r13' alternative of 'c1' alternative... */
    /* Creating 'ue_RadioAccessCapabilityInfo_r14' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueRadioAccessCapabilityInformation_r13' alternative... */
    UERadioAccessCapabilityInformation_NB_r14_IEs::ue_RadioAccessCapabilityInfo_r14 ue_RadioAccessCapabilityInfo_r14;
    /* Creating 'criticalExtensions' field */
    UECapabilityInformation_NB::criticalExtensions decoded_criticalExtensions;
    /* Setting 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field */
    /* Creating 'ue_Capability_r13' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field */
    /* Creating 'pdcp_Parameters_r13' field of 'ue_Capability_r13' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field... */
    /* Creating 'supportedROHC_Profiles_r13' field of 'pdcp_Parameters_r13' field of 'ue_Capability_r13' field of 'ueCapabilityInformation_r13' alternative... */

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_NB_r13::supportedROHC_Profiles_r13 pdcp_Parameters_r13_supportedROHC_Profiles_r13(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

    /* Calling a fully-initializing constructor */
    PDCP_Parameters_NB_r13 ue_Capability_r13_pdcp_Parameters_r13(pdcp_Parameters_r13_supportedROHC_Profiles_r13, maxNumberROHC_ContextSessions_r13_cs2);

    /* Creating 'phyLayerParameters_r13' field of 'ue_Capability_r13' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field... */

    /* Calling a fully-initializing constructor */
    PhyLayerParameters_NB_r13 ue_Capability_r13_phyLayerParameters_r13(multiTone_r13_supported, multiCarrier_r13_supported);

    /* Creating 'rf_Parameters_r13' field of 'ue_Capability_r13' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field... */
    /* Creating 'supportedBandList_r13' field of 'rf_Parameters_r13' field of 'ue_Capability_r13' field of 'ueCapabilityInformation_r13' alternative... */
    SupportedBandList_NB_r13 rf_Parameters_r13_supportedBandList_r13;
    {
	/* Adding component #2 */
	SupportedBand_NB_r13 comp2;
	fill_SupportedBand_NB_r13(comp2);
	rf_Parameters_r13_supportedBandList_r13.prepend(comp2);
    }
    {
	/* Adding component #1 */
	SupportedBand_NB_r13 comp1;
	fill_SupportedBand_NB_r13(comp1);
	rf_Parameters_r13_supportedBandList_r13.prepend(comp1);
    }

    /* Calling a fully-initializing constructor */
    RF_Parameters_NB_r13 ue_Capability_r13_rf_Parameters_r13(rf_Parameters_r13_supportedBandList_r13, multiNS_Pmax_r13_supported);

    /* Creating 'dummy' field of 'ue_Capability_r13' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field... */
    UE_Capability_NB_r13::dummy ue_Capability_r13_dummy;

    /* Calling a fully-initializing constructor */
    UE_Capability_NB_r13 ue_Capability_r13(AccessStratumRelease_NB_r13_rel13, UE_Capability_NB_r13_ue_Category_NB_r13_nb1, multipleDRB_r13_supported, ue_Capability_r13_pdcp_Parameters_r13, ue_Capability_r13_phyLayerParameters_r13, ue_Capability_r13_rf_Parameters_r13, ue_Capability_r13_dummy);

    /* Creating 'ue_RadioPagingInfo_r13' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field */

    /* Calling a fully-initializing constructor */
    UE_RadioPagingInfo_NB_r13 ue_RadioPagingInfo_r13(UE_RadioPagingInfo_NB_r13_ue_Category_NB_r13_nb1, multiCarrierPaging_r14_true, UE_RadioPagingInfo_NB_r13_mixedOperationMode_r15_supported, UE_RadioPagingInfo_NB_r13_wakeUpSignal_r15_true, UE_RadioPagingInfo_NB_r13_wakeUpSignalMinGap_eDRX_r15_ms40, multiCarrierPagingTDD_r15_true);

    /* Creating 'lateNonCriticalExtension' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field */
    static unsigned char ueCapabilityInformation_r13_lateNonCriticalExtension_value[] = {
	0x00
    };
    OssString ueCapabilityInformation_r13_lateNonCriticalExtension(sizeof(ueCapabilityInformation_r13_lateNonCriticalExtension_value), (char *)ueCapabilityInformation_r13_lateNonCriticalExtension_value);

    /* Creating 'nonCriticalExtension' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field */
    /* Creating 'ue_Capability_ContainerExt_r14' field of 'nonCriticalExtension' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field... */
    UECapabilityInformation_NB_Ext_r14_IEs::ue_Capability_ContainerExt_r14 ue_Capability_ContainerExt_r14;
    UE_Capability_NB_Ext_r14_IEs ue_Capability_ContainerExt_r14_decoded;
    fill_decoded(ue_Capability_ContainerExt_r14_decoded);
    ue_Capability_ContainerExt_r14.set_decoded(ue_Capability_ContainerExt_r14_decoded);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueCapabilityInformation_r13' alternative of 'criticalExtensions' field... */
    UECapabilityInformation_NB_Ext_r14_IEs::nonCriticalExtension ueCapabilityInformation_r13_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UECapabilityInformation_NB_Ext_r14_IEs ueCapabilityInformation_r13_nonCriticalExtension(ue_Capability_ContainerExt_r14, ueCapabilityInformation_r13_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UECapabilityInformation_NB_r13_IEs ueCapabilityInformation_r13(ue_Capability_r13, ue_RadioPagingInfo_r13, ueCapabilityInformation_r13_lateNonCriticalExtension, ueCapabilityInformation_r13_nonCriticalExtension);

    decoded_criticalExtensions.set_ueCapabilityInformation_r13(ueCapabilityInformation_r13);

    /* Calling a fully-initializing constructor */
    UECapabilityInformation_NB ue_RadioAccessCapabilityInfo_r14_decoded(0, decoded_criticalExtensions);

    ue_RadioAccessCapabilityInfo_r14.set_decoded(ue_RadioAccessCapabilityInfo_r14_decoded);

    /* Creating 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'nonCriticalExtension' field of 'ueRadioAccessCapabilityInformation_r13' alternative... */
    UERadioAccessCapabilityInformation_NB_r14_IEs::nonCriticalExtension nonCriticalExtension_nonCriticalExtension_nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UERadioAccessCapabilityInformation_NB_r14_IEs nonCriticalExtension_nonCriticalExtension(ue_RadioAccessCapabilityInfo_r14, nonCriticalExtension_nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UERadioAccessCapabilityInformation_NB_v1380_IEs nonCriticalExtension(lateNonCriticalExtension, nonCriticalExtension_nonCriticalExtension);

    /* Calling a fully-initializing constructor */
    UERadioAccessCapabilityInformation_NB_IEs ueRadioAccessCapabilityInformation_r13(ue_RadioAccessCapabilityInfo_r13, nonCriticalExtension);

    c1.set_ueRadioAccessCapabilityInformation_r13(ueRadioAccessCapabilityInformation_r13);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UERadioAccessCapabilityInformation_NB(criticalExtensions);
}

UERadioPagingInformation_NB *create_samplevalue_UERadioPagingInformation_NB()
{
    /* Creating 'criticalExtensions' field */
    UERadioPagingInformation_NB::criticalExtensions criticalExtensions;
    /* Setting 'c1' alternative of 'criticalExtensions' field */
    UERadioPagingInformation_NB::criticalExtensions::c1 c1;
    /* Setting 'ueRadioPagingInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field */
    /* Creating 'ue_RadioPagingInfo_r13' field of 'ueRadioPagingInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UERadioPagingInformation_NB_IEs::ue_RadioPagingInfo_r13 ue_RadioPagingInfo_r13;

    /* Calling a fully-initializing constructor */
    UE_RadioPagingInfo_NB_r13 decoded(UE_RadioPagingInfo_NB_r13_ue_Category_NB_r13_nb1, multiCarrierPaging_r14_true, UE_RadioPagingInfo_NB_r13_mixedOperationMode_r15_supported, UE_RadioPagingInfo_NB_r13_wakeUpSignal_r15_true, UE_RadioPagingInfo_NB_r13_wakeUpSignalMinGap_eDRX_r15_ms40, multiCarrierPagingTDD_r15_true);

    ue_RadioPagingInfo_r13.set_decoded(decoded);

    /* Creating 'nonCriticalExtension' field of 'ueRadioPagingInformation_r13' alternative of 'c1' alternative of 'criticalExtensions' field... */
    UERadioPagingInformation_NB_IEs::nonCriticalExtension nonCriticalExtension;

    /* Calling a fully-initializing constructor */
    UERadioPagingInformation_NB_IEs ueRadioPagingInformation_r13(ue_RadioPagingInfo_r13, nonCriticalExtension);

    c1.set_ueRadioPagingInformation_r13(ueRadioPagingInformation_r13);

    criticalExtensions.set_c1(c1);

    /* Calling a fully-initializing constructor */
    return new UERadioPagingInformation_NB(criticalExtensions);
}
